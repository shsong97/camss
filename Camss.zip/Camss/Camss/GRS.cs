﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Data.Odbc;
using System.Configuration;
using System.Windows.Forms;

public class GRS
{
    int tableCount = 0;
    int rowCount = 0;
    int colCount = 0;
    int rowIndex = 0;
    int tableIndex = 0;
    DataRow dr = null;
    DataSet ds = null;

    // Property 설정
    public int ColCount
    {
        get { return colCount; }
        set { colCount = value; }
    }
    public int RowCount
    {
        get { return rowCount; }
    }

    public GRS()
    {
    }
    public GRS(string querystring)
    {
        Query(querystring);
    }
    public GRS(string querystring, bool execute, SqlParameter[] sqlparam = null, CommandType comtype = CommandType.Text)
    {
        Execute(querystring, execute, sqlparam, comtype);
    }
    public void Query(string querystring)
    {
        if (querystring == "")
            return;
        SetDataset(DBManager.Query(querystring));
    }
    public int Execute(string querystring, bool execute, SqlParameter[] sqlparam = null, CommandType comtype = CommandType.Text)
    {
        if (querystring == "")
            return -1;
        return DBManager.Execute(querystring, sqlparam, comtype);
    }

    public DataSet GetDS()
    {
        return ds;
    }
    public GRS(DataRow data)
    {
        // Datarow의 필드 값을 setting
        dr = data;
        colCount = data.ItemArray.Length;
    }
    public GRS(DataSet data)
    {
        SetDataset(data);
    }
    public void SetDataset(DataSet data)
    {
        //DataSet 단위로 설정
        if (data == null)
            return;

        if (data.Tables.Count == 0)
            return;

        this.tableCount = data.Tables.Count;
        this.ds = data;

        if (data.Tables[0].Rows.Count > 0)
        {
            this.rowCount = data.Tables[0].Rows.Count;
            colCount = data.Tables[0].Rows[0].ItemArray.Length;
            this.dr = data.Tables[0].Rows[0];
        }
    }
    public bool NextResults()
    {
        if (this.tableCount == 0)
            return false;

        if (this.tableCount <= this.tableIndex)
            return false;

        this.tableIndex++;
        return true;
    }
    public bool PrevResults()
    {
        if (this.tableCount == 0)
            return false;

        if (this.tableIndex <= 0)
            return false;

        tableIndex--;

        return true;
    }
    public bool MoveNext()
    {
        rowIndex++;
        if (rowIndex < rowCount)
        {
            dr = ds.Tables[tableIndex].Rows[rowIndex];
            return true;
        }
        return false;
    }
    public string gRS(string param)
    {
        // Datarow의 필드 값을 string으로 return
        return dr[param].ToString();
    }
    public string gRS(int columnIndex)
    {
        // Datarow의 필드 값을 string으로 return
        return dr[columnIndex].ToString();
    }
    public int gRSInt(string param)
    {
        // Datarow의 필드 값을 int로 return
        return int.Parse(dr[param].ToString());
    }
    public int gRSInt(int columnIndex)
    {
        // Datarow의 필드 값을 int로 return
        return int.Parse(dr[columnIndex].ToString());
    }
    public double gRSDouble(string param)
    {
        // Datarow의 필드 값을 double로 return
        return double.Parse(dr[param].ToString());
    }
    public double gRSDouble(int columnIndex)
    {
        // Datarow의 필드 값을 double로 return
        return double.Parse(dr[columnIndex].ToString());
    }
    public Object gRSvar(string param)
    {
        // var type은 데이터 받는쪽에서 형변환해야함.
        var data = dr[param];
        return data;
    }
    public Object gRSvar(int columnIndex)
    {
        // var type은 데이터 받는쪽에서 형변환해야함.
        var data = dr[columnIndex];
        return data;
    }
}

