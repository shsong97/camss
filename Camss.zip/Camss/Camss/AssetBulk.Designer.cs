﻿namespace Camss
{
    partial class AssetBulk
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnFileUpload = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textFolderName = new System.Windows.Forms.TextBox();
            this.folderSearch = new System.Windows.Forms.Button();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnExecute = new System.Windows.Forms.Button();
            this.txtError = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 39);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(786, 269);
            this.dataGridView1.TabIndex = 1;
            // 
            // btnFileUpload
            // 
            this.btnFileUpload.Location = new System.Drawing.Point(386, 9);
            this.btnFileUpload.Name = "btnFileUpload";
            this.btnFileUpload.Size = new System.Drawing.Size(91, 24);
            this.btnFileUpload.TabIndex = 8;
            this.btnFileUpload.Text = "파일업로드";
            this.btnFileUpload.UseVisualStyleBackColor = true;
            this.btnFileUpload.Click += new System.EventHandler(this.btnFileUpload_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "폴더명";
            // 
            // textFolderName
            // 
            this.textFolderName.Location = new System.Drawing.Point(58, 12);
            this.textFolderName.Name = "textFolderName";
            this.textFolderName.Size = new System.Drawing.Size(230, 21);
            this.textFolderName.TabIndex = 6;
            // 
            // folderSearch
            // 
            this.folderSearch.Location = new System.Drawing.Point(294, 9);
            this.folderSearch.Name = "folderSearch";
            this.folderSearch.Size = new System.Drawing.Size(86, 24);
            this.folderSearch.TabIndex = 5;
            this.folderSearch.Text = "파일찾기";
            this.folderSearch.UseVisualStyleBackColor = true;
            this.folderSearch.Click += new System.EventHandler(this.folderSearch_Click);
            // 
            // txtResult
            // 
            this.txtResult.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtResult.Location = new System.Drawing.Point(0, 341);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(810, 92);
            this.txtResult.TabIndex = 9;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // btnExecute
            // 
            this.btnExecute.Location = new System.Drawing.Point(521, 9);
            this.btnExecute.Name = "btnExecute";
            this.btnExecute.Size = new System.Drawing.Size(106, 24);
            this.btnExecute.TabIndex = 10;
            this.btnExecute.Text = "자산반영";
            this.btnExecute.UseVisualStyleBackColor = true;
            this.btnExecute.Click += new System.EventHandler(this.btnExecute_Click);
            // 
            // txtError
            // 
            this.txtError.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtError.Location = new System.Drawing.Point(0, 320);
            this.txtError.Name = "txtError";
            this.txtError.Size = new System.Drawing.Size(810, 21);
            this.txtError.TabIndex = 11;
            // 
            // AssetBulk
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(810, 433);
            this.Controls.Add(this.txtError);
            this.Controls.Add(this.btnExecute);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.btnFileUpload);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textFolderName);
            this.Controls.Add(this.folderSearch);
            this.Controls.Add(this.dataGridView1);
            this.Name = "AssetBulk";
            this.Text = "AssetBulk";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnFileUpload;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textFolderName;
        private System.Windows.Forms.Button folderSearch;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnExecute;
        private System.Windows.Forms.TextBox txtError;
    }
}