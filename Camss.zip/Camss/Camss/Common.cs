﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Camss
{
    class Common
    {
        public string ConType = "SqlConnection";
        public string DbName = "ASSET";
        public string ID = "sa";

        public string TestServerName = "zkrcwf01";
        public string TestPassword = "otcns99";

        public string ServerName = "zkrbda03";
        public string password = "otcns99";
    }
}
