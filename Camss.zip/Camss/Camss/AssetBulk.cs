﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Camss
{
    public partial class AssetBulk : Form
    {
        public AssetBulk()
        {
            InitializeComponent();
            Common c = new Common();
            DBManager.SetConnectionString(c.ConType, c.ServerName, c.DbName, c.ID, c.password);
            if (!DBManager.Open())
            {
                MessageBox.Show("시스템 접속 에러");
                return;
            }
        }

        private void folderSearch_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            textFolderName.Text = openFileDialog1.FileName;
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(DBManager.ConnString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_BULKINSERT_ASSET", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@UserID", "lgkhj");
                        cmd.Parameters.Add("@ResultStatement", SqlDbType.VarChar, 8000);
                        cmd.Parameters["@ResultStatement"].Direction = ParameterDirection.Output;
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                        txtResult.Text = cmd.Parameters["@ResultStatement"].Value.ToString();
                    }
                }

                //SqlParameter[] sqlparam = new SqlParameter[2];
                //for (int i = 0; i < sqlparam.Length; i++)
                //{
                //    sqlparam[i] = new SqlParameter();
                //}
                //sqlparam[0].ParameterName = "@UserID";
                //sqlparam[0].Value = "lgkhj";
                //sqlparam[0].SqlDbType = SqlDbType.VarChar;
                //sqlparam[0].Size = 20;
                //sqlparam[1].ParameterName = "@ResultStatement";
                //sqlparam[0].SqlDbType = SqlDbType.VarChar;
                //sqlparam[1].Size = 8000;
                //sqlparam[1].Direction = ParameterDirection.Output;
                //GRS grs = new GRS("USP_BULKINSERT_ASSET", true, sqlparam, CommandType.StoredProcedure);
                //txtResult.Text = (string)sqlparam[1].Value;
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
                return;
            }
            
            MessageBox.Show("처리완료되었습니다.");
        }

        private void btnFileUpload_Click(object sender, EventArgs e)
        {
            string[] lines = System.IO.File.ReadAllLines(textFolderName.Text, Encoding.Default);

            string query = "delete from TB_ASSET_BULK";
            GRS grs = new GRS(query);
            string error_str = "";
            for (int index = 0; index < lines.Length; index++)
            {
                //lblCurrent.Text = index.ToString();
                string sdata = lines[index];
                string[] array = sdata.Split(',');
                
                if (array.Length < 3)
                    continue;
                
                query = "insert into TB_ASSET_BULK ";
                query += " select ";
                for (int i = 0; i < 45; i++)
                {
                    string param = array[i];
                    param = param.Replace("'", "");
                    if (param.Length > 1)
                    {
                        if (param.Substring(0, 1) == "\"")
                            param = param.Substring(1);
                        if (param.Substring(param.Length - 1, 1) == "\"")
                            param = param.Substring(0, param.Length - 1);
                    }
                    query += "'" + param + "',";
                }
                query += "''"; // email
                try
                {
                    grs = new GRS(query);
                }
                catch (Exception error)
                {
                    error_str += array[0] + ";";
                }
            }
            txtError.Text = error_str;

            grs = new GRS("select * from TB_ASSET_BULK order by assetno");
            DataSet ds = grs.GetDS();
            DataTable dt = ds.Tables[0];
            dataGridView1.DataSource = dt;
            dataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader);

        }
    }
}
