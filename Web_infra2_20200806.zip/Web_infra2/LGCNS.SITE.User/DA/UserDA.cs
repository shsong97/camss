using System;
using System.EnterpriseServices;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;

using LGCNS.LAF.DA;
using LGCNS.LAF.Common.Exceptions;
using LGCNS.LAF.Common.DataAccess;
using LGCNS.LAF.Common.Paging ;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.User.DA
{
	/// <summary>
	/// UserDA Ŭ����
	/// </summary>
	public class UserDA : LGCNS.LAF.DA.DABase
	{
		private const string PROJECT_NAME	= "LGCNS.SITE.User" ;
		private const string CLASS_NAME		= "LGCNS.SITE.User.DA.UserDA" ;

		public UserDA()	{}

		[AutoComplete(true)]
		public void InsertUser (UserDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertUser") ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_USER[0]) ;
		}


		[AutoComplete(true)]
		public void UpdateUser (UserDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateUser") ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_USER[0]) ;
		}


		[AutoComplete(true)]
		public void DeleteUser (string userID)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["UserID"]	= userID ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteUser") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}


		/// <summary>
		/// ����� ����� ��ȸ�Ѵ�.
		/// </summary>
		/// <param name="currentPage">��ȸ�� ������</param>
		/// <param name="pageSize">������ ũ��</param>
		/// <param name="order">���� Order,  ex)"UserID ASC"</param>
		/// <param name="userName">�˻�����:������̸�</param>
		/// <returns>����� ���</returns>
		[AutoComplete(true)]
		public UserDS SelectUserList (int currentPage, int pageSize, string order, string Area, string userName, string Authority)
		{
			if(order==null || order=="") 
				order = "UserName ASC" ; // ���ļ����� �������� ������� ������̸� ������ ����

			UserDS ds = new UserDS () ;

			// LPresparedStatement�� ������ ������
			LDataCollection dc = new LDataCollection () ;
			dc["[ORDER]"]	= order ; //ORDER BY ���� ������ ���� SQL �Ķ���ͷ� �����Ҽ� ���� ���� ���ȣ([,])�� �̿��Ͽ� ó�� (�������� [XXX]�κ��� ġȯ�ȴ�.)
			dc["Area"]	= Area ;
			dc["UserName"]	= userName ;
			dc["Authority"]	= Authority ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectUserList") ;
			ADOHelper.FillDataSet (ps, ds, "TB_USER", currentPage, pageSize, dc) ;

			if( pageSize > 0 )
			{
				int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;

				PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;
			}

			return ds ;
		}


		[AutoComplete(true)]
		public UserDS SelectUser(string userID)
		{
			UserDS ds = new UserDS () ;

			LDataCollection dc = new LDataCollection () ;
			dc["UserID"]	= userID ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectUser") ;
			ADOHelper.FillDataSet (ps, ds, new string []{"TB_USER"}, dc) ;

			return ds ;
		}

		[AutoComplete(true)]
		public UserDS SelectCapexUser(string userID)
		{
			UserDS ds = new UserDS () ;

			LDataCollection dc = new LDataCollection () ;
			dc["UserID"]	= userID ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectCapexUser") ;
			ADOHelper.FillDataSet (ps, ds, new string []{"TB_CAPEX_USER"}, dc) ;

			return ds ;
		}
	}
}