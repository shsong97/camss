using System;
using System.EnterpriseServices;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.User.DA;
using LGCNS.SITE.BBS.Biz;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.User.Biz
{
	public class UserBizNTx : LGCNS.LAF.Biz.BizNTxBase
	{
		public UserBizNTx() {}

		/// <summary>
		/// ����� ����� ����¡ó���ؼ� ��ȸ�Ѵ�.
		/// </summary>
		/// <param name="currentPage">��ȸ��������</param>
		/// <param name="pageSize">������ũ��</param>
		/// <param name="order">Order By���� ������ �� ���ļ��� ex) UserName ASC</param>
		/// <param name="userName">�˻����̸�</param>
		/// <returns></returns>
		[AutoComplete(true)]
		public UserDS SelectUserList (int currentPage, int pageSize, string order, string Area, string userName, string Authority)
		{
			UserDS ds = null;
			UserDA da = null;
			
			try
			{
				da = new UserDA();
				ds = da.SelectUserList(currentPage, pageSize, order, Area, userName, Authority);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;		
		}


		/// <summary>
		/// ����������� ����ڰ� ����� �Խù� ����� �����´�.
		/// </summary>
		/// <param name="userID"></param>
		/// <returns></returns>
		[AutoComplete(true)]
		public UserDS SelectUser(string userID)
		{
			UserDS ds = null;
			UserDA da = null;

			BBSBizNTx bbsBiz = null ;
			
			try
			{
				da = new UserDA();
				bbsBiz = new BBSBizNTx () ;

				ds = da.SelectUser(userID);
				ds.Merge (bbsBiz.SelectBBSList (userID)) ;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}

				if(bbsBiz != null)
				{
					bbsBiz.Dispose();
					bbsBiz = null;
				}
			}

			return ds ;
		}

		/// <summary>
		/// ����������� ����ڰ� ����� �Խù� ����� �����´�.
		/// </summary>
		/// <param name="userID"></param>
		/// <returns></returns>
		[AutoComplete(true)]
		public UserDS SelectCapexUser(string userID)
		{
			UserDS ds = null;
			UserDA da = null;
			
			try
			{
				da = new UserDA();
				ds = da.SelectCapexUser(userID);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}

		/// <summary>
		/// ������� ��ȣ�� ��ȸ�Ѵ�.
		/// </summary>
		/// <param name="userID"></param>
		/// <returns></returns>
		[AutoComplete(true)]
		public string SelectUserPassword (string userID)
		{
			string userPassword = null ;

			UserDA da = null;
			
			try
			{
				da = new UserDA();
				
				UserDS ds = da.SelectUser(userID);
				userPassword = ds.TB_USER [0].UserPassword ;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null ;
				}
			}

			return userPassword ;
		}
	}
}
