using System;
using System.Collections;
using System.EnterpriseServices;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.User.DA;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.User.Biz
{
	public class UserBizTx : LGCNS.LAF.Biz.BizTxBase
	{
		public UserBizTx() {}

		[AutoComplete(true)]
		public void InsertUser (UserDS ds)
		{
			UserDA da = null;
			
			try
			{
				da = new UserDA();
				da.InsertUser(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void UpdateUser (UserDS ds)
		{
			UserDA da = null;
			
			try
			{
				da = new UserDA();
				da.UpdateUser(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void DeleteUser (string userID)
		{
			UserDA da = null;
			
			try
			{
				da = new UserDA();
				da.DeleteUser (userID) ;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}
	}
}