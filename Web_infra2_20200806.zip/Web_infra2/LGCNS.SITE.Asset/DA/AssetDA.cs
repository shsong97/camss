using System;
using System.Collections.Specialized;
using System.EnterpriseServices;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;

using LGCNS.LAF.DA;
using LGCNS.LAF.Common.Exceptions;
using LGCNS.LAF.Common.DataAccess;
using LGCNS.LAF.Common.Paging ;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.Asset.DA
{
	/// <summary>
	/// AssetDA�� ���� ��� �����Դϴ�.
	/// </summary>
	public class AssetDA : LGCNS.LAF.DA.DABase
	{
		private const string PROJECT_NAME	= "LGCNS.SITE.Asset" ;
		private const string CLASS_NAME		= "LGCNS.SITE.Asset.DA.AssetDA" ;

		public AssetDA() {}

		#region SelectAsset

		[AutoComplete(true)]
		public AssetDS SelectAsset( string AssetNo )
		{
			AssetDS ds = new AssetDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["AssetNo"]	= AssetNo ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectAsset") ;
			ADOHelper.FillDataSet (ps, ds, new string[] {"TB_ASSET", "TB_ASSET_LOG"}, dc) ;

			return ds;
		}

		[AutoComplete(true)]
		public AssetDS SelectAssetList ( NameValueCollection searchCondition )
		{
			return SelectAssetList( 0, 0, "", searchCondition );
		}

		[AutoComplete(true)]
		public AssetDS SelectAssetList (int currentPage, int pageSize, string order, NameValueCollection searchCondition )
		{
			if(order==null || order=="") 
				order = "AssetNo" ; // ���ļ����� �������� �������

			AssetDS ds = new AssetDS();
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["[ORDER]"]	 = order ;
			dc["Area"]	 = searchCondition["Area"];
			dc["AssetNo"]	 = searchCondition["AssetNo"];
			dc["EmpNo"]      = searchCondition["EmpNo"];
			dc["EmpName"]    = searchCondition["EmpName"];
			dc["DeptCode"]   = searchCondition["DeptCode"];
			dc["SiteCode"]   = searchCondition["SiteCode"];
			dc["CreateDateFrom"] = searchCondition["CreateDateFrom"];
			dc["CreateDateTo"] = searchCondition["CreateDateTo"];
			dc["SerialNo"] = searchCondition["SerialNo"];
			dc["Status"] = searchCondition["Status"];
			dc["CPUType"] = searchCondition["CPUType"];
			dc["ModelNo"] = searchCondition["ModelNo"];
			dc["NodeName"] = searchCondition["NodeName"];

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectAssetList", ds.TB_ASSET) ;
			ADOHelper.FillDataSet (ps, ds, "TB_ASSET", currentPage, pageSize, dc) ;

			if( pageSize > 0 )
			{
				int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;
				PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;
			}

			return ds ;
		}

		public AssetDS SelectAssetListForXls( NameValueCollection searchCondition )
		{
			AssetDS ds = new AssetDS () ;

			LDataCollection dc = new LDataCollection () ;
			dc["Area"]	 = searchCondition["Area"];
			dc["AssetNo"]	 = searchCondition["AssetNo"];
			dc["EmpNo"]      = searchCondition["EmpNo"];
			dc["EmpName"]    = searchCondition["EmpName"];
			dc["DeptCode"]   = searchCondition["DeptCode"];
			dc["SiteCode"]   = searchCondition["SiteCode"];
			dc["CreateDateFrom"] = searchCondition["CreateDateFrom"];
			dc["CreateDateTo"]   = searchCondition["CreateDateTo"];
			dc["SerialNo"] = searchCondition["SerialNo"];
			dc["Status"] = searchCondition["Status"];
			dc["CPUType"] = searchCondition["CPUType"];
			dc["ModelNo"] = searchCondition["ModelNo"];
			dc["NodeName"] = searchCondition["NodeName"];

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectAssetListForXls" ) ;
			ADOHelper.FillDataSet (ps, ds, new string[] {"TB_ASSET_BULK"}, dc) ;

			return ds;
		}

		public AssetDS SelectAssetListForXls2( NameValueCollection searchCondition )
		{
			AssetDS ds = new AssetDS () ;

			LDataCollection dc = new LDataCollection () ;
			dc["Area"]	 = searchCondition["Area"];
			dc["AssetNo"]	 = searchCondition["AssetNo"];
			dc["EmpNo"]      = searchCondition["EmpNo"];
			dc["EmpName"]    = searchCondition["EmpName"];
			dc["DeptCode"]   = searchCondition["DeptCode"];
			dc["SiteCode"]   = searchCondition["SiteCode"];
			dc["CreateDateFrom"] = searchCondition["CreateDateFrom"];
			dc["CreateDateTo"]   = searchCondition["CreateDateTo"];
			dc["SerialNo"] = searchCondition["SerialNo"];
			dc["CPUType"] = searchCondition["CPUType"];
			dc["ModelNo"] = searchCondition["ModelNo"];
			dc["NodeName"] = searchCondition["NodeName"];

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectAssetListForXls2" ) ;
			ADOHelper.FillDataSet (ps, ds, new string[] {"TB_ASSET_LIST_IES"}, dc) ;

			return ds;
		}


		#endregion

		#region ManageAsset
		[AutoComplete(true)]
		public void InsertAsset (AssetDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertAsset", ds.TB_ASSET) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_ASSET[0]) ;
		}


		[AutoComplete(true)]
		public void UpdateAsset (AssetDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateAsset", ds.TB_ASSET) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_ASSET[0]) ;
		}


		[AutoComplete(true)]
		public void DeleteAsset (AssetDS ds)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["AssetNo"]	= ds.TB_ASSET[0].AssetNo;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteAsset", ds.TB_ASSET) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		#endregion
		

		#region AssetLog

		[AutoComplete(true)]
		public void InsertAssetLog (AssetDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertAssetLog", ds.TB_ASSET_LOG) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_ASSET_LOG[0]) ;
		}


		public void ChangeAssetNo( string OldAssetNo, string NewAssetNo )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["OldAssetNo"]	= OldAssetNo ;
			dc["NewAssetNo"]	= NewAssetNo ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "ChangeAssetNo" );
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		[AutoComplete(true)]
		public void UpdateAssetLog (AssetDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateAssetLog", ds.TB_ASSET_LOG) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_ASSET_LOG[0]) ;
		}


		[AutoComplete(true)]
		public AssetDS SelectAssetLog( string AssetNo, string Seq )
		{
			AssetDS ds = new AssetDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["AssetNo"]	= AssetNo ;
			dc["Seq"] = Seq ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectAssetLog", ds.TB_ASSET_LOG) ;
			ADOHelper.FillDataSet (ps, ds, new string[] {"TB_ASSET_LOG"}, dc) ;

			return ds;
		}

		public AssetDS SelectAssetLogList( string AssetNo, string EmpNo, string EmpName )
		{
			AssetDS ds = new AssetDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["AssetNo"]	= AssetNo ;
			dc["EmpNo"] = EmpNo ;
			dc["EmpName"] = EmpName ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectAssetLogList", ds.TB_ASSET_LOG) ;
			ADOHelper.FillDataSet (ps, ds, new string[] {"TB_ASSET_LOG"}, dc) ;

			return ds;
		}


		#endregion
		

		#region BulkImport

		[AutoComplete(true)]
		public void InsertAssetBulk(AssetDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertAssetBulk", ds.TB_ASSET_BULK ) ;
			foreach( AssetDS.TB_ASSET_BULKRow dr in ds.TB_ASSET_BULK.Rows )
			{
				try
				{
					ADOHelper.ExecuteNonQuery (ps, dr);
				}
				catch( Exception ex )
				{
					LGCNS.LAF.Common.Log.LogManager.Publish( ex, "AssetBulkImport", dr.AssetNo );
				}
			}
		}

		
		public string BulkInsertAsset( string UserID )
		{
			string ResultStatement = "";

			LDataCollection dc = new LDataCollection () ;
			dc["UserID"] = UserID;
			dc["ResultStatement"] = ResultStatement;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "BulkInsertAsset" ) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;

			ResultStatement = ps.DataParameters["@ResultStatement"].Value.ToString();

			return ResultStatement;
		}


		#endregion

		[AutoComplete(true)]
		public ICMSDS SelectICMS( string AssetNo )
		{
			ICMSDS ds = new ICMSDS () ;

			LDataCollection dc = new LDataCollection () ;
			dc["AssetNo"]	= AssetNo ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectICMS") ;
			ADOHelper.FillDataSet (ps, ds, new string[] {"TB_ICMS"}, dc) ;

			return ds;
		}

	}
}

