using System;
using System.Collections;
using System.EnterpriseServices;

using LGCNS.LAF.Common.Exceptions;
using LGCNS.LAF.Common.FileManagement;

using LGCNS.SITE.Asset.DA;
using LGCNS.SITE.DTO;

using System.IO;
using System.Text;

namespace LGCNS.SITE.Asset.Biz
{
	/// <summary>
	/// AssetBizTx�� ���� ��� �����Դϴ�.
	/// </summary>
	public class AssetBizTx : LGCNS.LAF.Biz.BizTxBase
	{
		public AssetBizTx() {}

		#region ManageAsset

		[AutoComplete(true)]
		public void InsertAsset(AssetDS ds)
		{
			AssetDA da = null;
			
			try
			{
				da = new AssetDA ();
				da.InsertAsset(ds);				
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		[AutoComplete(true)]
		public void UpdateAsset(AssetDS ds)
		{
			AssetDA da = null;
	
			try
			{
				da = new AssetDA();
				da.UpdateAsset(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		
		[AutoComplete(true)]
		public void DeleteAsset(AssetDS ds)
		{
			AssetDA da = null;
			
			try
			{
				da = new AssetDA();
				da.DeleteAsset( ds );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		#endregion

		[AutoComplete(true)]
		public void UpdateAssetLog(AssetDS ds)
		{
			AssetDA da = null;
	
			try
			{
				da = new AssetDA();
				da.UpdateAssetLog(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		public void ChangeAssetNo( string OldAssetNo, string NewAssetNo )
		{
			AssetDA da = null;
	
			try
			{
				da = new AssetDA();
				da.ChangeAssetNo(OldAssetNo,NewAssetNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		#region BulkImport

		public void FileSave( FileTransferObject fto )
		{
			try
			{
				FileManager.Save(fto);
				System.Threading.Thread.Sleep( 1000 );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
		}


		public void FileDelete( FileTransferObject fto )
		{
			try
			{
				FileManager.Delete( fto.FilePath );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
		}


		public AssetDS BulkImport( FileTransferObject fto )
		{
			AssetDS ds = null;

			try
			{
				string FileFullName = LGCNS.LAF.Common.FileManagement.Configuration.RealRootPath + fto.FilePath;

				ds = BindCSVFile( FileFullName );

				InsertAssetBulk( ds );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}

			return ds;
		}


		[AutoComplete(true)]
		public void InsertAssetBulk(AssetDS ds)
		{
			AssetDA da = null;
			
			try
			{
				da = new AssetDA ();
				da.InsertAssetBulk(ds);				
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		
		private AssetDS BindCSVFile( string FileName )
		{
			AssetDS ds = new AssetDS();
			ds.EnforceConstraints = false;
			AssetDS.TB_ASSET_BULKRow dr = null;

			try
			{
				char[] chIndex1 = {','};
				char[] chIndex2 = {'\"'};

				int cntCol;

				StreamReader sr = new StreamReader(FileName,Encoding.Default);

				sr.ReadLine();	//ù��°���� ����������� �ν���

				do
				{
					dr = ds.TB_ASSET_BULK.NewTB_ASSET_BULKRow();

					cntCol = 0;

					string strTextSource = sr.ReadLine();	//�����б�
					string strTextTemp = strTextSource;

					while( strTextTemp.Length > 0 )
					{
						string strTemp = "";

						if ( strTextTemp.IndexOfAny(chIndex1) == 0 )
						{
							strTextTemp = strTextTemp.Substring(1);
						}

						int strLen1 = strTextTemp.IndexOfAny(chIndex1);	//,�� ��ġ
						int strLen2 = strTextTemp.IndexOfAny(chIndex2); //"�� ��ġ

						if ( strLen1 < 0 )	//comma�� ������
						{
							strTemp = strTextTemp;
							strTextTemp = "";
						}
						else
						{
							if ((strLen2 == -1) || ( strLen2 > strLen1 ))
							{
								strTemp = strTextTemp.Substring(0, strLen1);
								strTextTemp = strTextTemp.Substring(strLen1);
							}
							else
							{
								strTextTemp = strTextTemp.Substring(1);

								int strLen3 = strTextTemp.IndexOfAny(chIndex2);
								int strLen4 = strTextTemp.Substring(strLen3+1).IndexOfAny(chIndex2);

								if ( strLen3< 0 )
								{
									strTemp = strTextTemp;
									strTextTemp = "";
								}
								else
								{
									if ( strLen4 == 0 )
									{
										int strLen5 = strTextTemp.Substring(strLen3+2).IndexOfAny(chIndex2);

										strTemp = strTextTemp.Substring(0, strLen5+strLen3+2);
										strTextTemp = strTextTemp.Substring(strLen5+strLen3+2 + 1);
									}
									else
									{
										strTemp = strTextTemp.Substring(0, strLen3);
										strTextTemp = strTextTemp.Substring(strLen3 + 1);
									}
								}
							}
						}

						dr[cntCol] = strTemp;

						cntCol = cntCol + 1;

						if ( cntCol == ds.TB_ASSET_BULK.Columns.Count )
						{
							break;
						}
					}
					
					if ( dr.AssetNo.ToString().CompareTo( "0" ) > 0 )
					{
						ds.TB_ASSET_BULK.AddTB_ASSET_BULKRow( dr );
					}

				} while(sr.Peek() != -1 );   //�������� �ɶ� ����    

				sr.Close();                 //streamReader�� �ݴ´�.

				return ds;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
		}


		public string BulkInsertAsset(string UserID)
		{
			AssetDA da = null;
			string ResultStatement = "";
			
			try
			{
				da = new AssetDA ();
				ResultStatement = da.BulkInsertAsset(UserID);				
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ResultStatement;
		}


		#endregion
	}
}
