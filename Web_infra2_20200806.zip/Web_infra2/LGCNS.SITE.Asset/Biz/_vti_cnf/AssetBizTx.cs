vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|24 Mar 2005 03:15:38 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|24 Mar 2005 03:15:38 -0000
vti_filesize:IR|6507
