using System;
using System.Collections.Specialized;
using System.EnterpriseServices;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.Asset.DA;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.Asset.Biz
{
	/// <summary>
	/// AssetBizNTx�� ���� ��� �����Դϴ�.
	/// </summary>
	public class AssetBizNTx : LGCNS.LAF.Biz.BizNTxBase
	{
		public AssetBizNTx() {}
		
		public AssetDS SelectAsset( string AssetNo )
		{
			AssetDS ds = null;
			AssetDA da = null;

			try
			{
				da = new AssetDA ();
				ds = da.SelectAsset(AssetNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}


		public AssetDS SelectAssetList( NameValueCollection searchCondition )
		{
			return SelectAssetList( 0, 0, "", searchCondition );
		}

		public AssetDS SelectAssetList( int currentPage, int pageSize, string order, NameValueCollection searchCondition )
		{
			AssetDS ds = null;
			AssetDA da = null;

			try
			{
				da = new AssetDA ();
				ds = da.SelectAssetList(currentPage,pageSize,order,searchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public AssetDS SelectAssetListForXls( NameValueCollection searchCondition )
		{
			AssetDS ds = null;
			AssetDA da = null;

			try
			{
				da = new AssetDA ();
				ds = da.SelectAssetListForXls(searchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public AssetDS SelectAssetListForXls2( NameValueCollection searchCondition )
		{
			AssetDS ds = null;
			AssetDA da = null;

			try
			{
				da = new AssetDA ();
				ds = da.SelectAssetListForXls2(searchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}


		public AssetDS SelectAssetLog( string AssetNo, string Seq )
		{
			AssetDS ds = null;
			AssetDA da = null;

			try
			{
				da = new AssetDA ();
				ds = da.SelectAssetLog(AssetNo,Seq);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public AssetDS SelectAssetLogList( string AssetNo, string EmpNo, string EmpName )
		{
			AssetDS ds = null;
			AssetDA da = null;

			try
			{
				da = new AssetDA ();
				ds = da.SelectAssetLogList(AssetNo,EmpNo,EmpName);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public ICMSDS SelectICMS( string AssetNo )
		{
			ICMSDS ds = null;
			AssetDA da = null;

			try
			{
				da = new AssetDA ();
				ds = da.SelectICMS(AssetNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

	}
}
