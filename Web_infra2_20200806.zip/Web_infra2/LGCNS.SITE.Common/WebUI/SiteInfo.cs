using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using LGCNS.LAF.Web;

using LGCNS.SITE.DTO;
using LGCNS.SITE.Code.Biz;

namespace LGCNS.SITE.Common.WebUI
{
	/// <summary>
	/// SiteInfo�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SiteInfo
	{
		public SiteInfo()
		{
			//
			// ���⿡ ������ ������ �߰��մϴ�.
			//
		}
		public static CodeDS SelectSiteList( string Area, string SiteCode, string SiteDesc, string BuildingCode )
		{
			CodeDS ds = null;
			CodeBizNTx biz = null;
		
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectSiteList( Area, SiteCode, SiteDesc, BuildingCode );			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}
		
		public static CodeDS SelectSiteListForICMS( string Area )
		{
			CodeDS ds = null;
			CodeBizNTx biz = null;
	
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectSiteListForICMS( Area );			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}

		public static void BindDropDownList( DropDownList ddnl, string Area )
		{
			BindDropDownList( ddnl, Area, false, false );
		}

		public static void BindDropDownList( DropDownList ddnl, string Area, bool isSpace )
		{
			BindDropDownList( ddnl, Area, isSpace, false );
		}

		public static void BindDropDownList( DropDownList ddnl, string Area, bool isSpace, bool isICMS )
		{
			CodeDS ds = null;
			CodeBizNTx biz = null;
		
			try
			{
				biz = new CodeBizNTx();
				if( isICMS )
				{
					ds = biz.SelectSiteListForICMS( Area );
				}
				else
				{
					ds = biz.SelectSiteListForDDL( Area );
				}
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}
			
			if (isSpace)
			{
				ds.TB_SITE.AddTB_SITERow( "", "", "", "", "", "", "" );
			}

			ddnl.DataSource = ds.TB_SITE;
			ddnl.DataTextField = "SiteDesc";
			ddnl.DataValueField = "SiteCode";
			ddnl.DataBind();

			if ( isSpace )
			{
				ddnl.SelectedIndex = ddnl.Items.Count - 1;
			}

			if ( ds != null )
			{
				ds.Dispose();
				ds = null;
			}
		}
	}
}
