using System;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using LGCNS.LAF.Web;

using LGCNS.SITE.DTO;
using LGCNS.SITE.Code.Biz;

namespace LGCNS.SITE.Common.WebUI
{
	/// <summary>
	/// AreaInfo�� ���� ��� �����Դϴ�.
	/// </summary>
	public class AreaInfo
	{
		public AreaInfo() {}

		public static void BindDropDownList( DropDownList ddnl )
		{
			BindDropDownList( ddnl, false );
		}
		public static void BindDropDownList( DropDownList ddnl, string args )
		{
			BindDropDownList( ddnl, false, args );
		}

		public static void BindDropDownList( DropDownList ddnl, bool isSpace, string args )
		{
			AreaDS ds = null;
			CodeBizNTx biz = null;

			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectAreaList(args);

				if (isSpace)
				{
					ds.TB_AREA.AddTB_AREARow( "", "", "", "", "", "" );
				}
			
				ddnl.DataSource = ds.TB_AREA;
				ddnl.DataTextField = "Area";
				ddnl.DataValueField = "Area";
				ddnl.DataBind();

				if ( isSpace )
				{
					ddnl.SelectedIndex = ddnl.Items.Count - 1;
				}

				SITEPageBase page = new SITEPageBase();
				string UserArea = page.CurrentUserArea;
				page.Dispose();
				page = null;

				if ( UserArea.Length > 0 && UserArea != "All" )
				{
					ddnl.SelectedValue = UserArea;
					ddnl.Enabled = false;
				}
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}

				
				if ( ds != null )
				{
					ds.Dispose();
					ds = null;
				}
			}
		}

		public static void BindDropDownList( DropDownList ddnl, bool isSpace )
		{
			BindDropDownList(ddnl,isSpace,"");
		}
	}
}
