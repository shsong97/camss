vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|21 Mar 2005 03:07:14 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|21 Mar 2005 03:07:14 -0000
vti_filesize:IR|2890
