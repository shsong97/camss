using System;

using LGCNS.SITE.DTO;
using LGCNS.SITE.Emp.Biz;


namespace LGCNS.SITE.Common.WebUI
{
	/// <summary>
	/// EmpInfo�� ���� ��� �����Դϴ�.
	/// </summary>
	public class EmpInfo
	{
		public EmpInfo()
		{
			//
			// ���⿡ ������ ������ �߰��մϴ�.
			//
		}

		public static string getEmpName( string Area, string EmpNo )
		{
			string EmpName = "";
			EmpDS ds = null;
			EmpBizNTx biz = null;
			
			try
			{
				biz = new EmpBizNTx();
				ds = biz.SelectEmp(Area, EmpNo);

				if ( ds.TB_EMP.Count == 1 )
				{
					EmpName = ds.TB_EMP[0].EmpName;
				}
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(ds != null)
				{
					ds.Dispose();
					ds = null;
				}

				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return EmpName;
		}
	}
}
