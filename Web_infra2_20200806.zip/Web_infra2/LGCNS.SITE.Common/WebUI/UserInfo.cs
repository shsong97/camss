using System;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using LGCNS.LAF.Web;

using LGCNS.SITE.DTO;
using LGCNS.SITE.User.Biz;

namespace LGCNS.SITE.Common.WebUI
{
	/// <summary>
	/// UserInfo�� ���� ��� �����Դϴ�.
	/// </summary>
	public class UserInfo
	{
		public UserInfo()
		{
			//
			// ���⿡ ������ ������ �߰��մϴ�.
			//
		}

		public static string getUserName( string UserID )
		{
			UserDS ds = null;
			UserBizNTx biz = null;
			
			try
			{
				biz = new UserBizNTx();
				ds = biz.SelectUser( UserID );
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
            if (ds.TB_USER.Rows.Count==1)
			    return ds.TB_USER[0].UserName;
            else 
                return UserID;
		}

		public static void BindDropDownList( DropDownList ddnl )
		{
			BindDropDownList( ddnl, "", false );
		}

		public static void BindDropDownList( DropDownList ddnl, bool isSpace )
		{
			BindDropDownList( ddnl, "", isSpace );
		}

		public static void BindDropDownList( DropDownList ddnl, string Area )
		{
			BindDropDownList( ddnl, Area, false );
		}

		public static void BindDropDownList( DropDownList ddnl, string Area, bool isSpace )
		{
			UserDS ds = null;
			UserBizNTx biz = null;
			
			try
			{
				biz = new UserBizNTx();
				ds = biz.SelectUserList(0, 0, null, Area, "","");
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			if (isSpace)
			{
				ds.TB_USER.AddTB_USERRow( "", "", "", "", "", "", "", "", "" );
			}

			ddnl.DataSource = ds.TB_USER;
			ddnl.DataTextField = "UserName";
			ddnl.DataValueField = "UserID";
			ddnl.DataBind();

			if ( isSpace )
			{
				ddnl.SelectedIndex = ddnl.Items.Count - 1;
			}

			if ( ds != null )
			{
				ds.Dispose();
				ds = null;
			}
		}
	}
}
