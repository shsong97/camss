using System;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using LGCNS.LAF.Web;

using LGCNS.SITE.DTO;
using LGCNS.SITE.Code.Biz;

namespace LGCNS.SITE.Common.WebUI
{
	/// <summary>
	/// CodeInfo�� ���� ��� �����Դϴ�.
	/// </summary>
	public class CodeInfo
	{
		public CodeInfo()
		{
			//
			// ���⿡ ������ ������ �߰��մϴ�.
			//
		}

		public static string getCodeDesc ( string ClassID, string Code )
		{
			string CodeDesc = "";
			CodeDS ds = null;
			CodeBizNTx biz = null;
		
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectCode( ClassID, Code );			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			if ( ds.TB_CODE.Count == 1 )
			{
				CodeDesc = ds.TB_CODE[0].CodeDesc;
			}

			if ( ds != null )
			{
				ds.Dispose();
				ds = null;
			}
			
			return CodeDesc;
		}

		public static void BindDropDownList( DropDownList ddnl, string CodeClass )
		{
			BindDropDownList( ddnl, CodeClass, false );
		}

		public static void BindDropDownList( DropDownList ddnl, string CodeClass, bool isSpace)
		{
			BindDropDownList( ddnl, CodeClass, isSpace, "" );
		}
		public static void BindDropDownList( DropDownList ddnl, string CodeClass, bool isSpace, string Args )
		{
			CodeDS ds = null;
			CodeBizNTx biz = null;
		
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectCodeList( CodeClass, Args );			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			if (isSpace)
			{
				ds.TB_CODE.AddTB_CODERow( CodeClass, "", "" );
			}

			ddnl.DataSource = ds.TB_CODE;
			ddnl.DataTextField = "CodeDesc";
			ddnl.DataValueField = "Code";
			ddnl.DataBind();

			if ( isSpace )
			{
				ddnl.SelectedIndex = ddnl.Items.Count - 1;
			}

			if ( ds != null )
			{
				ds.Dispose();
				ds = null;
			}
		}
	}
}
