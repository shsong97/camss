using System;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using LGCNS.LAF.Web;

using LGCNS.SITE.DTO;
using LGCNS.SITE.CAPEX.Biz;
using LGCNS.SITE.Code.Biz;

namespace LGCNS.SITE.Common.WebUI
{
	/// <summary>
	/// CapexInfo�� ���� ��� �����Դϴ�.
	/// </summary>
	public class CapexInfo
	{
		public CapexInfo() 	{}

		#region QUOTATION_NO 
		public static void BindDropDownList( DropDownList ddnl )
		{
			BindDropDownList( ddnl, false );
		}
		public static void BindDropDownList( DropDownList ddnl, string args )
		{
			BindDropDownList( ddnl, false, args );
		}

		public static void BindDropDownList( DropDownList ddnl, bool isSpace, string args )
		{
			CapexDS ds = null;
			CapexBizNTx biz = null;

			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectQuotationNo(args);

				if (isSpace)
				{
					ds.TB_QUOTATION_NO.AddTB_QUOTATION_NORow( "" );
				}
			
				ddnl.DataSource = ds.TB_QUOTATION_NO;
				ddnl.DataTextField = "QuotaNo";
				ddnl.DataValueField = "QuotaNo";
				ddnl.DataBind();

				if ( isSpace )
				{
					ddnl.SelectedIndex = ddnl.Items.Count - 1;
				}

			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}

				
				if ( ds != null )
				{
					ds.Dispose();
					ds = null;
				}
			}
		}

		public static void BindDropDownList( DropDownList ddnl, bool isSpace )
		{
			BindDropDownList(ddnl,isSpace,"");
		}

		#endregion

		#region Category 
		public static void BindDropDownListCategory( DropDownList ddnl )
		{
			BindDropDownListCategory( ddnl, false );
		}
		public static void BindDropDownListCategory( DropDownList ddnl, string args )
		{
			BindDropDownListCategory( ddnl, false, args );
		}

		public static void BindDropDownListCategory( DropDownList ddnl, bool isSpace, string args )
		{
			CapexDS ds = null;
			CapexBizNTx biz = null;

			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectCategory(args);

				if (isSpace)
				{
					ds.TB_BASE.AddTB_BASERow( "","" );
				}
			
				ddnl.DataSource = ds.TB_BASE;
				ddnl.DataTextField = "col1";
				ddnl.DataValueField = "col1";
				ddnl.DataBind();

				if ( isSpace )
				{
					ddnl.SelectedIndex = ddnl.Items.Count - 1;
				}

			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}

				
				if ( ds != null )
				{
					ds.Dispose();
					ds = null;
				}
			}
		}

		public static void BindDropDownListCategory( DropDownList ddnl, bool isSpace )
		{
			BindDropDownListCategory(ddnl,isSpace,"");
		}

		#endregion

		#region WBSE 
		public static void BindDropDownListWBSE( DropDownList ddnl )
		{
			BindDropDownListWBSE( ddnl, false );
		}
		public static void BindDropDownListWBSE( DropDownList ddnl, string args )
		{
			BindDropDownListWBSE( ddnl, false, args );
		}

		public static void BindDropDownListWBSE( DropDownList ddnl, bool isSpace, string args )
		{
			CapexDS ds = null;
			CapexBizNTx biz = null;

			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectWBSE(args);

				if (isSpace)
				{
					ds.TB_BASE.AddTB_BASERow( "","" );
				}
			
				ddnl.DataSource = ds.TB_BASE;
				ddnl.DataTextField = "col2";
				ddnl.DataValueField = "col2";
				ddnl.DataBind();

				if ( isSpace )
				{
					ddnl.SelectedIndex = ddnl.Items.Count - 1;
				}

			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}

				
				if ( ds != null )
				{
					ds.Dispose();
					ds = null;
				}
			}
		}

		public static void BindDropDownListWBSE( DropDownList ddnl, bool isSpace )
		{
			BindDropDownListWBSE(ddnl,isSpace,"");
		}

		#endregion

		#region Gubun 
		public static void BindDropDownListGubun( DropDownList ddnl )
		{
			BindDropDownListGubun( ddnl, false );
		}
		public static void BindDropDownListGubun( DropDownList ddnl, string args )
		{
			BindDropDownListGubun( ddnl, false, args );
		}

		public static void BindDropDownListGubun( DropDownList ddnl, bool isSpace, string args )
		{
			CapexDS ds = null;
			CapexBizNTx biz = null;

			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectGubun(args);

				if (isSpace)
				{
					ds.TB_BASE.AddTB_BASERow( "","" );
				}
			
				ddnl.DataSource = ds.TB_BASE;
				ddnl.DataTextField = "col1";
				ddnl.DataValueField = "col2";
				ddnl.DataBind();

				if ( isSpace )
				{
					ddnl.SelectedIndex = ddnl.Items.Count - 1;
				}

			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}

				
				if ( ds != null )
				{
					ds.Dispose();
					ds = null;
				}
			}
		}

		public static void BindDropDownListGubun( DropDownList ddnl, bool isSpace )
		{
			BindDropDownListGubun(ddnl,isSpace,"");
		}

		#endregion

		#region Capex Status 
		public static void BindDropDownListCStatus( DropDownList ddnl )
		{
			BindDropDownListCStatus( ddnl, false );
		}
		public static void BindDropDownListCStatus( DropDownList ddnl, string args )
		{
			BindDropDownListCStatus( ddnl, false, args );
		}

		public static void BindDropDownListCStatus( DropDownList ddnl, bool isSpace, string args )
		{
			CapexDS ds = null;
			CapexBizNTx biz = null;

			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectCapexStatus(args);

				if (isSpace)
				{
					ds.TB_BASE.AddTB_BASERow( "","" );
				}
			
				ddnl.DataSource = ds.TB_BASE;
				ddnl.DataTextField = "col1";
				ddnl.DataValueField = "col2";
				ddnl.DataBind();

				if ( isSpace )
				{
					ddnl.SelectedIndex = ddnl.Items.Count - 1;
				}

			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}

				
				if ( ds != null )
				{
					ds.Dispose();
					ds = null;
				}
			}
		}

		public static void BindDropDownListCStatus( DropDownList ddnl, bool isSpace )
		{
			BindDropDownListCStatus(ddnl,isSpace,"");
		}

		#endregion


		#region Model 
		public static void BindDropDownListModel(DropDownList ddnl)
		{
			BindDropDownListModel(ddnl, false );
		}
		public static void BindDropDownListModel( DropDownList ddnl, string args)
		{
			BindDropDownListModel( ddnl, false, args );
		}

		public static void BindDropDownListModel( DropDownList ddnl, bool isSpace, string args )
		{
			CapexDS ds = null;
			CapexBizNTx biz = null;

			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectModel(args);

				if (isSpace)
				{
					ds.TB_QUOTATION_NO.AddTB_QUOTATION_NORow( "" );
				}
			
				ddnl.DataSource = ds.TB_QUOTATION_NO;
				ddnl.DataTextField = "QuotaNo";
				ddnl.DataValueField = "QuotaNo";
				ddnl.DataBind();

				if ( isSpace )
				{
					ddnl.SelectedIndex = ddnl.Items.Count - 1;
				}

			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}

				
				if ( ds != null )
				{
					ds.Dispose();
					ds = null;
				}
			}
		}

		public static void BindDropDownListModel( DropDownList ddnl, bool isSpace )
		{
			BindDropDownListModel(ddnl,isSpace,"");
		}

		#endregion

		#region Ledger Entry 
		public static void BindDropDownListLE( DropDownList ddnl )
		{
			BindDropDownListLE( ddnl, false );
		}
		public static void BindDropDownListLE( DropDownList ddnl, string args )
		{
			BindDropDownListLE( ddnl, false, args );
		}

		public static void BindDropDownListLE( DropDownList ddnl, bool isSpace, string args )
		{
			CapexDS ds = null;
			CapexBizNTx biz = null;

			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectQuotationNo(args);

				if (isSpace)
				{
					ds.TB_QUOTATION_NO.AddTB_QUOTATION_NORow( "" );
				}
			
				ddnl.DataSource = ds.TB_QUOTATION_NO;
				ddnl.DataTextField = "QuotaNo";
				ddnl.DataValueField = "QuotaNo";
				ddnl.DataBind();

				if ( isSpace )
				{
					ddnl.SelectedIndex = ddnl.Items.Count - 1;
				}

			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}

				
				if ( ds != null )
				{
					ds.Dispose();
					ds = null;
				}
			}
		}

		public static void BindDropDownListLE( DropDownList ddnl, bool isSpace )
		{
			BindDropDownListLE(ddnl,isSpace,"");
		}

		#endregion

		#region Code 
		public static void BindDropDownListCode( DropDownList ddnl , string ClassID)
		{
			BindDropDownListCode( ddnl, false , ClassID);
		}
		public static void BindDropDownListCode( DropDownList ddnl, string args , string ClassID)
		{
			BindDropDownListCode( ddnl, false, args , ClassID);
		}

		public static void BindDropDownListCode( DropDownList ddnl, bool isSpace, string args , string ClassID)
		{

			CodeDS ds = null;
			CodeBizNTx biz = null;
		
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectCodeList( ClassID );	
		
				if (isSpace)
				{
					ds.TB_CODE.AddTB_CODERow( "","","" );
				}
			
				ddnl.DataSource = ds.TB_CODE;
				ddnl.DataTextField = "CodeDesc";
				ddnl.DataValueField = "Code";
				ddnl.DataBind();

				if ( isSpace )
				{
					ddnl.SelectedIndex = ddnl.Items.Count - 1;
				}
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}

				
				if ( ds != null )
				{
					ds.Dispose();
					ds = null;
				}
			}
		}

		public static void BindDropDownListCode( DropDownList ddnl, bool isSpace , string ClassID)
		{
			BindDropDownListCode(ddnl,isSpace,"",ClassID);
		}

		#endregion


	}
}
