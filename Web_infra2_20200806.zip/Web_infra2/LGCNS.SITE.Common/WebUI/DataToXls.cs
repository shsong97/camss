using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using LGCNS.LAF.Web.Controls;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.Common.WebUI
{
	/// <summary>
	/// DataToXls�� ���� ��� �����Դϴ�.
	/// </summary>
	/// DataToXls�� ���� ��� �����Դϴ�.

	/// </summary>

	public class DataToXls
	{
		public DataToXls()

		{
			//
			// ���⿡ ������ ������ �߰��մϴ�.
			//
		}

		public static void datagridToXls(HttpResponse Response,LDataGrid datagrid,String fileName)
		{
			Response.Clear();
			Response.ContentEncoding = System.Text.Encoding.GetEncoding("ks_c_5601-1987");
			Response.Charset = "euc-kr";
			Response.AddHeader("content-disposition","attachment;filename="+fileName);
			Response.ContentType="application/vnd.xls";
			System.IO.StringWriter stringWriter=new System.IO.StringWriter();
			System.Web.UI.HtmlTextWriter htmlWriter=new HtmlTextWriter(stringWriter);
			
			Response.Write("<meta http-equiv=Content-Type content='text/html; charset=ks_c_5601-1987'>");
			datagrid.RenderControl(htmlWriter);
 
			
			Response.Write(stringWriter.ToString());
			//Response.Flush();
			//Response.ClearHeaders();
			//Response.Close();			
			Response.End();
		}

	}
}

       