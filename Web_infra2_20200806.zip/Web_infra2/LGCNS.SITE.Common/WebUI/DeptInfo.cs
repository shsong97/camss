using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using LGCNS.LAF.Web;

using LGCNS.SITE.DTO;
using LGCNS.SITE.Code.Biz;

namespace LGCNS.SITE.Common.WebUI
{
	/// <summary>
	/// DeptInfo�� ���� ��� �����Դϴ�.
	/// </summary>
	public class DeptInfo
	{
		public DeptInfo()
		{
			//
			// ���⿡ ������ ������ �߰��մϴ�.
			//
		}

		public static string getDeptName( string Area, string DeptCode )
		{
			string DeptName = "";
			CodeDS ds = null;
			CodeBizNTx biz = null;
		
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectDeptList( Area, DeptCode, "" );
				if( ds.TB_DEPT.Count == 1 )
				{
					DeptName = ds.TB_DEPT[0].DeptName;
				}
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return DeptName;
		}

		public static string getDeptNameEng( string Area, string DeptCode )
		{
			string DeptNameEng = "";
			CodeDS ds = null;
			CodeBizNTx biz = null;
		
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectDeptList( Area, DeptCode, "" );
				if( ds.TB_DEPT.Count == 1 )
				{
					DeptNameEng = ds.TB_DEPT[0].DeptNameEng;
				}
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return DeptNameEng;
		}

		public static string getBizUnit( string Area, string DeptCode )
		{
			string BizUnit = "";
			CodeDS ds = null;
			CodeBizNTx biz = null;
		
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectDeptList( Area, DeptCode, "" );
				if( ds.TB_DEPT.Count == 1 )
				{
					BizUnit = ds.TB_DEPT[0].BizUnit;
				}
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return BizUnit;
		}

		public static void BindDropDownList( DropDownList ddnl, string Area )
		{
			BindDropDownList( ddnl, Area, false );
		}

		public static void BindDropDownList( DropDownList ddnl, string Area, bool isSpace )
		{
			CodeDS ds = null;
			CodeBizNTx biz = null;
		
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectDeptList( Area, "", "" );			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			if (isSpace)
			{
				ds.TB_DEPT.AddTB_DEPTRow( "", "", "", "", "", "" );
			}

			ddnl.DataSource = ds.TB_DEPT;
			ddnl.DataTextField = "DeptName";
			ddnl.DataValueField = "DeptCode";
			ddnl.DataBind();

			if ( isSpace )
			{
				ddnl.SelectedIndex = ddnl.Items.Count - 1;
			}

			if ( ds != null )
			{
				ds.Dispose();
				ds = null;
			}
		}
	}
}
