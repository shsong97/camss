using System;
using System.Web ;
using System.Web.UI ;
using System.Web.UI.WebControls ;

using LGCNS.LAF.Web ;

namespace LGCNS.SITE.Common
{
	/// <summary>
	/// UIHelper�� ���� ��� �����Դϴ�.
	/// </summary>
	public class UIHelper
	{
		private UIHelper()
		{
		}

		public static void SetFileLink (DataGrid grid, int fileNameCellIndex, int filePathCellIndex)
		{
			ScriptHelper.RegisterClientScriptBlock (grid.Page, "<iframe name='FileHandler_HiddenFrame' border=0 width=0 height=0></iframe>") ;

			grid.ItemCreated	+= new DataGridItemEventHandler(DataGrid_ItemCreated);
			grid.ItemDataBound	+= new DataGridItemEventHandler(DataGrid_ItemDataBound);
		}

		private static void DataGrid_ItemCreated(object sender, DataGridItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.SelectedItem)
			{
				HyperLink hlinkFile = new HyperLink () ;
				hlinkFile.ID		= "hlinkFile2" ;
				
				TableCell cell = new TableCell () ;
				cell.Controls.Add (hlinkFile) ;
				e.Item.Cells.Add (cell) ;
			}
		}

		private static void DataGrid_ItemDataBound(object sender, DataGridItemEventArgs e)
		{
			if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.SelectedItem)
			{
				HyperLink hlinkFile = e.Item.FindControl ("hlinkFile2") as HyperLink ;
				if(hlinkFile != null)
				{
					string fileName		= e.Item.Cells[0].Text;
					string uploadPath	= e.Item.Cells[1].Text;
					hlinkFile.Text		= fileName ;
					hlinkFile.Target	= "FileHandler_HiddenFrame" ;
					hlinkFile.NavigateUrl = String.Format ("FileHandler.ashx?FILEPATH={0}&FILENAME={1}", uploadPath, fileName) ;
				}
			}
		}
	}
}
