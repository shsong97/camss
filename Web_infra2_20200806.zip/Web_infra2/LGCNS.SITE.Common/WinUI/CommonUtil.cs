using System;
using System.Collections ;
using System.Configuration ;
using System.Windows.Forms ;

namespace LGCNS.SITE.Common.WinUI
{
	/// <summary>
	/// CommonUtil�� ���� ��� �����Դϴ�.
	/// </summary>
	public class CommonUtil
	{
		static CommonUtil()
		{
			//
			// ���⿡ ������ ������ �߰��մϴ�.
			//
		}

		public static DataGridTextBoxColumn CreateDataGridTextBoxColumn (string mappingName, string headerText, HorizontalAlignment hAlignment, int width)
		{
			DataGridTextBoxColumn dgCol = new DataGridTextBoxColumn () ;
			dgCol.MappingName = mappingName ;
			dgCol.HeaderText = headerText ;
			dgCol.Alignment = hAlignment ;
			dgCol.Width = width ;
			return dgCol ;
		}
	}
}
