vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|27 Jan 2004 09:11:28 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|27 Jan 2004 09:11:28 -0000
vti_filesize:IR|1797
