vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|09 Jul 2004 07:08:40 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|09 Jul 2004 07:08:40 -0000
vti_filesize:IR|5110
