vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|22 Apr 2004 07:17:32 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|22 Apr 2004 07:17:32 -0000
vti_filesize:IR|1812
