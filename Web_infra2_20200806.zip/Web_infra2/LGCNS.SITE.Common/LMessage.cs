using System;
using System.Diagnostics ;
using System.IO ;
using System.Data ;
using System.Collections ;
using System.Collections.Specialized ;
using LGCNS.LAF.Common.Exceptions ;
using LGCNS.LAF.Common.Message ;
using LGCNS.LAF.Common.Log ;

namespace LGCNS.SITE.Common
{
	/// <summary>
	/// LMessage�� ���� ��� �����Դϴ�.
	/// </summary>
	public class LMessage
	{
		private Hashtable _htMessages ;
		private Hashtable _htFileName ;
		private Hashtable _htWatchers ;
		private FileSystemWatcher _watcher ;

		#region Singleton���� ����

		/// <summary>
		/// Singleton ���ϱ���
		/// </summary>
		private static readonly LMessage _singletonInstance = new LMessage();

		/// <summary>
		/// LMessage�� Singleton �ν��Ͻ��� ��´�.
		/// </summary>
		public static LMessage Current 
		{
			get
			{
				return _singletonInstance ;
			}
		}
		
		private LMessage () 
		{
			_htMessages = Hashtable.Synchronized(new Hashtable());
			_htFileName = Hashtable.Synchronized(new Hashtable());
			_htWatchers = Hashtable.Synchronized(new Hashtable());
		}
		#endregion

		/// <summary>
		/// �ش� bizModule�� messageID�� �ش��ϴ� �޽����� ��´�.
		/// </summary>
		/// <param name="bizModule">Business Module��</param>
		/// <param name="messageID">�޽���ID</param>
		/// <returns>�޽���</returns>
		public string GetMessage(string bizModule, string messageID)
		{
			MessageDS messageDS = GetMessageDS (bizModule) ;

			MessageDS.MessageRow dr = messageDS.Message.FindByMessageID (messageID) ;

			string messageValue = "" ;

			if(dr==null)
			{
				messageValue = messageID ;
			}
			else
			{
				messageValue = dr.MessageValue ;
			}
			
			return messageValue ;
		}

		/// <summary>
		/// �ش� bizModule�� messageID�� �ش��ϴ� �޽����� ��´�.
		/// </summary>
		/// <param name="bizModule">Business Module��</param>
		/// <param name="messageID">�޽���ID</param>
		/// <param name="args">�޽��� �Ķ����</param>
		/// <returns>�Ķ���� ó���� �޽���</returns>
		public string GetMessage(string bizModule, string messageID, params Object[] args)
		{
			MessageDS messageDS = GetMessageDS (bizModule) ;

			MessageDS.MessageRow dr = messageDS.Message.FindByMessageID (messageID) ;

			string messageValue = "" ;

			if(dr==null)
			{
				messageValue = messageID ;
			}
			else
			{
				messageValue = String.Format (dr.MessageValue, args) ;
			}
			
			return messageValue ;
		}

		/// <summary>
		/// �ش� bizModule�� MessageDS �����ͼ��� ��´�.
		/// </summary>
		/// <param name="bizModule">Business Module��</param>
		/// <returns>MessageDS</returns>
		private MessageDS GetMessageDS (string bizModule)
		{
			MessageDS messageDS = null ;
 
			if(_htMessages.Contains(bizModule))
			{
				messageDS = _htMessages[bizModule] as MessageDS ;
			}
			else
			{
				string filePath = Configuration.GetMessageFilePath (bizModule) ;
			
				if(!File.Exists (filePath))
				{
					throw new MessagingException (filePath + " ����� Message ������ �������� �ʽ��ϴ�.", bizModule) ;
				}

				_htFileName[filePath.ToLower ()] = bizModule ; //��κ� ���� ����

				messageDS = new MessageDS() ;
				messageDS.ReadXml(filePath) ;

//				FileInfo fileInfo = new FileInfo (filePath) ;
		
//				if(!_htWatchers.Contains (fileInfo.DirectoryName))
//				{
//					FileSystemWatcher fileSystemWatcher = new FileSystemWatcher (fileInfo.DirectoryName ) ;
//					fileSystemWatcher.Changed +=new FileSystemEventHandler(FileSystemWatcher_Changed);
//					_htWatchers.Add (fileInfo.DirectoryName, fileSystemWatcher) ;
//				}
				if(_watcher==null)
				{
					FileInfo fileInfo = new FileInfo (filePath) ;
					_watcher = new FileSystemWatcher (fileInfo.DirectoryName) ;
					_watcher.NotifyFilter = NotifyFilters.LastAccess | NotifyFilters.LastWrite | NotifyFilters.FileName | NotifyFilters.DirectoryName ;
				
					//_watcher.Filter = "*.config" ;

					_watcher.WaitForChanged (WatcherChangeTypes.Changed , 100) ;
					_watcher.EnableRaisingEvents = true;
					_watcher.Changed += new FileSystemEventHandler(FileSystemWatcher_Changed);
				}

				_htMessages.Add (bizModule, messageDS) ;
			}

			return messageDS ;
		}

		private void FileSystemWatcher_Changed(object sender, FileSystemEventArgs e)
		{
			string filePath = e.FullPath ;
			if(!_htFileName.Contains (filePath.ToLower ())) return ;

			string bizModule = _htFileName[filePath.ToLower ()] as string ;
			switch(e.ChangeType)
			{
				case WatcherChangeTypes.Changed :
					if(_htMessages.Contains (bizModule))
					{
						FileStream fs = File.Open (filePath, FileMode.Open, FileAccess.Read) ;
						
						MessageDS messageDS = new MessageDS () ;
						messageDS.ReadXml (fs) ;
						fs.Close () ;
						_htMessages[bizModule] = messageDS ;
					}
					break ;

				case WatcherChangeTypes.Deleted :
					if(_htMessages.Contains (bizModule))
					{
						_htMessages.Remove (bizModule) ;
						_htFileName.Remove (filePath.ToLower ()) ;
					}
					break ;
			}
		}
	}
}
