using System;
//using System.Web.Mail;
using System.Net.Mail;
using LGCNS.LAF.Common.Exceptions;

namespace LGCNS.SITE.Common
{
	/// <summary>
	/// SendMail�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SendMail
	{
		public SendMail() {}


		public static bool Send( string from, string to, string subject, string body )
		{
			bool isFlag = true;
			MailMessage mailMsg;

			try
			{
				mailMsg = new MailMessage();
				mailMsg.From = new MailAddress(from);
				mailMsg.To.Add(new MailAddress(to));
				mailMsg.Subject = subject;
				mailMsg.Body = body;

				string server = LGCNS.LAF.Common.ConfigurationManagement.LConfigurationManager.GetConfigValue("SMTP_SERVER");
                SmtpClient client = new SmtpClient(server);
				client.Send(mailMsg);
			}
			catch( Exception ex )
			{
				isFlag = false;
				throw new BizException(ex.Message, ex);
			}
			
			return isFlag;
		}
	}
}
