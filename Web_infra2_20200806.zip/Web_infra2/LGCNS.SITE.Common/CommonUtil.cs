using System;

namespace LGCNS.SITE.Common
{
	/// <summary>
	/// CommonUtil�� ���� ��� �����Դϴ�.
	/// </summary>
	public class CommonUtil
	{
		public CommonUtil() {}

		public static bool isNumeric( string s )
		{
			try
			{
				int i = int.Parse( s );
			}
			catch( Exception ex )
			{
				string errmsg=ex.Message;
				return false;
			}

			return true;
		}

		public static string strNull( string s )
		{
			if( s == null )
			{
				return "";
			}
			else
			{
				return s;
			}
		}
	}
}
