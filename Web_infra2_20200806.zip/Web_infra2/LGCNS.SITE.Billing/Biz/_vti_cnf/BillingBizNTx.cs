vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Mar 2005 03:26:16 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|01 Mar 2005 03:26:16 -0000
vti_filesize:IR|2126
