using System;
using System.Data;
using System.EnterpriseServices;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.Billing.DA;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.Billing.Biz
{
	/// <summary>
	/// AssetBizNTx�� ���� ��� �����Դϴ�.
	/// </summary>
	public class BillingBizNTx : LGCNS.LAF.Biz.BizNTxBase
	{
		public BillingBizNTx() {}

		public DataSet SelectBillingMonth( string Area, string YearMonth )
		{
			DataSet ds = null;
			BillingDA da = null;

			try
			{
				da = new BillingDA ();
				ds = da.SelectBillingMonth( Area, YearMonth );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public DataSet SelectBilling( string Area, string SearchDate )
		{
			DataSet ds = null;
			BillingDA da = null;

			try
			{
				da = new BillingDA ();
				ds = da.SelectBilling( Area, SearchDate );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public DataSet SelectBillingList( string Area, string FromMonth, string ToMonth )
		{
			DataSet ds = null;
			BillingDA da = null;

			try
			{
				da = new BillingDA ();
				ds = da.SelectBillingList( Area, FromMonth, ToMonth );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public DataSet SelectBillingListForXls( string Area, string FromMonth, string ToMonth )
		{
			DataSet ds = null;
			BillingDA da = null;

			try
			{
				da = new BillingDA ();
				ds = da.SelectBillingListForXls( Area, FromMonth, ToMonth );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}
	}
}
