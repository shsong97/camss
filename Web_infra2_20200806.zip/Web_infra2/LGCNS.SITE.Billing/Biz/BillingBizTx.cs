using System;
using System.Collections;
using System.EnterpriseServices;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.Billing.DA;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.Billing.Biz
{
	/// <summary>
	/// BillingBizTx�� ���� ��� �����Դϴ�.
	/// </summary>
	public class BillingBizTx : LGCNS.LAF.Biz.BizTxBase
	{
		public BillingBizTx() {}

		public void Billing( string YearMonth )
		{
			BillingDA da = null;
			
			try
			{
				da = new BillingDA();
				da.Billing( YearMonth );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}
	}
}
