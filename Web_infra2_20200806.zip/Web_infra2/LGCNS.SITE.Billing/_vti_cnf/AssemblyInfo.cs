vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|30 Dec 2004 07:52:10 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|30 Dec 2004 07:52:10 -0000
vti_filesize:IR|2454
