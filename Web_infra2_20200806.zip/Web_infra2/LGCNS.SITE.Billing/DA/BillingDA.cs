using System;
using System.EnterpriseServices;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;

using LGCNS.LAF.DA;
using LGCNS.LAF.Common.Exceptions;
using LGCNS.LAF.Common.DataAccess;
using LGCNS.LAF.Common.Paging ;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.Billing.DA
{
	/// <summary>
	/// AssetDA�� ���� ��� �����Դϴ�.
	/// </summary>
	public class BillingDA : LGCNS.LAF.DA.DABase
	{
		private const string PROJECT_NAME	= "LGCNS.SITE.Billing" ;
		private const string CLASS_NAME		= "LGCNS.SITE.Billing.DA.BillingDA" ;

		public BillingDA() {}

		public void Billing( string YearMonth )
		{
			LDataCollection dc = new LDataCollection ();
			dc["YearMonth"] = YearMonth; 

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "Billing") ;
			ADOHelper.ExecuteNonQuery (ps, dc);
		}

		public DataSet SelectBillingMonth( string Area, string YearMonth )
		{
			LDataCollection dc = new LDataCollection ();
			dc["Area"] = Area; 
			dc["YearMonth"] = YearMonth; 

			DataSet ds = new DataSet();

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectBillingMonth") ;
			ADOHelper.FillDataSet( ps, ds, new string[] {"TB_BILLING_LIST"}, dc);

			return ds;
		}

		public DataSet SelectBilling( string Area, string SearchDate )
		{
			LDataCollection dc = new LDataCollection ();
			dc["Area"] = Area; 
			dc["Date"] = SearchDate; 

			DataSet ds = new DataSet();

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectBilling") ;
			ADOHelper.FillDataSet( ps, ds, new string[] {"TB_BILLING_LIST"}, dc);

			return ds;
		}

		public DataSet SelectBillingList( string Area, string FromMonth, string ToMonth )
		{
			LDataCollection dc = new LDataCollection ();
			dc["Area"] = Area; 
			dc["FromMonth"] = FromMonth;
			dc["ToMonth"] = ToMonth;

			DataSet ds = new DataSet();

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectBillingList") ;
			ADOHelper.FillDataSet( ps, ds, new string[] {"TB_BILLING_LIST"}, dc);

			return ds;
		}

		public DataSet SelectBillingListForXls( string Area, string FromMonth, string ToMonth )
		{
			LDataCollection dc = new LDataCollection ();
			dc["Area"] = Area; 
			dc["FromMonth"] = FromMonth;
			dc["ToMonth"] = ToMonth;

			DataSet ds = new DataSet();

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectBillingListForXls") ;
			ADOHelper.FillDataSet( ps, ds, new string[] {"TB_BILLING_LIST"}, dc);

			return ds;
		}
	}
}
