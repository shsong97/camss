vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 Jun 2005 16:45:06 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|01 Jun 2005 16:45:06 -0000
vti_filesize:IR|8314
