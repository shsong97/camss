using System;
using System.Data;
using System.EnterpriseServices;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.Code.DA;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.Code.Biz
{
	public class CodeBizNTx : LGCNS.LAF.Biz.BizNTxBase
	{
		public CodeBizNTx() {}

		#region Area

		[AutoComplete(true)]
		public AreaDS SelectArea( string Area )
		{
			AreaDS ds = null;
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				ds = da.SelectArea( Area );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}


		[AutoComplete(true)]
		public AreaDS SelectAreaList ()
		{
			return SelectAreaList("");
		}

		[AutoComplete(true)]
		public AreaDS SelectAreaList (string args)
		{
			AreaDS ds = null;
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				ds = da.SelectAreaList(args);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}
		#endregion

		#region Capex
		[AutoComplete(true)]
		public CodeDS SelectCapexUserList()
		{
			CodeDS ds = null;
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				ds = da.SelectCapexUserList();
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}
		#endregion


		#region Class
		[AutoComplete(true)]
		public CodeDS SelectCodeClassList( string ClassID )
		{
			CodeDS ds = null;
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				ds = da.SelectCodeClassList( ClassID );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}
		#endregion

		#region Code

		[AutoComplete(true)]
		public CodeDS SelectCode( string ClassID, string Code )
		{
			CodeDS ds = null;
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				ds = da.SelectCode( ClassID, Code );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}

		public CodeDS SelectCodeList (string classID)
		{
			return SelectCodeList (null, classID, "") ;
		}

		public CodeDS SelectCodeList (string classID, string Args)
		{
			return SelectCodeList (null, classID, Args) ;
		}

		[AutoComplete(true)]
		public CodeDS SelectCodeList (string order, string classID, string Args)
		{
			CodeDS ds = null;
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				ds = da.SelectCodeList( order, classID, Args );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}

		#endregion

		#region Menu
		[AutoComplete(true)]
		public DataSet SelectMenu(string UserID)
		{
			DataSet ds = null;
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				ds = da.SelectMenu( UserID );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}

		[AutoComplete(true)]
		public DataSet SelectCodeMenu(string UserID)
		{
			DataSet ds = null;
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				ds = da.SelectCodeMenu( UserID );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}
		#endregion

		#region Program
		[AutoComplete(true)]
		public ProgramDS SelectProgramClass()
		{
			ProgramDS ds = null;
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				ds = da.SelectProgramClass();
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}

		public string GetProgramAuthority( string ProgramFile )
		{
			ProgramDS ds = SelectProgram( ProgramFile );
			
			if ( ds.TB_PROGRAM.Count == 1 )
			{
				return ds.TB_PROGRAM[0].ProgramAuthority ;
			}
			else
			{
				return "Z";
			}
		}

		[AutoComplete(true)]
		public ProgramDS SelectProgram( string ProgramFile )
		{
			ProgramDS ds = null;
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				ds = da.SelectProgram( ProgramFile );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;		
		}

		[AutoComplete(true)]
		public ProgramDS SelectProgramList (int currentPage, int pageSize, string ProgramClass)
		{
			ProgramDS ds = null;
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				ds = da.SelectProgramList(currentPage, pageSize, ProgramClass);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;		
		}
		#endregion

		#region Notice
		[AutoComplete(true)]
		public CodeDS SelectNotice()
		{
			CodeDS ds = null;
			CodeDA da = null;
			try
			{
				da = new CodeDA();
				ds = da.SelectNotice();
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;		
		}

		public CodeDS SelectNoticeList()
		{
			CodeDS ds = null;
			CodeDA da = null;
			try
			{
				da = new CodeDA();
				ds = da.SelectNoticeList();
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;		
		}

		#endregion

		#region Dept

		[AutoComplete(true)]
		public CodeDS SelectDeptList ( string Area, string DeptCode, string DeptName )
		{
			CodeDS ds = null;
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				ds = da.SelectDeptList( Area, DeptCode, DeptName );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}

		#endregion

		#region Site
		[AutoComplete(true)]
		public CodeDS SelectSiteList ( string Area, string SiteCode, string SiteDesc, string BuildingCode )
		{
			CodeDS ds = null;
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				ds = da.SelectSiteList( Area, SiteCode, SiteDesc, BuildingCode );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}

		public CodeDS SelectSiteListForDDL ( string Area )
		{
			CodeDS ds = null;
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				ds = da.SelectSiteListForDDL( Area );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}

		public CodeDS SelectSiteListForICMS ( string Area )
		{
			CodeDS ds = null;
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				ds = da.SelectSiteListForICMS( Area );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}
		#endregion

		#region Model
		[AutoComplete(true)]
		public CodeDS SelectModelList (string ModelNo)
		{
			CodeDS ds = null;
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				ds = da.SelectModelList(ModelNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}
		#endregion
	}
}
