using System;
using System.Collections;
using System.EnterpriseServices;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.Code.DA;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.Code.Biz
{
	public class CodeBizTx : LGCNS.LAF.Biz.BizTxBase
	{
		public CodeBizTx() {}

		#region ManageArea
		[AutoComplete(true)]
		public void InsertArea(AreaDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.InsertArea(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void UpdateArea(AreaDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.UpdateArea(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void DeleteArea(string Area)
		{
			CodeDA da = null;

			try
			{
				AreaDS ds = new AreaDS();
				ds.EnforceConstraints = false;
				AreaDS.TB_AREARow dr = ds.TB_AREA.NewTB_AREARow();

				dr.Area = Area;
				ds.TB_AREA.AddTB_AREARow( dr );

				da = new CodeDA();
				da.DeleteArea(ds) ;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}
		#endregion

		#region ManageCodeClass
		[AutoComplete(true)]
		public void InsertCodeClass(CodeDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.InsertCodeClass(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void UpdateCodeClass(CodeDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.UpdateCodeClass(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void DeleteCodeClass(string ClassID)
		{
			CodeDA da = null;

			try
			{
				CodeDS ds = new CodeDS();
				ds.EnforceConstraints = false;
				CodeDS.TB_CLASSRow dr = ds.TB_CLASS.NewTB_CLASSRow();

				dr.Class = ClassID;
				ds.TB_CLASS.AddTB_CLASSRow( dr );

				da = new CodeDA();
				da.DeleteCodeClass(ds) ;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}
		#endregion

		#region ManageCode
		[AutoComplete(true)]
		public void InsertCode(CodeDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.InsertCode(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void UpdateCode(CodeDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.UpdateCode(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void DeleteCode(string ClassID, string CodeID)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.DeleteCode(ClassID,CodeID) ;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}
		#endregion

		#region ManageProgramClass
		[AutoComplete(true)]
		public void InsertProgramClass(ProgramDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.InsertProgramClass(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void UpdateProgramClass(ProgramDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.UpdateProgramClass(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void DeleteProgramClass(string ProgramClass)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.DeleteProgramClass(ProgramClass) ;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}
		#endregion

		#region ManageProgram
		[AutoComplete(true)]
		public void InsertProgram(ProgramDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.InsertProgram(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void UpdateProgram(ProgramDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.UpdateProgram(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void DeleteProgram(string ProgramClass,string ProgramID)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.DeleteProgram(ProgramClass,ProgramID) ;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}
		#endregion

		#region ManageNotice
		[AutoComplete(true)]
		public void InsertNotice(CodeDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.InsertNotice(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void UpdateNotice(CodeDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.UpdateNotice(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void DeleteNotice(int ID)
		{
			CodeDA da = null;

			try
			{
				CodeDS ds = new CodeDS();
				ds.EnforceConstraints = false;
				CodeDS.TB_NOTICERow dr = ds.TB_NOTICE.NewTB_NOTICERow();

				dr.ID = ID;
				ds.TB_NOTICE.AddTB_NOTICERow( dr );

				da = new CodeDA();
				da.DeleteNotice(ds) ;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}
		#endregion

		#region ManageDept
		[AutoComplete(true)]
		public void InsertDept(CodeDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.InsertDept(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void UpdateDept(CodeDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.UpdateDept(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void DeleteDept(string Area,string DeptCode)
		{
			CodeDA da = null;

			try
			{
				CodeDS ds = new CodeDS();
				ds.EnforceConstraints = false;
				CodeDS.TB_DEPTRow dr = ds.TB_DEPT.NewTB_DEPTRow();

				dr.DeptCode = DeptCode;
				dr.Area = Area;
				ds.TB_DEPT.AddTB_DEPTRow( dr );

				da = new CodeDA();
				da.DeleteDept(ds) ;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}
		#endregion

		#region ManageSite
		[AutoComplete(true)]
		public void InsertSite(CodeDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.InsertSite(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void UpdateSite(CodeDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.UpdateSite(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void DeleteSite(string Area,string SiteCode)
		{
			CodeDA da = null;

			try
			{
				CodeDS ds = new CodeDS();
				ds.EnforceConstraints = false;
				CodeDS.TB_SITERow dr = ds.TB_SITE.NewTB_SITERow();

				dr.Area = Area;
				dr.SiteCode = SiteCode;
				ds.TB_SITE.AddTB_SITERow( dr );

				da = new CodeDA();
				da.DeleteSite(ds) ;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}
		#endregion

		#region ManageModel
		[AutoComplete(true)]
		public void InsertModel(CodeDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.InsertModel(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void UpdateModel(CodeDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.UpdateModel(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void DeleteModel(string ModelNo)
		{
			CodeDA da = null;

			try
			{
				CodeDS ds = new CodeDS();
				ds.EnforceConstraints = false;
				CodeDS.TB_MODELRow dr = ds.TB_MODEL.NewTB_MODELRow();
				dr.ModelNo = ModelNo;
				ds.TB_MODEL.AddTB_MODELRow( dr );

				da = new CodeDA();
				da.DeleteModel(ds) ;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}
		#endregion


		#region ManageCapexUser
		[AutoComplete(true)]
		public void InsertCapexUser(CodeDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.InsertCapexUser(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void UpdateCapexUser(CodeDS ds)
		{
			CodeDA da = null;
			
			try
			{
				da = new CodeDA();
				da.UpdateCapexUser(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void DeleteCapexUser(string Col2)
		{
			CodeDA da = null;

			try
			{
				CodeDS ds = new CodeDS();
				ds.EnforceConstraints = false;
				CodeDS.TB_BASERow dr = ds.TB_BASE.NewTB_BASERow();
				dr.Col2 = Col2;
				ds.TB_BASE.AddTB_BASERow( dr );

				da = new CodeDA();
				da.DeleteCapexUser(ds) ;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}
		#endregion
	}
}