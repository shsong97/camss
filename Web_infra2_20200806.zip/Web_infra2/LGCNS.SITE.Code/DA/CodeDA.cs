using System;
using System.EnterpriseServices;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;

using LGCNS.LAF.DA;
using LGCNS.LAF.Common.Exceptions;
using LGCNS.LAF.Common.DataAccess;
using LGCNS.LAF.Common.Paging ;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.Code.DA
{
	/// <summary>
	/// CodeDA�� ���� ��� �����Դϴ�.
	/// </summary>
	public class CodeDA : LGCNS.LAF.DA.DABase
	{
		private const string PROJECT_NAME	= "LGCNS.SITE.Code" ;
		private const string CLASS_NAME		= "LGCNS.SITE.Code.DA.CodeDA" ;

		public CodeDA() { }

		#region Area
		[AutoComplete(true)]
		public AreaDS SelectAreaList()
		{
			return SelectAreaList("") ;
		}

		[AutoComplete(true)]
		public AreaDS SelectAreaList(string args)
		{
			AreaDS ds = new AreaDS () ;
			
			LDataCollection dc = new LDataCollection () ;
			dc["Args"]	= args ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectAreaListArgs", ds.TB_AREA) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_AREA"}, dc ) ;

			return ds ;
		}

		public AreaDS SelectArea( string Area)
		{
			AreaDS ds = new AreaDS () ;

			LDataCollection dc = new LDataCollection () ;
			dc["Area"]	= Area ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectArea", ds.TB_AREA) ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_AREA"}, dc) ;

			return ds ;
		}


		[AutoComplete(true)]
		public void InsertArea(AreaDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertArea", ds.TB_AREA) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_AREA[0]) ;
		}


		[AutoComplete(true)]
		public void UpdateArea(AreaDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateArea", ds.TB_AREA) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_AREA[0]) ;
		}


		[AutoComplete(true)]
		public void DeleteArea(AreaDS ds)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Area"] = ds.TB_AREA[0].Area;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteArea", ds.TB_AREA) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		#endregion


		#region Capex
		[AutoComplete(true)]
		public CodeDS SelectCapexUserList( )
		{
			CodeDS ds = new CodeDS () ;
			LDataCollection dc = new LDataCollection () ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectCapexUser") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_BASE"}, dc) ;

			return ds ;
		}


		[AutoComplete(true)]
		public void InsertCapexUser(CodeDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertCapexUser", ds.TB_BASE) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_BASE[0]) ;
		}


		[AutoComplete(true)]
		public void UpdateCapexUser(CodeDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateCapexUser", ds.TB_BASE) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_BASE[0]) ;
		}


		[AutoComplete(true)]
		public void DeleteCapexUser(CodeDS ds)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Col2"] = ds.TB_BASE[0].Col2;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteCapexUser", ds.TB_BASE) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}




		#endregion

		#region Class
		[AutoComplete(true)]
		public CodeDS SelectCodeClassList( string ClassID )
		{
			CodeDS ds = new CodeDS () ;
			LDataCollection dc = new LDataCollection () ;
			dc["ClassID"]	= ClassID ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectCodeClassList") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_CLASS"}, dc) ;

			return ds ;
		}


		[AutoComplete(true)]
		public void InsertCodeClass(CodeDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertCodeClass", ds.TB_CLASS) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_CLASS[0]) ;
		}


		[AutoComplete(true)]
		public void UpdateCodeClass(CodeDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateCodeClass", ds.TB_CLASS) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_CLASS[0]) ;
		}


		[AutoComplete(true)]
		public void DeleteCodeClass(CodeDS ds)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Class"] = ds.TB_CLASS[0].Class;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteCodeClass", ds.TB_CLASS) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}
		#endregion

		#region Code
		[AutoComplete(true)]
		public void InsertCode(CodeDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertCode", ds.TB_CODE) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_CODE[0]) ;
		}
		[AutoComplete(true)]
		public void UpdateCode(CodeDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateCode", ds.TB_CODE) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_CODE[0]) ;
		}


		[AutoComplete(true)]
		public void DeleteCode(string classID, string codeID)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Class"]	= classID;
			dc["Code"]	= codeID;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteCode") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		[AutoComplete(true)]
		public CodeDS SelectCodeList (string order, string classID, string Args)
		{
			if( order==null || order=="" ) 
				order = " Code ASC " ; // ���ļ����� �������� ������� ������̸� ������ ����

			CodeDS ds = new CodeDS () ;

			// LPresparedStatement�� ������ ������
			LDataCollection dc = new LDataCollection () ;
			dc["[ORDER]"]	= order ; //ORDER BY ���� ������ ���� SQL �Ķ���ͷ� �����Ҽ� ���� ���� ���ȣ([,])�� �̿��Ͽ� ó�� (�������� [XXX]�κ��� ġȯ�ȴ�.)
			dc["ClassID"]	= classID ;
			dc["Args"] = Args;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectCodeList") ;
			ADOHelper.FillDataSet (ps, ds, new string []{"TB_CODE"}, dc) ;

			//int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;

			//PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;

			return ds ;
		}
		
		[AutoComplete(true)]
		public CodeDS SelectCode(string classID, string code)
		{
			CodeDS ds = new CodeDS();

			LDataCollection dc = new LDataCollection();
			dc["ClassID"]	= classID;
			dc["Code"]	= code;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectCode") ;
			ADOHelper.FillDataSet (ps, ds, new string []{"TB_CODE"}, dc) ;

			return ds ;
		}
		#endregion

		#region Menu
		[AutoComplete(true)]
		public DataSet SelectMenu( string UserID )
		{
			DataSet ds = new DataSet();
			LDataCollection dc = new LDataCollection();
			dc["UserID"] = UserID;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectMenu") ;
			ADOHelper.FillDataSet (ps, ds, new string []{"TB_TOP_MENU", "TB_SUB_MENU"}, dc) ;

			return ds ;
		}

//		[AutoComplete(true)]
//		public DataSet SelectTopMenu( string UserID )
//		{
//			DataSet ds = new DataSet();
//			LDataCollection dc = new LDataCollection();
//			dc["UserID"] = UserID;
//
//			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectTopMenu") ;
//			ADOHelper.FillDataSet (ps, ds, new string []{"TB_PROGRAM_CLASS"}, dc) ;
//
//			return ds ;
//		}
//
//		[AutoComplete(true)]
//		public DataSet SelectSubMenu( string UserID )
//		{
//			DataSet ds = new DataSet();
//			LDataCollection dc = new LDataCollection();
//			dc["UserID"] = UserID;
//
//			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectSubMenu") ;
//			ADOHelper.FillDataSet (ps, ds, new string []{"TB_PROGRAM"}, dc) ;
//
//			return ds ;
//		}

		[AutoComplete(true)]
		public DataSet SelectCodeMenu( string UserID )
		{
			DataSet ds = new DataSet();
			LDataCollection dc = new LDataCollection();
			dc["UserID"] = UserID;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectCodeMenu") ;
			ADOHelper.FillDataSet (ps, ds, new string []{"TB_CODE_MENU"}, dc) ;

			return ds ;
		}
		#endregion

		#region ProgramClass
		[AutoComplete(true)]
		public ProgramDS SelectProgramClass()
		{
			ProgramDS ds = new ProgramDS();

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectProgramClass" ) ;
			ADOHelper.FillDataSet (ps, ds, new string []{"TB_PROGRAM_CLASS"} ) ;

			return ds;
		}
		[AutoComplete(true)]
		public void InsertProgramClass(ProgramDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertProgramClass", ds.TB_PROGRAM_CLASS) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_PROGRAM_CLASS[0]) ;
		}


		[AutoComplete(true)]
		public void UpdateProgramClass(ProgramDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateProgramClass", ds.TB_PROGRAM_CLASS) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_PROGRAM_CLASS[0]) ;
		}


		[AutoComplete(true)]
		public void DeleteProgramClass(string ProgramClass)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["ProgramClass"]	= ProgramClass ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteProgramClass") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}
		#endregion

		#region Program

		[AutoComplete(true)]
		public ProgramDS SelectProgram( string ProgramFile )
		{
			ProgramDS ds = new ProgramDS();

			LDataCollection dc = new LDataCollection();
			dc["ProgramFile"]	= ProgramFile;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectProgram", ds.TB_PROGRAM) ;
			ADOHelper.FillDataSet(ps, ds, new string [] {"TB_PROGRAM"}, dc) ;

			return ds;
		}

		[AutoComplete(true)]
		public ProgramDS SelectProgramList( int currentPage, int pageSize, string ProgramClass )
		{
			ProgramDS ds = new ProgramDS () ;

			// LPresparedStatement�� ������ ������
			LDataCollection dc = new LDataCollection () ;
			dc["ProgramClass"]	= ProgramClass ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectProgramList") ;
			ADOHelper.FillDataSet (ps, ds, "TB_PROGRAM", currentPage, pageSize, dc) ;

			int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;

			PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;

			return ds ;
		}

		[AutoComplete(true)]
		public void InsertProgram(ProgramDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertProgram", ds.TB_PROGRAM) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_PROGRAM[0]) ;
		}


		[AutoComplete(true)]
		public void UpdateProgram(ProgramDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateProgram", ds.TB_PROGRAM) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_PROGRAM[0]) ;
		}


		[AutoComplete(true)]
		public void DeleteProgram(string ProgramClass, string ProgramID)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["ProgramClass"]	= ProgramClass ;
			dc["ProgramID"]	= ProgramID ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteProgram") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}
		#endregion

		#region Notice
		[AutoComplete(true)]
		public CodeDS SelectNotice()
		{
			CodeDS ds = new CodeDS () ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectNotice") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_NOTICE"}) ;

			return ds ;
		}

		public CodeDS SelectNoticeList()
		{
			CodeDS ds = new CodeDS () ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectNoticeList") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_NOTICE"}) ;

			return ds ;
		}


		[AutoComplete(true)]
		public void InsertNotice(CodeDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertNotice", ds.TB_NOTICE) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_NOTICE[0]) ;
		}


		[AutoComplete(true)]
		public void UpdateNotice(CodeDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateNotice", ds.TB_NOTICE) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_NOTICE[0]) ;
		}


		[AutoComplete(true)]
		public void DeleteNotice(CodeDS ds)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["ID"] = ds.TB_NOTICE[0].ID;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteNotice", ds.TB_NOTICE) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}


		#endregion

		#region Dept

		[AutoComplete(true)]
		public CodeDS SelectDeptList( string Area, string DeptCode, string DeptName )
		{
			return SelectDeptList( Area, DeptCode, DeptName, "" );
		}

		[AutoComplete(true)]
		public CodeDS SelectDeptList( string Area, string DeptCode, string DeptName, string BizUnit )
		{
			CodeDS ds = new CodeDS () ;

			LDataCollection dc = new LDataCollection () ;
			dc["Area"]	= Area ;
			dc["DeptCode"]	= DeptCode ;
			//dc["DeptCode"]	= DeptCode ;
			dc["DeptName"]	= DeptName ;
			dc["BizUnit"] = BizUnit;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectDeptList") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_DEPT"}, dc) ;

			return ds ;
		}


		[AutoComplete(true)]
		public void InsertDept(CodeDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertDept", ds.TB_DEPT) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_DEPT[0]) ;
		}


		[AutoComplete(true)]
		public void UpdateDept(CodeDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateDept", ds.TB_DEPT) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_DEPT[0]) ;
		}


		[AutoComplete(true)]
		public void DeleteDept(CodeDS ds)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["DeptCode"] = ds.TB_DEPT[0].DeptCode;
			dc["Area"] = ds.TB_DEPT[0].Area;
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteDept", ds.TB_DEPT) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}
		#endregion

		#region Site
		public CodeDS SelectSiteList( string Area, string SiteCode, string SiteDesc, string BuildingCode )
		{
			CodeDS ds = new CodeDS () ;
			LDataCollection dc = new LDataCollection () ;
			dc["Area"]	= Area ;
			dc["SiteCode"]	= SiteCode ;
			dc["SiteDesc"]	= SiteDesc ;
			dc["BuildingCode"]	= BuildingCode ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectSiteList");
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_SITE"}, dc) ;

			return ds ;
		}

		public CodeDS SelectSiteListForDDL( string Area )
		{
			CodeDS ds = new CodeDS () ;
			ds.EnforceConstraints = false;
			LDataCollection dc = new LDataCollection () ;
			dc["Area"]	= Area ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectSiteListForDDL");
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_SITE"}, dc) ;

			return ds ;
		}

		public CodeDS SelectSiteListForICMS( string Area )
		{
			CodeDS ds = new CodeDS () ;
			ds.EnforceConstraints = false;
			LDataCollection dc = new LDataCollection () ;
			dc["Area"]	= Area ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectSiteListForICMS");
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_SITE"}, dc) ;

			return ds ;
		}

		
		[AutoComplete(true)]
		public void InsertSite(CodeDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertSite", ds.TB_SITE) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_SITE[0]) ;
		}


		[AutoComplete(true)]
		public void UpdateSite(CodeDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateSite", ds.TB_SITE) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_SITE[0]) ;
		}


		[AutoComplete(true)]
		public void DeleteSite(CodeDS ds)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Area"] = ds.TB_SITE[0].Area;
			dc["SiteCode"] = ds.TB_SITE[0].SiteCode;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteSite", ds.TB_SITE) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}
		#endregion

		#region Model

		public CodeDS SelectModelList(string ModelNo)
		{

			CodeDS ds = new CodeDS () ;
			ds.EnforceConstraints = false;
			LDataCollection dc = new LDataCollection () ;
			dc["ModelNo"]	= ModelNo ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectModelList");
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_MODEL"}, dc) ;

			return ds ;
		}


		[AutoComplete(true)]
		public void InsertModel(CodeDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertModel", ds.TB_MODEL) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_MODEL[0]) ;
		}


		[AutoComplete(true)]
		public void UpdateModel(CodeDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateModel", ds.TB_MODEL) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_MODEL[0]) ;
		}


		[AutoComplete(true)]
		public void DeleteModel(CodeDS ds)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["ModelNo"] = ds.TB_MODEL[0].ModelNo;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteModel", ds.TB_MODEL) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}


		#endregion
	}
}
