using System;
using System.Collections.Specialized;
using System.EnterpriseServices;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;

using LGCNS.LAF.DA;
using LGCNS.LAF.Common.Exceptions;
using LGCNS.LAF.Common.DataAccess;
using LGCNS.LAF.Common.Paging ;

using LGCNS.SITE.DTO;


namespace LGCNS.SITE.ICMS.DA
{
	/// <summary>
	/// ICMSDA�� ���� ��� �����Դϴ�.
	/// </summary>
	public class ICMSDA : LGCNS.LAF.DA.DABase
	{
		private const string PROJECT_NAME	= "LGCNS.SITE.ICMS" ;
		private const string CLASS_NAME		= "LGCNS.SITE.ICMS.DA.ICMSDA" ;

		public ICMSDA() {}

		#region ICMS

		[AutoComplete(true)]
		public void InsertICMS (ICMSDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertICMS", ds.TB_ICMS) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_ICMS[0]) ;
		}


		[AutoComplete(true)]
		public void UpdateICMS (ICMSDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateICMS", ds.TB_ICMS) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_ICMS[0]) ;
		}


		[AutoComplete(true)]
		public void DeleteICMS (ICMSDS ds)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"]	= ds.TB_ICMS[0].TicketNo;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteICMS", ds.TB_ICMS) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}
		

		#endregion
	
	
		#region ICMSAsset

		[AutoComplete(true)]
		public void InsertICMSAsset (ICMSDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertICMSAsset", ds.TB_ICMS_ASSET) ;

			foreach(ICMSDS.TB_ICMS_ASSETRow dr in ds.TB_ICMS_ASSET.Rows)
			{
				ADOHelper.ExecuteNonQuery (ps, dr) ;
			}
		}

		//20060525 lglsy - �ڻ��߰��ϸ鼭 detail ������ �߰��ϵ��� ������.
		[AutoComplete(true)]
		public void InsertICMSAssetDetail (ICMSDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertICMSAssetDetail", ds.TB_ICMS_ASSET) ;

			foreach(ICMSDS.TB_ICMS_ASSETRow dr in ds.TB_ICMS_ASSET.Rows)
			{
				ADOHelper.ExecuteNonQuery (ps, dr) ;
			}
		}

		[AutoComplete(true)]
		public void UpdateICMSAsset (ICMSDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateICMSAsset", ds.TB_ICMS_ASSET) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_ICMS_ASSET[0]) ;
		}


		[AutoComplete(true)]
		public void DeleteICMSAsset (ICMSDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteICMSAsset", ds.TB_ICMS_ASSET) ;

			foreach(ICMSDS.TB_ICMS_ASSETRow dr in ds.TB_ICMS_ASSET.Rows)
			{
				LDataCollection dc = new LDataCollection () ;
				dc["TicketNo"]	= dr.TicketNo;
				dc["AssetNo"] = dr.AssetNo;
			
				ADOHelper.ExecuteNonQuery (ps, dc) ;
			}
		}
		

		#endregion
	
	
		#region ICMSDetail

		[AutoComplete(true)]
		public void InsertICMSDetail (ICMSDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertICMSDetail", ds.TB_ICMS_DETAIL) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_ICMS_DETAIL[0]) ;
		}


		[AutoComplete(true)]
		public void UpdateICMSDetail (ICMSDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateICMSDetail", ds.TB_ICMS_DETAIL) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_ICMS_DETAIL[0]) ;
		}


		[AutoComplete(true)]
		public void DeleteICMSDetail (ICMSDS ds)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"]	= ds.TB_ICMS_DETAIL[0].TicketNo;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteICMSDetail", ds.TB_ICMS_DETAIL) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}
		

		#endregion


		#region Select

		[AutoComplete(true)]
		public ICMSDS SelectICMS( string TicketNo )
		{
			ICMSDS ds = new ICMSDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"]	= TicketNo ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectICMS", ds.TB_ICMS) ;
			ADOHelper.FillDataSet (ps, ds, new string[] {"TB_ICMS", "TB_ICMS_ASSET", "TB_ICMS_DETAIL"}, dc) ;

			return ds;
		}

		[AutoComplete(true)]
		public ICMSDS SelectIMACList( string FromDate, string ToDate  )
		{
			ICMSDS ds = new ICMSDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["ConfirmDateFrom"]	= FromDate;
			dc["ConfirmDateTo"]	= ToDate;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectIMACList", ds.TB_IMAC) ;
			ADOHelper.FillDataSet (ps, ds, new string[] {"TB_IMAC"}, dc) ;

			return ds ;
		}
		[AutoComplete(true)]
		public ICMSDS SelectICMSList( int currentPage, int pageSize, string order, NameValueCollection searchCondition  )
		{
			if(order==null || order=="") 
				order = "TicketNo" ; // ���ļ����� �������� �������

			ICMSDS ds = new ICMSDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["Order"] = order;
			dc["TicketNo"]	= searchCondition["TicketNo"] ;
			dc["AssetNo"]	= searchCondition["AssetNo"] ;
			dc["EmpNo"]	= searchCondition["EmpNo"] ;
			dc["EmpName"]	= searchCondition["EmpName"] ;
			dc["Engineer"]	= searchCondition["Engineer"] ;
			dc["ServiceType"]	= searchCondition["ServiceType"] ;
			dc["ConfirmFlag"]	= searchCondition["ConfirmFlag"] ;
			dc["ActivityDateFrom"]	= searchCondition["ActivityDateFrom"] ;
			dc["ActivityDateTo"]	= searchCondition["ActivityDateTo"] ;
			dc["ConfirmDateFrom"]	= searchCondition["ConfirmDateFrom"] ;
			dc["ConfirmDateTo"]	= searchCondition["ConfirmDateTo"] ;
			dc["Area"]	= searchCondition["Area"] ;
			dc["Bill"]	= searchCondition["Bill"] ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectICMSList") ;
			ADOHelper.FillDataSet (ps, ds, "TB_ICMS_LIST", currentPage, pageSize, dc) ;

			if( pageSize > 0 )
			{
				int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;
				PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;
			}

			return ds ;
		}

		public ICMSDS SelectICMSListForXls( int currentPage, int pageSize, string order, NameValueCollection searchCondition  )
		{
			if(order==null || order=="") 
				order = "TicketNo" ; // ���ļ����� �������� �������

			ICMSDS ds = new ICMSDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"]	= searchCondition["TicketNo"] ;
			dc["AssetNo"]	= searchCondition["AssetNo"] ;
			dc["EmpNo"]	= searchCondition["EmpNo"] ;
			dc["EmpName"]	= searchCondition["EmpName"] ;
			dc["Engineer"]	= searchCondition["Engineer"] ;
			dc["ServiceType"]	= searchCondition["ServiceType"] ;
			dc["ConfirmFlag"]	= searchCondition["ConfirmFlag"] ;
			dc["ActivityDateFrom"]	= searchCondition["ActivityDateFrom"] ;
			dc["ActivityDateTo"]	= searchCondition["ActivityDateTo"] ;
			dc["ConfirmDateFrom"]	= searchCondition["ConfirmDateFrom"] ;
			dc["ConfirmDateTo"]	= searchCondition["ConfirmDateTo"] ;
			dc["Area"]	= searchCondition["Area"] ;
			dc["Bill"]	= searchCondition["Bill"] ;
			

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectICMSListForXls") ;
			ADOHelper.FillDataSet (ps, ds, "TB_ICMS_LIST", currentPage, pageSize, dc) ;

			if( pageSize > 0 )
			{
				int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;
				PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;
			}

			return ds ;
		}

		public ICMSDS SelectICMSListForXls2( int currentPage, int pageSize, string order, NameValueCollection searchCondition  )
		{
			if(order==null || order=="") 
				order = "TicketNo" ; // ���ļ����� �������� �������

			ICMSDS ds = new ICMSDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"]	= searchCondition["TicketNo"] ;
			dc["AssetNo"]	= searchCondition["AssetNo"] ;
			dc["EmpNo"]	= searchCondition["EmpNo"] ;
			dc["EmpName"]	= searchCondition["EmpName"] ;
			dc["Engineer"]	= searchCondition["Engineer"] ;
			dc["ServiceType"]	= searchCondition["ServiceType"] ;
			dc["ConfirmFlag"]	= searchCondition["ConfirmFlag"] ;
			dc["ActivityDateFrom"]	= searchCondition["ActivityDateFrom"] ;
			dc["ActivityDateTo"]	= searchCondition["ActivityDateTo"] ;
			dc["ConfirmDateFrom"]	= searchCondition["ConfirmDateFrom"] ;
			dc["ConfirmDateTo"]	= searchCondition["ConfirmDateTo"] ;
			dc["Area"]	= searchCondition["Area"] ;
			dc["Bill"]	= searchCondition["Bill"] ;
			

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectICMSListForXls2") ;
			ADOHelper.FillDataSet (ps, ds, "TB_ICMS_LIST", currentPage, pageSize, dc) ;

			if( pageSize > 0 )
			{
				int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;
				PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;
			}

			return ds ;
		}
		public ICMSDS SelectIMACICMSListForXls( int currentPage, int pageSize, string order, NameValueCollection searchCondition  )
		{
			if(order==null || order=="") 
				order = "TicketNo" ; // ���ļ����� �������� �������

			ICMSDS ds = new ICMSDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"]	= searchCondition["TicketNo"] ;
			dc["AssetNo"]	= searchCondition["AssetNo"] ;
			dc["EmpNo"]	= searchCondition["EmpNo"] ;
			dc["EmpName"]	= searchCondition["EmpName"] ;
			dc["Engineer"]	= searchCondition["Engineer"] ;
			dc["ServiceType"]	= searchCondition["ServiceType"] ;
			dc["ConfirmFlag"]	= searchCondition["ConfirmFlag"] ;
			dc["ActivityDateFrom"]	= searchCondition["ActivityDateFrom"] ;
			dc["ActivityDateTo"]	= searchCondition["ActivityDateTo"] ;
			dc["ConfirmDateFrom"]	= searchCondition["ConfirmDateFrom"] ;
			dc["ConfirmDateTo"]	= searchCondition["ConfirmDateTo"] ;
			dc["Area"]	= searchCondition["Area"] ;
			dc["Bill"]	= searchCondition["Bill"] ;
			

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectIMACICMSListForXls") ;
			ADOHelper.FillDataSet (ps, ds, "TB_ICMS_LIST", currentPage, pageSize, dc) ;

			if( pageSize > 0 )
			{
				int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;
				PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;
			}

			return ds ;
		}
		public ICMSDS SelectRefreshListForXls( int currentPage, int pageSize, string order, NameValueCollection searchCondition  )
		{
			if(order==null || order=="") 
				order = "TicketNo" ; // ���ļ����� �������� �������

			ICMSDS ds = new ICMSDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"]	= searchCondition["TicketNo"] ;
			dc["AssetNo"]	= searchCondition["AssetNo"] ;
			dc["EmpNo"]	= searchCondition["EmpNo"] ;
			dc["EmpName"]	= searchCondition["EmpName"] ;
			dc["Engineer"]	= searchCondition["Engineer"] ;
			dc["ServiceType"]	= searchCondition["ServiceType"] ;
			dc["ConfirmFlag"]	= searchCondition["ConfirmFlag"] ;
			dc["ActivityDateFrom"]	= searchCondition["ActivityDateFrom"] ;
			dc["ActivityDateTo"]	= searchCondition["ActivityDateTo"] ;
			dc["ConfirmDateFrom"]	= searchCondition["ConfirmDateFrom"] ;
			dc["ConfirmDateTo"]	= searchCondition["ConfirmDateTo"] ;
			dc["Area"]	= searchCondition["Area"] ;
			dc["Bill"]	= searchCondition["Bill"] ;
			

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectRefreshListForXls") ;
			ADOHelper.FillDataSet (ps, ds, "TB_ICMS_LIST", currentPage, pageSize, dc) ;

			if( pageSize > 0 )
			{
				int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;
				PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;
			}

			return ds ;
		}

		public ICMSDS SelectTicket( string TicketNo )
		{
			ICMSDS ds = new ICMSDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"]	= TicketNo ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectTicket", ds.TB_ICMS) ;
			ADOHelper.FillDataSet (ps, ds, new string[] {"TB_ICMS"}, dc) ;

			return ds;
		}


		public ICMSDS SelectICMSAsset( string TicketNo, string AssetNo )
		{
			ICMSDS ds = new ICMSDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"]	= TicketNo ;
			dc["AssetNo"] = AssetNo;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectICMSAsset") ;
			ADOHelper.FillDataSet (ps, ds, new string[] {"TB_ICMS_ASSET"}, dc) ;

			return ds;
		}

		public ICMSDS SelectAssetDetail( string AssetNo )
		{
			ICMSDS ds = new ICMSDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["AssetNo"]	= AssetNo ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectAssetDetail") ;
			ADOHelper.FillDataSet (ps, ds, new string[] {"TB_ICMS_DETAIL"}, dc) ;

			return ds;
		}

		public ICMSDS SelectAssetList( string EmpNo, string TicketNo )
		{
			ICMSDS ds = new ICMSDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["EmpNo"]	= EmpNo ;
			dc["TicketNo"]	= TicketNo ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectAssetList") ;
			ADOHelper.FillDataSet (ps, ds, new string[] {"TB_ICMS_ASSET"}, dc) ;

			return ds;
		}

		#endregion

		public void ConfirmICMS( string TicketNo, string UserID )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"]	= TicketNo;
			dc["UserID"] = UserID;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "ConfirmICMS" ) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		public void CancelICMS( string TicketNo, string UserID )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"]	= TicketNo;
			dc["UserID"] = UserID;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "CancelICMS" ) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		
	}
}
