using System;
using System.Collections;
using System.EnterpriseServices;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.ICMS.DA;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.ICMS.Biz
{
	/// <summary>
	/// ICMSBizTx�� ���� ��� �����Դϴ�.
	/// </summary>
	public class ICMSBizTx : LGCNS.LAF.Biz.BizTxBase
	{
		public ICMSBizTx() {}

		#region ManageICMS

		[AutoComplete(true)]
		public void InsertICMS(ICMSDS ds)
		{
			ICMSDA da = null;
			
			try
			{
				da = new ICMSDA ();
				da.InsertICMS(ds);		
				//da.InsertICMSAsset(ds);
				da.InsertICMSDetail(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		[AutoComplete(true)]
		public void UpdateICMS(ICMSDS ds)
		{
			ICMSDA da = null;
	
			try
			{
				da = new ICMSDA();
				da.UpdateICMS(ds);
//				da.UpdateICMSAsset(ds);
				da.DeleteICMSDetail(ds);
				da.InsertICMSDetail(ds);

			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		
		[AutoComplete(true)]
		public void DeleteICMS(ICMSDS ds)
		{
			ICMSDA da = null;
			
			try
			{
				da = new ICMSDA();
				da.DeleteICMS(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		#endregion

		#region ManageICMSAsset

		public void InsertICMSAsset(ICMSDS ds)
		{
			ICMSDA da = null;
			
			try
			{
				da = new ICMSDA ();
				da.InsertICMSAsset(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}
		//20060525 lglsy - �ڻ��߰��ϸ鼭 detail ������ �߰��ϵ��� ������.
		public void InsertICMSAssetDetail (ICMSDS ds)
		{
			ICMSDA da = null;
			
			try
			{
				da = new ICMSDA ();
				da.InsertICMSAssetDetail(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		[AutoComplete(true)]
		public void UpdateICMSAsset(ICMSDS ds)
		{
			ICMSDA da = null;
	
			try
			{
				da = new ICMSDA();
				da.UpdateICMSAsset(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		public void DeleteICMSAsset(ICMSDS ds)
		{
			ICMSDA da = null;
			
			try
			{
				da = new ICMSDA();
				da.DeleteICMSAsset(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		#endregion


		public void ConfirmICMS( string TicketNo, string UserID )
		{
			ICMSDA da = null;
			
			try
			{
				da = new ICMSDA();
				da.ConfirmICMS(TicketNo,UserID);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}
		
		public void CancelICMS( string TicketNo, string UserID )
		{
			ICMSDA da = null;
			
			try
			{
				da = new ICMSDA();
				da.CancelICMS(TicketNo,UserID);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		public void UpdateEmp( EmpDS ds )
		{
			LGCNS.SITE.Emp.Biz.EmpBizTx biz = null;

			try
			{
				biz = new LGCNS.SITE.Emp.Biz.EmpBizTx();
				biz.UpdateEmp( ds );
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
	}
}
