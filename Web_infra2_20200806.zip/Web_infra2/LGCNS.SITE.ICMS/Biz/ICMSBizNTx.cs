using System;
using System.Collections.Specialized;
using System.EnterpriseServices;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.ICMS.DA;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.ICMS.Biz
{
	/// <summary>
	/// ICMSBizNTx�� ���� ��� �����Դϴ�.
	/// </summary>
	public class ICMSBizNTx : LGCNS.LAF.Biz.BizNTxBase
	{
		public ICMSBizNTx() {}
		

		public ICMSDS SelectICMS( string TicketNo )
		{
			ICMSDS ds = null;
			ICMSDA da = null;

			try
			{
				da = new ICMSDA ();
				ds = da.SelectICMS(TicketNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public ICMSDS SelectIMACList( string FromDate, string ToDate )
		{
			ICMSDS ds = null;
			ICMSDA da = null;

			try
			{
				da = new ICMSDA ();
				ds = da.SelectIMACList( FromDate, ToDate );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}
		public ICMSDS SelectICMSList( int currentPage, int pageSize, string order, NameValueCollection searchCondition )
		{
			ICMSDS ds = null;
			ICMSDA da = null;

			try
			{
				da = new ICMSDA ();
				ds = da.SelectICMSList(currentPage,pageSize,order,searchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public ICMSDS SelectICMSListForXls( int currentPage, int pageSize, string order, NameValueCollection searchCondition )
		{
			ICMSDS ds = null;
			ICMSDA da = null;

			try
			{
				da = new ICMSDA ();
				ds = da.SelectICMSListForXls(currentPage,pageSize,order,searchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public ICMSDS SelectICMSListForXls2( int currentPage, int pageSize, string order, NameValueCollection searchCondition )
		{
			ICMSDS ds = null;
			ICMSDA da = null;

			try
			{
				da = new ICMSDA ();
				ds = da.SelectICMSListForXls2(currentPage,pageSize,order,searchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}
		public ICMSDS SelectIMACICMSListForXls( int currentPage, int pageSize, string order, NameValueCollection searchCondition )
		{
			ICMSDS ds = null;
			ICMSDA da = null;

			try
			{
				da = new ICMSDA ();
				ds = da.SelectIMACICMSListForXls(currentPage,pageSize,order,searchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public ICMSDS SelectRefreshListForXls( int currentPage, int pageSize, string order, NameValueCollection searchCondition )
		{
			ICMSDS ds = null;
			ICMSDA da = null;

			try
			{
				da = new ICMSDA ();
				ds = da.SelectRefreshListForXls(currentPage,pageSize,order,searchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public ICMSDS SelectTicket( string TicketNo )
		{
			ICMSDS ds = null;
			ICMSDA da = null;

			try
			{
				da = new ICMSDA ();
				ds = da.SelectTicket(TicketNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public ICMSDS SelectICMSAsset( string TicketNo, string AssetNo )
		{
			ICMSDS ds = null;
			ICMSDA da = null;

			try
			{
				da = new ICMSDA ();
				ds = da.SelectICMSAsset(TicketNo,AssetNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}


		public ICMSDS SelectAssetDetail( string AssetNo )
		{
			ICMSDS ds = null;
			ICMSDA da = null;

			try
			{
				da = new ICMSDA ();
				ds = da.SelectAssetDetail(AssetNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}


		public ICMSDS SelectAssetList( string EmpNo, string TicketNo )
		{
			ICMSDS ds = null;
			ICMSDA da = null;

			try
			{
				da = new ICMSDA ();
				ds = da.SelectAssetList(EmpNo,TicketNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public UserDS SelectUser( string UserID )
		{
			UserDS ds = null;
			LGCNS.SITE.User.Biz.UserBizNTx biz = null;

			try
			{
				biz = new LGCNS.SITE.User.Biz.UserBizNTx();
				ds = biz.SelectUser( UserID );
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}

		public EmpDS SelectEmp( string Area, string EmpNo )
		{
			EmpDS ds = null;
			LGCNS.SITE.Emp.Biz.EmpBizNTx biz = null;

			try
			{
				biz = new LGCNS.SITE.Emp.Biz.EmpBizNTx();
				ds = biz.SelectEmp( Area, EmpNo );
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}

		public AssetDS SelectAsset( string AssetNo )
		{
			AssetDS ds = null;
			LGCNS.SITE.Asset.Biz.AssetBizNTx biz = null;

			try
			{
				biz = new LGCNS.SITE.Asset.Biz.AssetBizNTx();
				ds = biz.SelectAsset( AssetNo );
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}

		public CodeDS SelectSite( string Area, string SiteCode )
		{
			CodeDS ds = null;
			LGCNS.SITE.Code.Biz.CodeBizNTx biz = null;

			try
			{
				biz = new LGCNS.SITE.Code.Biz.CodeBizNTx();
				ds = biz.SelectSiteList( Area, SiteCode, "", "" );
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}
	}
}
