using System;
using System.EnterpriseServices;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Collections.Specialized;

using LGCNS.LAF.DA;
using LGCNS.LAF.Common.Exceptions;
using LGCNS.LAF.Common.DataAccess;
using LGCNS.LAF.Common.Paging ;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.Ticket.DA
{
	/// <summary>
	/// TicketDA�� ���� ��� �����Դϴ�.
	/// </summary>
	public class TicketDA : LGCNS.LAF.DA.DABase
	{
		private const string PROJECT_NAME	= "LGCNS.SITE.Ticket" ;
		private const string CLASS_NAME		= "LGCNS.SITE.Ticket.DA.TicketDA" ;

		public TicketDA() {}

		[AutoComplete(true)]
		public void InsertTicket(TicketDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertTicket", ds.TB_TICKET ) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_TICKET[0]) ;
			string ticketNo = ps.DataParameters ["@TicketNo"].Value.ToString();

			InsertTicketEmp(ds, ticketNo) ;
		}

		
		[AutoComplete(true)]
		private void InsertTicketEmp(TicketDS ds, string ticketNo)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertTicketEmp", ds.TB_TICKET_EMP ) ;
			foreach( TicketDS.TB_TICKET_EMPRow dr in ds.TB_TICKET_EMP.Rows )
			{
				dr.TicketNo = ticketNo;
				ADOHelper.ExecuteNonQuery (ps, dr);
			}
		}


		[AutoComplete(true)]
		public void UpdateTicket(TicketDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateTicket", ds.TB_TICKET ) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_TICKET[0]) ;

			string TicketNo = ps.DataParameters ["@TicketNo"].Value.ToString() ;

			DeleteTicketEmp( TicketNo );
			InsertTicketEmp( ds, TicketNo ) ;
		}


		[AutoComplete(true)]
		public void UpdateTicketEmp(TicketDS ds, string ticketNo)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateTicketEmp", ds.TB_TICKET_EMP ) ;
			foreach( TicketDS.TB_TICKET_EMPRow dr in ds.TB_TICKET_EMP.Rows )
			{
				dr.TicketNo = ticketNo;
				ADOHelper.ExecuteNonQuery (ps, dr);
			}
		}


		[AutoComplete(true)]
		public void UpdateTicketForEngineer(TicketDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateTicketForEngineer", ds.TB_TICKET ) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_TICKET[0]) ;
		}


		[AutoComplete(true)]
		public void DeleteTicket(string TicketNo)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = TicketNo;

			DeleteTicketEmp( TicketNo );

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteTicket" ) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}


		[AutoComplete(true)]
		public void DeleteTicketEmp(string ticketNo)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = ticketNo;

			LPreparedStatement ps = LPreparedStatementFactory.Create( PROJECT_NAME, CLASS_NAME, "DeleteTicketEmp" );
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}




		[AutoComplete(true)]
		public string InsertTicketTemp(TicketDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertTicketTemp", ds.TB_TICKET_TEMP ) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_TICKET_TEMP[0]) ;

			//�ű� ������ Ticket�� TicketID �� Return
			return ps.DataParameters["@TicketID"].Value.ToString();
		}


		[AutoComplete(true)]
		public void DeleteTicketASSET( string TicketID, string TicketNo )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketID"] = Convert.ToInt32(TicketID);
			dc["TicketNo"] = TicketNo;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteTicketASSET" ) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		[AutoComplete(true)]
		public void DeleteTicketTemp( string TicketID )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketID"] = TicketID;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteTicketTemp" ) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}


		[AutoComplete(true)]
		public void UpdateTicketTempForEngineer(TicketDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateTicketTempForEngineer", ds.TB_TICKET_TEMP ) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_TICKET_TEMP[0]) ;
		}


		[AutoComplete(true)]
		public TicketDS SelectTicket(string ticketNo)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = ticketNo;

			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectTicket") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_TICKET_ENTIRE","TB_TICKET_EMP_ENTIRE"}, dc) ;

			return ds ;
		}

        [AutoComplete(true)]
        public string isValidTicket(string ticketNo)
        {
            string result="";
            LDataCollection dc = new LDataCollection () ;
            dc["TicketNo"] = ticketNo;

            LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "isValidTicket") ;
            ADOHelper.ExecuteNonQuery (ps, dc) ;
            result = ps.DataParameters["@Result"].Value.ToString();
            return result;
        }

		[AutoComplete(true)]
		public TicketDS SelectMailTicket(string ticketNo, string TicketID, string SRFlag)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = ticketNo;
			dc["TicketID"] = TicketID;
			dc["SRFlag"] = SRFlag;

			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectMailTicket") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_TICKET_MAIL"}, dc) ;

			return ds ;
		}

		[AutoComplete(true)]
		public TicketDS SelectTicketTemp(string TicketID)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketID"] = TicketID;

			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectTicketTemp") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_TICKET_ENTIRE","TB_TICKET_EMP_ENTIRE"}, dc) ;

			return ds ;
		}

		
		[AutoComplete(true)]
		public TicketDS SelectTicketListByEmp(string Area, string EmpNo, string TicketNo)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Area"] = Area;
			dc["EmpNo"] = EmpNo;
			dc["TicketNo"] = TicketNo;

			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectTicketListByEmp") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_TICKET_LIST"}, dc) ;

			return ds ;
		}
//lglsy 20051107 ticketno , assetno ����
		[AutoComplete(true)]
		public TicketDS InsertTicketAssetData( string TicketID, string TicketNo,string AssetNo , string CompStatus, string CPUType, string ModelNumber)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketID"] = TicketID;
			dc["TicketNo"] = TicketNo;
			dc["AssetNo"] = AssetNo;
			dc["CompStatus"] = CompStatus;
			dc["CPUType"] = CPUType;
			dc["ModelNumber"] = ModelNumber;

			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertTicketAssetData") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_TICKET_ASSET"}, dc) ;

			return ds ;
		}

		//lglsy 20051014 �߰� InsertTicket���� Add Ŭ���� Asset Information�� ���̱� ����
		[AutoComplete(true)]
		public TicketDS SelectTicketAssetList(string Area, string EmpNo)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Area"] = Area;
			dc["EmpNo"] = EmpNo;

			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectTicketAssetList") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_TICKET_ASSETLIST"}, dc) ;

			return ds ;
		}		

		//lglsy 20051107 �߰� �ڻ� ������
		[AutoComplete(true)]
		public TicketDS isSelectTicketAssetList(string TicketNo, string TicketID)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = TicketNo;
			dc["TicketID"] = TicketID;

			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "isSelectTicketAssetList") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_TICKET_ASSETLIST"}, dc) ;

			return ds ;
		}	

		//lglsy 20051014 �߰� InsertTicket���� Add Ŭ���� Asset Information�� ���̱� ����
		[AutoComplete(true)]
		public TicketDS isGetAsset(string AssetNo)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["AssetNo"] = AssetNo;

			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectTicketAsset") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_TICKET_ASSETLIST"}, dc) ;

			return ds ;
		}	
		
		
		[AutoComplete(true)]
		public TicketDS SelectTicketList(int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["QueryType"] = searchCondition["QueryType"];
			dc["Area"] = searchCondition["Area"];
			dc["TicketNo"] = searchCondition["TicketNo"];
			dc["CreateDateFrom"] = searchCondition["CreateDateFrom"];
			dc["CreateDateTo"] = searchCondition["CreateDateTo"];
			dc["CloseDateFrom"] = searchCondition["CloseDateFrom"];
			dc["CloseDateTo"] = searchCondition["CloseDateTo"];
			dc["HdConfirm"] = searchCondition["HdConfirm"];
			dc["Status"] = searchCondition["Status"];
			dc["EmpNo"] = searchCondition["EmpNo"];
			dc["EmpName"] = searchCondition["EmpName"];
			dc["Engineer"] = searchCondition["Engineer"];
			dc["CreateID"] = searchCondition["CreateID"];
			dc["CompleteFlag"] = searchCondition["CompleteFlag"];
			dc["Division"] = searchCondition["Division"];
			dc["Engineer2"] = searchCondition["Engineer2"];
			dc["SiteCode"] = searchCondition["SiteCode"];
			dc["Description"] = searchCondition["Description"];

			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectTicketList") ;
			ADOHelper.FillDataSet (ps, ds, "TB_TICKET_LIST", currentPage, pageSize, dc) ;

			if( pageSize > 0 )
			{
				int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;

				PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;
			}

			return ds ;
		}
//20060502 Ticket���� ������ ��ϵȰ͵� ���̵��� ��.(HomePage.aspx����)
		[AutoComplete(true)]
		public TicketDS SelectTicketListHome(int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["QueryType"] = searchCondition["QueryType"];
			dc["Area"] = searchCondition["Area"];
			dc["TicketNo"] = searchCondition["TicketNo"];
			dc["CreateDateFrom"] = searchCondition["CreateDateFrom"];
			dc["CreateDateTo"] = searchCondition["CreateDateTo"];
			dc["CloseDateFrom"] = searchCondition["CloseDateFrom"];
			dc["CloseDateTo"] = searchCondition["CloseDateTo"];
			dc["HdConfirm"] = searchCondition["HdConfirm"];
			dc["Status"] = searchCondition["Status"];
			dc["EmpNo"] = searchCondition["EmpNo"];
			dc["EmpName"] = searchCondition["EmpName"];
			dc["Engineer"] = searchCondition["Engineer"];
			dc["CreateID"] = searchCondition["CreateID"];
			dc["CompleteFlag"] = searchCondition["CompleteFlag"];
			dc["Division"] = searchCondition["Division"];
			dc["Engineer2"] = searchCondition["Engineer2"];
			dc["SiteCode"] = searchCondition["SiteCode"];

			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectTicketListHome") ;
			ADOHelper.FillDataSet (ps, ds, "TB_TICKET_LIST", currentPage, pageSize, dc) ;

			if( pageSize > 0 )
			{
				int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;

				PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;
			}

			return ds ;
		}


		[AutoComplete(true)]
		public TicketDS SelectIMACTicketListXls(int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			LDataCollection dc = new LDataCollection () ;
			//			dc["QueryType"] = searchCondition["QueryType"];
			//			dc["ConfirmFlag"] = searchCondition["ConfirmFlag"];
			dc["ConfirmDateFrom"] = searchCondition["ConfirmDateFrom"];
			dc["ConfirmDateTo"] = searchCondition["ConfirmDateTo"];

			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectIMACTicketListXls") ;
			ADOHelper.FillDataSet (ps, ds, "TB_TICKET_LIST", currentPage, pageSize, dc) ;

			if( pageSize > 0 )
			{
				int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;

				PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;
			}

			return ds ;
		}
		[AutoComplete(true)]
		public TicketDS SelectTicketList3Days(int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["QueryType"] = searchCondition["QueryType"];
			dc["Area"] = searchCondition["Area"];
			dc["TicketNo"] = searchCondition["TicketNo"];
			dc["CreateDateFrom"] = searchCondition["CreateDateFrom"];
			dc["CreateDateTo"] = searchCondition["CreateDateTo"];
			dc["CloseDateFrom"] = searchCondition["CloseDateFrom"];
			dc["CloseDateTo"] = searchCondition["CloseDateTo"];
			dc["HdConfirm"] = searchCondition["HdConfirm"];
			dc["Status"] = searchCondition["Status"];
			dc["EmpNo"] = searchCondition["EmpNo"];
			dc["EmpName"] = searchCondition["EmpName"];
			dc["Engineer"] = searchCondition["Engineer"];
			dc["CreateID"] = searchCondition["CreateID"];
			dc["CompleteFlag"] = searchCondition["CompleteFlag"];
			dc["Division"] = searchCondition["Division"];

			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectTicketList3Days") ;
			ADOHelper.FillDataSet (ps, ds, "TB_TICKET_LIST", currentPage, pageSize, dc) ;

			if( pageSize > 0 )
			{
				int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;

				PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;
			}

			return ds ;
		}
		[AutoComplete(true)]
		public TicketDS SelectTicketListXls(int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["QueryType"] = searchCondition["QueryType"];
			dc["Area"] = searchCondition["Area"];
			dc["TicketNo"] = searchCondition["TicketNo"];
			dc["CreateDateFrom"] = searchCondition["CreateDateFrom"];
			dc["CreateDateTo"] = searchCondition["CreateDateTo"];
			dc["CloseDateFrom"] = searchCondition["CloseDateFrom"];
			dc["CloseDateTo"] = searchCondition["CloseDateTo"];
			dc["HdConfirm"] = searchCondition["HdConfirm"];
			dc["Status"] = searchCondition["Status"];
			dc["EmpNo"] = searchCondition["EmpNo"];
			dc["EmpName"] = searchCondition["EmpName"];
			dc["Engineer"] = searchCondition["Engineer"];
			dc["CreateID"] = searchCondition["CreateID"];
			dc["CompleteFlag"] = searchCondition["CompleteFlag"];
			dc["Division"] = searchCondition["Division"];
			dc["SiteCode"] = searchCondition["SiteCode"];
			dc["Description"] = searchCondition["Description"];

			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectTicketListXls") ;
			ADOHelper.FillDataSet (ps, ds, "TB_TICKET_LIST", currentPage, pageSize, dc) ;

			if( pageSize > 0 )
			{
				int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;

				PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;
			}

			return ds ;
		}

		public DataSet SelectDSR( string Area, string DateFrom, string Dateto )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Area"] = Area;
			dc["DateFrom"] = DateFrom;
			dc["DateTo"] = Dateto;

			DataSet ds = new DataSet();

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectDSR") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_DSR_TICKET", "TB_DSR_TICKET_LIST", "TB_DSR_SRPF", "TB_DSR_SRPF_LIST", "TB_DSR_ICMS", "TB_DSR_ICMS_LIST", "TB_DSR_ICMS_MONTH_LIST"}, dc) ;

			return ds ;
		}
		

		[AutoComplete(true)]
		public void ConfirmTicket(string TicketNo)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = TicketNo;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "ConfirmTicket" ) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		[AutoComplete(true)]
		public void ConfirmCancelTicket(string TicketNo)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = TicketNo;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "ConfirmCancelTicket" ) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		[AutoComplete(true)]
		public void SendSurvey(string TicketNo)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = TicketNo;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SendSurvey" ) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		[AutoComplete(true)]
		public bool CheckSurvey(string TicketNo)
		{
			string ResultStatement = "";

			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = TicketNo;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "CheckSurvey" ) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;

			ResultStatement = ps.DataParameters["@ResultStatement"].Value.ToString();

			if( ResultStatement.CompareTo("") > 0 )
				return true;
			else
				return false;
		}

		[AutoComplete(true)]
		public void InsertTicketBulk(TicketDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertTicketBulk", ds.TB_TICKET_BULK ) ;
			DeleteTicketBulk();
			foreach( TicketDS.TB_TICKET_BULKRow dr in ds.TB_TICKET_BULK.Rows )
			{
				try
				{
					ADOHelper.ExecuteNonQuery (ps, dr);
				}
				catch( Exception ex )
				{
					LGCNS.LAF.Common.Log.LogManager.Publish( ex, "TicketBulkImport", dr.TicketNo );
				}
			}
		}

		[AutoComplete(true)]
		public void DeleteTicketBulk()
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = "";
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteTicketBulk") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

        [AutoComplete(true)]
        public void DeleteErrorCapexNo()
        {
            LDataCollection dc = new LDataCollection () ;
            dc["TicketNo"] = "";
            LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteErrorCapexNo") ;
            ADOHelper.ExecuteNonQuery (ps, dc) ;
        }
        

		public string BulkInsertTicket( string UserID, string Area )
		{
			string ResultStatement = "";

			LDataCollection dc = new LDataCollection () ;
			dc["UserID"] = UserID;
			dc["Area"] = Area;
			dc["ResultStatement"] = ResultStatement;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "BulkInsertTicket" ) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;

			ResultStatement = ps.DataParameters["@ResultStatement"].Value.ToString();

			return ResultStatement;
		}


		public string SelectMailCheck( string ticketNo )
		{
			string ResultStatement = "";

			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = ticketNo;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectMailCheck" ) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;

			ResultStatement = ps.DataParameters["@ResultStatement"].Value.ToString();

			return ResultStatement;
		}

		#region Capex
		[AutoComplete(true)]
		public TicketDS SelectMailCapex( )
		{
			LDataCollection dc = new LDataCollection () ;

			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectMailCapex") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_BASE_MAIL"}, dc) ;

			return ds ;
		}

		[AutoComplete(true)]
		public CapexDS SelectCapexTicket( string TicketNo )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = TicketNo;

			CapexDS ds = new CapexDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectCapexTicket") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_CAPEX_LIST1"}, dc) ;

			return ds ;
		}

		
		public string CreateCapex( string TicketNo, string Area, string UserID, string Flag )
		{
			string ResultStatement = "";

			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = TicketNo;
			dc["Area"] = Area;
			dc["UserID"] = UserID;
			dc["Flag"] = Flag;
			dc["ResultStatement"] = ResultStatement;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "CreateCapex" ) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;

			ResultStatement = ps.DataParameters["@ResultStatement"].Value.ToString();

			return ResultStatement;
		}

		#endregion
	}
}
