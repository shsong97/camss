using System;
using System.Collections;
using System.EnterpriseServices;

using LGCNS.LAF.Common.Exceptions;
using LGCNS.LAF.Common.Log;

using LGCNS.SITE.Ticket.DA;
using LGCNS.SITE.DTO;
using LGCNS.LAF.Common.FileManagement;

using System.IO;
using System.Configuration;
using System.Text;

namespace LGCNS.SITE.Ticket.Biz
{
	public class TicketBizTx : LGCNS.LAF.Biz.BizTxBase
	{
		public TicketBizTx() {}

		[AutoComplete(true)]
		public void InsertTicket(TicketDS ds)
		{
			TicketDA da = null;
			
			try
			{
				da = new TicketDA ();
				da.InsertTicket(ds);				
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		[AutoComplete(true)]
		public void UpdateTicket(TicketDS ds)
		{
			TicketDA da = null;
	
			try
			{
				da = new TicketDA();
				da.UpdateTicket(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		[AutoComplete(true)]
		public void UpdateTicketForEngineer(TicketDS ds)
		{
			TicketDA da = null;
	
			try
			{
				da = new TicketDA();
				da.UpdateTicketForEngineer(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		public void DeleteTicket( string TicketNo )
		{
			TicketDA da = null;
			
			try
			{
				da = new TicketDA();
				da.DeleteTicket( TicketNo );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}



		//[AutoComplete(true)]
		public string InsertTicketTemp(TicketDS ds)
		{
			TicketDA da = null;
			string TicketID;
			
			try
			{
				da = new TicketDA ();
				TicketID = da.InsertTicketTemp(ds);				
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return TicketID;
		}


		[AutoComplete(true)]
		public void UpdateTicketTempForEngineer(TicketDS ds)
		{
			TicketDA da = null;
	
			try
			{
				da = new TicketDA();
				da.UpdateTicketTempForEngineer(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

	[AutoComplete(true)]
		public void DeleteTicketASSET( string TicketID, string TicketNo )
	{
		TicketDA da = null;
			
		try
		{
			da = new TicketDA();
			da.DeleteTicketASSET( TicketID, TicketNo );
		}
		catch(Exception ex)
		{
			throw new BizException(ex.Message, ex) ;
		}
		finally
		{
			if(da != null)
			{
				da.Dispose();
				da = null;
			}
		}
	}

		
		[AutoComplete(true)]
		public void DeleteTicketTemp( string TicketID )
		{
			TicketDA da = null;
			
			try
			{
				da = new TicketDA();
				da.DeleteTicketTemp( TicketID );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		public void ConfirmTicket( string TicketNo )
		{
			TicketDA da = null;
			
			try
			{
				da = new TicketDA();
				da.ConfirmTicket( TicketNo );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		public void ConfirmCancelTicket( string TicketNo )
		{
			TicketDA da = null;
			
			try
			{
				da = new TicketDA();
				da.ConfirmCancelTicket( TicketNo );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		public void SendSurvey( string TicketNo )
		{
			TicketDA da = null;
			
			try
			{
				da = new TicketDA();
				da.SendSurvey( TicketNo );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		public bool CheckSurvey( string TicketNo )
		{
			TicketDA da = null;
			bool CheckBit=false;

			try
			{
				da = new TicketDA();
				CheckBit=da.CheckSurvey( TicketNo );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
			return CheckBit;
		}


		public void FileSave( FileTransferObject fto )
		{
			try
			{
				FileManager.Save(fto);
				System.Threading.Thread.Sleep( 1000 );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
		}


		public void FileDelete( FileTransferObject fto )
		{
			try
			{
				FileManager.Delete( fto.FilePath );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
		}

        public void DeleteErrorCapexNo()
        {
            TicketDA da = null;
			
            try
            {
                da = new TicketDA();
                da.DeleteErrorCapexNo();
            }
            catch(Exception ex)
            {
                throw new BizException(ex.Message, ex) ;
            }
            finally
            {
                if(da != null)
                {
                    da.Dispose();
                    da = null;
                }
            }
        }
        

		public TicketDS BulkImport( FileTransferObject fto )
		{
			TicketDS ds = null;

			try
			{
				string FileFullName = LGCNS.LAF.Common.FileManagement.Configuration.RealRootPath + fto.FilePath;

				ds = BindCSVFile( FileFullName );

				InsertTicketBulk( ds );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}

			return ds;
		}

		
		[AutoComplete(true)]
		public void InsertTicketBulk(TicketDS ds)
		{
			TicketDA da = null;
			
			try
			{
				da = new TicketDA ();
				da.InsertTicketBulk(ds);				
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		public string SelectMailCheck(string ticketNo)
		{
			TicketDA da = null;
			string ResultStatement = "";

			try
			{
				da = new TicketDA();
				ResultStatement = da.SelectMailCheck(ticketNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ResultStatement;
		}

		public string BulkInsertTicket(string UserID, string Area)
		{
			TicketDA da = null;
			string ResultStatement = "";
			
			try
			{
				da = new TicketDA ();
				ResultStatement = da.BulkInsertTicket(UserID,Area);				
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ResultStatement;
		}


		private TicketDS BindCSVFile( string FileName )
		{
			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;
			TicketDS.TB_TICKET_BULKRow dr = null;

			try
			{
				char[] chIndex1 = {','};
				char[] chIndex2 = {'\"'};

				int cntCol;
			
				StreamReader sr = new StreamReader(FileName,Encoding.Default);

				sr.ReadLine();	//ù��°���� ����������� �ν���

				do
				{
					dr = ds.TB_TICKET_BULK.NewTB_TICKET_BULKRow();

					cntCol = 0;

					string strTextSource = sr.ReadLine();	//�����б�
					string strTextTemp = strTextSource;

					while( strTextTemp.Length > 0 )
					{
						string strTemp = "";

						if ( strTextTemp.IndexOfAny(chIndex1) == 0 )
						{
							strTextTemp = strTextTemp.Substring(1);
						}

						int strLen1 = strTextTemp.IndexOfAny(chIndex1);	//,�� ��ġ
						int strLen2 = strTextTemp.IndexOfAny(chIndex2); //"�� ��ġ

						if ( strLen1 < 0 )	//comma�� ������
						{
							strTemp = strTextTemp;
							strTextTemp = "";
						}
						else
						{
							if ((strLen2 == -1) || ( strLen2 > strLen1 ))
							{
								strTemp = strTextTemp.Substring(0, strLen1);
								strTextTemp = strTextTemp.Substring(strLen1);
							}
							else
							{
								strTextTemp = strTextTemp.Substring(1);

								int strLen3 = strTextTemp.IndexOfAny(chIndex2);
								int strLen4 = strTextTemp.Substring(strLen3+1).IndexOfAny(chIndex2);

								if ( strLen3< 0 )
								{
									strTemp = strTextTemp;
									strTextTemp = "";
								}
								else
								{
									if ( strLen4 == 0 )
									{
										int strLen5 = strTextTemp.Substring(strLen3+2).IndexOfAny(chIndex2);

										strTemp = strTextTemp.Substring(0, strLen5+strLen3+2);
										strTextTemp = strTextTemp.Substring(strLen5+strLen3+2 + 1);
									}
									else
									{
										strTemp = strTextTemp.Substring(0, strLen3);
										strTextTemp = strTextTemp.Substring(strLen3 + 1);
									}
								}
							}
						}

						dr[cntCol] = strTemp;

						cntCol = cntCol + 1;

						if ( cntCol == ds.TB_TICKET_BULK.Columns.Count )
						{
							break;
						}
					}
					// 2005-07-07 : CSV���Ͽ��� �� ������ �������� ������
					// ������ �Է� ����
					if( strTextSource.CompareTo("0") > 0 )
					{
						if ( dr.TicketNo.ToString().CompareTo( "0" ) > 0 )
						{
							ds.TB_TICKET_BULK.AddTB_TICKET_BULKRow( dr );
						}
					}

				} while(sr.Peek() != -1 );   //�������� �ɶ� ����    

				sr.Close();                 //streamReader�� �ݴ´�.

				return ds;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				
			}
			
		}

		#region Capex
		public string CreateCapex( string TicketNo, string Area, string UserID, string Flag )
		{
			TicketDA da = null;
			string ResultStatement = "";
			
			try
			{
				da = new TicketDA ();
				ResultStatement = da.CreateCapex(TicketNo, Area, UserID, Flag);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ResultStatement;
		}


		#endregion
	}
}
