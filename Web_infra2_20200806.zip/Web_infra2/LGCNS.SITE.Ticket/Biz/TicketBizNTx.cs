using System;
using System.EnterpriseServices;
using System.Data;
using System.Collections.Specialized;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.Ticket.DA;
using LGCNS.SITE.DTO;


namespace LGCNS.SITE.Ticket.Biz
{
	/// <summary>
	/// TicketBizNTx�� ���� ��� �����Դϴ�.
	/// </summary>
	public class TicketBizNTx : LGCNS.LAF.Biz.BizNTxBase
	{
		public TicketBizNTx() {}

		public TicketDS SelectTicket(string ticketNo)
		{
			TicketDS ds = null;
			TicketDA da = null;

			try
			{
				da = new TicketDA();
				ds = da.SelectTicket(ticketNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}


        public string isValidTicket(string ticketNo)
        {
            string result="";
            TicketDA da = null;

            try
            {
                da = new TicketDA();
                result = da.isValidTicket(ticketNo);
            }
            catch(Exception ex)
            {
                throw new BizException(ex.Message, ex) ;
            }
            finally
            {
                if(da != null)
                {
                    da.Dispose();
                    da = null;
                }
            }

            return result ;	

        }

		public TicketDS SelectMailTicket(string ticketNo, string TicketID, string SRFlag)
		{
			TicketDS ds = null;
			TicketDA da = null;

			try
			{
				da = new TicketDA();
				ds = da.SelectMailTicket(ticketNo, TicketID, SRFlag);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public TicketDS SelectTicketTemp(string TicketID)
		{
			TicketDS ds = null;
			TicketDA da = null;

			try
			{
				da = new TicketDA();
				ds = da.SelectTicketTemp(TicketID);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}


		public TicketDS SelectTicketListByEmp(string Area,string EmpNo, string TicketNo)
		{
			TicketDS ds = null;
			TicketDA da = null;

			try
			{
				da = new TicketDA();
				ds = da.SelectTicketListByEmp(Area, EmpNo, TicketNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}
//lglsy 20051107 ticketno , assetno ����
		public TicketDS InsertTicketAssetData( string TicketID, string TicketNo,string AssetNo , string CompStatus, string CPUType, string ModelNumber)
		{
			TicketDS ds = null;
			TicketDA da = null;

			try
			{
				da = new TicketDA();
				ds = da.InsertTicketAssetData (TicketID, TicketNo,AssetNo,  CompStatus,  CPUType,  ModelNumber);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}


		//lglsy 20051014 �߰� InsertTicket���� Add Ŭ���� Asset Information�� ���̱� ����
		public TicketDS SelectTicketAssetList(string Area, string EmpNo)
		{
			TicketDS ds = null;
			TicketDA da = null;

			try
			{
				da = new TicketDA();
				ds = da.SelectTicketAssetList(Area, EmpNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		//lglsy 20051107 �߰� �ڻ� ������
		public TicketDS isSelectTicketAssetList(string TicketNo, string TicketID)
		{
			TicketDS ds = null;
			TicketDA da = null;

			try
			{
				da = new TicketDA();
				ds = da.isSelectTicketAssetList( TicketNo, TicketID);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}


		//lglsy 20051014 �߰� InsertTicket���� Add Ŭ���� �ڻ����� �߰�
		public TicketDS isGetAsset(string AssetNo)
		{
			TicketDS ds = null;
			TicketDA da = null;

			try
			{
				da = new TicketDA();
				ds = da.isGetAsset(AssetNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}
		public TicketDS SelectIMACTicketListXls( int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			TicketDS ds = null;
			TicketDA da = null;

			try
			{
				da = new TicketDA();
				ds = da.SelectIMACTicketListXls(currentPage,pageSize,searchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public TicketDS SelectTicketList( int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			TicketDS ds = null;
			TicketDA da = null;

			try
			{
				da = new TicketDA();
				ds = da.SelectTicketList(currentPage,pageSize,searchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}
//20060502 Ticket���� ������ ��ϵȰ͵� ���̵��� ��.(HomePage.aspx����)
		public TicketDS SelectTicketListHome( int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			TicketDS ds = null;
			TicketDA da = null;

			try
			{
				da = new TicketDA();
				ds = da.SelectTicketListHome(currentPage,pageSize,searchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public TicketDS SelectTicketList3Days( int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			TicketDS ds = null;
			TicketDA da = null;

			try
			{
				da = new TicketDA();
				ds = da.SelectTicketList3Days(currentPage,pageSize,searchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}
		public TicketDS SelectTicketListXls( int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			TicketDS ds = null;
			TicketDA da = null;

			try
			{
				da = new TicketDA();
				ds = da.SelectTicketListXls(currentPage,pageSize,searchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public DataSet SelectDSR( string Area, string DateFrom, string Dateto )
		{
			DataSet ds = null;
			TicketDA da = null;

			try
			{
				da = new TicketDA();
				ds = da.SelectDSR(Area,DateFrom, Dateto);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public EmpDS SelectEmp(string Area, string EmpNo)
		{
			EmpDS ds = null;
			LGCNS.SITE.Emp.Biz.EmpBizNTx biz = null;

			try
			{
				biz = new LGCNS.SITE.Emp.Biz.EmpBizNTx();
				ds = biz.SelectEmp(Area,EmpNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}

		public EmpDS SelectEmp(string EmpNo)
		{
			EmpDS ds = null;
			LGCNS.SITE.Emp.Biz.EmpBizNTx biz = null;

			try
			{
				biz = new LGCNS.SITE.Emp.Biz.EmpBizNTx();
				ds = biz.SelectEmp(EmpNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}

		public ICMSDS SelectICMS( string TicketNo )
		{
			ICMSDS ds = null;
			LGCNS.SITE.ICMS.Biz.ICMSBizNTx biz = null;

			try
			{
				biz = new LGCNS.SITE.ICMS.Biz.ICMSBizNTx();
				ds = biz.SelectICMS( TicketNo );
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}

		public AcqDS SelectAcq( string TicketNo )
		{
			AcqDS ds = null;
			LGCNS.SITE.Acq.Biz.AcqBizNTx biz = null;

			try
			{
				biz = new LGCNS.SITE.Acq.Biz.AcqBizNTx();
				ds = biz.SelectAcq( TicketNo );
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}

		#region Capex
		public TicketDS SelectMailCapex( )
		{
			TicketDS ds = null;
			TicketDA da = null;

			try
			{
				da = new TicketDA();
				ds = da.SelectMailCapex();
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public CapexDS SelectCapexTicket( string TicketNo )
		{
			CapexDS ds = null;
			TicketDA da = null;

			try
			{
				da = new TicketDA();
				ds = da.SelectCapexTicket(TicketNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		#endregion
	}
}
