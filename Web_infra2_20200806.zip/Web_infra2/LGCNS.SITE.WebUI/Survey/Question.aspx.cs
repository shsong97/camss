using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;


namespace LGCNS.SITE.WebUI.SURVEY
{
	/// <summary>
	/// Question�� ���� ��� �����Դϴ�.
	/// </summary>
	public class Question : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Label lblTicketNo;
		protected System.Web.UI.WebControls.Label lblWork;
		protected System.Web.UI.WebControls.Button BtnSend;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdQuestion;
		protected System.Web.UI.WebControls.TextBox TbxJAns;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdJQuestion;
		protected System.Web.UI.WebControls.Label lblName;
		protected System.Web.UI.WebControls.Label lblWorkPlace;
		protected System.Web.UI.WebControls.Button BtnClose;
		protected System.Web.UI.WebControls.Label lblBizUnit;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.

			string TicketNo = this.Request["TicketNo"];
			string EmpNo = this.Request["uid"];
			this.BtnClose.Attributes.Add("OnClick","self.close()");
//			if (TicketNo  != null && EmpNo != null)
//			{
//				isSelectTicketDesc(TicketNo, EmpNo);
//				SelectKQuestion();
//				SelectJQuestion();
//			}

			if ( !Page.IsPostBack )
			{
				if (TicketNo  != null && EmpNo != null)
				{
					isSelectTicketDesc(TicketNo, EmpNo);
					SelectKQuestion();
					SelectJQuestion();
				}
			}

			if ( this.IsSubmittedBy )
			{
				if (TicketNo  != null && EmpNo != null)
				{
					isSelectTicketDesc(TicketNo, EmpNo);
					SelectKQuestion();
					SelectJQuestion();
				}
			}			
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSend.Click += new System.EventHandler(this.BtnSend_Click);
			this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		//lglsy 20051129 TicketNo ���� ������.
		private void isSelectTicketDesc(string TicketNo, string EmpNo)
		{
			SurveyDS ds = SurveyController.isSelectTicketDesc( TicketNo, EmpNo );
			
			if (ds.TB_TICKET_DESC[0].Area == "OEK")
			{
				this.lblBizUnit.Text = "Korea LG OTIS Elevator Company";
			}
			else if(ds.TB_TICKET_DESC[0].Area == "KCLC")
			{
				this.lblBizUnit.Text = "Carrier Ltd. Korea Ltd.(CLK)";
			}
			else
			{
				this.lblBizUnit.Text = "Carrier Refrigeration Korea (CRK)";
			}
//			this.lblBizUnit.Text = ds.TB_TICKET_DESC[0].Area;
			this.lblTicketNo.Text = ds.TB_TICKET_DESC[0].TicketNo;
			this.lblWork.Text = ds.TB_TICKET_DESC[0].TDescription;
			this.lblName.Text = ds.TB_TICKET_DESC[0].EmpName + " / " + ds.TB_TICKET_DESC[0].ContactNo;//tb_emp ���̺��� ������ �ؾ��ϴ���. db�� 
			this.lblWorkPlace.Text = ds.TB_TICKET_DESC[0].SiteDesc;//desc�� �ѷ��־����� �ϳ� �ٲٸ� ���Ϳ� ����Ǿ� �����µ� �װ��� ��������.
			                                                 //code�� �����ϰ� �ٲٸ� �����.

		}

		private void SelectKQuestion()
		{
			SurveyDS ds = SurveyController.SelectQuestion("K", "U");//������ ������ ������ΰ͸�
			this.DgrdQuestion.DataSource = ds.TB_SURVEY_QUEST;
			this.DgrdQuestion.DataBind();
		}

		private void SelectJQuestion()
		{
			SurveyDS ds = SurveyController.SelectQuestion("J", "U");//�ְ��� ������ ������ΰ͸�
			this.DgrdJQuestion.DataSource = ds.TB_SURVEY_QUEST;
			this.DgrdJQuestion.DataBind();
			if (this.DgrdJQuestion.Items.Count < 1 )
			{
				this.TbxJAns.Visible = false;
			}

		}

		private void BtnSend_Click(object sender, System.EventArgs e)
		{
			if ( this.DgrdQuestion.Items.Count > 0  )
			{
				string Result;
				SurveyDS ds = new SurveyDS();

				SurveyDS.TB_SURVEY_ANSWERRow rowANS = ds.TB_SURVEY_ANSWER.NewTB_SURVEY_ANSWERRow();

				rowANS.TicketNo = this.lblTicketNo.Text;
				rowANS.EmpNo = this.Request["uid"];
				if (((RadioButton)this.DgrdQuestion.Items[0].Cells[9].Controls[1]).Checked == true)  rowANS.ANS1 ="Y";
				else rowANS.ANS1 ="N";
				if (((RadioButton)this.DgrdQuestion.Items[1].Cells[9].Controls[1]).Checked == true)  rowANS.ANS2 ="Y";
				else rowANS.ANS2 ="N";
				if (((RadioButton)this.DgrdQuestion.Items[2].Cells[9].Controls[1]).Checked == true)  rowANS.ANS3 ="Y";
				else rowANS.ANS3 ="N";
				if (((RadioButton)this.DgrdQuestion.Items[3].Cells[9].Controls[1]).Checked == true)  rowANS.ANS4 ="Y";
				else rowANS.ANS4 ="N";
				if (((RadioButton)this.DgrdQuestion.Items[4].Cells[9].Controls[1]).Checked == true)  rowANS.ANS5 ="Y";
				else rowANS.ANS5 ="N";
				rowANS.ANS6 = this.TbxJAns.Text.Trim();
				rowANS.SendDate = "";
				rowANS.ReplyDate = "";

				ds.TB_SURVEY_ANSWER.AddTB_SURVEY_ANSWERRow(rowANS);
				//�ǵ����Ϳ� �ݿ�
				Result = SurveyController.InsertAnswerChk(this.lblTicketNo.Text);
				if (Result == "P") //7���� �������
				{
					ScriptHelper.ShowAlert(MessageManager.GetMessage("Common", "ANSWER_INSERT_PASS"));
				}
				else if (Result == "O") //������ ���
				{
					ScriptHelper.ShowAlert(MessageManager.GetMessage("Common", "ANSWER_INSERT_ON"));
				}
				else if (Result == "F") //������ ������������ ���°��
				{
					ScriptHelper.ShowAlert(MessageManager.GetMessage("Common", "ANSWER_INSERT_FALSE"));
				}
				else
				{
					SurveyController.InsertAnswer( ds );
					ScriptHelper.ShowAlert(MessageManager.GetMessage("Common", "ANSWER_INSERT_TRUE"));
				}
			}
			BtnSend.Visible = false;
			BtnClose.Visible = true;
		}

		private void BtnClose_Click(object sender, System.EventArgs e)
		{
			
		}
	}
}
