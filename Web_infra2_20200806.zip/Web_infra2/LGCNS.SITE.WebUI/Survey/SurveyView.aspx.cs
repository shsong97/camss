using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;


namespace LGCNS.SITE.WebUI.SURVEY
{
	/// <summary>
	/// SurveyView�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SurveyView : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Button BtnSearch;
		protected System.Web.UI.WebControls.Label LblTotalCount;
		protected System.Web.UI.WebControls.Label LblSatisfyCount;
		protected System.Web.UI.WebControls.Label LblNotSatisfyCount;
		protected System.Web.UI.WebControls.Label LblReturnRate;
		protected System.Web.UI.WebControls.Label LblSatisfyRate;
		protected System.Web.UI.WebControls.TextBox TbxSendDateFrom;
		protected System.Web.UI.WebControls.TextBox TbxSendDateTo;
		protected System.Web.UI.WebControls.Label LblReturnCount;
		protected System.Web.UI.WebControls.Label LblNotReturnCount;
		protected System.Web.UI.WebControls.Label LblNotReturnRate;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected System.Web.UI.WebControls.Label LblNotSatisfyRate;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos(true);

			XjosHelper.SetValidator (this.TbxSendDateFrom,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);
			XjosHelper.SetValidator (this.TbxSendDateTo,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);

			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if ( !Page.IsPostBack )
			{
				InitializeControls();
				//SearchTicketListPaging();
			}

			if ( this.IsSubmittedBy )
			{
				InitializeControls();
				//SearchTicketListPaging();
			}
		}


		private void InitializeControls()
		{
			LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea );
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			SelectSurveyRate();		
		}

		private void SelectSurveyRate()
		{
			SurveyDS ds = SurveyController.SelectSurveyRate(this.DdnlArea.SelectedValue, this.TbxSendDateFrom.Text, this.TbxSendDateTo.Text );
			LblTotalCount.Text = ds.TB_SURVEY_CHK[0].Total.Trim();
			LblReturnCount.Text = ds.TB_SURVEY_CHK[0].R_Total.Trim();
			LblReturnRate.Text = ds.TB_SURVEY_CHK[0].R_Rate.Trim();
			this.LblNotReturnCount.Text = ds.TB_SURVEY_CHK[0].Not_R_Total.Trim();
			this.LblNotReturnRate.Text = ds.TB_SURVEY_CHK[0].Not_R_Total_rate.Trim();
			LblSatisfyCount.Text = ds.TB_SURVEY_CHK[0].Satisfy.Trim();
			LblSatisfyRate.Text = ds.TB_SURVEY_CHK[0].Satisfy_Rate.Trim();
			LblNotSatisfyCount.Text = ds.TB_SURVEY_CHK[0].Not_Satisfy.Trim();
			LblNotSatisfyRate.Text = ds.TB_SURVEY_CHK[0].Not_Satisfy_Rate.Trim();
		}


	}
}
