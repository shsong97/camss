using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Mail;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;


namespace LGCNS.SITE.WebUI.SURVEY
{
	/// <summary>
	/// ConfigSurvey�� ���� ��� �����Դϴ�.
	/// </summary>
	public class ConfigSurvey : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Button BtnSearch;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.TextBox TextBox3;
		protected System.Web.UI.WebControls.DropDownList DdnlQuestType;
		protected System.Web.UI.WebControls.Button BtnNew;
		protected System.Web.UI.WebControls.Button BtnSurvey;
		protected System.Web.UI.WebControls.Button BtnAnswer;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdQuestion;

		// property to keep track of whether we are adding a new record,
		// and save it in viewstate between postbacks
		protected bool AddingNew 
		{
			get 
			{
				object o = ViewState["AddingNew"];
				return (o == null) ? false : (bool)o;
			}
			set 
			{
				ViewState["AddingNew"] = value;
			}
		}
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }
			this.DgrdQuestion.NavigateOnRowClick(
				"",
				"ManageQuestion.aspx",
				new string[2] { "Qtype", "Seq" },
				new int[2] { 0, 1 }
				);

			NavigationHelper.SetPopupWindow( this.BtnSurvey,
				"SurveyView.aspx",
				"SurveyView",
				550, 300,
				true
				);
			NavigationHelper.SetPopupWindow( this.BtnAnswer,
				"SurveyAnswerView.aspx",
				"SurveyAnswerView",
				1000, 600,
				true
				);
			if ( !Page.IsPostBack )
			{
				InitializeControls();
			}

			if ( this.IsSubmittedBy )
			{
				InitializeControls();
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
			this.BtnNew.Click += new System.EventHandler(this.BtnNew_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion



		private void InitializeControls()
		{
			InitializeControls( false );
		}

		private void InitializeControls(bool isClear)
		{
			this.DdnlQuestType.Items.Add("��ü");
			this.DdnlQuestType.Items.Add("������");
			this.DdnlQuestType.Items.Add("�ְ���");

			this.DdnlQuestType.SelectedValue = "��ü";

			BindGrid();
		}

		private void BindGrid()
		{
			string Qtype;
			//			SurveyDS ds = new SurveyDS();

			if (this.DdnlQuestType.SelectedValue == "��ü") Qtype = "A";
			else if(this.DdnlQuestType.SelectedValue == "������") Qtype = "K";
			else Qtype = "J";

			SurveyDS ds = SurveyController.SelectQuestion( Qtype );
			this.DgrdQuestion.DataSource = ds.TB_SURVEY_QUEST;
			this.DgrdQuestion.DataBind();
		}

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			BindGrid();
		}

		private void BtnNew_Click(object sender, System.EventArgs e)
		{
			NavigationHelper.Redirect("", "","ManageQuestion.aspx?Qtype="+this.DdnlQuestType.SelectedValue+"&seq=0");
		}


	}
}
