using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;


namespace LGCNS.SITE.WebUI.SURVEY
{
	/// <summary>
	/// ManageQuestion�� ���� ��� �����Դϴ�.
	/// </summary>
	public class ManageQuestion : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.DropDownList DdnlQuestType;
		protected System.Web.UI.WebControls.DropDownList DdnlUseCHK;
		protected System.Web.UI.WebControls.Button BtnSave;
		protected System.Web.UI.WebControls.Button BtnNew;
		protected System.Web.UI.WebControls.Label LblSeq;
		protected System.Web.UI.WebControls.TextBox TbxQuest;
		protected System.Web.UI.WebControls.Button BtnDelete;
		protected System.Web.UI.WebControls.Button BtnExit;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }
			
			XjosHelper.RegisterXjos(true);
			XjosHelper.SetValidator (this.TbxQuest,
				new XjosValidator (XjosValidatorType.Required)
				);
			
			if ( !Page.IsPostBack )
			{
				InitializeControls();
			}

			if ( this.IsSubmittedBy )
			{
				InitializeControls();
			}

//			InitializeControls();

		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnNew.Click += new System.EventHandler(this.BtnNew_Click);
			this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
			this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
			this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void InitializeControls()
		{
			InitializeControls( false );
		}

		private void InitializeControls(bool isClear)
		{
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlQuestType, "QUEST_TYPE", false );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlUseCHK, "USE_TYPE", false );

			string Qtype = this.Request["Qtype"];
			string Seq = this.Request["Seq"];
			
//			if (this.DdnlQuestType.SelectedValue == "�ְ���") Qtype = "J";
			if (Qtype == "�ְ���") Qtype = "J";
			else Qtype = "K";
			this.DdnlQuestType.SelectedValue = Qtype;
			this.DdnlUseCHK.SelectedValue = "U";

			if (this.LblSeq.Text != "")
			{
				Seq = this.LblSeq.Text;
			}
			else
			{
				this.LblSeq.Text = Seq;
			}
			
			if (Seq != "0" )
			{
				this.BtnDelete.Visible = true;
				this.DdnlQuestType.Enabled = false;
				BindSurvey(Qtype, Seq);
			}
			else
			{
				this.BtnDelete.Visible = false;
				this.DdnlQuestType.Enabled = true;
			}
		}


		private void BindSurvey(string Qtype, string Seq)
		{
//			string Qtype;
////			SurveyDS ds = new SurveyDS();
//
//			if (this.DdnlQuestType.SelectedValue == "��ü") Qtype = "A";
//			else if(this.DdnlQuestType.SelectedValue == "������") Qtype = "K";
//			else Qtype = "J";

			SurveyDS ds = SurveyController.SelectOneQuestion( Qtype, Seq );
//			this.DgrdQuestion.DataSource = ds.TB_SURVEY_QUEST;
//			this.DgrdQuestion.DataBind();

			SurveyDS.TB_SURVEY_QUESTRow dr = ds.TB_SURVEY_QUEST[0];

			this.TbxQuest.Text = dr.Question;
			this.DdnlQuestType.SelectedValue = dr.Qtype;
			this.DdnlUseCHK.SelectedValue = dr.UseCHK;
		}

		private void BtnDelete_Click(object sender, System.EventArgs e)
		{
			SurveyDS ds = new SurveyDS();
			if(this.LblSeq.Text.Trim() == "0" ) 
			{
				NavigationHelper.Redirect (MessageManager.GetMessage("Common", "NOT_INPUT_QUESTION"), "ManageQuestion.aspx?Qtype="+this.DdnlQuestType.SelectedValue+"&seq="+this.LblSeq.Text ) ;
				return; //������ �Էµ��� �ʾҴٸ� 
			}

			SurveyController.DeleteQuestion( this.DdnlQuestType.SelectedValue, this.LblSeq.Text);	

			NavigationHelper.Redirect("", "","ConfigSurvey.aspx");
		}

		private void BtnExit_Click(object sender, System.EventArgs e)
		{
			NavigationHelper.Redirect("", "","ConfigSurvey.aspx");
		}

		private void BtnNew_Click(object sender, System.EventArgs e)
		{
			this.TbxQuest.Text = "";
			this.LblSeq.Text = "0";		//�űԸ� ��Ÿ���� ���ؼ����.
			InitializeControls( false );
		}

		private void BtnSave_Click(object sender, System.EventArgs e)
		{
			SurveyDS ds = new SurveyDS();
			if(this.TbxQuest.Text.Trim() == "" ) 
			{
				NavigationHelper.Redirect (MessageManager.GetMessage("Common", "NOT_INPUT_QUESTION"), "ManageQuestion.aspx?Qtype="+this.DdnlQuestType.SelectedValue+"&seq="+this.LblSeq.Text ) ;
				return; //������ �Էµ��� �ʾҴٸ� 
			}
			if(this.LblSeq.Text == "0") 	SurveyController.InsertQuestion( this.DdnlQuestType.SelectedValue, this.TbxQuest.Text,this.CurrentUserID );
			else	SurveyController.UpdateQuestion( this.DdnlQuestType.SelectedValue, this.LblSeq.Text,this.TbxQuest.Text, this.DdnlUseCHK.SelectedValue, this.CurrentUserID );	

			NavigationHelper.Redirect("", "","ConfigSurvey.aspx");
		}
	}
}
