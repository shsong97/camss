using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.FileManagement;

using LGCNS.SITE.SURVEY.Biz;
using LGCNS.SITE.DTO;


namespace LGCNS.SITE.WebUI.SURVEY
{
	/// <summary>
	/// SurveyController�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SurveyController : ControllerBase
	{
		public SurveyController() {}

		//lglsy 20051129 TicketNo ���� ������.
		public static SurveyDS isSelectTicketDesc(string TicketNo, string EmpNo)
		{
			SurveyBizNTx biz = null ;
			SurveyDS ds = null ;

			try
			{
				biz = new SurveyBizNTx();
				ds = biz.isSelectTicketDesc( TicketNo, EmpNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static SurveyDS SelectQuestion(string Qtype)
		{
				return SelectQuestion( Qtype, "");
		}

		public static SurveyDS SelectQuestion(string Qtype, string Use)
		{
			SurveyBizNTx biz = null ;
			SurveyDS ds = null ;

			try
			{
				biz = new SurveyBizNTx();
				ds = biz.SelectQuestion( Qtype, Use);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static SurveyDS SelectSurveyRate(string Area, string DateFrom, string DateTo)
		{
			SurveyBizNTx biz = null ;
			SurveyDS ds = null ;

			try
			{
				biz = new SurveyBizNTx();
				ds = biz.SelectSurveyRate(Area, DateFrom, DateTo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static SurveyDS SelectSurveyAnswer(string TicketNo,string Area, string DateFrom, string DateTo)
		{
			SurveyBizNTx biz = null ;
			SurveyDS ds = null ;

			try
			{
				biz = new SurveyBizNTx();
				ds = biz.SelectSurveyAnswer(TicketNo, Area, DateFrom, DateTo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}


		public static SurveyDS SelectMailTicket(string TicketNo)
		{
			SurveyBizNTx biz = null ;
			SurveyDS ds = null ;

			try
			{
				biz = new SurveyBizNTx();
				ds = biz.SelectMailTicket( TicketNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}


		#region ManageQuestion
		public static SurveyDS SelectOneQuestion(string Qtype, string Seq)
		{
			SurveyBizNTx biz = null ;
			SurveyDS ds = null ;

			try
			{
				biz = new SurveyBizNTx();
				ds = biz.SelectOneQuestion(  Qtype, Seq);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}


		public static void InsertQuestion(string Qtype, string Question, string CreateID)
		{
			SurveyBizTx biz = null;
			
			try
			{
				biz = new SurveyBizTx () ;
				biz.InsertQuestion(Qtype, Question, CreateID);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		public static void UpdateQuestion(string Qtype, string Seq, string Question, string UserCHK, string UpdateID)
		{
			SurveyBizTx biz = null;
			
			try
			{
				biz = new SurveyBizTx () ;
				biz.UpdateQuestion(Qtype, Seq, Question, UserCHK, UpdateID);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		public static void DeleteQuestion( string Qtype,string Seq )
		{
			SurveyBizTx biz = null;
			
			try
			{
				biz = new SurveyBizTx() ;
				biz.DeleteQuestion(Qtype,Seq);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}

		public static void InsertAnswer (SurveyDS ds)
		{
			SurveyBizTx biz = null ;

			try
			{
				biz = new SurveyBizTx();
				biz.InsertAnswer (ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static string InsertAnswerChk(string TicketNo)
		{
			SurveyBizTx biz = null;
			string Result = "";

			try
			{
				biz = new SurveyBizTx();
				Result = biz.InsertAnswerChk(TicketNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}

			return Result;
		}
		#endregion


	}
}
