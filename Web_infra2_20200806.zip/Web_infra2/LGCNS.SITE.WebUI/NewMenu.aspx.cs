using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Web.Controls;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;
using LGCNS.SITE.WebUI.Code;

namespace LGCNS.SITE.WebUI 
{
	/// <summary>
	/// NewMenu�� ���� ��� �����Դϴ�.
	/// </summary>
	public class NewMenu : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.HyperLink HlkLogOut;

		public int mainMenuCnt;
		public ArrayList mainMenu; 
		public ArrayList subMenuCnt;
		public ArrayList mainMenuLink;

		public string[][] subMenu;
		public string[][] subMenuLink;
		protected System.Web.UI.WebControls.Label LblUserName;

		public string UserID;

		private void Page_Load(object sender, System.EventArgs e)
		{
//			if ( !this.isLogin() )
//			{
//				NavigationHelper.Redirect(MessageManager.GetMessage("Common", "LOGOUT_DONE"), "top", "Logout.aspx" );
//				return;
//			}

			if ( this.isLogin() )
			{
				UserID = this.CurrentUserID;

				this.LblUserName.Text = "| " + this.CurrentUserName + " | " + DateTime.Now.ToShortDateString() + " | " + this.CurrentUserAuthorityName + " | " + this.CurrentUserArea + " |";

				SelectMenu( UserID );
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void SelectMenu( string UserID )
		{
			DataSet ds = null;
			ds = MenuController.SelectMenu( UserID );

			mainMenuCnt = 0;
			mainMenu = new ArrayList();
			subMenuCnt = new ArrayList();
			mainMenuLink = new ArrayList();

			mainMenuCnt = ds.Tables["TB_TOP_MENU"].Rows.Count;

			foreach( DataRow dr in ds.Tables["TB_TOP_MENU"].Rows)
			{
				mainMenu.Add( dr[0].ToString() );
				subMenuCnt.Add( dr[1].ToString() );
				mainMenuLink.Add( dr[2].ToString() );
			}

			int inx = -1;
			int jnx = -1;
			string menuClass = "";

			subMenu = new string[mainMenuCnt][];
			subMenuLink = new string[mainMenuCnt][];

			foreach( DataRow dr in ds.Tables["TB_SUB_MENU"].Rows)
			{
				if ( menuClass == dr[0].ToString() )
				{
					jnx++;
				}
				else
				{
					inx++;
					jnx = 0;
					subMenu[inx] = new string[int.Parse( subMenuCnt[inx].ToString() )];
					subMenuLink[inx] = new string[int.Parse( subMenuCnt[inx].ToString() )];
				}

				subMenu[inx][jnx] = dr[1].ToString();
				subMenuLink[inx][jnx] = dr[2].ToString();

				menuClass = dr[0].ToString();
			}
		}
	}
}
