using System;

using LGCNS.LAF.Web;
using LGCNS.SITE.DTO;
//using LGCNS.SITE.Refresh.Biz;

namespace LGCNS.SITE.WebUI.Refresh
{
	/// <summary>
	/// RefreshController�� ���� ��� �����Դϴ�.
	/// </summary>
	public class RefreshController : ControllerBase
	{
		public RefreshController() {}

	}
}
