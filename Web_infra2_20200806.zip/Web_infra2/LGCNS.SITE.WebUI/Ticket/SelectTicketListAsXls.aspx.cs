using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Ticket
{
	/// <summary>
	/// SelectTicketListAsXls�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectTicketListAsXls : LGCNS.SITE.Common.SITEPageBase
	{
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			//this.DgrdDataGrid.EnableViewState = false ;

			try
			{
				SearctTicketListPaging() ;
			}
			catch(Exception ex)
			{
				ScriptHelper.ShowAlert ("�����ٿ�ε��� ������ �߻��߽��ϴ�. (" + ex.Message) ;
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void SearctTicketListPaging()
		{
			NameValueCollection searchCondition = new NameValueCollection();
			searchCondition["QueryType"] = "Normal";
			searchCondition["Area"] = Request["DdnlArea"];
			searchCondition["TicketNo"] = Request["TbxTicketNo"];
			searchCondition["CreateDateFrom"] = Request["TbxCreateDateFrom"];
			searchCondition["CreateDateTo"] = Request["TbxCreateDateTo"];
			searchCondition["CloseDateFrom"] = Request["TbxCloseDateFrom"];
			searchCondition["CloseDateTo"] = Request["TbxCloseDateTo"];
			searchCondition["HdConfirm"] = Request["DdnlHDConfirm"];
			searchCondition["Status"] = Request["DdnlStatus"];
			searchCondition["EmpNo"] = Request["TbxEmpNo"];
			searchCondition["EmpName"] = Request["TbxEmpName"];
			searchCondition["Engineer"] = Request["DdnlEngineer"];
			searchCondition["CreateID"] = Request["DdnlCreateID"];
			searchCondition["Division"] = Request["DdnlDivision"];
			searchCondition["SiteCode"] = Request["TbxSiteCode"];
			searchCondition["Description"] = Request["TbxDescription"];


			TicketDS ds = TicketController.SelectTicketListXls( 0, 0, searchCondition );
			this.DgrdDataGrid.DataSource = ds.TB_TICKET_LIST ;
			this.DgrdDataGrid.DataBind() ;
			LGCNS.SITE.Common.WebUI.DataToXls.datagridToXls(Response,this.DgrdDataGrid,"TicketList.xls");


			//this.DgrdDataGrid.ExportAsXls ("TicketList.xls") ;
		
		}
	}
}
