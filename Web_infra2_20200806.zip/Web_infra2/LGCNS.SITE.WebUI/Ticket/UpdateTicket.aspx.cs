using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Ticket
{
	/// <summary>
	/// UpdateTicket�� ���� ��� �����Դϴ�.
	/// </summary>
	public class UpdateTicket : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Label LblTicketNo;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdTicketEmp;
		protected System.Web.UI.WebControls.TextBox TbxDesc;
		protected System.Web.UI.WebControls.DropDownList DdnlZone;
		protected System.Web.UI.WebControls.DropDownList DdnlEngineer;
		protected System.Web.UI.WebControls.DropDownList DdnlStatus;
		protected System.Web.UI.WebControls.DropDownList DdnlAHD;
		protected System.Web.UI.WebControls.DropDownList DdnlICMS;
		protected System.Web.UI.WebControls.DropDownList DdnlBill;
		protected System.Web.UI.WebControls.TextBox TbxRemark;
		protected System.Web.UI.WebControls.TextBox TbxReasonNoHandle;
		protected System.Web.UI.WebControls.TextBox TbxCloseContents;
		protected System.Web.UI.WebControls.TextBox TbxCloseDate;
		protected System.Web.UI.WebControls.TextBox TbxHdConfirm;
		protected System.Web.UI.WebControls.TextBox TbxCreateID;
		protected System.Web.UI.WebControls.TextBox TbxCreateDate;
		protected System.Web.UI.WebControls.TextBox TbxUpdateID;
		protected System.Web.UI.WebControls.TextBox TbxUpdateDate;
		protected System.Web.UI.WebControls.Button BtnUpdate;
		protected System.Web.UI.WebControls.Button BtnCancel;
		protected System.Web.UI.WebControls.TextBox TbxEmpNo;
		protected System.Web.UI.WebControls.Button BtnAddEmp;
		protected System.Web.UI.WebControls.Button BtnSearchEmp;
		protected System.Web.UI.WebControls.Label LblTicketID;
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected System.Web.UI.WebControls.Label LblCreateID;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
		protected System.Web.UI.WebControls.TextBox TbxEmpNoAsset;
		protected System.Web.UI.WebControls.Button BtnSearchAsset;
		protected System.Web.UI.WebControls.TextBox TbxAssetNo;
		protected System.Web.UI.WebControls.Button BtnAddAsset;
		protected System.Web.UI.WebControls.Button BtnAssetList;
		protected System.Web.UI.WebControls.Button BtnAssetClare;
		protected System.Web.UI.WebControls.ImageButton IbtnCalendar;
		protected System.Web.UI.WebControls.TextBox TbxFinishPlan;
		protected System.Web.UI.WebControls.DropDownList DdnlDivision;
		protected System.Web.UI.WebControls.DropDownList DdnlAltEngineer;
		protected System.Web.UI.WebControls.TextBox TbxStatusFlag;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdHistory;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			// GET������� ȣ��ɶ�
			if ( !this.IsPostBack )
			{
				SelectTicketData(this.Request["TicketNo"], this.Request["TicketID"]);
				//lglsy 20051107 �ڻ� ������. -- �ۿ� ���������� ������ ����. del Ű�� ���� �ʾ���.
				isSelectTicketAssetList(this.Request["TicketNo"], this.Request["TicketID"]);
			}

			// POST������� ȣ��ɶ�
			// NavigationHelper�� LDataGrid�� ���� POST������� ȣ��ɶ��� ���� ������ �ε�ÿ��� 
			// IsPostBack ������Ƽ�� true�� �ǹǷ� 
			// IsSubmittedBy ������Ƽ�� ���� POST������� ȣ��Ǿ������� üũ�� �� �ִ�.
			if(this.IsSubmittedBy)
			{
				SelectTicketData(this.Request["TicketNo"], this.Request["TicketID"]);
				isSelectTicketAssetList(this.Request["TicketNo"], this.Request["TicketID"]);
			}


			if( this.IsReloadedByPopup )
			{
				ReloadControls();
			}

            ClientScript.RegisterHiddenField("TicketNo", LblTicketNo.Text) ;
            ClientScript.RegisterHiddenField("TicketID", LblTicketID.Text) ;

			this.DgrdTicketEmp.OpenWindowOnCellClick(
				6,
				"../Emp/UpdateEmp.aspx",
				"UpdateEmp",
				1000, 700,
				new string [2] {"Area", "EmpNo"},  // LinkŬ���� ������ Query String �� key�� �迭
				new int [2] {1, 2}, // LinkŬ���� ������ Query String �� value���� ������ Cell Index�� �迭
				false  // // ������������ ���� SelectTicket.aspx ���� submit��Ų��. (POST������� ȣ���Ѵ�.)
				);

			XjosHelper.RegisterXjos(true);

			XjosHelper.SetValidator (this.TbxDesc,
				new XjosValidator (XjosValidatorType.Required)
			) ;
			XjosHelper.SetValidator (this.TbxFinishPlan,
					new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
			);
			XjosHelper.ValidateOnClick (this.BtnUpdate);

			NavigationHelper.SetHistoryBack( this.BtnCancel );
			NavigationHelper.SetPopupWindow( this.IbtnCalendar,"SelectDate.aspx", "SelectDate", 210, 180, false );
			NavigationHelper.SetPopupWindow( this.BtnAssetList,"../Asset/SelectAssetList.aspx", "", 1000, 700, false );

			if( this.TbxTicketNo.Text == this.LblTicketNo.Text )
			{
				ScriptHelper.SetConfirmMessageOn( this.BtnUpdate, MessageManager.GetMessage( "Common", "UPDATE_QUESTION" ) );	
			}
			else
			{
				ScriptHelper.SetConfirmMessageOn( this.BtnUpdate, MessageManager.GetMessage( "Ticket", "CHANGE_TICKET" ) );	
			}

			if ( this.TbxEmpNo.Text.Length > 0 )
			{
				BtnAddEmp_Click( sender, e );
			}
		}


		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
            this.DdnlArea.SelectedIndexChanged += new System.EventHandler(this.DdnlArea_SelectedIndexChanged);
            this.BtnAddEmp.Click += new System.EventHandler(this.BtnAddEmp_Click);
            this.DgrdTicketEmp.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdTicketEmp_DeleteCommand);
            this.BtnSearchAsset.Click += new System.EventHandler(this.BtnSearchAsset_Click);
            this.BtnAddAsset.Click += new System.EventHandler(this.BtnAddAsset_Click);
            this.BtnAssetClare.Click += new System.EventHandler(this.BtnAssetClare_Click);
            this.DgrdDataGrid.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdDataGrid_DeleteCommand);
            this.BtnUpdate.Click += new System.EventHandler(this.BtnUpdate_Click);
            this.Load += new System.EventHandler(this.Page_Load);

        }
		#endregion

		#region SearchTicket

		private void SelectTicketData( string TicketNo, string TicketID )
		{
			this.LblTicketNo.Text = TicketNo;
			this.TbxTicketNo.Text = TicketNo;
			this.LblTicketID.Text = TicketID;

			TicketDS ds = null;
			//if ( (TicketNo.Length == 6) & (TicketController.isNumeric( TicketNo )) )
			// 2005-05-16 : Ticket �ν� ��� ����
			if (TicketController.isValidTicket(TicketNo))
			{
				ds = TicketController.SelectTicket( TicketNo );
			}
			else
			{
				ds = TicketController.SelectTicketTemp( TicketID );
			}
            if(ds.TB_TICKET_ENTIRE.Rows.Count>0) 
            {
                BindTicketInfo( ds.TB_TICKET_ENTIRE[0] );
                BindTicketEmpList( ds.TB_TICKET_EMP_ENTIRE );
                BindTicketHistoryByUser( ds.TB_TICKET_ENTIRE[0].Area, ds.TB_TICKET_EMP_ENTIRE[0].EmpNo, TicketNo );
            }
		}

		private void ReloadControls()
		{
			LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea );
			
			string Area = this.Request["DdnlArea"];
			
			LGCNS.SITE.Common.WebUI.UserInfo.BindDropDownList( this.DdnlEngineer );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlZone, "TICKET_ZONE", true );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlDivision, "TICKET_DIVISION" );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlStatus, "TICKET_STATUS" );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlAHD, "TICKET_STATUS" );

			this.DdnlArea.SelectedValue = Area;

			this.DdnlZone.SelectedValue = this.Request["DdnlZone"];
			this.DdnlEngineer.SelectedValue = this.Request["DdnlEngineer"];
			this.DdnlDivision.SelectedValue = this.Request["DdnlDivision"];

			this.DdnlStatus.SelectedValue = this.Request["DdnlStatus"];
			this.DdnlAHD.SelectedValue = this.Request["DdnlAHD"];
			this.DdnlICMS.SelectedValue = this.Request["DdnlICMS"];
			this.DdnlBill.SelectedValue = this.Request["DdnlBill"];

		}

		private void BindTicketInfo( TicketDS.TB_TICKET_ENTIRERow dr )
		{
			LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea );
			LGCNS.SITE.Common.WebUI.UserInfo.BindDropDownList( this.DdnlEngineer);
			//Alter Engineer �� �߰���. 20060509
			LGCNS.SITE.Common.WebUI.UserInfo.BindDropDownList( this.DdnlAltEngineer , true );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlZone, "TICKET_ZONE", true );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlDivision, "TICKET_DIVISION", true );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlStatus, "TICKET_STATUS" );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlAHD, "TICKET_STATUS" );

			this.DdnlArea.SelectedValue = dr.Area;
			NavigationHelper.SetPopupWindow( this.BtnSearchEmp,"../Emp/SearchEmp.aspx?Area=" + this.DdnlArea.SelectedValue, "SearchEmployees", 600, 500, false );

			this.TbxDesc.Text = dr.Description;
			this.DdnlZone.SelectedValue = dr.Zone;
			this.DdnlEngineer.SelectedValue = dr.Engineer;
			//Alter Engineer �� �߰���. 20060509
			if ( dr.IsAltEngineerNull() ) 
				this.DdnlAltEngineer.SelectedValue = "";
			else 
				this.DdnlAltEngineer.SelectedValue = dr.AltEngineer;
			this.DdnlDivision.SelectedValue = dr.Division;

			if ( !dr.IsFinishPlanNull() )
				this.TbxFinishPlan.Text = dr.FinishPlan;

			this.DdnlStatus.SelectedValue = dr.Status;
			this.DdnlAHD.SelectedValue = dr.AHD;
			this.DdnlICMS.SelectedValue = dr.ICMS;
			this.DdnlBill.SelectedValue = dr.BILL;

			this.TbxRemark.Text = dr.Remark;
			this.TbxReasonNoHandle.Text = dr.ReasonNoHandle;
			this.TbxCloseContents.Text = dr.CloseContents;

			if ( !dr.IsCloseDateNull() )
				this.TbxCloseDate.Text = dr.CloseDate;

			this.TbxHdConfirm.Text = dr.HdConfirm;
			this.LblCreateID.Text = dr.CreateID;
			this.TbxCreateID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.CreateID );
			this.TbxCreateDate.Text = dr.CreateDate;
			this.TbxUpdateID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.UpdateID );
			this.TbxUpdateDate.Text = dr.UpdateDate;
			this.TbxStatusFlag.Text = dr.StatusFlag;
		}

		private void BindTicketEmpList( TicketDS.TB_TICKET_EMP_ENTIREDataTable dt )
		{
			this.DgrdTicketEmp.DataSource = dt;
			this.DgrdTicketEmp.DataBind();
		}

		private void BindTicketHistoryByUser( string Area, string EmpNo, string TicketNo )
		{
			if ( this.DgrdTicketEmp.Items.Count == 1 )
			{
				TicketDS ds = TicketController.SelectTicketListByEmp( Area, EmpNo, TicketNo );
				this.DgrdHistory.ShowFooterMessage = false;
				this.DgrdHistory.DataSource = ds.TB_TICKET_LIST;
				this.DgrdHistory.DataBind();
			}
			else
			{
				TicketDS dsTicket = new TicketDS();
				this.DgrdHistory.DataSource = dsTicket.TB_TICKET_LIST;
				this.DgrdHistory.ShowFooterMessage = true;
				this.DgrdHistory.FooterMessage = MessageManager.GetMessage( "Common", "NO_DATA" );
				this.DgrdHistory.DataBind();
			}
		}

		#endregion

		#region ����� �߰�

		private void BindEmpList( string Area, string EmpNo )
		{
			if ( EmpNo.CompareTo( "" ) == 0 )
			{
				return;
			}

			if ( !isValidEmpNo( EmpNo ) )
			{
				return;
			}

			EmpDS ds = TicketController.SelectEmp( Area, EmpNo );

			if (ds.TB_EMP_ENTIRE.Count != 1 )
			{
				ScriptHelper.ShowAlert( MessageManager.GetMessage( "Common", "NOT_EXISTS" ) );
				return;
			}

			if ( this.DgrdTicketEmp.Items.Count > 0  )
			{
				EmpDS dsEmp = new EmpDS();
		
				for( int inx=0; inx<this.DgrdTicketEmp.Items.Count; inx++ )
				{
					EmpDS.TB_EMP_ENTIRERow rowEmp = dsEmp.TB_EMP_ENTIRE.NewTB_EMP_ENTIRERow();
					
					if ( this.DgrdTicketEmp.Items[inx].Cells[2].Text != EmpNo )
					{
						rowEmp.Area = this.DgrdTicketEmp.Items[inx].Cells[1].Text;
						rowEmp.EmpNo = this.DgrdTicketEmp.Items[inx].Cells[2].Text;
						rowEmp.DeptCode = this.DgrdTicketEmp.Items[inx].Cells[3].Text;
						rowEmp.SiteCode = this.DgrdTicketEmp.Items[inx].Cells[4].Text;
			
						rowEmp.EmpName = this.DgrdTicketEmp.Items[inx].Cells[7].Text;
						rowEmp.FullName = this.DgrdTicketEmp.Items[inx].Cells[8].Text;
						rowEmp.ContactNo = this.DgrdTicketEmp.Items[inx].Cells[9].Text;
						rowEmp.LoginID = this.DgrdTicketEmp.Items[inx].Cells[10].Text;
						rowEmp.DeptName = this.DgrdTicketEmp.Items[inx].Cells[11].Text;
                        rowEmp.JDECode=this.DgrdTicketEmp.Items[inx].Cells[12].Text;
						rowEmp.SiteCode = this.DgrdTicketEmp.Items[inx].Cells[13].Text;
						rowEmp.SiteDesc = this.DgrdTicketEmp.Items[inx].Cells[14].Text;
						rowEmp.BuildingCode = this.DgrdTicketEmp.Items[inx].Cells[15].Text;
						rowEmp.BuildingDesc = this.DgrdTicketEmp.Items[inx].Cells[16].Text;
						rowEmp.Email = ""; //Email �߰� 20060118
						
						dsEmp.TB_EMP_ENTIRE.AddTB_EMP_ENTIRERow( rowEmp );
					}
					
				}

				dsEmp.TB_EMP_ENTIRE.AddTB_EMP_ENTIRERow( 
					ds.TB_EMP_ENTIRE[0].Area,
					ds.TB_EMP_ENTIRE[0].EmpNo, 
					ds.TB_EMP_ENTIRE[0].EmpName, 
					ds.TB_EMP_ENTIRE[0].FirstName, 
					ds.TB_EMP_ENTIRE[0].LastName, 
					ds.TB_EMP_ENTIRE[0].FullName,
					ds.TB_EMP_ENTIRE[0].ContactNo, 
					ds.TB_EMP_ENTIRE[0].LoginID, 
					ds.TB_EMP_ENTIRE[0].DeptCode,
					ds.TB_EMP_ENTIRE[0].DeptName,
					ds.TB_EMP_ENTIRE[0].DeptNameEng,
					ds.TB_EMP_ENTIRE[0].BizUnit,
					ds.TB_EMP_ENTIRE[0].SiteCode,
					ds.TB_EMP_ENTIRE[0].SiteDesc,
					ds.TB_EMP_ENTIRE[0].SvcLevel,
					ds.TB_EMP_ENTIRE[0].LocationName,
					ds.TB_EMP_ENTIRE[0].BuildingCode,
					ds.TB_EMP_ENTIRE[0].BuildingDesc, "", //Email �߰� 20060118
                    ds.TB_EMP_ENTIRE[0].JDECode
					);
		
				this.DgrdTicketEmp.DataSource = dsEmp.TB_EMP_ENTIRE;
			}
			else
			{
				this.DgrdTicketEmp.DataSource = ds.TB_EMP_ENTIRE;
			}

			this.DgrdTicketEmp.DataBind();

			BindTicketHistoryByUser( Area, EmpNo, this.LblTicketNo.Text );
			//lglsy 20051014 �߰� InsertTicket���� Add Ŭ���� Asset Information�� ���̱� ����
		}

		#endregion

		#region Validation

		private bool isValidEmpNo( string EmpNo )
		{
			if ( isExistEmp( EmpNo ) )
			{
				ScriptHelper.ShowAlert( MessageManager.GetMessage( "Common", "EXISTS" ) );
				return false;
			}

			return true;
		}

		private bool isValidEmp()
		{
			bool isValid = true;

			if ( this.DgrdTicketEmp.Items.Count < 1 )
			{
				ScriptHelper.ShowAlert( MessageManager.GetMessage("Common", "NO_EMP") );
				isValid = false;
			}

			return isValid;
		}

		private bool isExistEmp( string EmpNo )
		{
			bool isExist = false;

			if ( this.DgrdTicketEmp.Items.Count > 0  )
			{
				for( int inx=0; inx<this.DgrdTicketEmp.Items.Count; inx++ )
				{
					if ( this.DgrdTicketEmp.Items[inx].Cells[0].Text == EmpNo )
					{
						isExist = true;
					}
				}
			}

			return isExist;
		} 

		private bool isValidTicketNo( string TicketNo )
		{
			bool isValid = true;

			if ( TicketController.isValidTicket( TicketNo ) )
			{
				TicketDS ds = TicketController.SelectTicket( TicketNo );

				if ( ds.TB_TICKET.Count > 0 )
				{
					ScriptHelper.ShowAlert( MessageManager.GetMessage( "Common", "EXIST_TICKET" ) );
					return false;
				}
			}

			return isValid;
		}

		#endregion

		#region Update

		private void BtnUpdate_Click(object sender, System.EventArgs e)
		{
			string OldTicketNo = this.LblTicketNo.Text.Trim().ToUpper();
			string NewTicketNo = this.TbxTicketNo.Text.Trim().ToUpper();
			string OldTicketID = this.LblTicketID.Text;
			string NewTicketID = "0";

			TicketDS ds = null;

			if ( isValidTicketNo( NewTicketNo ) && isValidEmp() )
			{
				ds = getTicketData();

				if( OldTicketNo == NewTicketNo )
				{
					if ( TicketController.isValidTicket( NewTicketNo ) )
					{
						//2005-06-02 : Ƽ�� ������ ICMS Bill ���� �ݿ�
						TicketController.UpdateTicket( ds );
					}
					else
					{
						// 2005-05-30 : �ӽ�Ƽ�� �����Ǵ� ���� ����
						NewTicketID = InsertTicketTempData(); //TicketController.InsertTicketTemp( ds );
						TicketController.DeleteTicket( OldTicketNo );
						TicketController.DeleteTicketTemp( OldTicketID );
					}
				}
				else
				{
					if ( TicketController.isValidTicket( NewTicketNo ) )
					{
                        //lgssha:20090504 ����Ƽ���� Ƽ�Ϲ�ȣ �ߺ����� Ȯ��
                        if(TicketController.isExistTicket(NewTicketNo))
                        {   
                            ScriptHelper.ShowAlert( MessageManager.GetMessage( "Ticket", "EXISTTICKET" ) );
                            return;
                        }
                        else
                        {
                            TicketController.DeleteTicket( OldTicketNo );
                            TicketController.DeleteTicketTemp( OldTicketID );
                            TicketController.InsertTicket( ds );
                        }
    				}
					else
					{
                        TicketController.DeleteTicket( OldTicketNo );
                        TicketController.DeleteTicketTemp( OldTicketID );
                        // 2005-05-30 : �ӽ�Ƽ�� �����Ǵ� ���� ����
						NewTicketID = InsertTicketTempData(NewTicketNo); //TicketController.InsertTicketTemp( ds );
					}
				}
				TicketController.DeleteTicketASSET( OldTicketID, OldTicketNo );

				for( int inx=0; inx<this.DgrdDataGrid.Items.Count; inx++ )
				{
				
					TicketDS dss = TicketController.InsertTicketAssetData (NewTicketID, NewTicketNo, this.DgrdDataGrid.Items[inx].Cells[1].Text, this.DgrdDataGrid.Items[inx].Cells[9].Text, this.DgrdDataGrid.Items[inx].Cells[10].Text, this.DgrdDataGrid.Items[inx].Cells[3].Text);
				}
				//����� �̵�
				NavigationHelper.Redirect(
					MessageManager.GetMessage( "Common", "UPDATE_DONE" ),
					"SelectTicket.aspx?TicketNo=" + NewTicketNo + "&TicketID=" + NewTicketID
					);
			}
		}

		// 2005-05-30 : �ӽ�Ƽ�� �����Ǵ� ���� ����
		private string InsertTicketTempData( string TicketNo )
		{
			TicketDS ds = new TicketDS();
			TicketDS.TB_TICKET_TEMPRow dr = ds.TB_TICKET_TEMP.NewTB_TICKET_TEMPRow();

			dr.TicketNo = TicketNo;
			dr.EmpNo    = this.DgrdTicketEmp.Items[0].Cells[2].Text;
			dr.DeptCode = this.DgrdTicketEmp.Items[0].Cells[3].Text;
			dr.SiteCode = this.DgrdTicketEmp.Items[0].Cells[4].Text;

			dr.Description = this.TbxDesc.Text.Trim();
			dr.Zone = this.DdnlZone.SelectedValue.ToString();
			dr.Engineer = this.DdnlEngineer.SelectedValue.ToString();
			dr.AltEngineer = this.DdnlAltEngineer.SelectedValue.ToString();
			dr.Division = this.DdnlDivision.SelectedValue.ToString();

			if ( this.TbxFinishPlan.Text.CompareTo("0") > 0 )
			{
				dr.FinishPlan = DateTime.Parse( this.TbxFinishPlan.Text.Trim() );
			}

			dr.Status = this.DdnlStatus.SelectedValue.ToString();
			dr.AHD = this.DdnlAHD.SelectedValue.ToString();
			dr.ICMS = this.DdnlICMS.SelectedValue.ToString();
			dr.BILL = this.DdnlBill.SelectedValue.ToString();
			dr.Remark = this.TbxRemark.Text.Trim();
			dr.ReasonNoHandle = this.TbxReasonNoHandle.Text.Trim();
			dr.CloseContents = this.TbxCloseContents.Text.Trim();

			if ( this.DdnlStatus.SelectedItem.Text == "closed" || this.DdnlStatus.SelectedItem.Text == "cancelled" )
			{
				dr.CloseDate = DateTime.Now;
			}

			dr.HdConfirm = this.TbxHdConfirm.Text.Trim();
			dr.CreateID = this.LblCreateID.Text;
			dr.CreateDate = DateTime.Parse( this.TbxCreateDate.Text );
			dr.UpdateID = this.CurrentUserID;
			dr.UpdateDate = DateTime.Now;
			dr.Area = this.DdnlArea.SelectedValue.ToString();

			ds.TB_TICKET_TEMP.AddTB_TICKET_TEMPRow( dr );

			return TicketController.InsertTicketTemp( ds );
		}

		private TicketDS getTicketData( )
		{
			TicketDS ds = new TicketDS();

			TicketDS.TB_TICKETRow dr = ds.TB_TICKET.NewTB_TICKETRow();
			
			dr.TicketNo = this.TbxTicketNo.Text;
			dr.Description = this.TbxDesc.Text.Trim();
			dr.Zone = this.DdnlZone.SelectedValue.ToString();
			dr.Engineer = this.DdnlEngineer.SelectedValue.ToString();
			//Alter Engineer �� �߰���. 20060509
			dr.AltEngineer = this.DdnlAltEngineer.SelectedValue.ToString();
			dr.Division = this.DdnlDivision.SelectedValue.ToString();

			if ( this.TbxFinishPlan.Text.CompareTo("0") > 0 )
			{
				dr.FinishPlan = DateTime.Parse( this.TbxFinishPlan.Text.Trim() );
			}

			dr.Status = this.DdnlStatus.SelectedValue.ToString();
			dr.AHD = this.DdnlAHD.SelectedValue.ToString();
			dr.ICMS = this.DdnlICMS.SelectedValue.ToString();
			dr.BILL = this.DdnlBill.SelectedValue.ToString();
			dr.Remark = this.TbxRemark.Text.Trim();
			dr.ReasonNoHandle = this.TbxReasonNoHandle.Text.Trim();
			dr.CloseContents = this.TbxCloseContents.Text.Trim();

			if ( this.DdnlStatus.SelectedItem.Text == "closed" || this.DdnlStatus.SelectedItem.Text == "cancelled" )
			{
				dr.CloseDate = DateTime.Now;
			}

			dr.HdConfirm = this.TbxHdConfirm.Text.Trim();
			dr.CreateID = this.LblCreateID.Text;
			dr.CreateDate = DateTime.Parse( this.TbxCreateDate.Text );
			dr.UpdateID = this.CurrentUserID;
			dr.UpdateDate = DateTime.Now;
			dr.Area = this.DdnlArea.SelectedValue.ToString();

			ds.TB_TICKET.AddTB_TICKETRow( dr );

			//TicketDS
			for( int inx=0; inx < this.DgrdTicketEmp.Items.Count; inx++ )
			{
				TicketDS.TB_TICKET_EMPRow drTicketEmp = ds.TB_TICKET_EMP.NewTB_TICKET_EMPRow();
				drTicketEmp.TicketNo = this.TbxTicketNo.Text;
				drTicketEmp.EmpNo    = this.DgrdTicketEmp.Items[inx].Cells[2].Text;
				drTicketEmp.DeptCode = this.DgrdTicketEmp.Items[inx].Cells[3].Text;
				drTicketEmp.SiteCode = this.DgrdTicketEmp.Items[inx].Cells[4].Text;

				ds.TB_TICKET_EMP.AddTB_TICKET_EMPRow( drTicketEmp );
			}
			return ds;
		}


		private void DeleteTicketTemp( string TicketID )
		{
			TicketController.DeleteTicketTemp( TicketID );
		}


		private string InsertTicketTempData()
		{
			TicketDS ds = new TicketDS();
			TicketDS.TB_TICKET_TEMPRow dr = ds.TB_TICKET_TEMP.NewTB_TICKET_TEMPRow();

			dr.TicketID = int.Parse( this.LblTicketID.Text );
			dr.TicketNo = this.TbxTicketNo.Text;
			dr.EmpNo    = this.DgrdTicketEmp.Items[0].Cells[2].Text;
			dr.DeptCode = this.DgrdTicketEmp.Items[0].Cells[3].Text;
			dr.SiteCode = this.DgrdTicketEmp.Items[0].Cells[4].Text;

			dr.Description = this.TbxDesc.Text.Trim();
			dr.Zone = this.DdnlZone.SelectedValue.ToString();
			dr.Engineer = this.DdnlEngineer.SelectedValue.ToString();
			dr.AltEngineer = this.DdnlAltEngineer.SelectedValue.ToString();
			dr.Division = this.DdnlDivision.SelectedValue.ToString();

			if ( this.TbxFinishPlan.Text.CompareTo("0") > 0 )
			{
				dr.FinishPlan = DateTime.Parse( this.TbxFinishPlan.Text.Trim() );
			}

			dr.Status = this.DdnlStatus.SelectedValue.ToString();
			dr.AHD = this.DdnlAHD.SelectedValue.ToString();
			dr.ICMS = this.DdnlICMS.SelectedValue.ToString();
			dr.BILL = this.DdnlBill.SelectedValue.ToString();
			dr.Remark = this.TbxRemark.Text.Trim();
			dr.ReasonNoHandle = this.TbxReasonNoHandle.Text.Trim();
			dr.CloseContents = this.TbxCloseContents.Text.Trim();

			if ( this.DdnlStatus.SelectedItem.Text == "closed" || this.DdnlStatus.SelectedItem.Text == "cancelled" )
			{
				dr.CloseDate = DateTime.Now;
			}

			dr.HdConfirm = this.TbxHdConfirm.Text;

			dr.CreateID = this.LblCreateID.Text;
			dr.CreateDate = DateTime.Parse( this.TbxCreateDate.Text );

			dr.UpdateID = this.CurrentUserID;
			dr.UpdateDate = DateTime.Now;

			dr.Area = this.DdnlArea.SelectedValue;

			ds.TB_TICKET_TEMP.AddTB_TICKET_TEMPRow( dr );

			return TicketController.InsertTicketTemp( ds );
		}


		#endregion


		//lglsy 20051107 �ڻ� ������.
		private void isSelectTicketAssetList(string TicketNo, string TicketID)
		{

			TicketDS ds = TicketController.isSelectTicketAssetList( TicketNo, TicketID );
			this.DgrdDataGrid.VirtualItemCount = 100 ;
			this.DgrdDataGrid.DataSource = ds.TB_TICKET_ASSETLIST;
			this.DgrdDataGrid.DataBind() ;

		}	

		private void DgrdTicketEmp_DeleteCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			EmpDS ds = new EmpDS();
		
			for( int inx=0; inx<this.DgrdTicketEmp.Items.Count; inx++ )
			{
				EmpDS.TB_EMP_ENTIRERow dr = ds.TB_EMP_ENTIRE.NewTB_EMP_ENTIRERow();
					
				if ( inx != e.Item.ItemIndex )
				{
					dr.Area = this.DgrdTicketEmp.Items[inx].Cells[1].Text;
					dr.EmpNo = this.DgrdTicketEmp.Items[inx].Cells[2].Text;
					dr.DeptCode = this.DgrdTicketEmp.Items[inx].Cells[3].Text;
					dr.SiteCode = this.DgrdTicketEmp.Items[inx].Cells[4].Text;
			
					dr.EmpName = this.DgrdTicketEmp.Items[inx].Cells[7].Text;
					dr.FullName = this.DgrdTicketEmp.Items[inx].Cells[8].Text;
					dr.ContactNo = this.DgrdTicketEmp.Items[inx].Cells[9].Text;
					dr.LoginID = this.DgrdTicketEmp.Items[inx].Cells[10].Text;
					dr.DeptName = this.DgrdTicketEmp.Items[inx].Cells[11].Text;
                    dr.JDECode = this.DgrdTicketEmp.Items[inx].Cells[12].Text;
					dr.SiteCode = this.DgrdTicketEmp.Items[inx].Cells[13].Text;
					dr.SiteDesc = this.DgrdTicketEmp.Items[inx].Cells[14].Text;
					dr.BuildingCode = this.DgrdTicketEmp.Items[inx].Cells[15].Text;
					dr.BuildingDesc = this.DgrdTicketEmp.Items[inx].Cells[16].Text;

					ds.TB_EMP_ENTIRE.AddTB_EMP_ENTIRERow( dr );
				}
			}

			this.DgrdTicketEmp.DataSource = ds.TB_EMP_ENTIRE;
			this.DgrdTicketEmp.DataBind();
			if (this.DgrdTicketEmp.Items.Count == 1) //20051228  ��� ������ �ϳ��� ������ history�� ������ �Ѵ�. lglsy
			{
				BindTicketHistoryByUser( this.DgrdTicketEmp.Items[0].Cells[1].Text, this.DgrdTicketEmp.Items[0].Cells[2].Text, this.LblTicketNo.Text );
				isSearchAsset(this.DgrdTicketEmp.Items[0].Cells[1].Text, this.DgrdTicketEmp.Items[0].Cells[2].Text);	//20051230  ��� ������ �ϳ��� ������ Asset Information �� ������ �Ѵ�. lglsy
			}
		}
		//lglsy 20051106 �߰�
		private void DgrdDataGrid_DeleteCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			TicketDS ds = new TicketDS();
			
			for( int inx=0; inx<this.DgrdDataGrid.Items.Count; inx++ )
			{
				
				TicketDS.TB_TICKET_ASSETLISTRow dr = ds.TB_TICKET_ASSETLIST.NewTB_TICKET_ASSETLISTRow();
				
				if ( inx != e.Item.ItemIndex )
				{
					dr.AssetNo = this.DgrdDataGrid.Items[inx].Cells[1].Text;
					dr.NodeName = this.DgrdDataGrid.Items[inx].Cells[2].Text;
					dr.ModelNumber = this.DgrdDataGrid.Items[inx].Cells[3].Text;
					dr.EmpNo = this.DgrdDataGrid.Items[inx].Cells[4].Text;
					dr.EmpName = this.DgrdDataGrid.Items[inx].Cells[5].Text;
					dr.DeptName = this.DgrdDataGrid.Items[inx].Cells[6].Text;
					dr.SiteCode = this.DgrdDataGrid.Items[inx].Cells[7].Text;
					dr.SiteDesc = this.DgrdDataGrid.Items[inx].Cells[8].Text;
					dr.CompStatusDesc = this.DgrdDataGrid.Items[inx].Cells[9].Text;
					dr.CPUTypeDesc = this.DgrdDataGrid.Items[inx].Cells[10].Text;

					ds.TB_TICKET_ASSETLIST.AddTB_TICKET_ASSETLISTRow(dr);
				}
			}
			this.DgrdDataGrid.DataSource = ds.TB_TICKET_ASSETLIST;
			this.DgrdDataGrid.DataBind();

		}

		private bool isPossibleMultiEmp()
		{
			bool isPossible = false;

			if( this.TbxTicketNo.Text == "SRICMS")
			{
				isPossible = true;
			}
			if( TicketController.isValidTicket( this.TbxTicketNo.Text ) )
			{
				isPossible = true;
			}
			else
			{
				if( this.DgrdTicketEmp.Items.Count < 1 )
				{
					isPossible = true;
				}
			}

			return isPossible;
		}

		private void DdnlArea_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EmpDS ds = new EmpDS();
			this.DgrdTicketEmp.DataSource = ds.TB_EMP_ENTIRE;
			this.DgrdTicketEmp.DataBind();

			NavigationHelper.SetPopupWindow( this.BtnSearchEmp,"../Emp/SearchEmp.aspx?Area=" + this.DdnlArea.SelectedValue, "SearchEmployees", 600, 500, false );
		}

		private void BtnAddEmp_Click(object sender, System.EventArgs e)
		{
			if( isPossibleMultiEmp() )
			{
				this.TbxEmpNoAsset.Text = this.TbxEmpNo.Text;
				BindEmpList( this.DdnlArea.SelectedValue, this.TbxEmpNo.Text );		
				
			}
			else
			{
				ScriptHelper.ShowAlert(
					MessageManager.GetMessage( "Ticket", "NOMORE_EMP" )
					);
			}	
			this.TbxEmpNo.Text = ""; //20051228 Add �� ����� ����
		}
		//lglsy 20051014 �߰� InsertTicket���� Add Ŭ���� Asset Information�� ���̱� ����
		private void isSearchAsset(string Area, string EmpNo)
		{

			TicketDS ds = TicketController.SelectTicketAssetList( Area, EmpNo );
			this.DgrdDataGrid.VirtualItemCount = 100 ;
			this.DgrdDataGrid.DataSource = ds.TB_TICKET_ASSETLIST;
			this.DgrdDataGrid.DataBind() ;

		}	



		//lglsy 20051106 �߰�
		private void BtnSearchAsset_Click(object sender, System.EventArgs e)
		{
			if( this.TbxEmpNoAsset.Text != "" )
			{
				//lglsy 20051014 �߰� InsertTicket���� Add Ŭ���� Asset Information�� ���̱� ����
				isSearchAsset(this.DdnlArea.SelectedValue, this.TbxEmpNoAsset.Text);	
				this.TbxEmpNoAsset.Text = "";
				
			}
			else
			{
				isSearchAsset("", "zzzz");	//���� ���� ���ֱ����� ���. �ٷ� ���ִ� ��� ã�ƾ���. 20051104 lglsy
				this.TbxEmpNoAsset.Text = "";
				ScriptHelper.ShowAlert(
					MessageManager.GetMessage( "Ticket", "NO_EMP" )
					);
			}
		
		}
		//lglsy 20051106 �߰�
		private void BtnAddAsset_Click(object sender, System.EventArgs e)
		{
			isGetAsset(this.TbxAssetNo.Text);	
			this.TbxAssetNo.Text = "";		
		}
		//lglsy 20051106 �߰�
		private void isGetAsset( string AssetNo )
		{
			if ( AssetNo.CompareTo( "" ) == 0 )
			{
				return;
			}

			TicketDS ds = TicketController.isGetAsset( AssetNo );

			if (ds.TB_TICKET_ASSETLIST.Count < 1 )
			{
				ScriptHelper.ShowAlert( MessageManager.GetMessage( "Common", "NOT_EXISTS" ) );
				return;
			}

			if ( this.DgrdDataGrid.Items.Count > 0  )
			{
				TicketDS dsAsset = new TicketDS();
		
				for( int inx=0; inx<this.DgrdDataGrid.Items.Count; inx++ )
				{
					TicketDS.TB_TICKET_ASSETLISTRow rowAsset = dsAsset.TB_TICKET_ASSETLIST.NewTB_TICKET_ASSETLISTRow();
					
					if ( this.DgrdDataGrid.Items[inx].Cells[2].Text != AssetNo )
					{
						rowAsset.AssetNo = this.DgrdDataGrid.Items[inx].Cells[1].Text;
						rowAsset.NodeName = this.DgrdDataGrid.Items[inx].Cells[2].Text;
						rowAsset.ModelNumber = this.DgrdDataGrid.Items[inx].Cells[3].Text;
						rowAsset.EmpNo = this.DgrdDataGrid.Items[inx].Cells[4].Text;
						rowAsset.EmpName = this.DgrdDataGrid.Items[inx].Cells[5].Text;
						rowAsset.DeptName = this.DgrdDataGrid.Items[inx].Cells[6].Text;
						rowAsset.SiteCode = this.DgrdDataGrid.Items[inx].Cells[7].Text;
						rowAsset.SiteDesc = this.DgrdDataGrid.Items[inx].Cells[8].Text;
						rowAsset.CompStatusDesc = this.DgrdDataGrid.Items[inx].Cells[9].Text;
						rowAsset.CPUTypeDesc = this.DgrdDataGrid.Items[inx].Cells[10].Text;
						
						dsAsset.TB_TICKET_ASSETLIST.AddTB_TICKET_ASSETLISTRow( rowAsset );
					}
				}

				dsAsset.TB_TICKET_ASSETLIST.AddTB_TICKET_ASSETLISTRow( 
					ds.TB_TICKET_ASSETLIST[0].AssetNo,
					ds.TB_TICKET_ASSETLIST[0].NodeName, 
					ds.TB_TICKET_ASSETLIST[0].ModelNumber, 
					ds.TB_TICKET_ASSETLIST[0].EmpNo, 
					ds.TB_TICKET_ASSETLIST[0].EmpName, 
					ds.TB_TICKET_ASSETLIST[0].DeptName,
					ds.TB_TICKET_ASSETLIST[0].SiteCode, 
					ds.TB_TICKET_ASSETLIST[0].SiteDesc, 
					ds.TB_TICKET_ASSETLIST[0].CompStatusDesc,
					ds.TB_TICKET_ASSETLIST[0].CPUTypeDesc
					);
		
				this.DgrdDataGrid.DataSource = dsAsset.TB_TICKET_ASSETLIST;
			}
			else
			{
				this.DgrdDataGrid.DataSource = ds.TB_TICKET_ASSETLIST;
			}

			this.DgrdDataGrid.DataBind();
			this.TbxAssetNo.Text = "";
		}

		private void BtnAssetClare_Click(object sender, System.EventArgs e)
		{
			isSearchAsset("", "ZZZZZZZZ");	//20051230  DgrdDataGrid�� ����Ÿ�� clear�ϱ����ؼ� ���. �Ӽ��������Ͽ� �����ϸ� �����Ͽ�����. lglsy
		}
	}
}
