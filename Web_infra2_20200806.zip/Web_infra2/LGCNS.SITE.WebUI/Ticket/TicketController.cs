using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.FileManagement;

using LGCNS.SITE.Ticket.Biz;
using LGCNS.SITE.DTO;


namespace LGCNS.SITE.WebUI.Ticket
{
	/// <summary>
	/// TicketController�� ���� ��� �����Դϴ�.
	/// </summary>
	public class TicketController : ControllerBase
	{
		public TicketController() {}

		#region ManageTicket
		public static void InsertTicket (TicketDS ds)
		{
			TicketBizTx biz = null ;

			try
			{
				biz = new TicketBizTx();
				biz.InsertTicket (ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static void UpdateTicket (TicketDS ds)
		{
			TicketBizTx biz = null ;

			try
			{
				biz = new TicketBizTx();
				biz.UpdateTicket(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static void DeleteTicket ( string TicketNo )
		{
			TicketBizTx biz = null ;

			try
			{
				biz = new TicketBizTx();
				biz.DeleteTicket( TicketNo );
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}
		public static void UpdateTicketForEngineer (TicketDS ds)
		{
			TicketBizTx biz = null ;

			try
			{
				biz = new TicketBizTx();
				biz.UpdateTicketForEngineer(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		#endregion

		#region ManageTicketTemp
		public static string InsertTicketTemp (TicketDS ds)
		{
			TicketBizTx biz = null ;
			string TicketID;

			try
			{
				biz = new TicketBizTx();
				TicketID = biz.InsertTicketTemp (ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}

			return TicketID;
		}

		public static void DeleteTicketASSET( string TicketID, string TicketNo )
		{
			TicketBizTx biz = null ;

			try
			{
				biz = new TicketBizTx();
				biz.DeleteTicketASSET(TicketID, TicketNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static void DeleteTicketTemp( string TicketID )
		{
			TicketBizTx biz = null ;

			try
			{
				biz = new TicketBizTx();
				biz.DeleteTicketTemp(TicketID);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}
		public static void UpdateTicketTempForEngineer(TicketDS ds)
		{
			TicketBizTx biz = null ;

			try
			{
				biz = new TicketBizTx();
				biz.UpdateTicketTempForEngineer(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		#endregion

		public static TicketDS SelectTicket(string TicketNo)
		{

			TicketBizNTx biz = null ;
			TicketDS ds = null ;

			try
			{
				biz = new TicketBizNTx();
				ds = biz.SelectTicket (TicketNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static TicketDS SelectMailTicket(string TicketNo, string TicketID, string SRFlag)
		{

			TicketBizNTx biz = null ;
			TicketDS ds = null ;

			try
			{
				biz = new TicketBizNTx();
				ds = biz.SelectMailTicket (TicketNo, TicketID, SRFlag);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static TicketDS SelectTicketTemp(string TicketID)
		{

			TicketBizNTx biz = null ;
			TicketDS ds = null ;

			try
			{
				biz = new TicketBizNTx();
				ds = biz.SelectTicketTemp (TicketID);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static TicketDS SelectTicketListByEmp( string Area, string EmpNo )
		{
			return SelectTicketListByEmp( Area, EmpNo, "" );
		}

		public static TicketDS SelectTicketListByEmp( string Area, string EmpNo, string TicketNo )
		{
			TicketDS ds = null ;
			TicketBizNTx biz = null ;

			try
			{
				biz = new TicketBizNTx();
				ds = biz.SelectTicketListByEmp (Area,EmpNo,TicketNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

//lglsy 20051107 ticketno , assetno ����
		public static TicketDS InsertTicketAssetData( string TicketID, string TicketNo,string AssetNo, string CompStatus, string CPUType, string ModelNumber)
		{
			TicketDS ds = null ;
			TicketBizNTx biz = null ;

			try
			{
				biz = new TicketBizNTx();
				ds = biz.InsertTicketAssetData (TicketID, TicketNo,AssetNo,  CompStatus,  CPUType,  ModelNumber);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		//lglsy 20051014 �߰� InsertTicket���� Add Ŭ���� Asset Information�� ���̱� ����
		public static TicketDS SelectTicketAssetList( string Area, string EmpNo  )
		{
			TicketBizNTx biz = null ;
			TicketDS ds = null ;

			try
			{
				biz = new TicketBizNTx();
				ds = biz.SelectTicketAssetList(Area, EmpNo );
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		//lglsy 20051107 �߰� �ڻ� ������
		public static TicketDS isSelectTicketAssetList(string TicketNo, string TicketID)
		{
			TicketBizNTx biz = null ;
			TicketDS ds = null ;

			try
			{
				biz = new TicketBizNTx();
				ds = biz.isSelectTicketAssetList( TicketNo, TicketID);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		//lglsy 20051014 �߰� InsertTicket���� Add Ŭ���� �ڻ����� �߰�
		public static TicketDS isGetAsset( string AssetNo  )
		{
			TicketBizNTx biz = null ;
			TicketDS ds = null ;

			try
			{
				biz = new TicketBizNTx();
				ds = biz.isGetAsset(AssetNo );
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}



		public static TicketDS SelectTicketList ( int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			TicketDS ds = null;
			TicketBizNTx biz = null;
			
			try
			{
				biz = new TicketBizNTx();
				ds = biz.SelectTicketList(currentPage, pageSize, searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}
//20060502 Ticket���� ������ ��ϵȰ͵� ���̵��� ��.(HomePage.aspx����)
		public static TicketDS SelectTicketListHome ( int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			TicketDS ds = null;
			TicketBizNTx biz = null;
			
			try
			{
				biz = new TicketBizNTx();
				ds = biz.SelectTicketListHome(currentPage, pageSize, searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}
		
		public static TicketDS SelectTicketList3Days ( int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			TicketDS ds = null;
			TicketBizNTx biz = null;
			
			try
			{
				biz = new TicketBizNTx();
				ds = biz.SelectTicketList3Days(currentPage, pageSize, searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}
		public static TicketDS SelectTicketListXls ( int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			TicketDS ds = null;
			TicketBizNTx biz = null;
			
			try
			{
				biz = new TicketBizNTx();
				ds = biz.SelectTicketListXls(currentPage, pageSize, searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}



		public static DataSet SelectDSR( string Area, string DateFrom, string Dateto )
		{
			DataSet ds = null;
			TicketBizNTx biz = null;

			try
			{
				biz = new TicketBizNTx();
				ds = biz.SelectDSR( Area, DateFrom, Dateto);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}


		public static void ConfirmTicket( string TicketNo )
		{
			TicketBizTx biz = null ;

			try
			{
				biz = new TicketBizTx();
				biz.ConfirmTicket(TicketNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static void ConfirmCancelTicket( string TicketNo )
		{
			TicketBizTx biz = null ;

			try
			{
				biz = new TicketBizTx();
				biz.ConfirmCancelTicket(TicketNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static bool isNumeric( string s )
		{
			try
			{
				int i = int.Parse( s );
			}
			catch( Exception ex )
			{
				string errmsg=ex.Message;
				return false;
			}

			return true;
		}
		
		public static bool isValidTicket( string TicketNo )	//Capex���� ���� ������ ���� �����ؾ���.
		{
            string result="";
            TicketBizNTx biz = null ;

            try
            {
                biz = new TicketBizNTx();
                result = biz.isValidTicket (TicketNo);
            }
            catch(Exception ex)
            {
                throw ex ;
            }
            finally
            {
                if(biz != null)
                {
                    biz.Dispose();
                    biz = null;
                }
            }

            if(result.Equals("Y"))
                return true;
            else
                return false;
		}

		public static void FileSave( FileTransferObject fto )
		{
			TicketBizTx biz = null;

			try
			{
				biz = new TicketBizTx();
				biz.FileSave(fto);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}			
		}


        public static void DeleteErrorCapexNo()
        {
            TicketBizTx biz = null;

            try
            {
                biz = new TicketBizTx();
                biz.DeleteErrorCapexNo();
            }
            catch(Exception ex)
            {
                throw ex ;
            }
            finally
            {
                if(biz!=null)
                {
                    biz.Dispose () ;
                    biz = null ;
                }
            }			
        }
		public static void FileDelete( FileTransferObject fto )
		{
			TicketBizTx biz = null;

			try
			{
				biz = new TicketBizTx();
				biz.FileDelete(fto);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}			
		}


		public static TicketDS BulkImport( FileTransferObject fto )
		{
			TicketBizTx biz = null;

			try
			{
				biz = new TicketBizTx();
				return biz.BulkImport(fto);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}


		public static string BulkInsertTicket( string UserID, string Area )
		{
			TicketBizTx biz = null;
			string ResultStatement = "";

			try
			{
				biz = new TicketBizTx();
				ResultStatement = biz.BulkInsertTicket(UserID,Area);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}

			return ResultStatement;
		}



		public static string SelectMailCheck( string ticketNo )
		{
			TicketBizTx biz = null;
			string ResultStatement = "";

			try
			{
				biz = new TicketBizTx();
				ResultStatement = biz.SelectMailCheck(ticketNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}

			return ResultStatement;
		}


		public static EmpDS SelectEmp(string Area, string EmpNo)
		{
			EmpDS ds = null;
			TicketBizNTx biz = null;
			
			try
			{
				biz = new TicketBizNTx();
				ds = biz.SelectEmp(Area,EmpNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}

		public static EmpDS SelectEmp(string EmpNo)
		{
			EmpDS ds = null;
			TicketBizNTx biz = null;
			
			try
			{
				biz = new TicketBizNTx();
				ds = biz.SelectEmp(EmpNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}
		public static TicketDS SelectIMACTicketListXls ( int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			TicketDS ds = null;
			TicketBizNTx biz = null;
			
			try
			{
				biz = new TicketBizNTx();
				ds = biz.SelectIMACTicketListXls(currentPage, pageSize, searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}
		public static ICMSDS SelectICMS( string TicketNo )
		{
			ICMSDS ds = null;
			TicketBizNTx biz = null;
			
			try
			{
				biz = new TicketBizNTx();
				ds = biz.SelectICMS( TicketNo );
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}

        public static bool isExistTicket( string TicketNo )
        {
            int cntTicket = 0;
            TicketBizNTx biz = null ;
            TicketDS ds = null ;

            try
            {
                biz = new TicketBizNTx();
                ds = biz.SelectTicket (TicketNo);
                cntTicket = ds.TB_TICKET_ENTIRE.Count;
            }
            catch(Exception ex)
            {
                throw ex ;
            }
            finally
            {
                if(ds != null)
                {
                    ds.Dispose();
                    ds = null;
                }
            }

            if( cntTicket > 0 )
            {
                return true;
            }
            else
            {
                return false;
            }
        }

		public static bool isExistICMS( string TicketNo )
		{
			int cntICMS = 0;
			ICMSDS ds = null;

			try
			{
				ds = SelectICMS( TicketNo );
				cntICMS = ds.TB_ICMS.Count;
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(ds != null)
				{
					ds.Dispose();
					ds = null;
				}
			}

			if( cntICMS == 1 )
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		public static bool isExistAcq( string TicketNo )
		{
			int cnt = 0;
			AcqDS ds = null;
			TicketBizNTx biz = null;
			
			try
			{
				biz = new TicketBizNTx();
				ds = biz.SelectAcq( TicketNo );

				cnt = ds.TB_ACQ.Count;
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			if( cnt == 1 )
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		#region Capex
		public static TicketDS SelectMailCapex( )
		{

			TicketBizNTx biz = null ;
			TicketDS ds = null ;

			try
			{
				biz = new TicketBizNTx();
				
				ds = biz.SelectMailCapex ();
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static bool isExistCapex( string TicketNo )
		{
			TicketBizNTx biz = null ;
			CapexDS ds = null;
			int cntCapex = 0;

			try
			{
				biz = new TicketBizNTx();
				
				ds = biz.SelectCapexTicket (TicketNo);
				cntCapex = ds.TB_CAPEX_LIST1.Count;
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			if( cntCapex == 0 )
			{
				return true;
			}
			else
			{
				return false;
			}
		}


		public static string CreateCapex( string TicketNo, string Area, string UserID, string Flag )
		{
			TicketBizTx biz = null;
			string ResultStatement = "";

			try
			{
				biz = new TicketBizTx();
				ResultStatement = biz.CreateCapex(TicketNo, Area, UserID, Flag);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}

			return ResultStatement;
		}

		#endregion
	}
}
