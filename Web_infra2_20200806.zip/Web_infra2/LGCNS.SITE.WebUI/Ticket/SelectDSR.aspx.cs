using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.Paging ;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Ticket
{
	/// <summary>
	/// SelectDSR�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectDSR : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxDateFrom;
		protected System.Web.UI.WebControls.TextBox TbxDateTo;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdTicketList;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdTicket;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdSRPF;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdSRPFList;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdICMS;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdICMSList;
		protected System.Web.UI.WebControls.Button BtnDetailTicket;
		protected System.Web.UI.WebControls.Panel PnlTicket;
		protected System.Web.UI.WebControls.Button BtnDetailSRPF;
		protected System.Web.UI.WebControls.Panel PnlSRPF;
		protected System.Web.UI.WebControls.Button BtnDetailICMS;
		protected System.Web.UI.WebControls.Panel PnlICMS;
		protected System.Web.UI.WebControls.Label LblICMSCount;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected System.Web.UI.WebControls.Button BtnDetailMonth;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdMonthList;
		protected System.Web.UI.WebControls.Panel PnlMonth;
		protected System.Web.UI.WebControls.Label LblSRPFCount;
		protected System.Web.UI.WebControls.Label LblInqueryDateForSRPF;
		protected System.Web.UI.WebControls.Label LblInqueryDateForICMS;
		protected System.Web.UI.WebControls.Button BtnSearch;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos(true);

			XjosHelper.SetValidator (this.TbxDateFrom,
				new XjosValidator(XjosValidatorType.Required),
				new XjosValidator(XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);
			XjosHelper.SetValidator (this.TbxDateTo,
				new XjosValidator(XjosValidatorType.Required),
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);

			if ( !Page.IsPostBack )
			{
				InitializeControls();
				BtnSearch_Click( sender, e );
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
			this.BtnDetailTicket.Click += new System.EventHandler(this.BtnDetailTicket_Click);
			this.BtnDetailSRPF.Click += new System.EventHandler(this.BtnDetailSRPF_Click);
			this.BtnDetailICMS.Click += new System.EventHandler(this.BtnDetailICMS_Click);
			this.BtnDetailMonth.Click += new System.EventHandler(this.BtnDetailMonth_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			SearchDSR( this.DdnlArea.SelectedValue, this.TbxDateFrom.Text, this.TbxDateTo.Text );
		}

		private void InitializeControls()
		{
			//DSR�� AREA ����Ʈ �߰�
			// ���� : 2005/04/13 
			// ������ : DSR���� AREA LIST ���� CARRIER �κ� �߰���û
			// �������� :DSR���� AREA LIST ���� CARRIER �κ� �߰���
			// ����� Method : InitializeControls
			// ��� : �߰��Ͽ����� �켱�� �ݿ� ����.(Configuration ���� �̰� ��� ����)

			//LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea, true );
			LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea, true, "CARRIER" );

			this.TbxDateFrom.Text = DateTime.Now.ToShortDateString();
			this.TbxDateTo.Text = DateTime.Now.ToShortDateString();
		}

		private void SearchDSR( string Area, string FromDate, string ToDate )
		{
			int SRPFCount = 0;
			int PFCount = 0;
			int IcmsItemSum = 0;
			int IcmsTotal = 0;
			//String SRPFRow = null;

			DataSet ds = TicketController.SelectDSR( Area, FromDate, ToDate  );
			//"TB_DSR_TICKET", "TB_DSR_TICKET_LIST", "TB_DSR_SRPF", "TB_DSR_SRPF_LIST", "TB_DSR_ICMS", "TB_DSR_ICMS_LIST"

			this.DgrdTicket.DataSource = ds.Tables["TB_DSR_TICKET"];
			this.DgrdTicket.DataBind();

			this.DgrdTicketList.DataSource = ds.Tables["TB_DSR_TICKET_LIST"];
			this.DgrdTicketList.DataBind();

			this.DgrdSRPF.DataSource = ds.Tables["TB_DSR_SRPF"];
			this.DgrdSRPF.DataBind();

			SRPFCount=Convert.ToInt32( ds.Tables["TB_DSR_SRPF"].Rows[0][1].ToString() );
			SRPFCount=SRPFCount+Convert.ToInt32( ds.Tables["TB_DSR_SRPF"].Rows[0][2].ToString() );
			PFCount=Convert.ToInt32( ds.Tables["TB_DSR_SRPF"].Rows[0][3].ToString() );
			//this.LblSRPFCount.Text = ds.Tables["TB_DSR_SRPF_LIST"].Rows.Count.ToString();
			this.LblSRPFCount.Text = Convert.ToString(SRPFCount) + "/" + Convert.ToString(PFCount);
			
			
			this.LblInqueryDateForSRPF.Text = " ( " + DateTime.Parse( ToDate ).ToShortDateString() + " ) ";

			this.DgrdSRPFList.DataSource = ds.Tables["TB_DSR_SRPF_LIST"];
			this.DgrdSRPFList.DataBind();

			this.DgrdICMS.DataSource = ds.Tables["TB_DSR_ICMS"];
			this.DgrdICMS.DataBind();

			this.LblICMSCount.Text = ds.Tables["TB_DSR_ICMS"].Rows[0][6].ToString();
			this.LblInqueryDateForICMS.Text = " ( " + DateTime.Parse( ToDate ).ToShortDateString() + " ) ";

			this.DgrdICMSList.DataSource = ds.Tables["TB_DSR_ICMS_LIST"];
			this.DgrdICMSList.DataBind();

			this.DgrdMonthList.DataSource = ds.Tables["TB_DSR_ICMS_MONTH_LIST"];
			this.DgrdMonthList.DataBind();
			/* ICMS Count Check : 2005/07/02
			 * field �׸� Sum�� Total�� ���� ������ Total�� ���������� ǥ��
			 * */
			for(int i=0; i<4; i++)
			{
				IcmsItemSum=0;
				for(int j=1; j<7; j++)
				{
					IcmsItemSum+=Convert.ToInt32( ds.Tables["TB_DSR_ICMS"].Rows[i][j].ToString() );
				}
				IcmsTotal=Convert.ToInt32( ds.Tables["TB_DSR_ICMS"].Rows[i][7].ToString() );
				if(IcmsItemSum != IcmsTotal)
				{// Total �� ���� ������ ���������� ǥ��
					this.DgrdICMS.Items[i].Cells[7].ForeColor = Color.Red;
				}
				else
				{
					this.DgrdICMS.Items[i].Cells[7].ForeColor = Color.Black;
				}
			}
		}

		private void BtnDetailTicket_Click(object sender, System.EventArgs e)
		{
			if ( this.PnlTicket.Visible )
			{
				this.PnlTicket.Visible = false;
			}
			else
			{
				this.PnlTicket.Visible = true;
			}
		}

		private void BtnDetailSRPF_Click(object sender, System.EventArgs e)
		{
			if ( this.PnlSRPF.Visible )
			{
				this.PnlSRPF.Visible = false;
			}
			else
			{
				this.PnlSRPF.Visible = true;
			}
		}

		private void BtnDetailICMS_Click(object sender, System.EventArgs e)
		{
			if ( this.PnlICMS.Visible )
			{
				this.PnlICMS.Visible = false;
			}
			else
			{
				this.PnlICMS.Visible = true;
			}
		}

		private void BtnDetailMonth_Click(object sender, System.EventArgs e)
		{
			if ( this.PnlMonth.Visible )
			{
				this.PnlMonth.Visible = false;
			}
			else
			{
				this.PnlMonth.Visible = true;
			}
		}
	}
}
