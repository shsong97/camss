using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.Paging ;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Ticket
{
	/// <summary>
	/// SelectTicketList�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectTicketList : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected System.Web.UI.WebControls.DropDownList DdnlStatus;
		protected System.Web.UI.WebControls.DropDownList DdnlHDConfirm;
		protected System.Web.UI.WebControls.TextBox TbxEmpNo;
		protected System.Web.UI.WebControls.TextBox TbxEmpName;
		protected System.Web.UI.WebControls.DropDownList DdnlCreateID;
		protected System.Web.UI.WebControls.Button BtnSearch;
		protected System.Web.UI.WebControls.TextBox TbxPageSize;
		protected System.Web.UI.WebControls.Label LblTotalCount;
		protected System.Web.UI.WebControls.DropDownList DdlPage;
		protected System.Web.UI.WebControls.Label LblTotalPages;
		protected System.Web.UI.WebControls.TextBox TbxCloseDateFrom;
		protected System.Web.UI.WebControls.TextBox TbxCloseDateTo;
		protected System.Web.UI.WebControls.TextBox TbxCreateDateFrom;
		protected System.Web.UI.WebControls.TextBox TbxCreateDateTo;
		protected System.Web.UI.WebControls.Button BtnSaveExcel;
		protected System.Web.UI.WebControls.Button BtnClear;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected System.Web.UI.WebControls.DropDownList DdnlCompleteFlag;
		protected System.Web.UI.WebControls.DropDownList DdnlDivision;
		protected System.Web.UI.WebControls.DropDownList DdnlEngineer;
		protected System.Web.UI.WebControls.DropDownList DdnlEngineer2;
		protected System.Web.UI.WebControls.TextBox TbxSiteCode;
		protected System.Web.UI.WebControls.TextBox TbxDescription;
        protected System.Web.UI.WebControls.Button BtnCapexError;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			NavigationHelper.RegisterHiddenIFrame ("HiddenFrame") ;
			NavigationHelper.SetNavigation (this.BtnSaveExcel, "HiddenFrame", "SelectTicketListAsXls.aspx", true) ;

			this.DgrdDataGrid.NavigateOnRowClick (
				"", // �̵��� �����Ӹ�, ��������ü�� �̵��Ҷ� ""�� �����Ѵ�.
				"SelectTicket.aspx", // LinkŬ���� �̵��� Url  (����ȸȭ��)
				new string [2] {"TicketNo", "TicketID"},  // LinkŬ���� ������ Query String �� key�� �迭
				new int [2] {0, 2}, // LinkŬ���� ������ Query String �� value���� ������ Cell Index�� �迭
				false  // // ������������ ���� SelectTicket.aspx ���� submit��Ų��. (POST������� ȣ���Ѵ�.)
				) ;
			
			XjosHelper.RegisterXjos (true) ;

			XjosHelper.SetValidator (this.TbxCreateDateFrom,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);
			XjosHelper.SetValidator (this.TbxCreateDateTo,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);
			XjosHelper.SetValidator (this.TbxCloseDateFrom,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);
			XjosHelper.SetValidator (this.TbxCloseDateTo,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);

			XjosHelper.ValidateOnClick(this.BtnSearch); // Xjos Validation�� ������ ��ư ����

			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if ( !Page.IsPostBack )
			{
				InitializeControls();
				//SearchTicketListPaging();
			}

			if ( this.IsSubmittedBy )
			{
				InitializeControls();
				//SearchTicketListPaging();
			}
			if ( this.IsReloaded ) {}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
            this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            this.BtnCapexError.Click += new System.EventHandler(this.BtnCapexError_Click);
            this.Load += new System.EventHandler(this.Page_Load);

        }
		#endregion

		private void InitializeControls()
		{
			InitializeControls( false );
		}

		private void InitializeControls(bool isClear)
		{
			this.TbxTicketNo.Text = "";
			this.TbxEmpNo.Text = "";
			this.TbxEmpName.Text = "";
			this.DdnlHDConfirm.SelectedValue = "";
			this.DdnlCompleteFlag.SelectedValue = "";

			LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea, false );
			this.DdnlArea.Items.Add("CARRIER");
			this.DdnlArea.Items.Add("");
			this.DdnlArea.SelectedIndex = 4;
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlStatus, "TICKET_STATUS", true, "STATUS" );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlDivision, "TICKET_DIVISION", true);
			LGCNS.SITE.Common.WebUI.UserInfo.BindDropDownList( this.DdnlEngineer, true );
			LGCNS.SITE.Common.WebUI.UserInfo.BindDropDownList( this.DdnlEngineer2, true );// closed Engineer :2005/10/14
			LGCNS.SITE.Common.WebUI.UserInfo.BindDropDownList( this.DdnlCreateID, true );

			if (!isClear)
			{
				// 2005-06-01 : Helpdesk������ Engineer�κ� üũ�ȵǰ�
				if ( this.CurrentUserAuthority.CompareTo( "H" ) > 0 )
				{
					this.DdnlEngineer.SelectedValue = this.CurrentUserID;
					this.DdnlEngineer2.SelectedValue = this.CurrentUserID;
				}
			}

			TicketDS ds = new TicketDS();
			this.DgrdDataGrid.ShowFooterMessage = true;
			this.DgrdDataGrid.FooterMessage = MessageManager.GetMessage( "Common", "NO_DATA" );
			this.DgrdDataGrid.DataSource = ds.TB_TICKET_LIST;
			this.DgrdDataGrid.DataBind();

			this.TbxCloseDateFrom.Text = "";
			this.TbxCloseDateTo.Text = "";

			this.TbxCreateDateFrom.Text = "";
			this.TbxCreateDateTo.Text = "";
			this.TbxDescription.Text = "";

			this.LblTotalCount.Text = "0";
			this.LblTotalPages.Text = "1";

			if ( !isClear )
			{
				if ( this.CurrentUserAuthority.CompareTo( "T" ) == 0 )
				{
					this.DdnlEngineer.SelectedValue = this.CurrentUserAlterUserID;
					this.DdnlHDConfirm.SelectedValue = "N";
					SearchTicketListPaging();
				}
			}

			if( isClear )
			{
				this.DdnlHDConfirm.SelectedValue = "";
			}

		}

		private void BtnClear_Click(object sender, System.EventArgs e)
		{
			InitializeControls( true );
		}

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			SearchTicketListPaging();
		}

		private void SearchTicketListPaging()
		{
			NameValueCollection searchCondition = new NameValueCollection();
			searchCondition["QueryType"] = "Normal";
			searchCondition["Area"] = this.DdnlArea.SelectedValue;
			searchCondition["TicketNo"] = this.TbxTicketNo.Text;
			searchCondition["CreateDateFrom"] = this.TbxCreateDateFrom.Text;
			searchCondition["CreateDateTo"] = this.TbxCreateDateTo.Text;
			searchCondition["CloseDateFrom"] = this.TbxCloseDateFrom.Text;
			searchCondition["CloseDateTo"] = this.TbxCloseDateTo.Text;
			searchCondition["HdConfirm"] = this.DdnlHDConfirm.SelectedValue;
			searchCondition["Status"] = this.DdnlStatus.SelectedValue;
			searchCondition["EmpNo"] = this.TbxEmpNo.Text;
			searchCondition["EmpName"] = this.TbxEmpName.Text;
			searchCondition["Engineer"] = this.DdnlEngineer.SelectedValue;
			searchCondition["CreateID"] = this.DdnlCreateID.SelectedValue;
			searchCondition["CompleteFlag"] = this.DdnlCompleteFlag.SelectedValue;
			searchCondition["Division"] = this.DdnlDivision.SelectedValue;
			searchCondition["Engineer2"] = this.DdnlEngineer2.SelectedValue;
			searchCondition["SiteCode"] = this.TbxSiteCode.Text;
			searchCondition["Description"] = this.TbxDescription.Text;

			int currentPage = Convert.ToInt32(this.DdlPage.SelectedValue);
			int pageSize	= Convert.ToInt32(this.TbxPageSize.Text);

			TicketDS ds = TicketController.SelectTicketList( currentPage, pageSize, searchCondition );
			//this.DgrdDataGrid.VirtualItemCount = 100 ;
			this.DgrdDataGrid.DataSource = ds.TB_TICKET_LIST ;
			this.DgrdDataGrid.DataBind() ;

			//��Ͽ� ���� ����
			int totalPage			= PagingHelper.GetTotalPage (ds) ;
			this.LblTotalCount.Text = PagingHelper.GetTotalCount (ds).ToString () ;
			this.LblTotalPages.Text = totalPage.ToString() ;

			//Page DropDownList Setting
			this.DdlPage.Items.Clear();
			for(int i = 1; i <= totalPage ; i++)
			{
				this.DdlPage.Items.Add(i.ToString());
			}

			//�������� ������ ���õǵ���
			if(this.DdlPage.Items.Count > 0)
			{
				if( currentPage <= totalPage )
				{
					this.DdlPage.Items[currentPage - 1].Selected = true;
				}
				else
				{
					this.DdlPage.Items[0].Selected = true;
				}
			}
		}

        private void BtnCapexError_Click(object sender, System.EventArgs e)
        {
            TicketController.DeleteErrorCapexNo();
        }
	}
}
