using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
//using System.Web.Mail;
using System.Net.Mail;
using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;


namespace LGCNS.SITE.WebUI.Ticket
{
	/// <summary>
	/// SelectTicket�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectTicket : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Button BtnList;
		protected System.Web.UI.WebControls.TextBox TbxEmpNo;
		protected System.Web.UI.WebControls.Button BtnAddEmp;
		protected System.Web.UI.WebControls.Button BtnSearchEmp;
		protected System.Web.UI.WebControls.Button BtnSelectAll;
		protected System.Web.UI.WebControls.Button BtnUnSelectAll;
		protected System.Web.UI.WebControls.Label LblTicketID;
		protected System.Web.UI.WebControls.TextBox TbxArea;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdTicketEmp;
		protected System.Web.UI.WebControls.TextBox TbxDesc;
		protected System.Web.UI.WebControls.TextBox TbxZone;
		protected System.Web.UI.WebControls.TextBox TbxEngineer;
		protected System.Web.UI.WebControls.TextBox TbxStatus;
		protected System.Web.UI.WebControls.TextBox TbxAHD;
		protected System.Web.UI.WebControls.TextBox TbxICMS;
		protected System.Web.UI.WebControls.TextBox TbxBill;
		protected System.Web.UI.WebControls.TextBox TbxRemark;
		protected System.Web.UI.WebControls.TextBox TbxReasonNoHandle;
		protected System.Web.UI.WebControls.TextBox TbxCloseContents;
		protected System.Web.UI.WebControls.TextBox TbxCloseDate;
		protected System.Web.UI.WebControls.TextBox TbxHdConfirm;
		protected System.Web.UI.WebControls.TextBox TbxCreateID;
		protected System.Web.UI.WebControls.TextBox TbxCreateDate;
		protected System.Web.UI.WebControls.TextBox TbxUpdateID;
		protected System.Web.UI.WebControls.TextBox TbxUpdateDate;
		protected System.Web.UI.WebControls.Button BtnICMS;
		protected System.Web.UI.WebControls.Button BtnConfirm;
		protected System.Web.UI.WebControls.Button BtnUpdate;
		protected System.Web.UI.WebControls.Button BtnDelete;
		protected System.Web.UI.WebControls.Button BtnCancel;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdHistory;
		protected System.Web.UI.WebControls.Button BtnAcq;
		protected System.Web.UI.WebControls.Button BtnConfirmCancel;
		protected System.Web.UI.WebControls.Button BtnSurvey;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
		protected System.Web.UI.WebControls.TextBox TbxFinishPlan;
		protected System.Web.UI.WebControls.TextBox TbxDivision;
		protected System.Web.UI.WebControls.TextBox TbxAltEngineer;
		protected System.Web.UI.WebControls.Button BtnCapex;
		protected System.Web.UI.WebControls.TextBox TbxStatusFlag;
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; } 

			XjosHelper.RegisterXjos(true);

			string TicketNo = this.Request["TicketNo"];
			string TicketID = this.Request["TicketID"];
			if (TicketID == null)
			{
				TicketID = "0";
			}
			// GET������� ȣ��ɶ�
			if ( !this.IsPostBack )
			{
				SelectTicketData( TicketNo, TicketID );
			}

			// POST������� ȣ��ɶ�
			// NavigationHelper�� LDataGrid�� ���� POST������� ȣ��ɶ��� ���� ������ �ε�ÿ��� 
			// IsPostBack ������Ƽ�� true�� �ǹǷ� 
			// IsSubmittedBy ������Ƽ�� ���� POST������� ȣ��Ǿ������� üũ�� �� �ִ�.
			if(this.IsSubmittedBy)
			{
				SelectTicketData( TicketNo, TicketID );
			}

            ClientScript.RegisterHiddenField("TicketNo", TbxTicketNo.Text) ;
            ClientScript.RegisterHiddenField("TicketID", LblTicketID.Text) ;

			NavigationHelper.SetNavigation(this.BtnICMS, "", "../ICMS/InsertICMS.aspx", true );
			NavigationHelper.SetNavigation(this.BtnAcq, "", "../Acq/InsertAcq.aspx", true );
			NavigationHelper.SetHistoryBack(this.BtnCancel) ;

			ScriptHelper.SetConfirmMessageOn (this.BtnDelete, MessageManager.GetMessage("Common", "DELETE_QUESTION") );
			ScriptHelper.SetConfirmMessageOn (this.BtnConfirm, MessageManager.GetMessage("Common", "CONFIRM_QUESTION") );

			//lglsy 20051107 �ڻ� ������.
			isSelectTicketAssetList(TicketNo, TicketID);

			if ( this.TbxStatus.Text == "closed" || this.TbxStatus.Text == "cancelled" )
			{
				this.BtnConfirm.Visible = true;
				this.BtnSurvey.Visible=false;
			}
			else
			{
				this.BtnConfirm.Visible = false;
				if( TbxAHD.Text == "open" && this.CurrentUserAuthority.CompareTo("H") <=0 )
				{
					BtnSurvey.Visible=true;
				}
			}

			if ( this.CurrentUserAuthority.CompareTo("A") <= 0 )
				this.BtnDelete.Visible = true;
			else
				this.BtnDelete.Visible = false;

			if ( !TicketController.isValidTicket( this.TbxTicketNo.Text ) )
			{
				this.BtnICMS.Visible = false;
				this.BtnConfirm.Visible = false;
				this.BtnAcq.Visible = false;
				this.BtnCapex.Visible = false;
			}

			if ( this.CurrentUserAuthority.CompareTo("H") <=0 )
			{
				NavigationHelper.SetNavigation(this.BtnUpdate, "", "UpdateTicket.aspx", true );
			}
			else
			{
				NavigationHelper.SetNavigation(this.BtnUpdate, "", "UpdateTicketForEngineer.aspx", true );
				this.BtnConfirm.Visible = false;
			}

			if ( this.TbxHdConfirm.Text == "Y" )
			{
				this.BtnUpdate.Visible = false;
				this.BtnDelete.Visible = false;
				this.BtnConfirm.Visible = false;
				this.BtnICMS.Visible = false;
				this.BtnAcq.Visible = false;
				this.BtnConfirmCancel.Visible=true;
				this.BtnSurvey.Visible=true;

			}
            this.BtnUpdate.Visible = true;

			if ( TicketController.isValidTicket( this.TbxTicketNo.Text ) )
			{
				//ICMS�� �����ϸ� ICMS ��ư "Y"
				if( TicketController.isExistICMS( this.TbxTicketNo.Text ) )
				{
					this.BtnICMS.Visible = true;
				}

				//Acq�� �����ϸ� 
				if( TicketController.isExistAcq( this.TbxTicketNo.Text ) )
				{
					this.BtnAcq.Visible = true;
				}

				//			Capex ���� ���̱� ����
				if ( this.CurrentUserAuthority.CompareTo("A") <= 0 )
				{
					if( TicketController.isExistCapex( this.TbxTicketNo.Text ) )
					{
						BtnCapex.Visible=true;
					}
					else
					{
						BtnCapex.Visible=false;
					}
				}
				else
				{
					this.BtnCapex.Visible = false;
				}
			}

		}


		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
            this.BtnConfirm.Click += new System.EventHandler(this.BtnConfirm_Click);
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            this.BtnConfirmCancel.Click += new System.EventHandler(this.BtnConfirmCancel_Click);
            this.BtnSurvey.Click += new System.EventHandler(this.BtnSurvey_Click);
            this.BtnCapex.Click += new System.EventHandler(this.BtnCapex_Click);
            this.Load += new System.EventHandler(this.Page_Load);

        }
		#endregion


		private void SelectTicketData( string TicketNo, string TicketID )
		{
			this.TbxTicketNo.Text = TicketNo;
			this.LblTicketID.Text = TicketID;

			TicketDS ds = null;

			if ( TicketController.isValidTicket( TicketNo ) )
			{
				ds = TicketController.SelectTicket( TicketNo );
			}
			else
			{
				ds = TicketController.SelectTicketTemp( TicketID );
			}
            if(ds.TB_TICKET_EMP_ENTIRE.Rows.Count>0)
            {
                BindTicketEmpList( ds.TB_TICKET_EMP_ENTIRE );
            }
			if(ds.TB_TICKET_ENTIRE.Rows.Count>0)
			{
				BindTicketInfo( ds.TB_TICKET_ENTIRE[0] );
				BindTicketHistoryByUser( ds.TB_TICKET_ENTIRE[0].Area, ds.TB_TICKET_EMP_ENTIRE[0].EmpNo, TicketNo );
			}

			//lglsy 20051014 �߰� InsertTicket���� Add Ŭ���� Asset Information�� ���̱� ����
		}

		//lglsy 20051107 �ڻ� ������.
		private void isSelectTicketAssetList(string TicketNo, string TicketID)
		{
			TicketDS ds = TicketController.isSelectTicketAssetList( TicketNo, TicketID );
			this.DgrdDataGrid.VirtualItemCount = 100 ;
			this.DgrdDataGrid.DataSource = ds.TB_TICKET_ASSETLIST;
			this.DgrdDataGrid.DataBind() ;
		}	


		private void BindTicketInfo( TicketDS.TB_TICKET_ENTIRERow dr )
		{
			this.TbxArea.Text = dr.Area;

			this.TbxDesc.Text = dr.Description;
			this.TbxZone.Text = LGCNS.SITE.Common.WebUI.CodeInfo.getCodeDesc( "TICKET_ZONE", dr.Zone );
			
			this.TbxEngineer.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.Engineer );
			//Alter Engineer �� �߰���. 20060509
			if ( !dr.IsAltEngineerNull() && !(dr.AltEngineer == ""))
				this.TbxAltEngineer.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.AltEngineer );
			
			this.TbxDivision.Text = LGCNS.SITE.Common.WebUI.CodeInfo.getCodeDesc( "TICKET_DIVISION", dr.Division );

			if ( !dr.IsFinishPlanNull() )
				this.TbxFinishPlan.Text = dr.FinishPlan;

			this.TbxStatus.Text = LGCNS.SITE.Common.WebUI.CodeInfo.getCodeDesc( "TICKET_STATUS", dr.Status );
			this.TbxAHD.Text = LGCNS.SITE.Common.WebUI.CodeInfo.getCodeDesc( "TICKET_STATUS", dr.AHD );
			this.TbxICMS.Text = dr.ICMS;
			this.TbxBill.Text = dr.BILL;

			this.TbxRemark.Text = dr.Remark;
			this.TbxReasonNoHandle.Text = dr.ReasonNoHandle;
			this.TbxCloseContents.Text = dr.CloseContents;

			if ( !dr.IsCloseDateNull() )
				this.TbxCloseDate.Text = dr.CloseDate;

			this.TbxHdConfirm.Text = dr.HdConfirm;
			this.TbxCreateID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.CreateID );
			this.TbxCreateDate.Text = dr.CreateDate;
			this.TbxUpdateID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.UpdateID );
			this.TbxUpdateDate.Text = dr.UpdateDate;
			this.TbxStatusFlag.Text = dr.StatusFlag;
		}


		private void BindTicketEmpList( TicketDS.TB_TICKET_EMP_ENTIREDataTable dt )
		{
			this.DgrdTicketEmp.DataSource = dt;
			this.DgrdTicketEmp.DataBind();
		}


		private void BindTicketHistoryByUser( string Area, string EmpNo, string TicketNo )
		{
			if ( this.DgrdTicketEmp.Items.Count == 1 )
			{
				TicketDS ds = TicketController.SelectTicketListByEmp( Area, EmpNo, TicketNo );
				this.DgrdHistory.ShowFooterMessage = false;
				this.DgrdHistory.DataSource = ds.TB_TICKET_LIST;
				this.DgrdHistory.DataBind();
			}
			else
			{
				TicketDS dsTicket = new TicketDS();
				this.DgrdHistory.DataSource = dsTicket.TB_TICKET_LIST;
				this.DgrdHistory.ShowFooterMessage = true;
				this.DgrdHistory.FooterMessage = MessageManager.GetMessage( "Common", "NO_DATA" );
				this.DgrdHistory.DataBind();
			}
		}



		private void BtnClose_Click(object sender, System.EventArgs e)
		{
			NavigationHelper.Close( false );
		}


		private void BtnConfirm_Click(object sender, System.EventArgs e)
		{
			string TicketNo = this.TbxTicketNo.Text;
			TicketController.ConfirmTicket( TicketNo );  
			NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "CONFIRM_DONE" ), "SelectTicket.aspx?TicketNo=" + TicketNo );
		}


		private void BtnDelete_Click(object sender, System.EventArgs e)
		{
			string TicketNo = this.TbxTicketNo.Text;

			if ( TicketController.isValidTicket( TicketNo ) )
			{
				DeleteTicket();
			}
			else
			{
				DeleteTicketTemp();
			}
			NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "DELETE_DONE" ), "SelectTicketList.aspx" );
		}



		private void DeleteTicket()
		{
			//Need Validation
			TicketController.DeleteTicket( this.TbxTicketNo.Text );
		}


		private void DeleteTicketTemp()
		{
			TicketController.DeleteTicketTemp( this.LblTicketID.Text );
		}

		private void BtnConfirmCancel_Click(object sender, System.EventArgs e)
		{
			string TicketNo = this.TbxTicketNo.Text;
			TicketController.ConfirmCancelTicket( TicketNo );
			NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "CONFIRM_CANCEL_DONE" ), "SelectTicket.aspx?TicketNo=" + TicketNo );		
		}

		private void BtnSurvey_Click(object sender, System.EventArgs e)
		{
			string TicketNo = this.TbxTicketNo.Text;
			if ( this.TbxHdConfirm.Text == "Y" )
			{
				SendMailSRConfirm(TicketNo);
				this.BtnSurvey.Visible=false;
			}
			else
			{
				SendMailInsertSR( TicketNo);
			}
		}
//SR ���� ���� ����.
		private void SendMailInsertSR(string TicketNo)
		{
			string mailBody;
			TicketDS ds = null;
			ds = TicketController.SelectMailTicket( TicketNo, LblTicketID.Text, "I" );

			MailMessage mailMsg = new MailMessage();
			for (int i = 0; i < ds.TB_TICKET_MAIL.Count; i++)
			{
				mailMsg.From= new MailAddress(ds.TB_TICKET_MAIL[i].MailFrom);
				mailMsg.To.Add(new MailAddress(ds.TB_TICKET_MAIL[i].MailTo));
				mailMsg.Bcc.Add(new MailAddress(ds.TB_TICKET_MAIL[i].MailBcc));
				if (ds.TB_TICKET_MAIL[i].TicketNo.Trim() == "SR")				
				{
					if (ds.TB_TICKET_MAIL[i].MailCc.Trim() != "")
					{
						mailMsg.CC.Add(new MailAddress(ds.TB_TICKET_MAIL[i].MailCc));
					}
				}
				mailMsg.Subject = ds.TB_TICKET_MAIL[i].Subject;
				
				//mail Body
				mailBody = "";
				mailBody = mailBody		+ " ��û��ȣ : " + TicketNo.Trim() +"\n";
				mailBody = mailBody		+ " �� û �� : " + ds.TB_TICKET_MAIL[i].EmpName +"\n";
				mailBody = mailBody		+ " �������� : " + ds.TB_TICKET_MAIL[i].InsertDate +"\n";
				mailBody = mailBody		+ " ��û���� : " + ds.TB_TICKET_MAIL[i].Description +"\n";
				mailBody = mailBody		+ " ���� ���� CSC Helpdesk �� ������ ��û������ �� �� �Ǿ����ϴ�. \n";
				mailBody = mailBody		+ " �����մϴ�. ";
				mailMsg.Body = mailBody;

                string server = LGCNS.LAF.Common.ConfigurationManagement.LConfigurationManager.GetConfigValue("SMTP_SERVER");
                SmtpClient client = new SmtpClient(server);
				if (ds.TB_TICKET_MAIL[i].TicketNo.Trim() != "CANCEL")
				{
                    client.Send(mailMsg);
                }
            }

			if (ds.TB_TICKET_MAIL[0].TicketNo.Trim() != "CANCEL")
			{
				ScriptHelper.ShowAlert(MessageManager.GetMessage("Common", "SEND_SR_DONE"));
			}
		}
//SR�Ϸ� �Ǿ����ϴ�.
		private void SendMailSRConfirm(string TicketNo)
		{
			string mailBody;

			TicketDS ds = null;
			ds = TicketController.SelectMailTicket( TicketNo, "0", "C" );

			MailMessage mailMsg = new MailMessage();
			//mailMsg.UrlContentBase = "http://www.w3.org/TR/REC-html40";

			for (int i = 0; i < ds.TB_TICKET_MAIL.Count; i++)
			{

				mailMsg.From = new MailAddress(ds.TB_TICKET_MAIL[i].MailFrom);
				mailMsg.To.Add(new MailAddress(ds.TB_TICKET_MAIL[i].MailTo));
				mailMsg.Bcc.Add(new MailAddress(ds.TB_TICKET_MAIL[i].MailBcc));
				if (ds.TB_TICKET_MAIL[i].TicketNo.Trim() == "SR")				
				{
					if (ds.TB_TICKET_MAIL[i].MailCc.Trim() != "")
					{
						mailMsg.CC.Add(new MailAddress(ds.TB_TICKET_MAIL[i].MailCc));
					}
				}
				mailMsg.Subject = ds.TB_TICKET_MAIL[i].Subject;

				//mail Body
				mailBody = "";
				mailBody = mailBody		+ " ��û��ȣ : " + TicketNo.Trim() +"\n";
				mailBody = mailBody		+ " �� û �� : " + ds.TB_TICKET_MAIL[i].EmpName +"\n";
				mailBody = mailBody		+ " �������� : " + ds.TB_TICKET_MAIL[i].InsertDate +"\n";
				mailBody = mailBody		+ " ��û���� : " + ds.TB_TICKET_MAIL[i].Description +"\n\n";
	 
				mailBody = mailBody		+ " �ֱٿ� �������� CSC Helpdesk �� ������ ��û�ϼ̽��ϴ�.  \n";
				mailBody = mailBody		+ " ����� �����Բ��� ��û�Ͻ� ��� �Ǵ� ���񽺰� ���������� ó���Ǿ����� Ȯ���ϰ��� �մϴ�.  \n\n";
				mailBody = mailBody		+ " �������� ��û������ ���� �ذ���� �ʾҴٸ�, ����� ��û��ȣ(" +TicketNo.Trim()+ ")�� �����Ͽ� Helpdesk�� ��ȭ �ֽʽÿ�.  \n\n";
				mailBody = mailBody		+ " ���񿡰� ���������� �ſ� �߿��մϴ�. \n\n";
				mailBody = mailBody		+ " �Ʒ� ��η� ���ż� ���������� ���翡 ���� ��Ź�帳�ϴ�.  \n\n";
				mailBody = mailBody		+ " http://172.28.64.10/LGCNS.SITE.WebUI/Survey/Question.aspx?TicketNo=" + TicketNo.Trim() + "&uid=" + ds.TB_TICKET_MAIL[i].EmpNo.Trim() + " \n\n";
				mailBody = mailBody		+ " �����մϴ�.";

				mailMsg.Body = mailBody;


                string server = LGCNS.LAF.Common.ConfigurationManagement.LConfigurationManager.GetConfigValue("SMTP_SERVER");
                SmtpClient client = new SmtpClient(server);
                if (ds.TB_TICKET_MAIL[i].TicketNo.Trim() != "CANCEL")
				{
					client.Send(mailMsg);
				}
			}//for
		}

//Capex ������ ���� ������ ����
//������ �������� �ٽ� ������ �ʴ� ������ ��� ������.
		private void BtnCapex_Click(object sender, System.EventArgs e)
		{
			string TicketNo = this.TbxTicketNo.Text;
			string Area = this.TbxArea.Text;
			string UserID = this.CurrentUserAlterUserID;
			string TicketDes = this.TbxDesc.Text;
			string CreateDate = this.TbxCreateDate.Text;
			string EmpName = this.DgrdTicketEmp.Items[0].Cells[4].Text;
			string Flag = "A";

			string mailBody;
			
			TicketDS ds = null;

            if( TicketController.CreateCapex(TicketNo, Area, UserID, Flag) == "OK")
            {

                ds = null;
                ds = TicketController.SelectMailCapex();

                MailMessage mailMsg = new MailMessage();
                //mailMsg.UrlContentBase = "http://www.w3.org/TR/REC-html40";

                for (int i = 0; i < ds.TB_BASE_MAIL.Count; i++)
                {
                    if (ds.TB_BASE_MAIL[i].Col1 == "A") mailMsg.To.Add(new MailAddress(ds.TB_BASE_MAIL[i].Email));
                    if (ds.TB_BASE_MAIL[i].Col1 == "D") mailMsg.From = new MailAddress(ds.TB_BASE_MAIL[i].Email);
                }//for					
                mailMsg.Subject = "[ " + TicketNo + " - " + EmpName + " ] Capex ���� �Ǿ����ϴ�.";

                //mail Body
                mailBody = "";
                mailBody = mailBody		+ " ��û��ȣ : " + TicketNo.Trim() +"\n";
                mailBody = mailBody		+ " �� û �� : " +  EmpName.Trim() +"\n";
                mailBody = mailBody		+ " �������� : " + CreateDate.Trim() +"\n";
                mailBody = mailBody		+ " ��û���� : " + TicketDes.Trim() +"\n";

                mailBody = mailBody		+ " �����մϴ�.";

                mailMsg.Body = mailBody;


                string server = LGCNS.LAF.Common.ConfigurationManagement.LConfigurationManager.GetConfigValue("SMTP_SERVER");
                SmtpClient client = new SmtpClient(server);
                client.Send(mailMsg);
                BtnCapex.Visible=false;
                NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "SEND_DONE" ), "SelectTicket.aspx?TicketNo=" + TicketNo );		
            }
            else 
            {
                NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "EXIST_CAPEX" ), "SelectTicket.aspx?TicketNo=" + TicketNo );
            }
		}
	}
}
