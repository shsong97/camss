using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;



namespace LGCNS.SITE.WebUI.Ticket
{
	/// <summary>
	/// UpdateTicketForEngineer�� ���� ��� �����Դϴ�.
	/// </summary>
	public class UpdateTicketForEngineer : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Label LblTicketNo;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdTicketEmp;
		protected System.Web.UI.WebControls.TextBox TbxDesc;
		protected System.Web.UI.WebControls.TextBox TbxRemark;
		protected System.Web.UI.WebControls.TextBox TbxReasonNoHandle;
		protected System.Web.UI.WebControls.TextBox TbxCloseContents;
		protected System.Web.UI.WebControls.TextBox TbxCloseDate;
		protected System.Web.UI.WebControls.TextBox TbxHdConfirm;
		protected System.Web.UI.WebControls.TextBox TbxCreateID;
		protected System.Web.UI.WebControls.TextBox TbxCreateDate;
		protected System.Web.UI.WebControls.TextBox TbxUpdateID;
		protected System.Web.UI.WebControls.TextBox TbxUpdateDate;
		protected System.Web.UI.WebControls.Button BtnUpdate;
		protected System.Web.UI.WebControls.Button BtnConfirm;
		protected System.Web.UI.WebControls.Button BtnCancel;
		protected System.Web.UI.WebControls.Button BtnInsert;
		protected System.Web.UI.WebControls.Label LblTicketID;
		protected System.Web.UI.WebControls.DropDownList DdnlZone;
		protected System.Web.UI.WebControls.DropDownList DdnlEngineer;
		protected System.Web.UI.WebControls.DropDownList DdnlStatus;
		protected System.Web.UI.WebControls.DropDownList DdnlAHD;
		protected System.Web.UI.WebControls.DropDownList DdnlICMS;
		protected System.Web.UI.WebControls.DropDownList DdnlBill;
		protected System.Web.UI.WebControls.Label LblCreateID;
		protected System.Web.UI.WebControls.Label LblStatus;
		protected System.Web.UI.WebControls.Label LblArea;
		protected System.Web.UI.WebControls.TextBox TbxFinishPlan;
		protected System.Web.UI.WebControls.DropDownList DdnlDivision;
		protected System.Web.UI.WebControls.DropDownList DdnlAltEngineer;
		protected System.Web.UI.WebControls.TextBox TbxStatusFlag;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdHistory;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			// GET������� ȣ��ɶ�
			if ( !this.IsPostBack )
			{
				SelectTicketData(this.Request["TicketNo"], this.Request["TicketID"]);
			}

			// POST������� ȣ��ɶ�
			if(this.IsSubmittedBy)
			{
				SelectTicketData(this.Request["TicketNo"], this.Request["TicketID"]);
			}

            ClientScript.RegisterHiddenField("TicketNo", LblTicketNo.Text) ;
            ClientScript.RegisterHiddenField("TicketID", LblTicketID.Text) ;
//Engineer �� ����� ������ ���� �� �� �ֵ�����. 20070622 ������D ��û
			this.DgrdTicketEmp.OpenWindowOnCellClick(
				1,
				"../Emp/UpdateEmp.aspx",
				"UpdateEmp",
				1000, 700,
				new string [2] {"Area", "EmpNo"},  // LinkŬ���� ������ Query String �� key�� �迭
				new int [2] {0, 1}, // LinkŬ���� ������ Query String �� value���� ������ Cell Index�� �迭
				false  // // ������������ ���� SelectTicket.aspx ���� submit��Ų��. (POST������� ȣ���Ѵ�.)
				);

			XjosHelper.RegisterXjos(true);

			NavigationHelper.SetHistoryBack( this.BtnCancel );

			//ScriptHelper.SetConfirmMessageOn( this.BtnUpdate, MessageManager.GetMessage( "Common", "UPDATE_QUESTION" ) );
			ScriptHelper.SetConfirmMessageOn( this.BtnUpdate, "�����Ͻðڽ��ϱ�? ( ��ó�������� �ԷµǸ� ���´� frozen���� ����˴ϴ�. ���᳻���� �ԷµǸ� ���´� closed�� ����˴ϴ�. )" );
		}


		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.TbxReasonNoHandle.TextChanged += new System.EventHandler(this.TbxReasonNoHandle_TextChanged);
			this.TbxCloseContents.TextChanged += new System.EventHandler(this.TbxCloseContents_TextChanged);
			this.BtnUpdate.Click += new System.EventHandler(this.BtnUpdate_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		#region SearchTicket

		private void SelectTicketData( string TicketNo, string TicketID )
		{
			this.LblTicketNo.Text = TicketNo;
			this.LblTicketID.Text = TicketID;

			TicketDS ds = null;

			if ( TicketController.isValidTicket( TicketNo ) )
			{
				ds = TicketController.SelectTicket( TicketNo );
			}
			else
			{
				ds = TicketController.SelectTicketTemp( TicketID );
			}
            if(ds.TB_TICKET_ENTIRE.Rows.Count>0) 
            {
                BindTicketInfo( ds.TB_TICKET_ENTIRE[0] );
                BindTicketEmpList( ds.TB_TICKET_EMP_ENTIRE );
                BindTicketHistoryByUser( ds.TB_TICKET_ENTIRE[0].Area, ds.TB_TICKET_EMP_ENTIRE[0].EmpNo, TicketNo );
            }
		}

		private void BindTicketInfo( TicketDS.TB_TICKET_ENTIRERow dr )
		{
			this.LblArea.Text = dr.Area;
			
			LGCNS.SITE.Common.WebUI.UserInfo.BindDropDownList( this.DdnlEngineer );
			//Alter Engineer �� �߰���. 20060509
			LGCNS.SITE.Common.WebUI.UserInfo.BindDropDownList( this.DdnlAltEngineer , true );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlZone, "TICKET_ZONE" );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlDivision, "TICKET_DIVISION", true );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlStatus, "TICKET_STATUS" );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlAHD, "TICKET_STATUS" );

			this.TbxDesc.Text = dr.Description;
			this.DdnlZone.SelectedValue = dr.Zone;
			this.DdnlEngineer.SelectedValue = dr.Engineer;
			//Alter Engineer �� �߰���. 20060509
			if ( dr.IsAltEngineerNull() ) 
				this.DdnlAltEngineer.SelectedValue = "";
			else 
				this.DdnlAltEngineer.SelectedValue = dr.AltEngineer;
			this.DdnlDivision.SelectedValue = dr.Division;

			if ( !dr.IsFinishPlanNull() )
				this.TbxFinishPlan.Text = dr.FinishPlan;

			this.DdnlStatus.SelectedValue = dr.Status;
			this.LblStatus.Text = dr.Status;
			this.DdnlAHD.SelectedValue = dr.AHD;
			this.DdnlICMS.SelectedValue = dr.ICMS;
			this.DdnlBill.SelectedValue = dr.BILL;

			this.TbxRemark.Text = dr.Remark;
			this.TbxReasonNoHandle.Text = dr.ReasonNoHandle;
			this.TbxCloseContents.Text = dr.CloseContents;

			if ( !dr.IsCloseDateNull() )
				this.TbxCloseDate.Text = dr.CloseDate;

			this.TbxHdConfirm.Text = dr.HdConfirm;
			this.TbxCreateID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.CreateID );
			this.TbxCreateDate.Text = dr.CreateDate;
			this.TbxUpdateID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.UpdateID );
			this.TbxUpdateDate.Text = dr.UpdateDate;
			this.TbxStatusFlag.Text = dr.StatusFlag;
		}

		private void BindTicketEmpList( TicketDS.TB_TICKET_EMP_ENTIREDataTable dt )
		{
			this.DgrdTicketEmp.DataSource = dt;
			this.DgrdTicketEmp.DataBind();
		}

		private void BindTicketHistoryByUser( string Area, string EmpNo, string TicketNo )
		{
			if ( this.DgrdTicketEmp.Items.Count == 1 )
			{
				TicketDS ds = TicketController.SelectTicketListByEmp( Area, EmpNo, TicketNo );
				this.DgrdHistory.ShowFooterMessage = false;
				this.DgrdHistory.DataSource = ds.TB_TICKET_LIST;
				this.DgrdHistory.DataBind();
			}
			else
			{
				TicketDS dsTicket = new TicketDS();
				this.DgrdHistory.DataSource = dsTicket.TB_TICKET_LIST;
				this.DgrdHistory.ShowFooterMessage = true;
				this.DgrdHistory.FooterMessage = MessageManager.GetMessage( "Common", "NO_DATA" );
				this.DgrdHistory.DataBind();
			}
		}

		#endregion

		#region Update

		private void BtnUpdate_Click(object sender, System.EventArgs e)
		{
			string TicketNo = this.LblTicketNo.Text;
			string TicketID = this.LblTicketID.Text;

			UpdateValidation();
			//2005-06-02 : Ƽ�� ������ ICMS Bill ���� �ݿ�
			if ( TicketController.isValidTicket( TicketNo ) )
			{
				UpdateTicketData( TicketNo );
			}
			else
			{
				UpdateTicketTempData( TicketID );
			}

			//����� �̵�
			NavigationHelper.Redirect(
				MessageManager.GetMessage( "Common", "UPDATE_DONE" ),
				"SelectTicket.aspx?TicketNo=" + TicketNo + "&TicketID=" + TicketID
				);
		}

		private void UpdateValidation()
		{
			if ( this.TbxCloseContents.Text.CompareTo("") > 0 )
			{
				this.DdnlStatus.SelectedValue = "closed";
			}
			else if ( this.TbxReasonNoHandle.Text.CompareTo("") > 0 )
			{
				this.DdnlStatus.SelectedValue = "frozen";
			}
		}

		private void UpdateTicketData( string TicketNo )
		{
			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			TicketDS.TB_TICKETRow dr = ds.TB_TICKET.NewTB_TICKETRow();
			
			dr.TicketNo = TicketNo;
			dr.Status = this.DdnlStatus.SelectedValue.ToString();
			dr.Remark = this.TbxRemark.Text.Trim();	// remark ���� �߰�(2005-06-01)
			dr.ReasonNoHandle = this.TbxReasonNoHandle.Text.Trim();
			dr.CloseContents = this.TbxCloseContents.Text.Trim();
			
			if ( this.DdnlStatus.SelectedItem.Text == "closed" || this.DdnlStatus.SelectedItem.Text == "cancelled" )
			{
				dr.CloseDate = DateTime.Now;
			}
			dr.UpdateID = this.CurrentUserID;
			dr.UpdateDate = DateTime.Now;

			ds.TB_TICKET.AddTB_TICKETRow( dr );

			//��� ��û
			//2005-06-02 : Ƽ�� ������ ICMS Bill ���� �ݿ�
			TicketController.UpdateTicketForEngineer( ds );
		}


		private void UpdateTicketTempData( string TicketID )
		{
			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			TicketDS.TB_TICKET_TEMPRow dr = ds.TB_TICKET_TEMP.NewTB_TICKET_TEMPRow();
			
			dr.TicketID = int.Parse( TicketID );
			dr.Status = this.DdnlStatus.SelectedValue.ToString();
			dr.Remark = this.TbxRemark.Text.Trim();	// remark ���� �߰�(2005-06-01)
			dr.ReasonNoHandle = this.TbxReasonNoHandle.Text.Trim();
			dr.CloseContents = this.TbxCloseContents.Text.Trim();

			if ( this.DdnlStatus.SelectedItem.Text == "closed" || this.DdnlStatus.SelectedItem.Text == "cancelled" )
			{
				dr.CloseDate = DateTime.Now;
			}
			dr.UpdateID = this.CurrentUserID;
			dr.UpdateDate = DateTime.Now;

			ds.TB_TICKET_TEMP.AddTB_TICKET_TEMPRow( dr );

			//��� ��û
			//2005-06-02 : Ƽ�� ������ ICMS Bill ���� �ݿ�
			TicketController.UpdateTicketTempForEngineer( ds );
		}

		#endregion

		private void TbxReasonNoHandle_TextChanged(object sender, System.EventArgs e)
		{
			if ( !this.IsSubmittedBy )
			{
				if ( this.TbxReasonNoHandle.Text.CompareTo("") > 0 )
				{
					this.TbxCloseContents.ReadOnly = true;
					this.TbxCloseContents.BackColor = System.Drawing.Color.WhiteSmoke;
				}
				else if ( this.TbxReasonNoHandle.Text.CompareTo("") == 0 )
				{
					this.TbxCloseContents.ReadOnly = false;
					this.TbxCloseContents.BackColor = System.Drawing.Color.White;
				}
			}
		}

		private void TbxCloseContents_TextChanged(object sender, System.EventArgs e)
		{

		}
	}
}
