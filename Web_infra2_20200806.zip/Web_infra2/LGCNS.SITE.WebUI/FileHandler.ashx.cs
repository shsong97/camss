﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace LGCNS.SITE.WebUI
{
    /// <summary>
    /// Summary description for FileHandler
    /// </summary>
    public class FileHandler : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            string file = context.Request.QueryString["FILENAME"];
            string filePath = context.Request["FILEPATH"];
            string realPath = LGCNS.LAF.Common.FileManagement.Configuration.RealRootPath + filePath;
            string contentDisposition = @"attachment; filename=""" + file + @"""";
            context.Response.ContentType = "application/octet-stream";
            context.Response.AppendHeader("Content-Disposition", contentDisposition);
            context.Response.WriteFile(realPath);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}