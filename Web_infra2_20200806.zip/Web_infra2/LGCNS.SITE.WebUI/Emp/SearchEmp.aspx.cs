using System;
using System.Collections;
using System.Collections.Specialized ;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Emp
{
	/// <summary>
	/// SearchEmp�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SearchEmp : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Button BtnSearch;
		protected System.Web.UI.WebControls.DropDownList DdnlSearchCondition;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdEmpList;
		protected System.Web.UI.WebControls.TextBox TbxSearchValue;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected System.Web.UI.WebControls.Button BtnInsert;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			this.DgrdEmpList.NavigateOnCellClick(
				6,
				"",
				"UpdateEmp.aspx",
				new string[2] { "Area", "EmpNo" },
				new int[2] { 1, 2 }
			);

			NavigationHelper.SetNavigation( this.BtnInsert, "", "InsertEmp.aspx", false );
			
			XjosHelper.RegisterXjos(true);

			if( this.IsSubmittedBy )
			{
				InitialProcess();
			}

			if ( !this.IsPostBack ){
				InitialProcess();
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
			this.DgrdEmpList.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdEmpList_ItemCommand);
			this.DgrdEmpList.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.DgrdEmpList_PageIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		//2005-06-01 : Area���о��� ��ȸ�� ����
		private void InitialProcess()
		{
			string Area = "";
			LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea, true );

			if ( this.Request["DdnlArea"] == null )
			{
				Area = this.Request.QueryString["Area"];
			}
			else
			{
				Area = Request["DdnlArea"];
			}

			if( Area != null & Area.Length > 0 )
			{
				this.DdnlArea.SelectedValue = Area;
				//this.DdnlArea.Enabled = false;
			}
			else
			{
				this.DdnlArea.SelectedValue = "";
			}

			BindEmpList();
		}


		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			DgrdEmpList.EditItemIndex = -1;
			DgrdEmpList.CurrentPageIndex = 0;
			BindEmpList();
		}


		private void BindEmpList( )
		{
			string SearchCondition = this.DdnlSearchCondition.SelectedValue.ToString();
			string SearchValue = this.TbxSearchValue.Text.ToString();

			EmpDS ds = LGCNS.SITE.WebUI.Emp.EmpController.SelectEmpList( this.DdnlArea.SelectedValue, SearchCondition, SearchValue );

			if ( ds.TB_EMP_ENTIRE.Count == 0 )
			{
				this.DgrdEmpList.ShowFooterMessage = true;
				this.DgrdEmpList.FooterMessage = MessageManager.GetMessage( "Common", "NO_DATA" );
			}
			else
			{
				this.DgrdEmpList.ShowFooterMessage = false;
			}

			this.DgrdEmpList.DataSource = ds.TB_EMP_ENTIRE;
			this.DgrdEmpList.DataBind();
		}


		private void DgrdEmpList_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			DgrdEmpList.EditItemIndex = -1;
			DgrdEmpList.CurrentPageIndex = e.NewPageIndex;
			BindEmpList();
		}


		private void DgrdEmpList_ItemCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			if( e.CommandName == "Select" )
			{
				NameValueCollection valuesToSend = new NameValueCollection();
				valuesToSend["Area"] = e.Item.Cells[6].Text;
				valuesToSend["TbxEmpNo"] = e.Item.Cells[2].Text;
				valuesToSend["DdnlDeptCode"] = e.Item.Cells[3].Text;
				valuesToSend["DdnlSiteCode"] = e.Item.Cells[4].Text;
				valuesToSend["TbxEmpName"] = e.Item.Cells[5].Text;
				NavigationHelper.Close (true, valuesToSend);
			}
		}
	}
}

