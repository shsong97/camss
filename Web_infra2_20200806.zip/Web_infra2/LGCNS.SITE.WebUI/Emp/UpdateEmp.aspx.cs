using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;
using LGCNS.SITE.Common;

namespace LGCNS.SITE.WebUI.Emp
{
	/// <summary>
	/// UpdateEmp�� ���� ��� �����Դϴ�.
	/// </summary>
	public class UpdateEmp : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxEmpName;
		protected System.Web.UI.WebControls.TextBox TbxFirstName;
		protected System.Web.UI.WebControls.TextBox TbxLastName;
		protected System.Web.UI.WebControls.Label LblFullName;
		protected System.Web.UI.WebControls.TextBox TbxContactNo;
		protected System.Web.UI.WebControls.DropDownList DdnlDeptCode;
		protected System.Web.UI.WebControls.Label LblDeptCode;
		protected System.Web.UI.WebControls.Label LblDeptNameEng;
		protected System.Web.UI.WebControls.Label LblBizUnit;
		protected System.Web.UI.WebControls.DropDownList DdnlSiteCode;
		protected System.Web.UI.WebControls.Label LblSiteCode;
		protected System.Web.UI.WebControls.Label LblSvcLevel;
		protected System.Web.UI.WebControls.Label LblLocationName;
		protected System.Web.UI.WebControls.Label LblBuildingCode;
		protected System.Web.UI.WebControls.Label LblBuildingDesc;
		protected System.Web.UI.WebControls.Button BtnSave;
		protected System.Web.UI.WebControls.ImageButton IbtnSearchDept;
		protected System.Web.UI.WebControls.Label LblArea;
		protected System.Web.UI.WebControls.TextBox TbxEmpNo;
		protected System.Web.UI.WebControls.Label LblEmpNo;
		protected System.Web.UI.WebControls.TextBox TbxLoginID;
		protected System.Web.UI.WebControls.TextBox TbxEmail;
		protected System.Web.UI.WebControls.Button BtnCancel;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos(true);

			XjosHelper.SetValidator (this.TbxEmpName,
				new XjosValidator (XjosValidatorType.Required)
				);
			XjosHelper.SetValidator (this.TbxFirstName,
				new XjosValidator (XjosValidatorType.Required)
				);
			XjosHelper.SetValidator (this.TbxLastName,
				new XjosValidator (XjosValidatorType.Required),
				new XjosValidator (XjosValidatorType.Alphabetic)
				);
			XjosHelper.SetValidator (this.TbxContactNo,
				new XjosValidator (XjosValidatorType.Required)
				);
			XjosHelper.SetValidator (this.TbxLoginID,
				new XjosValidator (XjosValidatorType.Required)
				//new XjosValidator (XjosValidatorType.Alphabetic)
				);
			XjosHelper.SetValidator (this.TbxEmail,
				new XjosValidator (XjosValidatorType.Required)
				);

			XjosHelper.ValidateOnClick (
				this.BtnSave,
				MessageManager.GetMessage("Common", "UPDATE_QUESTION")
				) ;

			NavigationHelper.SetHistoryBack( this.BtnCancel );

			if ( !this.IsPostBack )
			{
				BindEmp( this.Request["Area"], this.Request["EmpNo"] );
			}

			if ( this.IsSubmittedBy ) { 
				BindEmp( this.Request["Area"], this.Request["EmpNo"] );
			}
			// 20050501 : Admin�� ���� ����ܴ̿� ��������
			if ( this.CurrentUserAuthority.CompareTo("A") == 0 )
			{
				this.TbxEmpNo.Visible = false;
				if( this.LblEmpNo.Text.Length > 1 )
				{
					if( this.LblEmpNo.Text.Substring(0,1).CompareTo("2") != 0 )
						this.TbxEmpNo.Visible = true;
				}
			}
			else
			{
				this.TbxEmpNo.Visible = false;
			}

			if ( !this.IsReloaded ) { }

            ClientScript.RegisterHiddenField("Area", this.LblArea.Text );
            ClientScript.RegisterHiddenField("EmpNo", this.LblEmpNo.Text );

			NavigationHelper.SetPopupWindow(
				this.IbtnSearchDept,
				"../Code/SelectDeptList.aspx?Area=" + this.LblArea.Text,
				"SearchDept",
				1000, 400,
				false
				);
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
			this.TbxLastName.TextChanged += new System.EventHandler(this.TbxLastName_TextChanged);
			this.DdnlDeptCode.SelectedIndexChanged += new System.EventHandler(this.DdnlDeptCode_SelectedIndexChanged);
			this.DdnlSiteCode.SelectedIndexChanged += new System.EventHandler(this.DdnlSiteCode_SelectedIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BindEmp( string Area, string EmpNo )
		{
			EmpDS ds = EmpController.SelectEmp( Area, EmpNo );
			EmpDS.TB_EMP_ENTIRERow dr = ds.TB_EMP_ENTIRE[0];

			this.LblArea.Text = dr.Area;

			LGCNS.SITE.Common.WebUI.DeptInfo.BindDropDownList( this.DdnlDeptCode, this.LblArea.Text );
			LGCNS.SITE.Common.WebUI.SiteInfo.BindDropDownList( this.DdnlSiteCode, this.LblArea.Text );


			LblEmpNo.Text = dr.EmpNo;
			TbxEmpName.Text = dr.EmpName;
			TbxFirstName.Text = dr.FirstName;
			TbxLastName.Text = dr.LastName;
			LblFullName.Text = dr.FullName;
			TbxContactNo.Text = dr.ContactNo;
			TbxLoginID.Text = dr.LoginID;
			if (!dr.IsEmailNull())
			{
				this.TbxEmail.Text = dr.Email;
			}
			

			//SetIndexOfDdnl( this.DdnlDeptCode, dr.DeptCode );
			try
			{
				DdnlDeptCode.SelectedValue = dr.DeptCode;
				LblDeptCode.Text = dr.DeptCode;

				if( !dr.IsDeptNameEngNull() )
					LblDeptNameEng.Text = dr.DeptNameEng;
				if( !dr.IsBizUnitNull() )
					LblBizUnit.Text = dr.BizUnit;
			}
			catch( Exception ex )
			{
				string errmsg=ex.Message;
				LGCNS.SITE.Common.WebUI.DeptInfo.BindDropDownList( this.DdnlDeptCode, this.LblArea.Text, true );
			}

			//SetIndexOfDdnl( this.DdnlSiteCode, dr.SiteCode );
			try
			{
				DdnlSiteCode.SelectedValue = dr.SiteCode;
				
				LblSiteCode.Text = dr.SiteCode;
				//LblSiteDesc.Text = dr.SiteDesc;
				LblSvcLevel.Text = dr.SvcLevel;
				LblLocationName.Text = dr.LocationName;
				LblBuildingCode.Text = dr.BuildingCode;
				LblBuildingDesc.Text = dr.BuildingDesc;
			}
			catch( Exception ex )
			{
				string errmsg=ex.Message;
				LGCNS.SITE.Common.WebUI.SiteInfo.BindDropDownList( this.DdnlSiteCode, this.LblArea.Text, true );
			}

			ds.Dispose();
		}

		public void SetIndexOfDdnl( DropDownList ddnl, string searchString )
		{
			try
			{
				ddnl.SelectedValue = searchString;
			}
			catch( Exception ex )
			{
				string errmsg=ex.Message;
				ddnl.SelectedIndex = ddnl.Items.Count - 1;
			}
		}

		private void TbxLastName_TextChanged(object sender, System.EventArgs e)
		{
			this.LblFullName.Text = this.TbxLastName.Text + ", " + this.TbxFirstName.Text;
		}


		private void DdnlDeptCode_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EmpDS ds = EmpController.SelectDept( this.LblArea.Text, this.DdnlDeptCode.SelectedValue );

			EmpDS.TB_DEPTRow dr = ds.TB_DEPT[0];

			this.LblDeptCode.Text = dr.DeptCode;
			this.LblDeptNameEng.Text = dr.DeptNameEng;
			this.LblBizUnit.Text = dr.BizUnit;

			if( ds != null )
			{
				ds.Dispose();
				ds = null;
			}
		}


		private void DdnlSiteCode_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EmpDS ds = EmpController.SelectSite( this.LblArea.Text, this.DdnlSiteCode.SelectedValue );

			EmpDS.TB_SITERow dr = ds.TB_SITE[0];

			this.LblSiteCode.Text = dr.SiteCode;
			this.LblSvcLevel.Text = dr.SvcLevel;
			this.LblLocationName.Text = dr.LocationName;
			this.LblBuildingCode.Text = dr.BuildingCode;
			this.LblBuildingDesc.Text = dr.BuildingDesc;

			if( ds != null )
			{
				ds.Dispose();
				ds = null;
			}
		}

		private void BtnSave_Click(object sender, System.EventArgs e)
		{
			bool isUpdateEmp = false;
			EmpDS ds = new EmpDS();
			// 20050501 : Admin�� ���� ����ܴ̿� ��������
			if( this.TbxEmpNo.Text.CompareTo("")  > 0 )
			{
				isUpdateEmp = true;
			}

			EmpDS.TB_EMPRow dr = ds.TB_EMP.NewTB_EMPRow();

			dr.Area = this.LblArea.Text.Trim();
			dr.EmpNo = this.LblEmpNo.Text.Trim();
			dr.EmpName = this.TbxEmpName.Text.Trim();
			dr.FirstName = this.TbxFirstName.Text.Trim().ToUpper();
			dr.LastName = this.TbxLastName.Text.Trim().ToUpper();
			dr.ContactNo = this.TbxContactNo.Text.Trim();
			dr.LoginID = this.TbxLoginID.Text.Trim().ToUpper();
			dr.DeptCode = this.DdnlDeptCode.SelectedValue.ToString();
			dr.SiteCode = this.DdnlSiteCode.SelectedValue.ToString();
			dr.TempEmp = this.TbxEmpNo.Text.Trim();
			dr.Email = this.TbxEmail.Text.Trim();

			ds.TB_EMP.AddTB_EMPRow( dr );

			EmpController.UpdateEmp( ds );

			if ( this.IsSubmittedBy )
			{
				NameValueCollection valuesToSend = new NameValueCollection();
				valuesToSend["LblEmpNo"] = this.LblEmpNo.Text;
				NavigationHelper.Close (true, valuesToSend);
			}
			else
			{
				
				if( isUpdateEmp == true )
					NavigationHelper.Redirect (MessageManager.GetMessage("Common", "UPDATE_DONE"), "SelectEmp.aspx?Area=" + this.LblArea.Text + "&EmpNo=" + this.TbxEmpNo.Text.Trim() ) ; 
				else
					NavigationHelper.Redirect (MessageManager.GetMessage("Common", "UPDATE_DONE"), "SelectEmp.aspx?Area=" + this.LblArea.Text + "&EmpNo=" + this.LblEmpNo.Text ) ; 
			}
		}

	}
}
