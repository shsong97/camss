using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Emp
{
	/// <summary>
	/// SelectEmpList�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectEmpList : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.DropDownList DdnlSearchCondition;
		protected System.Web.UI.WebControls.TextBox TbxSearchValue;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdEmpList;
		protected System.Web.UI.WebControls.Button BtnInsert;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected System.Web.UI.WebControls.Button BtnSearch;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			this.DgrdEmpList.NavigateOnRowClick(
				"",
				"SelectEmp.aspx",
				new string[2] { "Area", "EmpNo" },
				new int[2] { 0, 1 }
			);

			NavigationHelper.SetNavigation( this.BtnInsert, "", "InsertEmp.aspx", true );

			XjosHelper.RegisterXjos(true);

			if ( !this.IsPostBack )
			{
				LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea, true );
				EmpDS ds = new EmpDS();
				BindEmpList( ds );
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
			this.DgrdEmpList.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.DgrdEmpList_PageIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			this.DgrdEmpList.CurrentPageIndex = 0;
			getEmpList();
		}

		private void getEmpList()
		{
			string SearchCondition = this.DdnlSearchCondition.SelectedValue.ToString();
			string SearchValue = this.TbxSearchValue.Text.ToString();

			EmpDS ds = LGCNS.SITE.WebUI.Emp.EmpController.SelectEmpList( this.DdnlArea.SelectedValue, SearchCondition, SearchValue );
			BindEmpList( ds );
		}

		private void BindEmpList( EmpDS ds )
		{
			if ( ds.TB_EMP_ENTIRE.Count == 0 )
			{
				this.DgrdEmpList.ShowFooterMessage = true;
				this.DgrdEmpList.FooterMessage = MessageManager.GetMessage( "Common", "NO_DATA" );
			}
			else
			{
				this.DgrdEmpList.ShowFooterMessage = false;
			}

			this.DgrdEmpList.DataSource = ds.TB_EMP_ENTIRE;
			this.DgrdEmpList.DataBind();
		}

		private void DgrdEmpList_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			this.DgrdEmpList.CurrentPageIndex = e.NewPageIndex;
			getEmpList();
		}
	}
}
