using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
//using System.Drawing;
using System.Web;
//using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.Exceptions ;
using LGCNS.LAF.Common.FileManagement;

using LGCNS.SITE.DTO;
using LGCNS.SITE.Emp.Biz;

namespace LGCNS.SITE.WebUI.Emp
{
	public class EmpController : ControllerBase
	{
		public EmpController() {}

		#region Employee

		public static string getEmpName( string Area, string EmpNo )
		{
			EmpDS ds = SelectEmp( Area, EmpNo );
			return ds.TB_EMP[0].EmpName;
		}

		public static bool isExistEmpNo(string Area, string EmpNo)
		{
			string result="";
			EmpBizNTx biz = null;
				
			try
			{
				biz = new EmpBizNTx();
				result = biz.isExistEmpNo(Area,EmpNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			if(result.Equals("Y"))
				return true;
			else
				return false;
		}
		public static EmpDS SelectEmp(string Area, string EmpNo)
		{
			EmpDS ds = null;
			EmpBizNTx biz = null;
			
			try
			{
				biz = new EmpBizNTx();
				ds = biz.SelectEmp(Area,EmpNo);
			}
			catch(Exception ex)
			{
				throw ex ;
				//throw new ApplicationException ("����� Ȯ���Ͻʽÿ�." + ex.ToString() ) ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}

		public static EmpDS SelectEmpList (string Area, string SearchCondition, string SearchValue)
		{
			if ( SearchCondition == "EmpNo" )
			{
				return SelectEmpList( 0, 0, SearchCondition, Area, SearchValue, "" );
			}
			else if( SearchCondition == "EmpName" )
			{
				return SelectEmpList( 0, 0, SearchCondition, Area, "", SearchValue );
			}
			else
			{
				return SelectEmpList( 0, 0, SearchCondition, Area, "", "" );
			}
		}

		public static EmpDS SelectEmpList (int currentPage, int pageSize, string order, string Area, string EmpNo, string EmpName)
		{
			EmpDS ds = null;
			EmpBizNTx biz = null;
			
			try
			{
				biz = new EmpBizNTx();
				ds = biz.SelectEmpList(currentPage, pageSize, order, Area, EmpNo, EmpName);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}

		public static void InsertEmp(EmpDS ds)
		{
			EmpBizTx biz = null;
			
			try
			{
				biz = new EmpBizTx () ;
				biz.InsertEmp(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		public static void UpdateEmp(EmpDS ds)
		{
			EmpBizTx biz = null;
			
			try
			{
				biz = new EmpBizTx () ;
				biz.UpdateEmp(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		public static void DeleteEmp( string Area, string EmpNo )
		{
			EmpBizTx biz = null;
			
			try
			{
				biz = new EmpBizTx() ;
				biz.DeleteEmp(Area, EmpNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		#endregion

		#region Dept
		public static EmpDS SelectDept ( string Area, string DeptCode )
		{
			EmpDS ds = null;
			EmpBizNTx biz = null;
			
			try
			{
				biz = new EmpBizNTx();
				ds = biz.SelectDept( Area, DeptCode );
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}
		#endregion

		#region Site
		public static EmpDS SelectSite( string Area, string SiteCode )
		{
			EmpDS ds = null;
			EmpBizNTx biz = null;
			
			try
			{
				biz = new EmpBizNTx();
				ds = biz.SelectSite( Area, SiteCode );
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}
		#endregion
	}
}
