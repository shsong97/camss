using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;
using LGCNS.SITE.Common;

namespace LGCNS.SITE.WebUI.Emp
{
	/// <summary>
	/// InsertEmp�� ���� ��� �����Դϴ�.
	/// </summary>
	public class InsertEmp : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Label LblDeptNameEng;
		protected System.Web.UI.WebControls.Label LblBizUnit;
		protected System.Web.UI.WebControls.Label LblSvcLevel;
		protected System.Web.UI.WebControls.Label LblLocationName;
		protected System.Web.UI.WebControls.Label LblBuildingCode;
		protected System.Web.UI.WebControls.Label LblBuildingDesc;
		protected System.Web.UI.WebControls.TextBox TbxEmpNo;
		protected System.Web.UI.WebControls.TextBox TbxEmpName;
		protected System.Web.UI.WebControls.TextBox TbxFirstName;
		protected System.Web.UI.WebControls.TextBox TbxLastName;
		protected System.Web.UI.WebControls.Label LblFullName;
		protected System.Web.UI.WebControls.TextBox TbxContactNo;
		protected System.Web.UI.WebControls.DropDownList DdnlDeptCode;
		protected System.Web.UI.WebControls.DropDownList DdnlSiteCode;
		protected System.Web.UI.WebControls.Button BtnSave;
		protected System.Web.UI.WebControls.Label LblDeptCode;
		protected System.Web.UI.WebControls.Label LblSiteCode;
		protected System.Web.UI.WebControls.ImageButton IbtnSearchDept;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected System.Web.UI.WebControls.TextBox TbxLoginID;
		protected System.Web.UI.WebControls.TextBox TbxEmail;
		protected System.Web.UI.WebControls.Button BtnCancel;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos(true);

			XjosHelper.SetValidator (this.TbxEmpNo,
				new XjosValidator (XjosValidatorType.Required),
				//new XjosValidator (XjosValidatorType.Minlength, "6", "6�ڸ� �̻��Դϴ�."),
				new XjosValidator (XjosValidatorType.Alpha_Numeric)
				) ;
			//this.TbxEmpNo.MaxLength = 6;

			XjosHelper.SetValidator (this.TbxEmpName,
				new XjosValidator (XjosValidatorType.Required)
			);
			XjosHelper.SetValidator (this.TbxFirstName,
				new XjosValidator (XjosValidatorType.Required)
				);
			XjosHelper.SetValidator (this.TbxLastName,
				new XjosValidator (XjosValidatorType.Required),
				new XjosValidator (XjosValidatorType.Alphabetic)
				);
			XjosHelper.SetValidator (this.TbxContactNo,
				new XjosValidator (XjosValidatorType.Required)
				);
			XjosHelper.SetValidator (this.TbxLoginID,
				new XjosValidator (XjosValidatorType.Required)
				//new XjosValidator (XjosValidatorType.Alphabetic)
				);
			XjosHelper.SetValidator (this.TbxEmail,
				new XjosValidator (XjosValidatorType.Required)
				);
			XjosHelper.ValidateOnClick (
				this.BtnSave,
				MessageManager.GetMessage("Common", "REGISTER_QUESTION")
				) ;



			NavigationHelper.SetHistoryBack( this.BtnCancel );

			if ( !this.IsPostBack )
			{
				LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea );
				LGCNS.SITE.Common.WebUI.DeptInfo.BindDropDownList( this.DdnlDeptCode, this.DdnlArea.SelectedValue );
				LGCNS.SITE.Common.WebUI.SiteInfo.BindDropDownList( this.DdnlSiteCode, this.DdnlArea.SelectedValue );
			}

			if ( !this.IsReloaded ) { }
			if ( this.IsSubmittedBy ) {
				LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea );
				LGCNS.SITE.Common.WebUI.DeptInfo.BindDropDownList( this.DdnlDeptCode, this.DdnlArea.SelectedValue );
				LGCNS.SITE.Common.WebUI.SiteInfo.BindDropDownList( this.DdnlSiteCode, this.DdnlArea.SelectedValue );			

				if ( this.Request["DdnlArea"].Length > 0 )
				{
					this.DdnlArea.SelectedValue = this.Request["DdnlArea"].ToString();
					DdnlArea_SelectedIndexChanged( sender, e );
				}
			}

			NavigationHelper.SetPopupWindow(
				this.IbtnSearchDept,
				"../Code/SelectDeptList.aspx?Area=" + this.DdnlArea.SelectedValue,
				"SearchDept",
				1000, 400,
				false
				);
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
			this.DdnlArea.SelectedIndexChanged += new System.EventHandler(this.DdnlArea_SelectedIndexChanged);
			this.TbxLastName.TextChanged += new System.EventHandler(this.TbxLastName_TextChanged);
			this.DdnlDeptCode.SelectedIndexChanged += new System.EventHandler(this.DdnlDeptCode_SelectedIndexChanged);
			this.DdnlSiteCode.SelectedIndexChanged += new System.EventHandler(this.DdnlSiteCode_SelectedIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void TbxLastName_TextChanged(object sender, System.EventArgs e)
		{
			this.LblFullName.Text = this.TbxLastName.Text + ", " + this.TbxFirstName.Text;
		}


		private void DdnlDeptCode_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EmpDS ds = EmpController.SelectDept( this.DdnlArea.SelectedValue, this.DdnlDeptCode.SelectedValue );

			EmpDS.TB_DEPTRow dr = ds.TB_DEPT[0];

			this.LblDeptCode.Text = dr.DeptCode;
			this.LblDeptNameEng.Text = dr.DeptNameEng;
			this.LblBizUnit.Text = dr.BizUnit;

			if( ds != null )
			{
				ds.Dispose();
				ds = null;
			}
		}


		private void DdnlSiteCode_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			EmpDS ds = EmpController.SelectSite( this.DdnlArea.SelectedValue, this.DdnlSiteCode.SelectedValue );

			EmpDS.TB_SITERow dr = ds.TB_SITE[0];

			this.LblSiteCode.Text = dr.SiteCode;
			this.LblSvcLevel.Text = dr.SvcLevel;
			this.LblLocationName.Text = dr.LocationName;
			this.LblBuildingCode.Text = dr.BuildingCode;
			this.LblBuildingDesc.Text = dr.BuildingDesc;

			if( ds != null )
			{
				ds.Dispose();
				ds = null;
			}
		}

		private void DdnlArea_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			NavigationHelper.SetPopupWindow(
				this.IbtnSearchDept,
				"../Code/SelectDeptList.aspx?Area=" + this.DdnlArea.SelectedValue,
				"SearchDept",
				1000, 400,
				false
				);
			
			LGCNS.SITE.Common.WebUI.DeptInfo.BindDropDownList( this.DdnlDeptCode, this.DdnlArea.SelectedValue );
			LGCNS.SITE.Common.WebUI.SiteInfo.BindDropDownList( this.DdnlSiteCode, this.DdnlArea.SelectedValue );

			DdnlDeptCode_SelectedIndexChanged( sender, e );
			DdnlSiteCode_SelectedIndexChanged( sender, e );
		}

		private void BtnSave_Click(object sender, System.EventArgs e)
		{
			EmpDS ds = new EmpDS();

			EmpDS.TB_EMPRow dr = ds.TB_EMP.NewTB_EMPRow();

			dr.Area = this.DdnlArea.SelectedValue;
			dr.EmpNo = this.TbxEmpNo.Text.Trim().ToUpper();
			dr.EmpName = this.TbxEmpName.Text.Trim();
			dr.FirstName = this.TbxFirstName.Text.Trim().ToUpper();
			dr.LastName = this.TbxLastName.Text.Trim().ToUpper();
			dr.ContactNo = this.TbxContactNo.Text.Trim();
			dr.LoginID = this.TbxLoginID.Text.Trim().ToUpper();
			dr.DeptCode = this.DdnlDeptCode.SelectedValue.ToString();
			dr.SiteCode = this.DdnlSiteCode.SelectedValue.ToString();
			dr.Email = this.TbxEmail.Text.Trim();
			ds.TB_EMP.AddTB_EMPRow( dr );

			bool isExistEmpNo=EmpController.isExistEmpNo(this.DdnlArea.SelectedValue,this.TbxEmpNo.Text.Trim().ToUpper());

			if(isExistEmpNo)
			{
				ScriptHelper.ShowAlert( MessageManager.GetMessage( "Common", "EXIST_EMPNO" ) );
			}
			else
			{
				EmpController.InsertEmp( ds );
				NavigationHelper.Redirect (MessageManager.GetMessage("Common", "REGISTER_DONE"), "SelectEmp.aspx?Area=" + this.DdnlArea.SelectedValue + "&EmpNo=" + this.TbxEmpNo.Text ) ;
			}
		}
	}
}
