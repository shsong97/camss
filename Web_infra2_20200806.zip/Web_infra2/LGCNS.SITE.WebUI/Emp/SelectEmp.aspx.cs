using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;
using LGCNS.SITE.Common;

namespace LGCNS.SITE.WebUI.Emp
{
	/// <summary>
	/// SelectEmp�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectEmp : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Label LblEmpName;
		protected System.Web.UI.WebControls.Label LblFullName;
		protected System.Web.UI.WebControls.Label LblContactNo;
		protected System.Web.UI.WebControls.Label LblDeptCode;
		protected System.Web.UI.WebControls.Label LblDeptName;
		protected System.Web.UI.WebControls.Label LblDeptNameEng;
		protected System.Web.UI.WebControls.Label LblBizUnit;
		protected System.Web.UI.WebControls.Label LblSiteCode;
		protected System.Web.UI.WebControls.Label LblSiteDesc;
		protected System.Web.UI.WebControls.Label LblSvcLevel;
		protected System.Web.UI.WebControls.Label LblLocationName;
		protected System.Web.UI.WebControls.Label LblBuildingCode;
		protected System.Web.UI.WebControls.Label LblBuildingDesc;
		protected System.Web.UI.WebControls.Button BtnUpdate;
		protected System.Web.UI.WebControls.Button BtnCancel;
		protected System.Web.UI.WebControls.Button BtnList;
		protected System.Web.UI.WebControls.Button BtnApply;
		protected System.Web.UI.WebControls.Label LblArea;
		protected System.Web.UI.WebControls.Label LblEmpNo;
		protected System.Web.UI.WebControls.Button BtnDelete;
		protected System.Web.UI.WebControls.Label LblEmail;
		protected System.Web.UI.WebControls.Label LblLoginID;
		protected System.Web.UI.WebControls.Button BtnInsert;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			BindEmp( this.Request["Area"], this.Request["EmpNo"] );

            ClientScript.RegisterHiddenField("Area", this.LblArea.Text );
            ClientScript.RegisterHiddenField("EmpNo", this.LblEmpNo.Text );

			XjosHelper.RegisterXjos(true);

			NavigationHelper.SetNavigation( this.BtnUpdate, "", "UpdateEmp.aspx", true );
			NavigationHelper.SetNavigation( this.BtnInsert, "", "InsertEmp.aspx", false );
			NavigationHelper.SetHistoryBack( this.BtnCancel );
			NavigationHelper.SetNavigation( this.BtnList, "", "SelectEmpList.aspx", false );


		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnApply.Click += new System.EventHandler(this.BtnApply_Click);
			this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BindEmp( string Area, string EmpNo )
		{
			EmpDS ds = EmpController.SelectEmp( Area, EmpNo );
			EmpDS.TB_EMP_ENTIRERow dr = ds.TB_EMP_ENTIRE[0];

			this.LblArea.Text = dr.Area;
			LblEmpNo.Text = dr.EmpNo;
			LblEmpName.Text = dr.EmpName;
			this.LblFullName.Text = dr.FullName;
			LblContactNo.Text = dr.ContactNo;
			LblLoginID.Text = dr.LoginID;

			if( !dr.IsEmailNull())
				this.LblEmail.Text = dr.Email;
			if( !dr.IsDeptCodeNull() )
				LblDeptCode.Text = dr.DeptCode;
			if( !dr.IsDeptNameNull() )
				LblDeptName.Text = dr.DeptName;
			if( !dr.IsDeptNameEngNull() )
				LblDeptNameEng.Text = dr.DeptNameEng;
			if( !dr.IsBizUnitNull() )
				LblBizUnit.Text = dr.BizUnit;

			if( !dr.IsSiteCodeNull() )
			{
				LblSiteCode.Text = dr.SiteCode;

				if( !dr.IsSiteDescNull() )
				{
					LblSiteDesc.Text = dr.SiteDesc;
					LblSvcLevel.Text = dr.SvcLevel;
					LblLocationName.Text = dr.LocationName;
					LblBuildingCode.Text = dr.BuildingCode;
					LblBuildingDesc.Text = dr.BuildingDesc;
				}
			}

			ds.Dispose();
		}

		private void BtnApply_Click(object sender, System.EventArgs e)
		{
			NameValueCollection valuesToSend = new NameValueCollection();
			valuesToSend["TbxEmpNo"] = this.LblEmpNo.Text;
			valuesToSend["DdnlDeptCode"] = this.LblDeptCode.Text;
			valuesToSend["DdnlSiteCode"] = this.LblSiteCode.Text;
			valuesToSend["TbxEmpName"] = this.LblEmpName.Text;
			NavigationHelper.Close (true, valuesToSend);
		}

		private void BtnDelete_Click(object sender, System.EventArgs e)
		{
			string Area=this.LblArea.Text;
			string EmpNo=this.LblEmpNo.Text;
			EmpController.DeleteEmp( Area, EmpNo );
			//������ ������� �̵�
			NavigationHelper.Redirect("�����Ǿ����ϴ�.", "SelectEMPList.aspx") ;
		}
	}
}
