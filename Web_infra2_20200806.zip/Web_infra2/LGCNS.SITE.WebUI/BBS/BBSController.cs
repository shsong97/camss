using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.FileManagement;

using LGCNS.SITE.BBS.Biz;
using LGCNS.SITE.DTO;


namespace LGCNS.SITE.WebUI.BBS
{
	/// <summary>
	/// BBSController 
	/// </summary>
	public class BBSController : ControllerBase
	{
		public BBSController() {}

		public static void SetFileInfo (BBSDS ds, ArrayList arrayFTO)
		{
			foreach(FileTransferObject fto in arrayFTO)
			{
				BBSDS.TB_BBS_FILERow drFile = ds.TB_BBS_FILE.NewTB_BBS_FILERow();
				drFile.FileName		= fto.OriginalFileName;					
				drFile.UploadPath	= fto.FilePath;
				ds.TB_BBS_FILE.AddTB_BBS_FILERow(drFile);
			}
		}

		public static void InsertBBS (BBSDS ds, ArrayList arrayFTO)
		{
			BBSBizTx biz = null ;

			try
			{
				biz = new BBSBizTx();
				biz.InsertBBS (ds, arrayFTO);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static void UpdateBBS (BBSDS ds, ArrayList arrayFTO, ArrayList arrayUploadPath)
		{
			BBSBizTx biz = null ;

			try
			{
				biz = new BBSBizTx();
				biz.UpdateBBS(ds, arrayFTO, arrayUploadPath);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static void DeleteBBS (int seq)
		{
			BBSBizTx biz = null ;

			try
			{
				biz = new BBSBizTx();
				biz.DeleteBBS(seq);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static BBSDS SelectBBSList(int currentPage, int pageSize, string order, string title)
		{
			BBSBizNTx biz = null ;
			BBSDS ds = null ;

			try
			{
				biz = new BBSBizNTx();
				ds = biz.SelectBBSList(currentPage, pageSize, order, title);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static BBSDS SelectBBSList(string registerID)
		{
			BBSBizNTx biz = null ;
			BBSDS ds = null ;

			try
			{
				biz = new BBSBizNTx();
				ds = biz.SelectBBSList (registerID);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static BBSDS SelectBBS(int seq)
		{
			BBSBizNTx biz = null ;
			BBSDS ds = null ;

			try
			{
				biz = new BBSBizNTx();
				ds = biz.SelectBBS (seq);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}
	}
}
