using System;
using System.Collections.Specialized;

using LGCNS.LAF.Common.FileManagement;

using LGCNS.LAF.Web;
using LGCNS.SITE.DTO;
using LGCNS.SITE.Asset.Biz;

namespace LGCNS.SITE.WebUI.Asset
{
	/// <summary>
	/// AssetController�� ���� ��� �����Դϴ�.
	/// </summary>
	public class AssetController : ControllerBase
	{
		public AssetController() {}

		#region ManageAsset

		public static void InsertAsset (AssetDS ds)
		{
			AssetBizTx biz = null ;

			try
			{
				biz = new AssetBizTx();
				biz.InsertAsset (ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static void UpdateAsset (AssetDS ds)
		{
			AssetBizTx biz = null ;

			try
			{
				biz = new AssetBizTx();
				biz.UpdateAsset(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static void DeleteAsset (AssetDS ds)
		{
			AssetBizTx biz = null ;

			try
			{
				biz = new AssetBizTx();
				biz.DeleteAsset(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		#endregion

		#region SelectAsset

		public static bool isExistAsset( string AssetNo )
		{
			AssetDS ds = SelectAsset( AssetNo );
			if ( ds.TB_ASSET.Count == 1 )
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		public static AssetDS SelectAsset(string AssetNo)
		{
			AssetBizNTx biz = null ;
			AssetDS ds = null ;

			try
			{
				biz = new AssetBizNTx();
				ds = biz.SelectAsset(AssetNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}


		public static AssetDS SelectAssetList( int currentPage, int pageSize, string order, NameValueCollection searchCondition )
		{
			AssetBizNTx biz = null ;
			AssetDS ds = null ;

			try
			{
				biz = new AssetBizNTx();
				ds = biz.SelectAssetList(currentPage,pageSize,order,searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}


		public static AssetDS SelectAssetListForXls( NameValueCollection searchCondition )
		{
			AssetBizNTx biz = null ;
			AssetDS ds = null ;

			try
			{
				biz = new AssetBizNTx();
				ds = biz.SelectAssetListForXls(searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static AssetDS SelectAssetListForXls2( NameValueCollection searchCondition )
		{
			AssetBizNTx biz = null ;
			AssetDS ds = null ;

			try
			{
				biz = new AssetBizNTx();
				ds = biz.SelectAssetListForXls2(searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		#endregion

		public static void UpdateAssetLog (AssetDS ds)
		{
			AssetBizTx biz = null ;

			try
			{
				biz = new AssetBizTx();
				biz.UpdateAssetLog(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static void ChangeAssetNo( string OldAssetNo, string NewAssetNo )
		{
			AssetBizTx biz = null ;

			try
			{
				biz = new AssetBizTx();
				biz.ChangeAssetNo(OldAssetNo,NewAssetNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}


		public static AssetDS SelectAssetLog(string AssetNo, string Seq)
		{
			AssetBizNTx biz = null ;
			AssetDS ds = null ;

			try
			{
				biz = new AssetBizNTx();
				ds = biz.SelectAssetLog(AssetNo,Seq);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static AssetDS SelectAssetLogList(string AssetNo, string EmpNo, string EmpName )
		{
			AssetBizNTx biz = null ;
			AssetDS ds = null ;

			try
			{
				biz = new AssetBizNTx();
				ds = biz.SelectAssetLogList(AssetNo,EmpNo,EmpName);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}



		#region BulkImport

		public static void FileSave( FileTransferObject fto )
		{
			AssetBizTx biz = null;

			try
			{
				biz = new AssetBizTx();
				biz.FileSave(fto);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}			
		}


		public static void FileDelete( FileTransferObject fto )
		{
			AssetBizTx biz = null;

			try
			{
				biz = new AssetBizTx();
				biz.FileDelete(fto);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}			
		}


		public static AssetDS BulkImport( FileTransferObject fto )
		{
			AssetBizTx biz = null;

			try
			{
				biz = new AssetBizTx();
				return biz.BulkImport(fto);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}


		public static string BulkInsertAsset( string UserID )
		{
			AssetBizTx biz = null;
			string ResultStatement = "";

			try
			{
				biz = new AssetBizTx();
				ResultStatement = biz.BulkInsertAsset(UserID);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}

			return ResultStatement;
		}

		#endregion

		public static bool isExistICMS( string AssetNo )
		{
			bool isExist = false;
			
			ICMSDS ds = null;
			AssetBizNTx biz = null;

			try
			{
				biz = new AssetBizNTx();
				ds = biz.SelectICMS( AssetNo );

				if ( ds.Tables["TB_ICMS"].Rows.Count > 0 )
				{
					isExist = true;
				}
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(ds!=null)
				{
					ds.Dispose();
					ds = null;
				}
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null;
				}
			}

			return isExist;
		}
	}
}
