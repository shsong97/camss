using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Asset
{
	/// <summary>
	/// SelectAssetListAsXls�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectAssetListAsXls : LGCNS.SITE.Common.SITEPageBase
	{
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			this.DgrdDataGrid.EnableViewState = false ;

			try
			{
				SelectAssetListForXls() ;
			}
			catch(Exception ex)
			{
				ScriptHelper.ShowAlert ("�����ٿ�ε��� ������ �߻��߽��ϴ�. (" + ex.Message) ;
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
            this.Load += new System.EventHandler(this.Page_Load);

        }
		#endregion

		private void SelectAssetListForXls()
		{
			NameValueCollection searchCondition = new NameValueCollection();
			searchCondition["Area"] = this.Request["DdnlArea"];
			searchCondition["AssetNo"] = this.Request["TbxAssetNo"];
			searchCondition["EmpNo"] = this.Request["TbxEmpNo"];
			searchCondition["EmpName"] = this.Request["TbxEmpName"];
			searchCondition["DeptCode"] = this.Request["DdnlDeptCode"];
			searchCondition["SiteCode"] = this.Request["DdnlSiteCode"];
			searchCondition["CreateDateFrom"] = this.Request["TbxCreateDateFrom"];
			searchCondition["CreateDateTo"] = this.Request["TbxCreateDateTo"];
			searchCondition["SerialNo"] = this.Request["TbxSerialNo"];
			searchCondition["Status"] = this.Request["DdnlStatusCode"];
			searchCondition["CPUType"] = this.Request["DdnlCPUType"];
			searchCondition["ModelNo"] = this.Request["TbxModelNo"];
			searchCondition["NodeName"] = this.Request["TbxNodeName"];

			AssetDS ds = AssetController.SelectAssetListForXls( searchCondition );
			this.DgrdDataGrid.DataSource = ds.TB_ASSET_BULK;
			this.DgrdDataGrid.DataBind() ;
		
			//this.DgrdDataGrid.ExportAsXls ("AssetList.xls") ;
			LGCNS.SITE.Common.WebUI.DataToXls.datagridToXls(Response,this.DgrdDataGrid,"AssetList.xls");
		}
	}
}
