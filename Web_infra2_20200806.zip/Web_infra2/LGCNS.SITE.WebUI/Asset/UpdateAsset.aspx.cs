using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;




namespace LGCNS.SITE.WebUI.Asset
{
	/// <summary>
	/// UpdateAsset�� ���� ��� �����Դϴ�.
	/// </summary>
	public class UpdateAsset : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxAssetNo;
		protected System.Web.UI.WebControls.TextBox TbxParentAssetNo;
		protected System.Web.UI.WebControls.TextBox TbxOldBarcode;
		protected System.Web.UI.WebControls.TextBox TbxModelNumber;
		protected System.Web.UI.WebControls.ImageButton IbtnSearchModel;
		protected System.Web.UI.WebControls.TextBox TbxSerialNumber;
		protected System.Web.UI.WebControls.TextBox TbxManufacturer;
		protected System.Web.UI.WebControls.DropDownList DdnlCompStatus;
		protected System.Web.UI.WebControls.DropDownList DdnlClassID;
		protected System.Web.UI.WebControls.TextBox TbxEmpNo;
		protected System.Web.UI.WebControls.ImageButton IbtnSearchEmp;
		protected System.Web.UI.WebControls.TextBox TbxEmpName;
		protected System.Web.UI.WebControls.DropDownList DdnlDeptCode;
		protected System.Web.UI.WebControls.DropDownList DdnlSiteCode;
		protected System.Web.UI.WebControls.DropDownList DdnlCPUType;
		protected System.Web.UI.WebControls.TextBox TbxCPUSpeed;
		protected System.Web.UI.WebControls.DropDownList DdnlOPSystem;
		protected System.Web.UI.WebControls.TextBox TbxTotalMemory;
		protected System.Web.UI.WebControls.TextBox TbxHardDiskSize;
		protected System.Web.UI.WebControls.TextBox TbxNodeName;
		protected System.Web.UI.WebControls.TextBox TbxServerName;
		protected System.Web.UI.WebControls.TextBox TbxMACAddress_1st;
		protected System.Web.UI.WebControls.TextBox TbxMACAddress_2nd;
		protected System.Web.UI.WebControls.DropDownList DdnlSystemID;
		protected System.Web.UI.WebControls.TextBox TbxTypeDesc;
		protected System.Web.UI.WebControls.TextBox TbxPhyInventoryDate;
		protected System.Web.UI.WebControls.TextBox TbxDateInstalled;
		protected System.Web.UI.WebControls.TextBox TbxDateReceived;
		protected System.Web.UI.WebControls.TextBox TbxDisposedDate;
		protected System.Web.UI.WebControls.TextBox TbxComments;
		protected System.Web.UI.WebControls.TextBox TbxCreateID;
		protected System.Web.UI.WebControls.TextBox TbxCreateDate;
		protected System.Web.UI.WebControls.TextBox TbxUpdateID;
		protected System.Web.UI.WebControls.TextBox TbxUpdateDate;
		protected System.Web.UI.WebControls.Button BtnSave;
		protected System.Web.UI.WebControls.TextBox TbxFloorID;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected System.Web.UI.WebControls.TextBox TbxOldAssetNo;
		protected System.Web.UI.WebControls.Button BtnCancel;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos(true);
			SetValidator();

			ScriptHelper.SetConfirmMessageOn( this.BtnSave, MessageManager.GetMessage( "Common", "UPDATE_QUESTION" ) );
			NavigationHelper.SetHistoryBack( this.BtnCancel );

			NavigationHelper.SetPopupWindow(
				this.IbtnSearchModel,
				"../Code/SelectModelList.aspx",
				"SearchModel",
				1000, 400,
				false
				);

			NavigationHelper.SetPopupWindow(
				this.IbtnSearchEmp,
				"../Emp/SearchEmp.aspx",
				"SearchModel",
				600, 400,
				true
				);

			if ( !this.IsPostBack )
			{
				InitialContorls();
				BindAsset( this.Request["AssetNo"] );
			}
			if ( this.IsSubmittedBy )
			{
				//InitialContorls();
				ReloadControls();
				// ���� : 2005/04/12 
				// ������ : �ڻ� ������ combo box �ʱ�ȭ �Ǵ� ���� ����
				// �������� : BindAsset( this.Request["AssetNo"] ) �κ� �츲
				// ����� Method : Page_Load
				BindAsset( this.Request["AssetNo"] );
			}

			ClientScript.RegisterHiddenField("AssetNo", this.TbxAssetNo.Text );
            ClientScript.RegisterHiddenField("Area", this.DdnlArea.SelectedValue );
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DdnlArea.SelectedIndexChanged += new System.EventHandler(this.DdnlArea_SelectedIndexChanged);
			this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		private void SetValidator()
		{
			XjosHelper.SetValidator (this.TbxAssetNo,
				new XjosValidator (XjosValidatorType.Required),
				new XjosValidator (XjosValidatorType.Minlength, "8", "8�ڸ� �̻��Դϴ�.")
				//new XjosValidator (XjosValidatorType.Numeric)
				);
			this.TbxAssetNo.MaxLength = 8;
			XjosHelper.SetValidator (this.TbxParentAssetNo,
				new XjosValidator (XjosValidatorType.Minlength, "8", "8�ڸ��ϴ�."),
				new XjosValidator (XjosValidatorType.Numeric)
				);
			this.TbxParentAssetNo.MaxLength = 8;

			XjosHelper.SetValidator (this.TbxPhyInventoryDate, new XjosValidator (XjosValidatorType.Date) );
			XjosHelper.SetValidator (this.TbxDateInstalled, new XjosValidator (XjosValidatorType.Date) );
			XjosHelper.SetValidator (this.TbxDateReceived, new XjosValidator (XjosValidatorType.Date) );
			XjosHelper.SetValidator (this.TbxDisposedDate, new XjosValidator (XjosValidatorType.Date) );
			XjosHelper.SetValidator (this.TbxCreateDate, new XjosValidator (XjosValidatorType.Date) );
			XjosHelper.SetValidator (this.TbxUpdateDate, new XjosValidator (XjosValidatorType.Date) );

			XjosHelper.ValidateOnClick ( this.BtnSave ) ;
		}

		private void InitialContorls()
		{
			LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea );

//			string Area = this.Request["Area"];
//			this.DdnlArea.SelectedValue = Area;

//			LGCNS.SITE.Common.WebUI.DeptInfo.BindDropDownList( this.DdnlDeptCode, Area );
//			LGCNS.SITE.Common.WebUI.SiteInfo.BindDropDownList( this.DdnlSiteCode, Area );

			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlCompStatus, "COMP_STATUS", false );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlClassID, "CLASS_ID", false );

			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlCPUType, "CPU_TYPE", false );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlOPSystem, "OP_SYSTEM", true );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlSystemID, "SYSTEM_ID", true );
		}

		private void ReloadControls()
		{
			LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea );
			
			string Area = this.Request["Area"];
			
			LGCNS.SITE.Common.WebUI.DeptInfo.BindDropDownList( this.DdnlDeptCode, Area, true );
			LGCNS.SITE.Common.WebUI.SiteInfo.BindDropDownList( this.DdnlSiteCode, Area, true );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlCompStatus, "COMP_STATUS", false );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlClassID, "CLASS_ID", false );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlCPUType, "CPU_TYPE", false );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlOPSystem, "OP_SYSTEM", false );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlSystemID, "SYSTEM_ID", false );

			this.TbxAssetNo.Text = this.Request["TbxAssetNo"];
			this.DdnlArea.SelectedValue = Area;
			this.TbxParentAssetNo.Text = this.Request["TbxParentAssetNo"];
			this.TbxOldBarcode.Text = this.Request["TbxOldBarcode"];
			this.TbxModelNumber.Text = this.Request["TbxModelNumber"];
			this.TbxSerialNumber.Text = this.Request["TbxSerialNumber"];
			this.TbxManufacturer.Text = this.Request["TbxManufacturer"];
			this.DdnlCompStatus.SelectedValue = this.Request["DdnlCompStatus"];
			this.DdnlClassID.SelectedValue = this.Request["DdnlClassID"];
			this.TbxEmpNo.Text = this.Request["TbxEmpNo"];

			this.DdnlDeptCode.SelectedValue = this.Request["DdnlDeptCode"];
			this.DdnlSiteCode.SelectedValue = this.Request["DdnlSiteCode"];

			this.TbxFloorID.Text = this.Request["TbxFloorID"];
			this.DdnlCPUType.SelectedValue = this.Request["DdnlCPUType"];
			this.TbxCPUSpeed.Text = this.Request["TbxCPUSpeed"];
			this.DdnlOPSystem.SelectedValue = this.Request["DdnlOPSystem"];
			this.TbxTotalMemory.Text = this.Request["TbxTotalMemory"];
			this.TbxHardDiskSize.Text = this.Request["TbxHardDiskSize"];
			this.TbxNodeName.Text = this.Request["TbxNodeName"];
			this.TbxServerName.Text = this.Request["TbxServerName"];
			this.TbxMACAddress_1st.Text = this.Request["TbxMACAddress_1st"];
			this.TbxMACAddress_2nd.Text = this.Request["TbxMACAddress_2nd"];
			this.DdnlSystemID.SelectedValue = this.Request["DdnlSystemID"];
			this.TbxTypeDesc.Text = this.Request["TbxTypeDesc"];
			this.TbxDisposedDate.Text = this.Request["TbxDisposedDate"];
			this.TbxComments.Text = this.Request["TbxComments"];

//			this.TbxPhyInventoryDate.Text = DateTime.Now.ToShortDateString();
//			this.TbxDateInstalled.Text = DateTime.Now.ToShortDateString();
//			this.TbxDateReceived.Text = DateTime.Now.ToShortDateString();
//
//			this.TbxCreateID.Text = this.CurrentUserName;
//			this.TbxCreateDate.Text = DateTime.Now.ToShortDateString();
//			this.TbxUpdateID.Text = this.CurrentUserName;
//			this.TbxUpdateDate.Text = DateTime.Now.ToShortDateString();
		}


		private void BindAsset( string AssetNo )
		{
			if ( AssetNo == null || AssetNo.Length != 8 )
			{
				ScriptHelper.ShowAlert( "�ڻ��ȣ�� �̻��մϴ�." );
				return;
			}

			AssetDS ds = AssetController.SelectAsset( AssetNo );
			AssetDS.TB_ASSETRow dr = ds.TB_ASSET[0];

			string Area = dr.Area;
			this.DdnlArea.SelectedValue = Area;

			LGCNS.SITE.Common.WebUI.DeptInfo.BindDropDownList( this.DdnlDeptCode, Area );
			LGCNS.SITE.Common.WebUI.SiteInfo.BindDropDownList( this.DdnlSiteCode, Area );

			this.TbxAssetNo.Text = dr.AssetNo;
			this.TbxOldAssetNo.Text = dr.AssetNo;
			this.DdnlArea.SelectedValue = dr.Area;
			this.TbxParentAssetNo.Text = dr.ParentAssetNo;
			this.TbxOldBarcode.Text = dr.OldBarcode;
			this.TbxModelNumber.Text = dr.ModelNumber;
			this.TbxSerialNumber.Text = dr.SerialNumber;
			this.TbxManufacturer.Text = dr.Manufacturer;
			this.DdnlCompStatus.SelectedValue = dr.CompStatus;
			this.DdnlClassID.SelectedValue = dr.ClassID;
			this.TbxEmpNo.Text = dr.EmpNo;
			this.TbxEmpName.Text = LGCNS.SITE.Common.WebUI.EmpInfo.getEmpName( dr.Area, dr.EmpNo );
			
			try
			{
				this.DdnlDeptCode.SelectedValue = dr.DeptCode;
			}
			catch( ArgumentOutOfRangeException ae )
			{
				string errmsg=ae.Message;
				LGCNS.SITE.Common.WebUI.DeptInfo.BindDropDownList( this.DdnlDeptCode, Area, true );	
			}
			try{ this.DdnlSiteCode.SelectedValue = dr.SiteCode; }
			catch( ArgumentOutOfRangeException ae )
			{
				string errmsg=ae.Message;
				LGCNS.SITE.Common.WebUI.SiteInfo.BindDropDownList( this.DdnlSiteCode, Area, true );
			}

			this.TbxFloorID.Text = dr.FloorID;
			this.DdnlCPUType.SelectedValue = dr.CPUType;
			this.TbxCPUSpeed.Text = dr.CPUSpeed;
			this.DdnlOPSystem.SelectedValue = dr.OPSystem.Trim();
			this.TbxTotalMemory.Text = dr.TotalMemory;
			this.TbxHardDiskSize.Text = dr.HardDiskSize;
			this.TbxNodeName.Text = dr.NodeName;
			this.TbxServerName.Text = dr.ServerName;
			this.TbxMACAddress_1st.Text = dr.MACAddress_1st;
			this.TbxMACAddress_2nd.Text = dr.MACAddress_2nd;
			//this.TbxPhyInventoryDate.Text = dr.PhyInventoryDate.ToShortDateString();
			//this.TbxDateInstalled.Text = dr.DateInstalled.ToShortDateString();
			//this.TbxDateReceived.Text = dr.DateReceived.ToShortDateString();
			this.DdnlSystemID.SelectedValue = dr.SystemID.Trim();
			this.TbxTypeDesc.Text = dr.TypeDesc;

			if ( ! dr.IsPhyInventoryDateNull() )
			{
				this.TbxPhyInventoryDate.Text = dr.PhyInventoryDate.ToShortDateString();
			}
			if ( ! dr.IsDateInstalledNull() )
			{
				this.TbxDateInstalled.Text = dr.DateInstalled.ToShortDateString();
			}			
			if ( ! dr.IsDateReceivedNull() )
			{
				this.TbxDateReceived.Text = dr.DateReceived.ToShortDateString();
			}	

			this.TbxComments.Text = dr.Comments;
			this.TbxCreateID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.CreateID ); 
			this.TbxCreateDate.Text = dr.CreateDate.ToShortDateString();
			this.TbxUpdateID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.UpdateID );
			this.TbxUpdateDate.Text = dr.UpdateDate.ToShortDateString();
		}


		private void BtnSave_Click(object sender, System.EventArgs e)
		{
			UpdateAssetInfo();
		}

		private AssetDS GetAssetInfo()
		{
			AssetDS ds = new AssetDS();
			ds.EnforceConstraints = false;
			AssetDS.TB_ASSETRow dr = ds.TB_ASSET.NewTB_ASSETRow();

			dr.AssetNo = this.TbxAssetNo.Text;
			dr.ParentAssetNo = this.TbxParentAssetNo.Text;
			dr.OldBarcode = this.TbxOldBarcode.Text;
			dr.ModelNumber = this.TbxModelNumber.Text;
			dr.SerialNumber = this.TbxSerialNumber.Text;
			dr.Manufacturer = this.TbxManufacturer.Text;
			dr.CompStatus = this.DdnlCompStatus.SelectedValue;
			dr.ClassID = this.DdnlClassID.SelectedValue;
			dr.EmpNo = this.TbxEmpNo.Text;
			dr.DeptCode = this.DdnlDeptCode.SelectedValue;
			dr.SiteCode = this.DdnlSiteCode.SelectedValue;
			dr.FloorID = this.TbxFloorID.Text;
			dr.CPUType = this.DdnlCPUType.SelectedValue;
			dr.CPUSpeed = this.TbxCPUSpeed.Text;
			dr.OPSystem = this.DdnlOPSystem.SelectedValue;
			dr.TotalMemory = this.TbxTotalMemory.Text;
			dr.HardDiskSize = this.TbxHardDiskSize.Text;
			dr.NodeName = this.TbxNodeName.Text;
			dr.ServerName = this.TbxServerName.Text;
			dr.MACAddress_1st = this.TbxMACAddress_1st.Text;
			dr.MACAddress_2nd = this.TbxMACAddress_2nd.Text;
			dr.PhyInventoryDate = DateTime.Parse( this.TbxPhyInventoryDate.Text );
			dr.DateInstalled = DateTime.Parse( this.TbxDateInstalled.Text );
			dr.DateReceived = DateTime.Parse( this.TbxDateReceived.Text );
			dr.SystemID = this.DdnlSystemID.SelectedValue;
			dr.TypeDesc = this.TbxTypeDesc.Text;
			if ( this.TbxDisposedDate.Text.Length > 0 )
			{
				dr.DisposedDate = DateTime.Parse( this.TbxDisposedDate.Text );
			}
			else
			{
				if ( this.DdnlCompStatus.SelectedValue == "DISP" )
				{
					dr.DisposedDate = DateTime.Now;
				}
			}
			dr.Comments = this.TbxComments.Text;

			dr.TicketNo = "ZZZZZZ";
			dr.UpdateID = this.CurrentUserID;
			dr.UpdateDate = DateTime.Now;
			dr.Area = this.DdnlArea.SelectedValue;
		
			ds.TB_ASSET.AddTB_ASSETRow( dr );

			return ds;
		}

		private void UpdateAssetInfo()
		{
			AssetDS ds = GetAssetInfo();

			if( this.TbxAssetNo.Text != this.TbxOldAssetNo.Text )
			{
				AssetController.ChangeAssetNo( this.TbxOldAssetNo.Text, this.TbxAssetNo.Text );
			}
			
			AssetController.UpdateAsset( ds );

			NavigationHelper.Redirect( 
				MessageManager.GetMessage("Common", "UPDATE_DONE"),
				"",
				"SelectAsset.aspx?AssetNo=" + this.TbxAssetNo.Text
				);
		}

		private void DdnlArea_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			string Area = this.DdnlArea.SelectedValue;
			LGCNS.SITE.Common.WebUI.DeptInfo.BindDropDownList( this.DdnlDeptCode, Area, true );
			LGCNS.SITE.Common.WebUI.SiteInfo.BindDropDownList( this.DdnlSiteCode, Area, true );
			this.TbxEmpNo.Text = "";
			this.TbxEmpName.Text = "";
		}
	}
}
