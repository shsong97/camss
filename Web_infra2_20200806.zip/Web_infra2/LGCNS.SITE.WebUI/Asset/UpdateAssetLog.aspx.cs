using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;




namespace LGCNS.SITE.WebUI.Asset
{
	/// <summary>
	/// UpdateAssetLog�� ���� ��� �����Դϴ�.
	/// </summary>
	public class UpdateAssetLog : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxAssetNo;
		protected System.Web.UI.WebControls.TextBox TbxParentAssetNo;
		protected System.Web.UI.WebControls.TextBox TbxOldBarcode;
		protected System.Web.UI.WebControls.TextBox TbxModelNumber;
		protected System.Web.UI.WebControls.TextBox TbxSerialNumber;
		protected System.Web.UI.WebControls.TextBox TbxManufacturer;
		protected System.Web.UI.WebControls.TextBox TbxEmpNo;
		protected System.Web.UI.WebControls.TextBox TbxEmpName;
		protected System.Web.UI.WebControls.TextBox TbxFloorID;
		protected System.Web.UI.WebControls.TextBox TbxCPUSpeed;
		protected System.Web.UI.WebControls.TextBox TbxTotalMemory;
		protected System.Web.UI.WebControls.TextBox TbxHardDiskSize;
		protected System.Web.UI.WebControls.TextBox TbxNodeName;
		protected System.Web.UI.WebControls.TextBox TbxServerName;
		protected System.Web.UI.WebControls.TextBox TbxMACAddress_1st;
		protected System.Web.UI.WebControls.TextBox TbxMACAddress_2nd;
		protected System.Web.UI.WebControls.TextBox TbxTypeDesc;
		protected System.Web.UI.WebControls.TextBox TbxPhyInventoryDate;
		protected System.Web.UI.WebControls.TextBox TbxDateInstalled;
		protected System.Web.UI.WebControls.TextBox TbxDateReceived;
		protected System.Web.UI.WebControls.TextBox TbxDisposedDate;
		protected System.Web.UI.WebControls.TextBox TbxComments;
		protected System.Web.UI.WebControls.TextBox TbxCompStatus;
		protected System.Web.UI.WebControls.TextBox TbxClassID;
		protected System.Web.UI.WebControls.TextBox TbxDeptCode;
		protected System.Web.UI.WebControls.TextBox TbxSiteCode;
		protected System.Web.UI.WebControls.TextBox TbxCPUType;
		protected System.Web.UI.WebControls.TextBox TbxOPSystem;
		protected System.Web.UI.WebControls.TextBox TbxSystemID;
		protected System.Web.UI.WebControls.Button BtnUpdate;
		protected System.Web.UI.WebControls.TextBox TbxSeq;
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected System.Web.UI.WebControls.TextBox TbxChangeDate;
		protected System.Web.UI.WebControls.TextBox TbxOldAssetNo;
		protected System.Web.UI.WebControls.TextBox TbxArea;
		protected System.Web.UI.WebControls.Button BtnCancel;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos(true);

			XjosHelper.SetValidator (this.TbxChangeDate,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);
			XjosHelper.ValidateOnClick(this.BtnUpdate); // Xjos Validation�� ������ ��ư ����

			NavigationHelper.SetHistoryBack( this.BtnCancel );
			ScriptHelper.SetConfirmMessageOn( this.BtnUpdate, MessageManager.GetMessage( "Common", "UPDATE_QUESTION" ) );

			if( !this.IsPostBack)
			{
				BindAssetLog( this.Request["AssetNo"], this.Request["Seq"] );
			}

			if ( this.IsSubmittedBy )
			{
				BindAssetLog( this.Request["AssetNo"], this.Request["Seq"] );
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnUpdate.Click += new System.EventHandler(this.BtnUpdate_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BindAssetLog( string AssetNo, string Seq )
		{
			if ( AssetNo == null || AssetNo.Length != 8 )
			{
				ScriptHelper.ShowAlert( "�ڻ��ȣ�� �̻��մϴ�." );
				return;
			}

			AssetDS ds = AssetController.SelectAssetLog( AssetNo, Seq );
			AssetDS.TB_ASSET_LOGRow dr = ds.TB_ASSET_LOG[0];

			this.TbxAssetNo.Text = dr.AssetNo;

			this.TbxSeq.Text = dr.Seq.ToString();
			this.TbxOldAssetNo.Text = dr.OldAssetNo;
			this.TbxArea.Text = dr.Area;

			this.TbxTicketNo.Text = dr.TicketNo;
			this.TbxChangeDate.Text = dr.ChangeDate.ToShortDateString();

			this.TbxParentAssetNo.Text = dr.ParentAssetNo;
			this.TbxOldBarcode.Text = dr.OldBarcode;
			this.TbxModelNumber.Text = dr.ModelNumber;
			this.TbxSerialNumber.Text = dr.SerialNumber;
			this.TbxManufacturer.Text = dr.Manufacturer;
			this.TbxCompStatus.Text = LGCNS.SITE.Common.WebUI.CodeInfo.getCodeDesc( "COMP_STATUS", dr.CompStatus );
			this.TbxClassID.Text = LGCNS.SITE.Common.WebUI.CodeInfo.getCodeDesc( "CLASS_ID", dr.ClassID );
			this.TbxEmpNo.Text = dr.EmpNo;
			this.TbxEmpName.Text = LGCNS.SITE.Common.WebUI.EmpInfo.getEmpName( dr.Area, dr.EmpNo );
			this.TbxDeptCode.Text = LGCNS.SITE.Common.WebUI.DeptInfo.getDeptName( dr.Area, dr.DeptCode );
			this.TbxSiteCode.Text = dr.SiteCode;
			this.TbxFloorID.Text = dr.FloorID;
			this.TbxCPUType.Text = LGCNS.SITE.Common.WebUI.CodeInfo.getCodeDesc( "CPU_TYPE", dr.CPUType );
			this.TbxCPUSpeed.Text = dr.CPUSpeed;
			if ( !dr.IsOPSystemNull() )
			{
				this.TbxOPSystem.Text = LGCNS.SITE.Common.WebUI.CodeInfo.getCodeDesc( "OP_SYSTEM", dr.OPSystem );
			}
			this.TbxTotalMemory.Text = dr.TotalMemory;
			this.TbxHardDiskSize.Text = dr.HardDiskSize;
			this.TbxNodeName.Text = dr.NodeName;
			this.TbxServerName.Text = dr.ServerName;
			this.TbxMACAddress_1st.Text = dr.MACAddress_1st;
			this.TbxMACAddress_2nd.Text = dr.MACAddress_2nd;
			this.TbxPhyInventoryDate.Text = dr.PhyInventoryDate.ToShortDateString();
			this.TbxDateInstalled.Text = dr.DateInstalled.ToShortDateString();
			this.TbxDateReceived.Text = dr.DateReceived.ToShortDateString();
			this.TbxSystemID.Text = LGCNS.SITE.Common.WebUI.CodeInfo.getCodeDesc( "SYSTEM_ID", dr.SystemID );
			this.TbxTypeDesc.Text = dr.TypeDesc;
			if ( ! dr.IsDisposedDateNull() )
			{
				this.TbxDisposedDate.Text = dr.DisposedDate.ToShortDateString();
			}
			this.TbxComments.Text = dr.Comments;
		}

		private void BtnUpdate_Click(object sender, System.EventArgs e)
		{
			AssetDS ds = new AssetDS();
			ds.EnforceConstraints = false;
			AssetDS.TB_ASSET_LOGRow dr = ds.TB_ASSET_LOG.NewTB_ASSET_LOGRow();

			dr.AssetNo = this.TbxAssetNo.Text;
			dr.Seq = int.Parse( this.TbxSeq.Text );
			dr.ChangeDate = DateTime.Parse( this.TbxChangeDate.Text );

			ds.TB_ASSET_LOG.AddTB_ASSET_LOGRow( dr );

			AssetController.UpdateAssetLog( ds );

			NavigationHelper.Redirect( 
				MessageManager.GetMessage("Common", "UPDATE_DONE"),
				"",
				"SelectAsset.aspx?AssetNo=" + this.TbxAssetNo.Text
				);
			
		}
	}
}
