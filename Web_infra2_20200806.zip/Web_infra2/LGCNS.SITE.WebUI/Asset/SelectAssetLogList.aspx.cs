using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Asset
{
	/// <summary>
	/// SelectAssetLogList�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectAssetLogList : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxAssetNo;
		protected System.Web.UI.WebControls.TextBox TbxEmpNo;
		protected System.Web.UI.WebControls.TextBox TbxEmpName;
		protected System.Web.UI.WebControls.Button BtnSearch;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdAssetLogList;
		protected System.Web.UI.WebControls.Button BtnClear;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }
			XjosHelper.RegisterXjos(true);

			if( !this.IsPostBack )
			{
				InitialControls();
			}

//			if( this.TbxAssetNo.Text == "" && this.TbxEmpNo.Text == "" && this.TbxEmpName.Text == "" )
//			{
//				ScriptHelper.SetConfirmMessageOn( this.BtnSearch, MessageManager.GetMessage( "Common", "ENTIRE_SEARCH" ) );
//			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
			this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void InitialControls()
		{
			this.TbxAssetNo.Text = "";
			this.TbxEmpNo.Text = "";
			this.TbxEmpName.Text = "";
		}

		private void BtnClear_Click(object sender, System.EventArgs e)
		{
			InitialControls();
		}

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			BindAssetLogList( this.TbxAssetNo.Text, this.TbxEmpNo.Text, this.TbxEmpName.Text );
		}

		private void BindAssetLogList( string AssetNo, string EmpNo, string EmpName )
		{
			if( AssetNo == "" && EmpNo == "" && EmpName == "" )
			{
				ScriptHelper.ShowAlert(
					MessageManager.GetMessage( "Common", "NO_CONDITION" )
				);
			}
			else
			{
				AssetDS ds = AssetController.SelectAssetLogList( AssetNo, EmpNo, EmpName );
				this.DgrdAssetLogList.DataSource = ds.TB_ASSET_LOG;
				this.DgrdAssetLogList.DataBind();
			}
		}
	}
}
