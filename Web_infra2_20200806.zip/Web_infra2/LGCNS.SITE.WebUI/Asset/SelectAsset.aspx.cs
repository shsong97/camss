using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Asset
{
	/// <summary>
	/// SelectAsset�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectAsset : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxAssetNo;
		protected System.Web.UI.WebControls.TextBox TbxParentAssetNo;
		protected System.Web.UI.WebControls.TextBox TbxOldBarcode;
		protected System.Web.UI.WebControls.TextBox TbxModelNumber;
		protected System.Web.UI.WebControls.TextBox TbxSerialNumber;
		protected System.Web.UI.WebControls.TextBox TbxManufacturer;
		protected System.Web.UI.WebControls.TextBox TbxCompStatus;
		protected System.Web.UI.WebControls.TextBox TbxClassID;
		protected System.Web.UI.WebControls.TextBox TbxEmpNo;
		protected System.Web.UI.WebControls.TextBox TbxDeptCode;
		protected System.Web.UI.WebControls.TextBox TbxSiteCode;
		protected System.Web.UI.WebControls.TextBox TbxCPUType;
		protected System.Web.UI.WebControls.TextBox TbxCPUSpeed;
		protected System.Web.UI.WebControls.TextBox TbxOPSystem;
		protected System.Web.UI.WebControls.TextBox TbxTotalMemory;
		protected System.Web.UI.WebControls.TextBox TbxHardDiskSize;
		protected System.Web.UI.WebControls.TextBox TbxNodeName;
		protected System.Web.UI.WebControls.TextBox TbxServerName;
		protected System.Web.UI.WebControls.TextBox TbxMACAddress_1st;
		protected System.Web.UI.WebControls.TextBox TbxMACAddress_2nd;
		protected System.Web.UI.WebControls.TextBox TbxPhyInventoryDate;
		protected System.Web.UI.WebControls.TextBox TbxDateInstalled;
		protected System.Web.UI.WebControls.TextBox TbxDateReceived;
		protected System.Web.UI.WebControls.TextBox TbxSystemID;
		protected System.Web.UI.WebControls.TextBox TbxTypeDesc;
		protected System.Web.UI.WebControls.TextBox TbxDisposedDate;
		protected System.Web.UI.WebControls.TextBox TbxComments;
		protected System.Web.UI.WebControls.TextBox TbxCreateID;
		protected System.Web.UI.WebControls.TextBox TbxCreateDate;
		protected System.Web.UI.WebControls.TextBox TbxUpdateID;
		protected System.Web.UI.WebControls.TextBox TbxUpdateDate;
		protected System.Web.UI.WebControls.TextBox TbxEmpName;
		protected System.Web.UI.WebControls.Button BtnUpdate;
		protected System.Web.UI.WebControls.Button BtnDelete;
		protected System.Web.UI.WebControls.Button BtnCancel;
		protected System.Web.UI.WebControls.TextBox TbxFloorID;
		protected System.Web.UI.WebControls.Button BtnList;
		protected System.Web.UI.WebControls.TextBox TbxArea;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdAssetHistory;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos(true);

			this.DgrdAssetHistory.NavigateOnRowClick (
				"", // �̵��� �����Ӹ�, ��������ü�� �̵��Ҷ� ""�� �����Ѵ�.
				"UpdateAssetLog.aspx", // LinkŬ���� �̵��� Url  (����ȸȭ��)
				new string [2] {"AssetNo", "Seq"},  // LinkŬ���� ������ Query String �� key�� �迭
				new int [2] {0,1}, // LinkŬ���� ������ Query String �� value���� ������ Cell Index�� �迭
				false  // // ������������ ���� SelectTicket.aspx ���� submit��Ų��. (POST������� ȣ���Ѵ�.)
				) ;

			NavigationHelper.SetNavigation( this.BtnUpdate, "", "UpdateAsset.aspx", true );
			NavigationHelper.SetHistoryBack( this.BtnCancel );
			NavigationHelper.SetNavigation( this.BtnList, "", "SelectAssetList.aspx", false );

			ScriptHelper.SetConfirmMessageOn( this.BtnDelete, MessageManager.GetMessage("Common", "DELETE_QUESTION" ) );

			BindAsset( this.Request["AssetNo"] );

            ClientScript.RegisterHiddenField("AssetNo", this.TbxAssetNo.Text );
            ClientScript.RegisterHiddenField("Area", this.TbxArea.Text );

			if ( this.CurrentUserAuthority.CompareTo("A") > 0 )
			{
				this.BtnUpdate.Visible = false;
				this.BtnDelete.Visible = false;
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BindAsset( string AssetNo )
		{
			if ( AssetNo == null || AssetNo.Length != 8 )
			{
				ScriptHelper.ShowAlert( "�ڻ��ȣ�� �̻��մϴ�." );
				return;
			}

			AssetDS ds = AssetController.SelectAsset( AssetNo );
			AssetDS.TB_ASSETRow dr = ds.TB_ASSET[0];

			this.TbxAssetNo.Text = dr.AssetNo;
			this.TbxArea.Text = dr.Area;
			this.TbxParentAssetNo.Text = dr.ParentAssetNo;
			this.TbxOldBarcode.Text = dr.OldBarcode;
			this.TbxModelNumber.Text = dr.ModelNumber;
			this.TbxSerialNumber.Text = dr.SerialNumber;
			this.TbxManufacturer.Text = dr.Manufacturer;
			this.TbxCompStatus.Text = LGCNS.SITE.Common.WebUI.CodeInfo.getCodeDesc( "COMP_STATUS", dr.CompStatus );
			
			this.TbxClassID.Text = LGCNS.SITE.Common.WebUI.CodeInfo.getCodeDesc( "CLASS_ID", dr.ClassID );
			this.TbxEmpNo.Text = dr.EmpNo;
			this.TbxEmpName.Text = LGCNS.SITE.Common.WebUI.EmpInfo.getEmpName( this.TbxArea.Text, dr.EmpNo );
			this.TbxDeptCode.Text = LGCNS.SITE.Common.WebUI.DeptInfo.getDeptName( dr.Area, dr.DeptCode );
			
			this.TbxSiteCode.Text = dr.SiteCode;
			this.TbxFloorID.Text = dr.FloorID;
			this.TbxCPUType.Text = LGCNS.SITE.Common.WebUI.CodeInfo.getCodeDesc( "CPU_TYPE", dr.CPUType );
			this.TbxCPUSpeed.Text = dr.CPUSpeed;
			if ( !dr.IsOPSystemNull() )
			{
				this.TbxOPSystem.Text = LGCNS.SITE.Common.WebUI.CodeInfo.getCodeDesc( "OP_SYSTEM", dr.OPSystem );
			}
			this.TbxTotalMemory.Text = dr.TotalMemory;
			this.TbxHardDiskSize.Text = dr.HardDiskSize;
			this.TbxNodeName.Text = dr.NodeName;
			this.TbxServerName.Text = dr.ServerName;
			this.TbxMACAddress_1st.Text = dr.MACAddress_1st;
			this.TbxMACAddress_2nd.Text = dr.MACAddress_2nd;
			if ( ! dr.IsPhyInventoryDateNull() )
			{
				this.TbxPhyInventoryDate.Text = dr.PhyInventoryDate.ToShortDateString();
			}
			if ( ! dr.IsDateInstalledNull() )
			{
				this.TbxDateInstalled.Text = dr.DateInstalled.ToShortDateString();
			}			
			if ( ! dr.IsDateReceivedNull() )
			{
				this.TbxDateReceived.Text = dr.DateReceived.ToShortDateString();
			}				

			this.TbxSystemID.Text = LGCNS.SITE.Common.WebUI.CodeInfo.getCodeDesc( "SYSTEM_ID", dr.SystemID );
			this.TbxTypeDesc.Text = dr.TypeDesc;
			if ( ! dr.IsDisposedDateNull() )
			{
				this.TbxDisposedDate.Text = dr.DisposedDate.ToShortDateString();
			}
			this.TbxComments.Text = dr.Comments;
			this.TbxCreateID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.CreateID );
			this.TbxCreateDate.Text = dr.CreateDate.ToShortDateString() + " " + dr.CreateDate.ToShortTimeString();
			this.TbxUpdateID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.UpdateID );
			this.TbxUpdateDate.Text = dr.UpdateDate.ToShortDateString() + " " + dr.UpdateDate.ToShortTimeString();

			this.DgrdAssetHistory.DataSource = ds.TB_ASSET_LOG;
			this.DgrdAssetHistory.DataBind();

		}

		private void BtnDelete_Click(object sender, System.EventArgs e)
		{
			string AssetNo = this.TbxAssetNo.Text;
			if ( isValidDelete( AssetNo ) )
			{
				DeleteAsset( AssetNo );

				NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "DELETE_DONE" ), "SelectAssetList.aspx" );
			}
		}

		private bool isValidDelete( string AssetNo )
		{
			bool isValid = true;

			if ( AssetController.isExistICMS( AssetNo ) )
			{
				ScriptHelper.ShowAlert( MessageManager.GetMessage( "Common", "EXISTS_ICMS" ) );
				isValid = false;
			}

			return isValid;
		}

		private void DeleteAsset( string AssetNo )
		{
			AssetDS ds = new AssetDS();
			ds.EnforceConstraints = false;
			AssetDS.TB_ASSETRow dr = ds.TB_ASSET.NewTB_ASSETRow();
			dr.AssetNo = AssetNo;
			ds.TB_ASSET.AddTB_ASSETRow( dr );

			AssetController.DeleteAsset( ds );
		}
	}
}
