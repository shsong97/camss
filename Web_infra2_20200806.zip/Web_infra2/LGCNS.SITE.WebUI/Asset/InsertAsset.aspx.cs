using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Asset
{
	/// <summary>
	/// InsertAsset�� ���� ��� �����Դϴ�.
	/// </summary>
	public class InsertAsset : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxAssetNo;
		protected System.Web.UI.WebControls.TextBox TbxParentAssetNo;
		protected System.Web.UI.WebControls.TextBox TbxOldBarcode;
		protected System.Web.UI.WebControls.TextBox TbxModelNumber;
		protected System.Web.UI.WebControls.TextBox TbxSerialNumber;
		protected System.Web.UI.WebControls.TextBox TbxManufacturer;
		protected System.Web.UI.WebControls.TextBox TbxEmpNo;
		protected System.Web.UI.WebControls.TextBox TbxCPUSpeed;
		protected System.Web.UI.WebControls.TextBox TbxTotalMemory;
		protected System.Web.UI.WebControls.TextBox TbxHardDiskSize;
		protected System.Web.UI.WebControls.TextBox TbxNodeName;
		protected System.Web.UI.WebControls.TextBox TbxServerName;
		protected System.Web.UI.WebControls.TextBox TbxMACAddress_1st;
		protected System.Web.UI.WebControls.TextBox TbxMACAddress_2nd;
		protected System.Web.UI.WebControls.TextBox TbxPhyInventoryDate;
		protected System.Web.UI.WebControls.TextBox TbxDateInstalled;
		protected System.Web.UI.WebControls.TextBox TbxDateReceived;
		protected System.Web.UI.WebControls.TextBox TbxTypeDesc;
		protected System.Web.UI.WebControls.TextBox TbxDisposedDate;
		protected System.Web.UI.WebControls.TextBox TbxComments;
		protected System.Web.UI.WebControls.TextBox TbxCreateID;
		protected System.Web.UI.WebControls.TextBox TbxCreateDate;
		protected System.Web.UI.WebControls.TextBox TbxUpdateID;
		protected System.Web.UI.WebControls.TextBox TbxUpdateDate;
		protected System.Web.UI.WebControls.Button BtnSave;
		protected System.Web.UI.WebControls.DropDownList DdnlCompStatus;
		protected System.Web.UI.WebControls.DropDownList DdnlClassID;
		protected System.Web.UI.WebControls.DropDownList DdnlDeptCode;
		protected System.Web.UI.WebControls.DropDownList DdnlSiteCode;
		protected System.Web.UI.WebControls.DropDownList DdnlCPUType;
		protected System.Web.UI.WebControls.DropDownList DdnlOPSystem;
		protected System.Web.UI.WebControls.DropDownList DdnlSystemID;
		protected System.Web.UI.WebControls.ImageButton IbtnSearchModel;
		protected System.Web.UI.WebControls.ImageButton IbtnSearchEmp;
		protected System.Web.UI.WebControls.TextBox TbxEmpName;
		protected System.Web.UI.WebControls.TextBox TbxFloorID;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected System.Web.UI.WebControls.Button BtnCancel;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos(true);

			SetValidator();
			
			NavigationHelper.SetPopupWindow(
				this.IbtnSearchModel,
				"../Code/SelectModelList.aspx",
				"SearchModel",
				1000, 400,
				false
			);

			NavigationHelper.SetPopupWindow(
				this.IbtnSearchEmp,
				"../Emp/SearchEmp.aspx",
				"SearchModel",
				600, 400,
				true
				);

			ScriptHelper.SetConfirmMessageOn( this.BtnSave, MessageManager.GetMessage("Common", "REGISTER_QUESTION" ) );
			NavigationHelper.SetHistoryBack( this.BtnCancel );

			if ( !this.IsPostBack )
			{
				InitialContorls();
			}
			if( this.IsSubmittedBy )
			{
				SetControls();
			}
		}

		private void SetValidator()
		{
			XjosHelper.SetValidator (this.TbxAssetNo,
				new XjosValidator (XjosValidatorType.Required),
				new XjosValidator (XjosValidatorType.Minlength, "8", "8�ڸ� �̻��Դϴ�.")
				//new XjosValidator (XjosValidatorType.Numeric)
				);
			this.TbxAssetNo.MaxLength = 8;
			XjosHelper.SetValidator (this.TbxParentAssetNo,
				new XjosValidator (XjosValidatorType.Minlength, "8", "8�ڸ��ϴ�.")
				//new XjosValidator (XjosValidatorType.Numeric)
				);
			this.TbxParentAssetNo.MaxLength = 8;

			XjosHelper.SetValidator (this.TbxPhyInventoryDate, new XjosValidator (XjosValidatorType.Date) );
			XjosHelper.SetValidator (this.TbxDateInstalled, new XjosValidator (XjosValidatorType.Date) );
			XjosHelper.SetValidator (this.TbxDateReceived, new XjosValidator (XjosValidatorType.Date) );
			XjosHelper.SetValidator (this.TbxDisposedDate, new XjosValidator (XjosValidatorType.Date) );
			XjosHelper.SetValidator (this.TbxCreateDate, new XjosValidator (XjosValidatorType.Date) );
			XjosHelper.SetValidator (this.TbxUpdateDate, new XjosValidator (XjosValidatorType.Date) );

			XjosHelper.ValidateOnClick (
				this.BtnSave,
				MessageManager.GetMessage("Common", "REGISTER_QUESTION")
				) ;
		}

		private void InitialContorls()
		{
			LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea );
			string Area = this.DdnlArea.SelectedValue;
			LGCNS.SITE.Common.WebUI.DeptInfo.BindDropDownList( this.DdnlDeptCode, Area );
			LGCNS.SITE.Common.WebUI.SiteInfo.BindDropDownList( this.DdnlSiteCode, Area );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlCompStatus, "COMP_STATUS", false );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlClassID, "CLASS_ID", false );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlCPUType, "CPU_TYPE", false );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlOPSystem, "OP_SYSTEM", false );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlSystemID, "SYSTEM_ID", false );

			this.TbxPhyInventoryDate.Text = DateTime.Now.ToShortDateString();
			this.TbxDateInstalled.Text = DateTime.Now.ToShortDateString();
			this.TbxDateReceived.Text = DateTime.Now.ToShortDateString();

			this.TbxCreateID.Text = this.CurrentUserName;
			this.TbxCreateDate.Text = DateTime.Now.ToShortDateString();
			this.TbxUpdateID.Text = this.CurrentUserName;
			this.TbxUpdateDate.Text = DateTime.Now.ToShortDateString();
		}

		private void SetControls()
		{
			LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea );
			this.DdnlArea.SelectedValue = this.Request["DdnlArea"];
			string Area = this.DdnlArea.SelectedValue;
			LGCNS.SITE.Common.WebUI.DeptInfo.BindDropDownList( this.DdnlDeptCode, Area );
			LGCNS.SITE.Common.WebUI.SiteInfo.BindDropDownList( this.DdnlSiteCode, Area );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlCompStatus, "COMP_STATUS", false );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlClassID, "CLASS_ID", false );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlCPUType, "CPU_TYPE", false );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlOPSystem, "OP_SYSTEM", false );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlSystemID, "SYSTEM_ID", false );

			this.TbxAssetNo.Text = this.Request["TbxAssetNo"];
			
			this.TbxParentAssetNo.Text = this.Request["TbxParentAssetNo"];
			this.TbxOldBarcode.Text = this.Request["TbxOldBarcode"];
			this.TbxModelNumber.Text = this.Request["TbxModelNumber"];
			this.TbxSerialNumber.Text = this.Request["TbxSerialNumber"];
			this.TbxManufacturer.Text = this.Request["TbxManufacturer"];
			this.DdnlCompStatus.SelectedValue = this.Request["DdnlCompStatus"];
			this.DdnlClassID.SelectedValue = this.Request["DdnlClassID"];
			this.TbxEmpNo.Text = this.Request["TbxEmpNo"];
			this.DdnlDeptCode.SelectedValue = this.Request["DdnlDeptCode"];
			this.DdnlSiteCode.SelectedValue = this.Request["DdnlSiteCode"];
			this.TbxFloorID.Text = this.Request["TbxFloorID"];
			this.DdnlCPUType.SelectedValue = this.Request["DdnlCPUType"];
			this.TbxCPUSpeed.Text = this.Request["TbxCPUSpeed"];
			this.DdnlOPSystem.SelectedValue = this.Request["DdnlOPSystem"];
			this.TbxTotalMemory.Text = this.Request["TbxTotalMemory"];
			this.TbxHardDiskSize.Text = this.Request["TbxHardDiskSize"];
			this.TbxNodeName.Text = this.Request["TbxNodeName"];
			this.TbxServerName.Text = this.Request["TbxServerName"];
			this.TbxMACAddress_1st.Text = this.Request["TbxMACAddress_1st"];
			this.TbxMACAddress_2nd.Text = this.Request["TbxMACAddress_2nd"];
			this.DdnlSystemID.SelectedValue = this.Request["DdnlSystemID"];
			this.TbxTypeDesc.Text = this.Request["TbxTypeDesc"];
			this.TbxDisposedDate.Text = this.Request["TbxDisposedDate"];
			this.TbxComments.Text = this.Request["TbxComments"];

			this.TbxPhyInventoryDate.Text = DateTime.Now.ToShortDateString();
			this.TbxDateInstalled.Text = DateTime.Now.ToShortDateString();
			this.TbxDateReceived.Text = DateTime.Now.ToShortDateString();

			this.TbxCreateID.Text = this.CurrentUserName;
			this.TbxCreateDate.Text = DateTime.Now.ToShortDateString();
			this.TbxUpdateID.Text = this.CurrentUserName;
			this.TbxUpdateDate.Text = DateTime.Now.ToShortDateString();
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
            this.DdnlArea.SelectedIndexChanged += new System.EventHandler(this.DdnlArea_SelectedIndexChanged);
            this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
            this.Load += new System.EventHandler(this.Page_Load);

        }
		#endregion

		private void BtnSave_Click(object sender, System.EventArgs e)
		{
			SaveAsset();
		}

		private void SaveAsset()
		{
			AssetDS ds = new AssetDS();
			AssetDS.TB_ASSETRow dr = ds.TB_ASSET.NewTB_ASSETRow();

			dr.AssetNo = this.TbxAssetNo.Text;
			dr.ParentAssetNo = this.TbxParentAssetNo.Text;
			dr.OldBarcode = this.TbxOldBarcode.Text;
			dr.ModelNumber = this.TbxModelNumber.Text;
			dr.SerialNumber = this.TbxSerialNumber.Text;
			dr.Manufacturer = this.TbxManufacturer.Text;
			dr.CompStatus = this.DdnlCompStatus.SelectedValue;
			dr.ClassID = this.DdnlClassID.SelectedValue;
			dr.EmpNo = this.TbxEmpNo.Text;
			dr.DeptCode = this.DdnlDeptCode.SelectedValue;
			dr.SiteCode = this.DdnlSiteCode.SelectedValue;
			dr.FloorID = this.TbxFloorID.Text;
			dr.CPUType = this.DdnlCPUType.SelectedValue;
			dr.CPUSpeed = this.TbxCPUSpeed.Text;
			dr.OPSystem = this.DdnlOPSystem.SelectedValue;
			dr.TotalMemory = this.TbxTotalMemory.Text;
			dr.HardDiskSize = this.TbxHardDiskSize.Text;
			dr.NodeName = this.TbxNodeName.Text;
			dr.ServerName = this.TbxServerName.Text;
			dr.MACAddress_1st = this.TbxMACAddress_1st.Text;
			dr.MACAddress_2nd = this.TbxMACAddress_2nd.Text;
			dr.PhyInventoryDate = DateTime.Parse( this.TbxPhyInventoryDate.Text );
			dr.DateInstalled = DateTime.Parse( this.TbxDateInstalled.Text );
			dr.DateReceived = DateTime.Parse( this.TbxDateReceived.Text );
			dr.SystemID = this.DdnlSystemID.SelectedValue;
			dr.TypeDesc = this.TbxTypeDesc.Text;
			if ( this.TbxDisposedDate.Text.Length > 0 )
			{
				dr.DisposedDate = DateTime.Parse( this.TbxDisposedDate.Text );
			}
			else
			{
				if ( this.DdnlCompStatus.SelectedValue == "DISP" )
				{
					dr.DisposedDate = DateTime.Now;
				}
			}

			dr.Comments = this.TbxComments.Text;

			dr.TicketNo = "ZZZZZZ";
			dr.CreateID = this.CurrentUserID;
			dr.UpdateID = this.CurrentUserID;
			dr.CreateDate = DateTime.Now;
			dr.UpdateDate = DateTime.Now;
			dr.Area = this.DdnlArea.SelectedValue;
		
			ds.TB_ASSET.AddTB_ASSETRow( dr );

			AssetController.InsertAsset( ds );

			NavigationHelper.Redirect( 
				MessageManager.GetMessage("Common", "REGISTER_DONE"),
				"",
				"SelectAsset.aspx?AssetNo=" + this.TbxAssetNo.Text
			);
		}

		private void DdnlArea_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			string Area = this.DdnlArea.SelectedValue;
			LGCNS.SITE.Common.WebUI.DeptInfo.BindDropDownList( this.DdnlDeptCode, Area );
			LGCNS.SITE.Common.WebUI.SiteInfo.BindDropDownList( this.DdnlSiteCode, Area );
			this.TbxEmpNo.Text = "";
			this.TbxEmpName.Text = "";
		}

	}
}