using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Paging;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Asset
{
	/// <summary>
	/// SelectAssetList�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectAssetList : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxAssetNo;
		protected System.Web.UI.WebControls.TextBox TbxEmpNo;
		protected System.Web.UI.WebControls.TextBox TbxEmpName;

		protected System.Web.UI.WebControls.DropDownList DdnlDeptCode;
		protected System.Web.UI.WebControls.DropDownList DdnlSiteCode;

		protected System.Web.UI.WebControls.TextBox TbxPageSize;
		protected System.Web.UI.WebControls.Label LblTotalCount;
		protected System.Web.UI.WebControls.DropDownList DdlPage;
		protected System.Web.UI.WebControls.Label LblTotalPages;

		protected System.Web.UI.WebControls.Button BtnSearch;
		protected System.Web.UI.WebControls.Button BtnClear;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected System.Web.UI.WebControls.TextBox TbxSerialNo;
		protected System.Web.UI.WebControls.Button BtnSaveExcelForIES;
		protected System.Web.UI.WebControls.Button BtnSaveExcel;
		protected System.Web.UI.WebControls.DropDownList DdnlStatusCode;
		protected System.Web.UI.WebControls.TextBox TbxCreateDateTo;
		protected System.Web.UI.WebControls.TextBox TbxCreateDateFrom;
		protected System.Web.UI.WebControls.DropDownList DdnlCPUType;
		protected System.Web.UI.WebControls.TextBox TbxModelNo;
		protected System.Web.UI.WebControls.TextBox TbxNodeName;
		
		
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos (true) ;

			NavigationHelper.RegisterHiddenIFrame ("HiddenFrame") ;
			NavigationHelper.RegisterHiddenIFrame ("HiddenFrame2") ;
			NavigationHelper.SetNavigation (this.BtnSaveExcel, "HiddenFrame", "SelectAssetListAsXls.aspx", true) ;
			NavigationHelper.SetNavigation (this.BtnSaveExcelForIES, "HiddenFrame2", "SelectAssetListAsXls2.aspx", true) ;

			this.DgrdDataGrid.NavigateOnRowClick (
				"", // �̵��� �����Ӹ�, ��������ü�� �̵��Ҷ� ""�� �����Ѵ�.
				"SelectAsset.aspx", // LinkŬ���� �̵��� Url  (����ȸȭ��)
				new string [1] {"AssetNo"},  // LinkŬ���� ������ Query String �� key�� �迭
				new int [1] {0}, // LinkŬ���� ������ Query String �� value���� ������ Cell Index�� �迭
				false  // // ������������ ���� SelectTicket.aspx ���� submit��Ų��. (POST������� ȣ���Ѵ�.)
				) ;

			SetValidator();

			if ( !Page.IsPostBack )
			{
				InitializeControls();
				//SearchAssetListPaging();
			}

			if ( this.IsSubmittedBy )
			{
				InitializeControls();
				//SearchAssetListPaging();
			}
		}

		private void SetValidator()
		{
			XjosHelper.SetValidator (this.TbxCreateDateFrom,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);
			XjosHelper.SetValidator (this.TbxCreateDateTo,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);
			XjosHelper.ValidateOnClick(this.BtnSearch); // Xjos Validation�� ������ ��ư ����
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
            this.DdnlArea.SelectedIndexChanged += new System.EventHandler(this.DdnlArea_SelectedIndexChanged);
            this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            this.Load += new System.EventHandler(this.Page_Load);

        }
		#endregion

		private void InitializeControls()
		{
			InitializeControls( false );
		}

		private void InitializeControls( bool isClear )
		{
			this.TbxAssetNo.Text = "";
			this.TbxEmpNo.Text = "";
			this.TbxEmpName.Text = "";

			LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea, true );
			string Area = this.DdnlArea.SelectedValue;
			LGCNS.SITE.Common.WebUI.DeptInfo.BindDropDownList( this.DdnlDeptCode, Area, true );
			LGCNS.SITE.Common.WebUI.SiteInfo.BindDropDownList( this.DdnlSiteCode, Area, true );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlStatusCode, "COMP_STATUS", true );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlCPUType, "CPU_TYPE", true );

			AssetDS ds = new AssetDS();
			this.DgrdDataGrid.ShowFooterMessage = true;
			this.DgrdDataGrid.FooterMessage = MessageManager.GetMessage( "Common", "NO_DATA" );
			this.DgrdDataGrid.DataSource = ds.TB_ASSET;
			this.DgrdDataGrid.DataBind();

			this.TbxCreateDateFrom.Text = "";
			this.TbxCreateDateTo.Text = "";

			this.LblTotalCount.Text = "0";
			this.LblTotalPages.Text = "1";
		}


		private void BtnClear_Click(object sender, System.EventArgs e)
		{
			InitializeControls( true );
		}

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			SearchAssetListPaging();
		}

		private void SearchAssetListPaging()
		{
			NameValueCollection searchCondition = new NameValueCollection();
			searchCondition["Area"] = this.DdnlArea.SelectedValue;
			searchCondition["AssetNo"] = this.TbxAssetNo.Text;
			searchCondition["EmpNo"] = this.TbxEmpNo.Text;
			searchCondition["EmpName"] = this.TbxEmpName.Text;
			searchCondition["DeptCode"] = this.DdnlDeptCode.SelectedValue;
			searchCondition["SiteCode"] = this.DdnlSiteCode.SelectedValue;
			searchCondition["CreateDateFrom"] = this.TbxCreateDateFrom.Text;
			searchCondition["CreateDateTo"] = this.TbxCreateDateTo.Text;
			searchCondition["SerialNo"] = this.TbxSerialNo.Text;
			searchCondition["Status"] = this.DdnlStatusCode.SelectedValue;
			searchCondition["CPUType"] = this.DdnlCPUType.SelectedValue;
			searchCondition["ModelNo"] = this.TbxModelNo.Text;
			searchCondition["NodeName"] = this.TbxNodeName.Text;
			

			int currentPage = Convert.ToInt32(this.DdlPage.SelectedValue);
			int pageSize	= Convert.ToInt32(this.TbxPageSize.Text);

			string order = "";

			AssetDS ds = AssetController.SelectAssetList( currentPage, pageSize, order, searchCondition );
			this.DgrdDataGrid.VirtualItemCount = 100 ;
			this.DgrdDataGrid.DataSource = ds.TB_ASSET;
			this.DgrdDataGrid.DataBind() ;

			//��Ͽ� ���� ����
			int totalPage			= PagingHelper.GetTotalPage (ds) ;
			this.LblTotalCount.Text = PagingHelper.GetTotalCount (ds).ToString () ;
			this.LblTotalPages.Text = totalPage.ToString() ;

			//Page DropDownList Setting
			this.DdlPage.Items.Clear();
			for(int i = 1; i <= totalPage ; i++)
			{
				this.DdlPage.Items.Add(i.ToString());
			}

			//�������� ������ ���õǵ���
			if(this.DdlPage.Items.Count > 0)
			{
				if( currentPage <= totalPage )
				{
					this.DdlPage.Items[currentPage - 1].Selected = true;
				}
				else
				{
					this.DdlPage.Items[0].Selected = true;
				}
			}
		}

		private void DdnlArea_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			string Area = this.DdnlArea.SelectedValue;
			LGCNS.SITE.Common.WebUI.DeptInfo.BindDropDownList( this.DdnlDeptCode, Area, true );
			LGCNS.SITE.Common.WebUI.SiteInfo.BindDropDownList( this.DdnlSiteCode, Area, true );
		}

	}
}
