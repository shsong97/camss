using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Mail;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

namespace LGCNS.SITE.WebUI.User
{
	/// <summary>
	/// MailSample�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SendMail : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Button BtnSend;
		protected System.Web.UI.WebControls.TextBox TbxFrom;
		protected System.Web.UI.WebControls.TextBox TbxTo;
		protected System.Web.UI.WebControls.TextBox TbxSubject;
		protected System.Web.UI.WebControls.TextBox TbxSMTP;
		protected System.Web.UI.WebControls.TextBox TbxBody;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			if ( this.IsSubmittedBy )
			{
				this.TbxSMTP.Text = LGCNS.LAF.Common.ConfigurationManagement.LConfigurationManager.GetConfigValue("SMTP_SERVER");
				this.TbxFrom.Text = this.CurrentUserEmail;
				this.TbxTo.Text = this.Request["Email"];
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSend.Click += new System.EventHandler(this.Button1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			MailMessage mailMsg = new MailMessage();
			mailMsg.From = TbxFrom.Text.Trim();
			mailMsg.To = TbxTo.Text.Trim();
			mailMsg.Subject = TbxSubject.Text.Trim();
			mailMsg.Body = TbxBody.Text.Trim();

			SmtpMail.SmtpServer = this.TbxSMTP.Text;
			SmtpMail.Send(mailMsg);

			ScriptHelper.ShowAlert(MessageManager.GetMessage("Common", "SEND_DONE"));
		}
	}
}
