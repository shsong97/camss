using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.Exceptions ;
using LGCNS.LAF.Common.FileManagement;

using LGCNS.SITE.DTO;
using LGCNS.SITE.User.Biz;

namespace LGCNS.SITE.WebUI.User
{
	/// <summary>
	/// UserController�� ���� ��� �����Դϴ�.
	/// </summary>
	public class UserController : ControllerBase
	{
		public UserController() {}
		
		public static string getUserArea( UserDS.TB_USERRow dr )
		{
			string Area = "";
			if ( dr.IsAreaNull() )
			{
				Area = "";
			}
			else
			{
				Area = dr.Area.Trim();
			}

			return Area;
		}

		/// <summary>
		/// ����� ����� �����´�.
		/// </summary>
		/// <param name="currentPage"></param>
		/// <param name="pageSize"></param>
		/// <param name="userName"></param>
		/// <returns></returns>
		public static UserDS SelectUserList (int currentPage, int pageSize, string userName, string Authority)
		{
			return SelectUserList (currentPage, pageSize, null, "", userName, Authority) ;
		}

		/// <summary>
		/// ����� ����� �����´�.
		/// </summary>
		/// <param name="currentPage"></param>
		/// <param name="pageSize"></param>
		/// <param name="order"></param>
		/// <param name="userName"></param>
		/// <returns></returns>
		public static UserDS SelectUserList (int currentPage, int pageSize, string order, string Area, string userName, string Authority)
		{
			UserDS ds = null;
			UserBizNTx biz = null;
			
			try
			{
				biz = new UserBizNTx();
				ds = biz.SelectUserList(currentPage, pageSize, order, Area, userName, Authority);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}

		/// <summary>
		/// ��������θ� ��ȸ�Ѵ�.
		/// </summary>
		/// <param name="userID"></param>
		/// <returns></returns>
		public static UserDS SelectUser(string userID)
		{
			UserDS ds = null;
			UserBizNTx biz = null;
			
			try
			{
				biz = new UserBizNTx();
				ds = biz.SelectUser(userID);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}

		/// <summary>
		/// ������� ��ȣ�� ��ȸ�Ѵ�.
		/// </summary>
		/// <param name="userID"></param>
		/// <returns></returns>
		public static string SelectUserPassword (string userID)
		{
			string userPassword = null ;

			UserBizNTx biz = null;
			
			try
			{
				biz = new UserBizNTx();
				
				userPassword = biz.SelectUserPassword(userID);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return userPassword ;
		}

		/// <summary>
		/// ����������� ����Ѵ�.
		/// </summary>
		/// <param name="ds"></param>
		public static void InsertUser (UserDS ds)
		{
			UserBizTx biz = null;
			
			try
			{
				biz = new UserBizTx () ;
				biz.InsertUser(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}

		/// <summary>
		/// ����������� �����Ѵ�.
		/// </summary>
		/// <param name="ds"></param>
		public static void UpdateUser (UserDS ds)
		{
			UserBizTx biz = null;
			
			try
			{
				biz = new UserBizTx () ;
				biz.UpdateUser(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}

		/// <summary>
		/// ����ڸ� �����Ѵ�.
		/// </summary>
		/// <param name="userID"></param>
		public static void DeleteUser (string userID)
		{
			UserBizTx biz = null;
			
			try
			{
				biz = new UserBizTx () ;
				biz.DeleteUser(userID);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
	}
}
