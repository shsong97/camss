 using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.Paging ;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.User
{
	/// <summary>
	/// SelectUserList�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectUserList : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Button BtnSearchPaging;
		protected System.Web.UI.WebControls.DropDownList DdlOrderBy;
		protected System.Web.UI.WebControls.DropDownList DdlOrderByColumn;
		protected LGCNS.LAF.Web.Controls.LDataGrid LDataGrid1;
		protected System.Web.UI.WebControls.Button BtnInsert;
		protected System.Web.UI.WebControls.DropDownList DdnlAuthority;
		protected System.Web.UI.WebControls.TextBox TbxUserName;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

            XjosHelper.RegisterXjos(true);

            this.LDataGrid1.NavigateOnRowClick(
                "",
                "SelectUser.aspx",
                new string[1] { "UserID" },
                new int[1] { 0 },
                false // GET������� �̵��Ѵ�.
                );


            if (!IsPostBack)
			{
				LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( DdnlAuthority, "AUTHORITY",true );
				this.SearchUserListPaging();
			}


			NavigationHelper.SetNavigation( this.BtnInsert, "", "InsertUser.aspx", false );
			
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSearchPaging.Click += new System.EventHandler(this.BtnSearchPaging_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BtnSearchPaging_Click(object sender, System.EventArgs e)
		{
			this.SearchUserListPaging();
		}

		private void SearchUserListPaging()
		{
			//Paging ���ǰ�
			int currentPage = 0; //Convert.ToInt32(this.DdlPage.SelectedValue);
			int pageSize	= 0; //Convert.ToInt32(this.TbxPageSize.Text);
			string order	= this.DdlOrderByColumn.SelectedValue + " " + this.DdlOrderBy.SelectedValue ;
			int index=DdnlAuthority.SelectedIndex;
			if( index<0 )
				index=0;
			UserDS ds=null;
			if(DdnlAuthority.Items.Count>0)
				ds = UserController.SelectUserList (currentPage, pageSize, order, "", this.TbxUserName.Text,DdnlAuthority.SelectedValue) ;
			else
				ds = UserController.SelectUserList (currentPage, pageSize, order, "", this.TbxUserName.Text,"") ;

			this.LDataGrid1.DataSource = ds.TB_USER ;
			this.LDataGrid1.DataBind () ;

//			//��Ͽ� ���� ����
//			int totalPage			= PagingHelper.GetTotalPage (ds) ;
//			this.LblTotalCount.Text = PagingHelper.GetTotalCount (ds).ToString () ;
//			this.LblTotalPages.Text = totalPage.ToString();
//
//			//Page DropDownList Setting
//			this.DdlPage.Items.Clear();
//			for(int i = 1; i <= totalPage; i++)
//			{
//				this.DdlPage.Items.Add(i.ToString());
//			}
//
//			//�������� ������ ���õǵ���
//			if(this.DdlPage.Items.Count > 0)
//			{
//				if( currentPage < totalPage )
//				{
//					this.DdlPage.Items[currentPage - 1].Selected = true;
//				}
//				else
//				{
//					this.DdlPage.Items[0].Selected = true;
//				}
//			}
		}


	}
}
