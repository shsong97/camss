using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.User
{
	/// <summary>
	/// UpdateUser�� ���� ��� �����Դϴ�.
	/// </summary>
	public class UpdateUser : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Label LblUserID;
		protected System.Web.UI.WebControls.TextBox TbxUserName;
		protected System.Web.UI.WebControls.TextBox TbxUserNameEng;
		protected System.Web.UI.WebControls.TextBox TbxUserPassword;
		protected System.Web.UI.WebControls.TextBox TbxEmail;
		protected System.Web.UI.WebControls.TextBox TbxContactNo;
		protected System.Web.UI.WebControls.DropDownList DdnlAuthority;
		protected System.Web.UI.WebControls.DropDownList DdnlAlterUser;

		protected System.Web.UI.WebControls.Button BtnUpdate;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected System.Web.UI.WebControls.Button BtnCancel;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos (true) ;
			XjosHelper.SetValidator (TbxUserName,
				new XjosValidator (XjosValidatorType.Required)
				) ;
			XjosHelper.SetValidator (TbxUserNameEng,
				new XjosValidator (XjosValidatorType.Required)
				) ;
			XjosHelper.SetValidator (TbxEmail,
				new XjosValidator (XjosValidatorType.Required),
				new XjosValidator (XjosValidatorType.Email)
				) ;
			XjosHelper.SetValidator (TbxUserPassword,
				new XjosValidator (XjosValidatorType.Required),
				new XjosValidator (XjosValidatorType.Minlength, "4"),
				new XjosValidator (XjosValidatorType.Alpha_Numeric)
				) ;
			XjosHelper.SetValidator (TbxContactNo,
				new XjosValidator (XjosValidatorType.Required)
				) ;
			XjosHelper.ValidateOnClick (
				this.BtnUpdate, 
				MessageManager.GetMessage("Common", "UPDATE_QUESTION")
				) ;

			NavigationHelper.SetHistoryBack (this.BtnCancel) ;

			if ( this.IsSubmittedBy )
			{
				InitialControls();
				InqueryUserInfo( Request["UserID"] );
			}

			CheckAuthority();
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnUpdate.Click += new System.EventHandler(this.BtnUpdate_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void InitialControls()
		{
			LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea, true );
			this.DdnlArea.Enabled = true;
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( DdnlAuthority, "AUTHORITY" );
			LGCNS.SITE.Common.WebUI.UserInfo.BindDropDownList( this.DdnlAlterUser );
		}

		private void InqueryUserInfo( string UserID )
		{
			UserDS ds = UserController.SelectUser ( UserID );
			UserDS.TB_USERRow dr = ds.TB_USER[0];

			this.LblUserID.Text			= dr.UserID;
			this.TbxUserName.Text		= dr.UserName;
			this.TbxUserPassword.Text	= dr.UserPassword;
			this.TbxEmail.Text			= dr.Email;
			this.TbxUserNameEng.Text	= dr.UserNameEng;
			this.TbxContactNo.Text		= dr.ContactNo;
			this.DdnlAuthority.SelectedValue = dr.Authority;
			this.DdnlAlterUser.SelectedValue = dr.AlterUserID;

			this.DdnlArea.SelectedValue = UserController.getUserArea( dr );

		}

		private void CheckAuthority()
		{
			if ( this.CurrentUserAuthority.CompareTo("A") > 0 )
			{
				this.DdnlAuthority.Enabled = false;
				this.DdnlAlterUser.Enabled = false;
				this.DdnlArea.Enabled = false;
			}
		}

		private void BtnUpdate_Click(object sender, System.EventArgs e)
		{
			//������û
			UserController.UpdateUser( dsUser() );

			//������ �̵�
			NavigationHelper.Redirect(MessageManager.GetMessage("Common", "UPDATE_DONE"), "SelectUser.aspx?UserID=" + this.LblUserID.Text );
		}

		private UserDS dsUser()
		{
			UserDS ds = new UserDS();
			UserDS.TB_USERRow row = ds.TB_USER.NewTB_USERRow();

			row.UserID = this.LblUserID.Text;
			row.UserPassword = this.TbxUserPassword.Text;
			row.UserName = this.TbxUserName.Text;
			row.Email = this.TbxEmail.Text;
			row.UserNameEng = this.TbxUserNameEng.Text.Trim();
			row.ContactNo = this.TbxContactNo.Text.Trim();
			row.Authority = this.DdnlAuthority.SelectedValue;
			row.AlterUserID = this.DdnlAlterUser.SelectedValue;
			row.Area = this.DdnlArea.SelectedValue;

			ds.TB_USER.AddTB_USERRow(row);

			return ds;
		}
	}
}
