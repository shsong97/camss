using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.Paging;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Code
{
	/// <summary>
	/// ManageProgram�� ���� ��� �����Դϴ�.
	/// </summary>
	public class ManageProgram : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Button BtnSearch;
		protected System.Web.UI.WebControls.Button BtnInsert;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
		protected System.Web.UI.WebControls.Label Message;
		protected System.Web.UI.WebControls.DropDownList DdnlProgramClass;

		bool isEditing = false;

		// property to keep track of whether we are adding a new record,
		// and save it in viewstate between postbacks
		protected bool AddingNew 
		{
			get 
			{
				object o = ViewState["AddingNew"];
				return (o == null) ? false : (bool)o;
			}
			set 
			{
				ViewState["AddingNew"] = value;
			}
		}
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos(true);

			if( !this.IsPostBack ) 
			{ 
				BindProgramClass();
				BindGrid(); 
			}
			if( this.IsSubmittedBy ) 
			{ 
				BindProgramClass();
				BindGrid(); 
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DdnlProgramClass.SelectedIndexChanged += new System.EventHandler(this.DdnlProgramClass_SelectedIndexChanged);
			this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
			this.BtnInsert.Click += new System.EventHandler(this.BtnInsert_Click);
			this.DgrdDataGrid.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdDataGrid_EditCommand);
			this.DgrdDataGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.DgrdDataGrid_PageIndexChanged);
			this.DgrdDataGrid.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdDataGrid_CancelCommand);
			this.DgrdDataGrid.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdDataGrid_UpdateCommand);
			this.DgrdDataGrid.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdDataGrid_DeleteCommand);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BindProgramClass()
		{
			ProgramDS ds = ProgramController.SelectProgramClass();
			this.DdnlProgramClass.DataSource = ds.TB_PROGRAM_CLASS;
			this.DdnlProgramClass.DataValueField = "ProgramClass";
			this.DdnlProgramClass.DataTextField = "ProgramClassDesc";
			this.DdnlProgramClass.DataBind();
		}

		void CheckIsEditing(string commandName) 
		{

			if (DgrdDataGrid.EditItemIndex != -1) 
			{

				// we are currently editing a row
				if (commandName != "Cancel" && commandName != "Update") 
				{

					// user's edit changes (if any) will not be committed
					Message.Text = "Your changes have not been saved yet.  Please press update to save your changes, or cancel to discard your changes, before selecting another item.";
					isEditing = true;
				}
			}
		}

		private void BindGrid()
		{
			ProgramDS ds = ProgramController.SelectProgramList( 0 , 0, this.DdnlProgramClass.SelectedValue );

			this.DgrdDataGrid.DataSource = ds.TB_PROGRAM;
			this.DgrdDataGrid.DataBind();
		}

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			this.DgrdDataGrid.CurrentPageIndex = 0;
			this.DgrdDataGrid.EditItemIndex = -1;
			BindGrid();
		}

		private void BtnInsert_Click(object sender, System.EventArgs e)
		{
			// add a new row to the end of the data, and set editing mode 'on'

			CheckIsEditing("");

			if (!isEditing) 
			{
				// set the flag so we know to do an insert at Update time
				AddingNew = true;

				// add new row to the end of the dataset after binding

				// first get the data
				ProgramDS ds = ProgramController.SelectProgramList( 0, 0, this.DdnlProgramClass.SelectedValue );
				ds.EnforceConstraints = false;

				// add a new blank row to the end of the data
				ds.TB_PROGRAM.AddTB_PROGRAMRow( this.DdnlProgramClass.SelectedValue, "", "", ds.TB_PROGRAM.Rows.Count + 1, "", "" );

				// figure out the EditItemIndex, last record on last page
				int recordCount = ds.TB_PROGRAM.Rows.Count;
				//if (recordCount > 1)
					recordCount--;
//				DgrdDataGrid.CurrentPageIndex = recordCount/DgrdDataGrid.PageSize;
//				DgrdDataGrid.EditItemIndex = recordCount%DgrdDataGrid.PageSize;

				DgrdDataGrid.EditItemIndex = recordCount;

				// databind
				DgrdDataGrid.DataSource = ds.TB_PROGRAM;
				DgrdDataGrid.DataBind();
			}
		}


		private void DgrdDataGrid_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			// display a new page of data

			if (!isEditing) 
			{
				DgrdDataGrid.EditItemIndex = -1;
				DgrdDataGrid.CurrentPageIndex = e.NewPageIndex;
				BindGrid();
			}

		}

		private void DgrdDataGrid_EditCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			if ( !isEditing )
			{
				this.DgrdDataGrid.EditItemIndex = e.Item.ItemIndex;
				
				BindGrid();
			}
		}

		private void DgrdDataGrid_CancelCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			// cancel editing

			DgrdDataGrid.EditItemIndex = -1;
			BindGrid();

			AddingNew = false;

		}

		private void DgrdDataGrid_UpdateCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			ProgramDS ds = new ProgramDS();
			ds.TB_PROGRAM.AddTB_PROGRAMRow(
				((TextBox)e.Item.Cells[1].Controls[1]).Text,
				((TextBox)e.Item.Cells[2].Controls[1]).Text,
				((TextBox)e.Item.Cells[3].Controls[1]).Text,
				int.Parse( ((TextBox)e.Item.Cells[4].Controls[1]).Text ),
				((DropDownList)e.Item.Cells[5].Controls[1]).SelectedValue,
				((TextBox)e.Item.Cells[6].Controls[1]).Text
				);

			if (AddingNew)
			{
				//Insert
				ProgramController.InsertProgram( ds );
			}
			else
			{
				//Update
				ProgramController.UpdateProgram( ds );
			}

			if (AddingNew) 
			{

				DgrdDataGrid.CurrentPageIndex = 0;
				AddingNew = false;
			}

			// rebind the grid
			DgrdDataGrid.EditItemIndex = -1;
			BindGrid();

		}

		private void DgrdDataGrid_DeleteCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			// delete the selected row
			if (!isEditing) 
			{
				//Delete
				ProgramController.DeleteProgram( 
					((Label)DgrdDataGrid.Items[e.Item.ItemIndex].Cells[1].Controls[1]).Text,
					((Label)DgrdDataGrid.Items[e.Item.ItemIndex].Cells[2].Controls[1]).Text
					);

				// rebind the grid
				DgrdDataGrid.CurrentPageIndex = 0;
				DgrdDataGrid.EditItemIndex = -1;
				BindGrid();
			}

		}

		private void DdnlProgramClass_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			BtnSearch_Click( sender, e );
		}

		public DataTable BindCodeList( string ClassID )
		{
			CodeDS ds = CodeController.SelectCodeList( ClassID );
			return ds.TB_CODE;
		}

		public int GetStateIndex( string ClassID, string Code )
		{
			CodeDS ds = CodeController.SelectCodeList( ClassID );
 
			for ( int i = 0; i < ds.TB_CODE.Count; i++)
			{
				CodeDS.TB_CODERow dr = ds.TB_CODE[i];

				if ( dr.Code.ToString() == Code.Trim() )
				{
					return i;
				}
			}

			return 0;
		}

		
	}
}
