using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.Exceptions ;

using LGCNS.SITE.DTO;
using LGCNS.SITE.Code;
using LGCNS.SITE.Code.Biz;

namespace LGCNS.SITE.WebUI.Code
{
	/// <summary>
	/// MenuController�� ���� ��� �����Դϴ�.
	/// </summary>
	public class MenuController : ControllerBase
	{
		public MenuController() {}

		public static DataSet SelectMenu( string UserID )
		{
			DataSet ds = null;
			CodeBizNTx biz = null;

			if ( UserID == null ) { UserID = ""; }
		
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectMenu( UserID );			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}

		public static DataSet SelectCodeMenu( string UserID )
		{
			DataSet ds = null;
			CodeBizNTx biz = null;

			if ( UserID == null ) { UserID = ""; }
		
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectCodeMenu( UserID );			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}

//		public static DataSet SelectTopMenu( string UserID )
//		{
//			DataSet ds = null;
//			CodeBizNTx biz = null;
//
//			if ( UserID == null ) { UserID = ""; }
//		
//			try
//			{
//				biz = new CodeBizNTx();
//				ds = biz.SelectTopMenu( UserID );			
//			}
//			catch( Exception ex )
//			{
//				throw ex;
//			}
//			finally
//			{
//				if ( biz != null )
//				{
//					biz.Dispose();
//					biz = null;
//				}
//			}
//
//			return ds;
//		}
//
//		public static DataSet SelectSubMenu( string UserID )
//		{
//			DataSet ds = null;
//			CodeBizNTx biz = null;
//
//			if ( UserID == null ) { UserID = ""; }
//		
//			try
//			{
//				biz = new CodeBizNTx();
//				ds = biz.SelectSubMenu( UserID );			
//			}
//			catch( Exception ex )
//			{
//				throw ex;
//			}
//			finally
//			{
//				if ( biz != null )
//				{
//					biz.Dispose();
//					biz = null;
//				}
//			}
//
//			return ds;
//		}
	}
}
