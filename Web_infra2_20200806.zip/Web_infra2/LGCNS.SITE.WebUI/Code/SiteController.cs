using System;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using LGCNS.LAF.Web;

using LGCNS.SITE.DTO;
using LGCNS.SITE.Code.Biz;

namespace LGCNS.SITE.WebUI.Code
{
	/// <summary>
	/// DeptController�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SiteController : ControllerBase
	{
		public SiteController() {}

		#region ManageSite
		public static void InsertSite(CodeDS ds)
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx () ;
				biz.InsertSite(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		public static void UpdateSite(CodeDS ds)
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx () ;
				biz.UpdateSite(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		public static void DeleteSite( string Area, string SiteCode )
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx() ;
				biz.DeleteSite(Area,SiteCode);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		#endregion

		public static CodeDS SelectSiteList( string Area )
		{
			return SelectSiteList( Area, "", "", "" );
		}

		public static CodeDS SelectSiteList( string Area, string SiteCode )
		{
			return SelectSiteList( Area, SiteCode, "", "" );
		}

		public static CodeDS SelectSiteList( string Area, string SiteCode, string SiteDesc, string BuildingCode )
		{
			CodeDS ds = null;
			CodeBizNTx biz = null;
		
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectSiteList( Area, SiteCode, SiteDesc, BuildingCode );			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}
	}
}
