using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Code
{
	/// <summary>
	/// ManageSite�� ���� ��� �����Դϴ�.
	/// </summary>
	public class ManageSite : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Button BtnSearch;
		protected System.Web.UI.WebControls.Button BtnInsert;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
		protected System.Web.UI.WebControls.Label Message;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected System.Web.UI.WebControls.TextBox TbxSiteCode;
	
		bool isEditing = false;

		// property to keep track of whether we are adding a new record,
		// and save it in viewstate between postbacks
		protected bool AddingNew 
		{
			get 
			{
				object o = ViewState["AddingNew"];
				return (o == null) ? false : (bool)o;
			}
			set 
			{
				ViewState["AddingNew"] = value;
			}
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos(true);

			if( !this.IsPostBack ) { 
				LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea, true );
				BindGrid(); }
			if( this.IsSubmittedBy ) { 
				LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea, true );
				BindGrid(); }
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
			this.BtnInsert.Click += new System.EventHandler(this.BtnInsert_Click);
			this.DgrdDataGrid.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdDataGrid_EditCommand);
			this.DgrdDataGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.DgrdDataGrid_PageIndexChanged);
			this.DgrdDataGrid.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdDataGrid_CancelCommand);
			this.DgrdDataGrid.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdDataGrid_UpdateCommand);
			this.DgrdDataGrid.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdDataGrid_DeleteCommand);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		void CheckIsEditing(string commandName) 
		{

			if (DgrdDataGrid.EditItemIndex != -1) 
			{

				// we are currently editing a row
				if (commandName != "Cancel" && commandName != "Update") 
				{

					// user's edit changes (if any) will not be committed
					Message.Text = "Your changes have not been saved yet.  Please press update to save your changes, or cancel to discard your changes, before selecting another item.";
					isEditing = true;
				}
			}
		}

		private void BindGrid()
		{
			CodeDS ds = SiteController.SelectSiteList( this.DdnlArea.SelectedValue, this.TbxSiteCode.Text );

			this.DgrdDataGrid.DataSource = ds.TB_SITE;
			this.DgrdDataGrid.DataBind();
		}

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			this.DgrdDataGrid.CurrentPageIndex = 0;
			this.DgrdDataGrid.EditItemIndex = -1;
			BindGrid();
		}

		private void BtnInsert_Click(object sender, System.EventArgs e)
		{
			// add a new row to the end of the data, and set editing mode 'on'

			CheckIsEditing("");

			if (!isEditing) 
			{
				// set the flag so we know to do an insert at Update time
				AddingNew = true;

				// add new row to the end of the dataset after binding

				// first get the data
				CodeDS ds = SiteController.SelectSiteList( this.DdnlArea.SelectedValue );
				ds.EnforceConstraints = false;

				// add a new blank row to the end of the data
				// ���� : 2005/04/11 
				// ������ : Area ������ ��ȸ�Ѵ��� �߰��ÿ��� Building Desc ������ Area�� �߰��ǰ� BuildingDesc������ NULL�� ��
				// �������� : Table�� Insert�� Parameter ��ġ�� Ʋ���� �߸������
				// ����� Method : BtnInsert_Click

				ds.TB_SITE.AddTB_SITERow( this.DdnlArea.SelectedValue,"","","","","","" );

				// figure out the EditItemIndex, last record on last page
				int recordCount = ds.TB_SITE.Rows.Count;
				//if (recordCount > 1)
					recordCount--;
				DgrdDataGrid.CurrentPageIndex = recordCount/DgrdDataGrid.PageSize;
				DgrdDataGrid.EditItemIndex = recordCount%DgrdDataGrid.PageSize;

				// databind
				DgrdDataGrid.DataSource = ds.TB_SITE;
				DgrdDataGrid.DataBind();
			}
		}


		private void DgrdDataGrid_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			// display a new page of data

			if (!isEditing) 
			{
				DgrdDataGrid.EditItemIndex = -1;
				DgrdDataGrid.CurrentPageIndex = e.NewPageIndex;
				BindGrid();
			}

		}

		private void DgrdDataGrid_EditCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			if ( !isEditing )
			{
				this.DgrdDataGrid.EditItemIndex = e.Item.ItemIndex;
				BindGrid();
			}
		}

		private void DgrdDataGrid_CancelCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			// cancel editing

			DgrdDataGrid.EditItemIndex = -1;
			BindGrid();

			AddingNew = false;

		}

		private void DgrdDataGrid_UpdateCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			CodeDS ds = new CodeDS();

			CodeDS.TB_SITERow dr = ds.TB_SITE.NewTB_SITERow();

			dr.Area = ((DropDownList)e.Item.Cells[7].Controls[1]).SelectedValue;
			dr.SiteCode = ((TextBox)e.Item.Cells[1].Controls[1]).Text;
			dr.SiteDesc = ((TextBox)e.Item.Cells[2].Controls[1]).Text;
			dr.SvcLevel = ((TextBox)e.Item.Cells[3].Controls[1]).Text;
			dr.LocationName = ((TextBox)e.Item.Cells[4].Controls[1]).Text;
			dr.BuildingCode = ((TextBox)e.Item.Cells[5].Controls[1]).Text;
			dr.BuildingDesc = ((TextBox)e.Item.Cells[6].Controls[1]).Text;

			ds.TB_SITE.AddTB_SITERow( dr );

			if (AddingNew)
			{
				//Insert
				SiteController.InsertSite( ds );
			}
			else
			{
				//Update
				SiteController.UpdateSite( ds );
			}

			if (AddingNew) 
			{

				DgrdDataGrid.CurrentPageIndex = 0;
				AddingNew = false;
			}

			// rebind the grid
			DgrdDataGrid.EditItemIndex = -1;
			BindGrid();

		}

		private void DgrdDataGrid_DeleteCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			// delete the selected row
			if (!isEditing) 
			{
				//Delete
				//2005-06-01 : Site ������ �ȵǴ� ���� ����
				SiteController.DeleteSite( ((Label)DgrdDataGrid.Items[e.Item.ItemIndex].Cells[7].Controls[1]).Text,((Label)DgrdDataGrid.Items[e.Item.ItemIndex].Cells[1].Controls[1]).Text );

				// rebind the grid
				DgrdDataGrid.CurrentPageIndex = 0;
				DgrdDataGrid.EditItemIndex = -1;
				BindGrid();
			}

		}

		public DataTable BindAreaList( )
		{
			AreaDS ds = AreaController.SelectAreaList();
			return ds.TB_AREA;
		}

		public int GetStateIndex( string Area )
		{
			AreaDS ds = AreaController.SelectAreaList();
 
			for ( int i = 0; i < ds.TB_AREA.Count; i++)
			{
				AreaDS.TB_AREARow dr = ds.TB_AREA[i];

				if ( dr.Area.ToString() == Area )
				{
					return i;
				}
			}

			return 0;
		}
	}
}
