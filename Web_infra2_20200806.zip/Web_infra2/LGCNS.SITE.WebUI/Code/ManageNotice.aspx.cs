using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Code
{
	/// <summary>
	/// ManageNotice�� ���� ��� �����Դϴ�.
	/// </summary>
	public class ManageNotice : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Button BtnSave;
		protected System.Web.UI.WebControls.TextBox TbxContents;
		protected System.Web.UI.WebControls.TextBox TbxTitle;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos(true);

			XjosHelper.SetValidator (this.TbxTitle,
				new XjosValidator (XjosValidatorType.Required)
				);
			XjosHelper.SetValidator (this.TbxContents,
				new XjosValidator (XjosValidatorType.Required)
				);
			XjosHelper.ValidateOnClick (
				this.BtnSave,
				MessageManager.GetMessage("Common", "REGISTER_QUESTION")
				) ;

			if( !this.IsPostBack ) { BindGrid(); }
			if( this.IsSubmittedBy ) { BindGrid(); }
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
			this.DgrdDataGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdDataGrid_ItemCommand);
			this.DgrdDataGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.DgrdDataGrid_PageIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BindGrid()
		{
			CodeDS ds = NoticeController.SelectNoticeList();

			this.DgrdDataGrid.DataSource = ds.TB_NOTICE;
			this.DgrdDataGrid.DataBind();
		}

		private void DgrdDataGrid_ItemCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			if ( e.CommandName == "Select" )
			{
				this.TbxTitle.Text = e.Item.Cells[2].Text;
				this.TbxContents.Text = e.Item.Cells[3].Text;
			}
		}

		private void BtnSave_Click(object sender, System.EventArgs e)
		{
			SaveNotice();
		}

		private void SaveNotice()
		{
			CodeDS ds = new CodeDS();
			CodeDS.TB_NOTICERow dr = ds.TB_NOTICE.NewTB_NOTICERow();

			dr.ID = 0;
			dr.Title = this.TbxTitle.Text.Trim();
			dr.Content = this.TbxContents.Text.Trim();
			dr.CreateId = this.CurrentUserID;
			dr.CreateDate = DateTime.Now;
			ds.TB_NOTICE.AddTB_NOTICERow( dr );

			NoticeController.InsertNotice( ds );

			ScriptHelper.ShowAlert( MessageManager.GetMessage( "Common" , "REGISTER_DONE" ) );

			this.DgrdDataGrid.CurrentPageIndex = 0;
			BindGrid();
		}

		private void DgrdDataGrid_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			this.DgrdDataGrid.CurrentPageIndex = e.NewPageIndex;
			BindGrid();
		}
	}
}
