using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Code
{
	/// <summary>
	/// SelectDeptList�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectDeptList : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxDeptName;
		protected System.Web.UI.WebControls.Button BtnSearch;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }
			XjosHelper.RegisterXjos(true);

			if ( !this.IsPostBack )
			{
				LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea );
				if( this.Request["Area"] != null )
				{
					this.DdnlArea.SelectedValue = this.Request["Area"];
					this.DdnlArea.Enabled = false;
				}
				BindGrid();
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DgrdDataGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdDataGrid_ItemCommand);
			this.DgrdDataGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.DgrdDataGrid_PageIndexChanged);
			this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			this.DgrdDataGrid.CurrentPageIndex = 0;
			this.DgrdDataGrid.EditItemIndex = -1;
			BindGrid();
		}

		private void BindGrid()
		{
			CodeDS ds = DeptController.SelectDeptList( this.DdnlArea.SelectedValue, "", this.TbxDeptName.Text );

			this.DgrdDataGrid.DataSource = ds.TB_DEPT;
			this.DgrdDataGrid.DataBind();
		}

		private void DgrdDataGrid_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			// display a new page of data
			DgrdDataGrid.EditItemIndex = -1;
			DgrdDataGrid.CurrentPageIndex = e.NewPageIndex;
			BindGrid();
		}

		private void DgrdDataGrid_ItemCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			if( e.CommandName == "Select" )
			{
				NameValueCollection valuesToSend = new NameValueCollection();
				valuesToSend["DdnlDeptCode"]  = e.Item.Cells[1].Text;
				NavigationHelper.Close( true, valuesToSend );
			}
		}
	}
}
