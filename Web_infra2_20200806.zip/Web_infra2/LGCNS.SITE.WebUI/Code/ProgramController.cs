using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.Exceptions ;

using LGCNS.SITE.DTO;
using LGCNS.SITE.Code;
using LGCNS.SITE.Code.Biz;

namespace LGCNS.SITE.WebUI.Code
{
	/// <summary>
	/// ProgramController�� ���� ��� �����Դϴ�.
	/// </summary>
	public class ProgramController : ControllerBase
	{
		public ProgramController() {}

		#region ProgramClass
		public static ProgramDS SelectProgramClass()
		{
			ProgramDS ds = null;
			CodeBizNTx biz = null;

			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectProgramClass();			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}

		public static void InsertProgramClass(ProgramDS ds)
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx () ;
				biz.InsertProgramClass(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		public static void UpdateProgramClass(ProgramDS ds)
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx () ;
				biz.UpdateProgramClass(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		public static void DeleteProgramClass( string ProgramClass )
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx() ;
				biz.DeleteProgramClass(ProgramClass);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		#endregion

		#region Program
		public static ProgramDS SelectProgramList (int currentPage, int pageSize, string ProgramClass)
		{
			ProgramDS ds = null;
			CodeBizNTx biz = null;
			
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectProgramList(currentPage, pageSize, ProgramClass);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}


		public static void InsertProgram(ProgramDS ds)
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx () ;
				biz.InsertProgram(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		public static void UpdateProgram(ProgramDS ds)
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx () ;
				biz.UpdateProgram(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		public static void DeleteProgram( string ProgramClass, string ProgramID )
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx() ;
				biz.DeleteProgram(ProgramClass,ProgramID);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		#endregion
	}
}
