using System;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using LGCNS.LAF.Web;

using LGCNS.SITE.DTO;
using LGCNS.SITE.Code.Biz;

namespace LGCNS.SITE.WebUI.Code
{
	/// <summary>
	/// DeptController�� ���� ��� �����Դϴ�.
	/// </summary>
	public class DeptController : ControllerBase
	{
		public DeptController() {}

		#region ManageDept
		public static void InsertDept(CodeDS ds)
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx () ;
				biz.InsertDept(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		public static void UpdateDept(CodeDS ds)
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx () ;
				biz.UpdateDept(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		public static void DeleteDept( string Area, string DeptCode )
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx() ;
				biz.DeleteDept(Area,DeptCode);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		#endregion

		public static CodeDS SelectDeptList( string Area )
		{
			return SelectDeptList( Area, "", "" );
		}

		public static CodeDS SelectDeptList( string Area, string DeptCode )
		{
			return SelectDeptList( Area, DeptCode, "" );
		}

		public static CodeDS SelectDeptList( string Area, string DeptCode, string DeptName )
		{
			CodeDS ds = null;
			CodeBizNTx biz = null;
		
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectDeptList( Area, DeptCode, DeptName );			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}
        
        public static bool isExistDept( string Area, string DeptCode )
        {
            CodeDS ds = SelectDept( Area, DeptCode );
            if ( ds.TB_DEPT.Count>0 )
                return true;
            else
                return false;
        }

		public static CodeDS SelectDept( string Area, string DeptCode )
		{
			return SelectDeptList( Area, DeptCode, "" );
		}

		public static string getDeptName( string Area, string DeptCode )
		{
			CodeDS ds = SelectDept( Area, DeptCode );
			if ( ds.TB_DEPT[0].IsDeptNameNull() )
				return "";
			else
				return ds.TB_DEPT[0].DeptName;
		}

		public static string getDeptNameEng( string Area, string DeptCode )
		{
			CodeDS ds = SelectDept( Area, DeptCode );
			if ( ds.TB_DEPT[0].IsDeptNameEngNull() )
				return "";
			else
				return ds.TB_DEPT[0].DeptNameEng;
		}
	}
}
