using System;

using LGCNS.LAF.Web;
using LGCNS.SITE.Common;
using LGCNS.SITE.DTO;
using LGCNS.SITE.Code;
using LGCNS.SITE.Code.Biz;

namespace LGCNS.SITE.WebUI.Code
{
	/// <summary>
	/// NoticeController�� ���� ��� �����Դϴ�.
	/// </summary>
	public class NoticeController : ControllerBase
	{
		public NoticeController() {}

		public static CodeDS SelectNotice()
		{
			CodeDS ds = null;
			CodeBizNTx biz = null;

			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectNotice();			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}

		public static CodeDS SelectNoticeList()
		{
			CodeDS ds = null;
			CodeBizNTx biz = null;
		
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectNoticeList();			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}


		public static void InsertNotice(CodeDS ds)
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx () ;
				biz.InsertNotice(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		public static void UpdateNotice(CodeDS ds)
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx () ;
				biz.UpdateNotice(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		public static void DeleteNotice( int ID )
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx() ;
				biz.DeleteNotice(ID);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}

	}
}
