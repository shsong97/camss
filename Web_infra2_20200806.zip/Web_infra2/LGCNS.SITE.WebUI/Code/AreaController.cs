using System;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using LGCNS.LAF.Web;

using LGCNS.SITE.DTO;
using LGCNS.SITE.Code.Biz;

namespace LGCNS.SITE.WebUI.Code
{
	/// <summary>
	/// AreaController�� ���� ��� �����Դϴ�.
	/// </summary>
	public class AreaController : ControllerBase
	{
		public AreaController() {}

		public static AreaDS SelectAreaList()
		{
			AreaDS ds = null;
			CodeBizNTx biz = null;
		
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectAreaList( );			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}

		public static AreaDS SelectArea( string Area )
		{
			AreaDS ds = null;
			CodeBizNTx biz = null;
		
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectArea( Area );			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}

		#region ManageArea
		public static void InsertArea(AreaDS ds)
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx () ;
				biz.InsertArea(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		public static void UpdateArea(AreaDS ds)
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx () ;
				biz.UpdateArea(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		public static void DeleteArea( string Area )
		{
			CodeBizTx biz = null;
			
			try
			{
				biz = new CodeBizTx() ;
				biz.DeleteArea(Area);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}
		#endregion

	}
}
