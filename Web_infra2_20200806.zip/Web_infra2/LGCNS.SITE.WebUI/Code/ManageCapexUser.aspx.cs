using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Code
{
	/// <summary>
	/// ManageCapexUser�� ���� ��� �����Դϴ�.
	/// </summary>
	public class ManageCapexUser : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Button BtnSearch;
		protected System.Web.UI.WebControls.Button BtnInsert;
		protected System.Web.UI.WebControls.Label Message;
		protected System.Web.UI.WebControls.DataGrid DgrdDataGrid;
		
		bool isEditing = false;

		// property to keep track of whether we are adding a new record,
		// and save it in viewstate between postbacks
		protected bool AddingNew 
		{
			get 
			{
				object o = ViewState["AddingNew"];
				return (o == null) ? false : (bool)o;
			}
			set 
			{
				ViewState["AddingNew"] = value;
			}
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos(true);

			if( !this.IsPostBack ) { BindGrid(); }
			if( this.IsSubmittedBy ) { BindGrid(); }
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
			this.BtnInsert.Click += new System.EventHandler(this.BtnInsert_Click);
			this.DgrdDataGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.DgrdDataGrid_PageIndexChanged);
			this.DgrdDataGrid.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdDataGrid_CancelCommand);
			this.DgrdDataGrid.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdDataGrid_EditCommand);
			this.DgrdDataGrid.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdDataGrid_UpdateCommand);
			this.DgrdDataGrid.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdDataGrid_DeleteCommand);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion



		void CheckIsEditing(string commandName) 
		{

			if (DgrdDataGrid.EditItemIndex != -1) 
			{

				// we are currently editing a row
				if (commandName != "Cancel" && commandName != "Update") 
				{

					// user's edit changes (if any) will not be committed
					Message.Text = "Your changes have not been saved yet.  Please press update to save your changes, or cancel to discard your changes, before selecting another item.";
					isEditing = true;
				}
			}
		}

		private void BindGrid()
		{
			CodeDS ds = CodeController.SelectCapexUserList();

			this.DgrdDataGrid.DataSource = ds.TB_BASE;
			this.DgrdDataGrid.DataBind();
		}

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			this.DgrdDataGrid.CurrentPageIndex = 0;
			this.DgrdDataGrid.EditItemIndex = -1;
			BindGrid();
			AddingNew = false;
		}

		private void BtnInsert_Click(object sender, System.EventArgs e)
		{
			// add a new row to the end of the data, and set editing mode 'on'

			CheckIsEditing("");

			if (!isEditing) 
			{
				// set the flag so we know to do an insert at Update time
				AddingNew = true;

				// add new row to the end of the dataset after binding

				// first get the data
				CodeDS ds = CodeController.SelectCapexUserList();
				ds.EnforceConstraints = false;

				// add a new blank row to the end of the data
				ds.TB_BASE.AddTB_BASERow( "","","","","","","","","","","" );

				// figure out the EditItemIndex, last record on last page
				int recordCount = ds.TB_BASE.Rows.Count;
				if (recordCount > 1)
					recordCount--;
				DgrdDataGrid.CurrentPageIndex = recordCount/DgrdDataGrid.PageSize;
				DgrdDataGrid.EditItemIndex = recordCount; //%DgrdDataGrid.PageSize;
				//if (recordCount == DgrdDataGrid.PageSize)
				//	DgrdDataGrid.CurrentPageIndex++;
				// databind
				DgrdDataGrid.DataSource = ds.TB_BASE;
				DgrdDataGrid.DataBind();
			}
		}


		private void DgrdDataGrid_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			// display a new page of data

			if (!isEditing) 
			{
				DgrdDataGrid.EditItemIndex = -1;
				DgrdDataGrid.CurrentPageIndex = e.NewPageIndex;
				BindGrid();
			}

		}

		private void DgrdDataGrid_EditCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			if ( !isEditing )
			{
				this.DgrdDataGrid.EditItemIndex = e.Item.ItemIndex;
				BindGrid();
			}
		}

		private void DgrdDataGrid_CancelCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			// cancel editing

			DgrdDataGrid.EditItemIndex = -1;
			BindGrid();

			AddingNew = false;

		}



		private void DgrdDataGrid_UpdateCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			CodeDS ds = new CodeDS();
			ds.EnforceConstraints = false;
			CodeDS.TB_BASERow dr = ds.TB_BASE.NewTB_BASERow();
			
			dr.C_key = "CAPEX00001";
			dr.Col9 = "CAPEX A:������ B:ȸ�� C:BA";

			if ( ((DropDownList)e.Item.Cells[1].Controls[1]).SelectedValue == "" )
			{
				ScriptHelper.ShowAlert(	MessageManager.GetMessage( "Common", "NO_GUBUN" ) );
				return;
			}
			dr.Col1 = ((DropDownList)e.Item.Cells[1].Controls[1]).SelectedValue ;

			if ( ((TextBox)e.Item.Cells[2].Controls[1]).Text == "" )
			{
				ScriptHelper.ShowAlert(	MessageManager.GetMessage( "Common", "NO_ID" ) );
				return;
			}
			dr.Col2 = ((TextBox)e.Item.Cells[2].Controls[1]).Text;

			dr.Col3 = ((TextBox)e.Item.Cells[3].Controls[1]).Text;
						
			ds.TB_BASE.AddTB_BASERow( dr );

			if (AddingNew)
			{
				//Insert
				CodeController.InsertCapexUser( ds );
			}
			else
			{
				//Update
				CodeController.UpdateCapexUser( ds );
			}

			if (AddingNew) 
			{

				DgrdDataGrid.CurrentPageIndex = 0;
				AddingNew = false;
			}

			// rebind the grid
			DgrdDataGrid.EditItemIndex = -1;
			BindGrid();

		}

		private void DgrdDataGrid_DeleteCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			// delete the selected row
			if (!isEditing) 
			{
				string Col2 = ((Label)DgrdDataGrid.Items[e.Item.ItemIndex].Cells[2].Controls[1]).Text;
				//Delete
				CodeController.DeleteCapexUser( Col2 );

				// rebind the grid
				DgrdDataGrid.CurrentPageIndex = 0;
				DgrdDataGrid.EditItemIndex = -1;
				BindGrid();
			}

		}

		public DataTable BindCodeList( string ClassID )
		{
			CodeDS ds = CodeController.SelectCodeList( ClassID );
			return ds.TB_CODE;
		}

		public int GetStateIndex( string ClassID, string Code )
		{
			CodeDS ds = CodeController.SelectCodeList( ClassID );
 
			for ( int i = 0; i < ds.TB_CODE.Count; i++)
			{
				CodeDS.TB_CODERow dr = ds.TB_CODE[i];

				if ( dr.Code.ToString() == Code )
				{
					return i;
				}
			}

			return 0;
		}
	}
}
