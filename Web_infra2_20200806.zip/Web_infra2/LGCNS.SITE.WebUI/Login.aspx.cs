using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using System.Web.Security;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;
using LGCNS.SITE.User.Biz;

namespace LGCNS.SITE.WebUI
{
	/// <summary>
	/// Login ������
	/// </summary>
	public class Login : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Panel Panel1;
		protected System.Web.UI.WebControls.TextBox TbxUserID;
		protected System.Web.UI.WebControls.TextBox TbxUserPassword;
		protected System.Web.UI.WebControls.Button BtnLogin;
		protected System.Web.UI.WebControls.Button BtnLogout;
		protected System.Web.UI.WebControls.Panel Panel2;
		protected System.Web.UI.WebControls.Button BtnHome;
		protected System.Web.UI.WebControls.Label LblLoginInfo;
		
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			//���������� ����
			string scUrl;
			scUrl = this.Request.RawUrl.ToString() ;
			if (scUrl.IndexOf("TicketNo") > 0)
			{

				scUrl = scUrl.Substring(scUrl.IndexOf("ReturnUrl")+13);

				FormsAuthentication.RedirectFromLoginPage("Survey", false);
				FormsAuthentication.SetAuthCookie ("Survey", false) ;
				NavigationHelper.Redirect( null, "top", scUrl);
			}

			//�α׾ƿ�����
			if ( ( this.Request.IsAuthenticated == false ) | ( this.CurrentUserID == null ) )
			{
				this.Panel1.Visible = true;
				this.Panel2.Visible = false;
				this.BtnLogin.Enabled = true;
				this.BtnLogout.Enabled = false;
				this.LblLoginInfo.Visible = false;
                Type t = this.GetType();
                ClientScript.RegisterStartupScript(t, "Focus", ScriptHelper.ToJavaScript( "document.getElementById('TbxUserID').focus();" ) );
			}
			else
			{
				this.Panel1.Visible = false;
				this.Panel2.Visible = true;
				this.BtnLogin.Enabled = false;
				this.BtnLogout.Enabled = true;
				this.LblLoginInfo.Visible = true;

				this.LblLoginInfo.Text = this.CurrentUserName + "���� �α��εǾ� �ֽ��ϴ�.";
			}

			// �Է��ʵ忡 Xjos Validadation ����
			XjosHelper.RegisterXjos (true) ;

			XjosHelper.SetValidator (this.TbxUserID, 
				new XjosValidator (XjosValidatorType.Required,		"����� ID�� �ʼ��Է��Դϴ�.") ,
				new XjosValidator (XjosValidatorType.Alpha_Numeric, "����� ID�� �����ڸ� �Է°����մϴ�.") ,
				new XjosValidator (XjosValidatorType.Minlength ,"1", "����� ID�� �ּ�1�ڸ� �Դϴ�.") 
				) ;
			
			XjosHelper.SetValidator (this.TbxUserPassword, 
				new XjosValidator (XjosValidatorType.Required,		"����� ��ȣ�� �ʼ��Է��Դϴ�.") ,
				new XjosValidator (XjosValidatorType.Alpha_Numeric,	"����� ��ȣ�� �����ڸ� �Է°����մϴ�.") 
				) ;

			// Ŭ���� Xjos Validation�� ������ ��ư ��Ʈ�� ����
			XjosHelper.ValidateOnClick (this.BtnLogin);

		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnLogin.Click += new System.EventHandler(this.BtnLogin_Click);
			this.BtnHome.Click += new System.EventHandler(this.BtnHome_Click);
			this.BtnLogout.Click += new System.EventHandler(this.BtnLogout_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BtnLogin_Click(object sender, System.EventArgs e)
		{
			UserBizNTx biz = new UserBizNTx();
			UserDS ds = biz.SelectUser(this.TbxUserID.Text);

			if(ds.TB_USER.Count == 0)
			{
				ScriptHelper.ShowAlert(MessageManager.GetMessage("User", "NO_USERID"));
			}
			else
			{ 
				UserDS.TB_USERRow row = ds.TB_USER[0];

				if(row.UserPassword != this.TbxUserPassword.Text)
				{
					ScriptHelper.ShowAlert(MessageManager.GetMessage("User", "INVALID_USERPASSWORD"));
				}
				else
				{
					Session.Clear();

					if ( row.Authority.ToString() == "A" ||
						row.Authority.ToString() == "H" )
					{
						Session.Timeout = 240; //minutes
					}
					else
					{
						Session.Timeout = 60; //minutes
					}
					
					Session["UserID"] = row.UserID;
					Session["UserName"] = row.UserName;
					Session["UserPassword"] = row.UserPassword;
					Session["Email"] = row.Email;
					Session["UserAuthority"] = row.Authority;
					Session["UserAuthorityName"] = LGCNS.SITE.Common.WebUI.CodeInfo.getCodeDesc( "AUTHORITY", row.Authority );
					Session["AlterUserID"] = row.AlterUserID;

					UserDS Capexds = biz.SelectCapexUser(this.TbxUserID.Text);
					
					
					if(Capexds.TB_CAPEX_USER.Rows.Count>0)
					{
						UserDS.TB_CAPEX_USERRow capexrow = Capexds.TB_CAPEX_USER[0];
						Session["CapexUserAuthority"] = capexrow.Col1;
					}
					else
						Session["CapexUserAuthority"] = "";
					

					if ( row.IsAreaNull() )
						Session["UserArea"] = "";
					else
						Session["UserArea"] = row.Area;

					FormsAuthentication.RedirectFromLoginPage(row.UserName, false);
					FormsAuthentication.SetAuthCookie (row.UserID, false) ;
					NavigationHelper.Redirect( null, "top", "Default.aspx");
				}
			}
		}

		private void BtnLogout_Click(object sender, System.EventArgs e)
		{
			FormsAuthentication.SignOut();
			Session.Clear();
			
			NavigationHelper.Redirect("Logout.aspx");
		}

		private void BtnHome_Click(object sender, System.EventArgs e)
		{
			NavigationHelper.Redirect("Default.aspx");
		}
	}
}

