using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;



namespace LGCNS.SITE.WebUI.ICMS
{
	/// <summary>
	/// SelectICMSAsset�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectICMSAsset : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Button BtnApply;
		protected System.Web.UI.WebControls.Label LblTicketNo;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdInsertList;
		protected System.Web.UI.WebControls.Button BtnSelectAllForInsert;
		protected System.Web.UI.WebControls.Button BtnUnSelectAllForInsert;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDeleteList;
		protected System.Web.UI.WebControls.Button BtnSelectAllForDelete;
		protected System.Web.UI.WebControls.Button BtnUnSelectAllForDelete;
		protected System.Web.UI.WebControls.Button BtnClose;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos(true);

			string EmpNo = this.Request["EmpNo"];
			string TicketNo = this.Request["TicketNo"];

			this.DgrdInsertList.SetMultipleSelect(
				0,
				false,
				this.BtnSelectAllForInsert,  // üũ�ڽ��� ��ü������ ��ư
				this.BtnUnSelectAllForInsert , // üũ�ڽ��� ��ü���������� ��ư
				"."
				) ;

			this.DgrdDeleteList.SetMultipleSelect(
				0,
				false,
				this.BtnSelectAllForDelete,  // üũ�ڽ��� ��ü������ ��ư
				this.BtnUnSelectAllForDelete , // üũ�ڽ��� ��ü���������� ��ư
				"."
				) ;

			XjosHelper.ValidateOnClick( this.BtnApply );

			if ( !this.IsPostBack )
			{
				this.LblTicketNo.Text = TicketNo;
				BindICMSAsset( EmpNo, TicketNo );
			}
			if ( this.IsSubmittedBy )
			{
				this.LblTicketNo.Text = TicketNo;
				BindICMSAsset( EmpNo, TicketNo );
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnApply.Click += new System.EventHandler(this.BtnApply_Click);
			this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BindICMSAsset( string EmpNo, string TicketNo )
		{
			BindInsertList( EmpNo, TicketNo );
			BindDeleteList( TicketNo );
		}

		private void BindInsertList( string EmpNo, string TicketNo )
		{
			ICMSDS ds = ICMSController.SelectAssetList( EmpNo, TicketNo );
			this.DgrdInsertList.DataSource = ds.TB_ICMS_ASSET;
			this.DgrdInsertList.DataBind();

			if ( ds.TB_ICMS_ASSET.Count >= 5 )
			{
				this.DgrdInsertList.AllowScroll = true;
				this.DgrdInsertList.ScrollHeight = 110;
				this.DgrdInsertList.ScrollWidth = 950;
			}
		}
		private void BindDeleteList( string TicketNo )
		{
			ICMSDS ds  = ICMSController.SelectICMSAsset( TicketNo );
			this.DgrdDeleteList.DataSource = ds.TB_ICMS_ASSET;
			this.DgrdDeleteList.DataBind();

			if ( ds.TB_ICMS_ASSET.Count >= 5 )
			{
				this.DgrdDeleteList.AllowScroll = true;
				this.DgrdDeleteList.ScrollHeight = 110;
				this.DgrdDeleteList.ScrollWidth = 950;
			}
		}

		private void BtnApply_Click(object sender, System.EventArgs e)
		{
			DeleteICMSAsset();
			InsertICMSAsset();
			NavigationHelper.Close( true );
		}

		private void DeleteICMSAsset()
		{
			if(this.DgrdDeleteList.SelectedItems != null)
			{
				ICMSDS ds = new ICMSDS();
				ds.EnforceConstraints = false;
				ICMSDS.TB_ICMS_ASSETRow dr = null;

				DataGridItem[] selectedItems = this.DgrdDeleteList.SelectedItems ;
				// ������ ������ ��θ� ArrayList�� �ִ´�.
				for(int i=0;i<selectedItems.Length ; i++)
				{
					dr = ds.TB_ICMS_ASSET.NewTB_ICMS_ASSETRow();

					dr.TicketNo = selectedItems[i].Cells [1].Text;
					dr.AssetNo  = selectedItems[i].Cells [2].Text;

					ds.TB_ICMS_ASSET.AddTB_ICMS_ASSETRow( dr );
				}

				ICMSController.DeleteICMSAsset( ds );
			}
		}

		private void InsertICMSAsset()
		{
			if(this.DgrdInsertList.SelectedItems != null)
			{
				ICMSDS ds = new ICMSDS();
				ds.EnforceConstraints = false;
				ICMSDS.TB_ICMS_ASSETRow dr = null;

				DataGridItem[] selectedItems = this.DgrdInsertList.SelectedItems ;
				// ������ ������ ��θ� ArrayList�� �ִ´�.
				for(int i=0;i<selectedItems.Length ; i++)
				{
					dr = ds.TB_ICMS_ASSET.NewTB_ICMS_ASSETRow();

					dr.TicketNo      = selectedItems[i].Cells [1].Text;
					dr.AssetNo       = selectedItems[i].Cells [2].Text;
					dr.ParentAssetNo = selectedItems[i].Cells [3].Text;
					dr.Make          = selectedItems[i].Cells [4].Text;
					dr.ModelNo       = selectedItems[i].Cells [5].Text;
					dr.SerialNo      = selectedItems[i].Cells [6].Text;
					dr.Status        = selectedItems[i].Cells [7].Text;
					dr.AssetType     = selectedItems[i].Cells [9].Text;
					dr.CPUType       = selectedItems[i].Cells [11].Text;

					ds.TB_ICMS_ASSET.AddTB_ICMS_ASSETRow( dr );
				}
				ICMSController.InsertICMSAsset( ds );
			}
		}

		private void BtnClose_Click(object sender, System.EventArgs e)
		{
			NavigationHelper.Close( false );
		}
	}
}
