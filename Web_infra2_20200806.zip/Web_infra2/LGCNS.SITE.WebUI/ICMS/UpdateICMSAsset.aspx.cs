using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;



namespace LGCNS.SITE.WebUI.ICMS
{
	/// <summary>
	/// UpdateICMSAsset�� ���� ��� �����Դϴ�.
	/// </summary>
	public class UpdateICMSAsset : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected System.Web.UI.WebControls.TextBox TbxAssetNo;
		protected System.Web.UI.WebControls.TextBox TbxParentAssetNo;
		protected System.Web.UI.WebControls.TextBox TbxSerial;
		protected System.Web.UI.WebControls.DropDownList DdnlParentAssetType;
		protected System.Web.UI.WebControls.DropDownList DdnlStatus;
		protected System.Web.UI.WebControls.DropDownList DdnlCPUType;
		protected System.Web.UI.WebControls.DropDownList DdnlMonitorType;
		protected System.Web.UI.WebControls.TextBox TbxPONumber;

		protected System.Web.UI.WebControls.Button BtnSave;
		protected System.Web.UI.WebControls.Label LblStatus;
		protected System.Web.UI.WebControls.ImageButton IbtnSearchModel;
		protected System.Web.UI.WebControls.TextBox TbxModelNumber;
		protected System.Web.UI.WebControls.TextBox TbxManufacturer;
		protected System.Web.UI.WebControls.DropDownList DdnlClassID;
		protected System.Web.UI.WebControls.Panel Panel1;
		protected System.Web.UI.WebControls.Label LblCPUType;
		protected System.Web.UI.WebControls.Button BtnClose;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos(true);

			NavigationHelper.SetPopupWindow(
				this.IbtnSearchModel,
				"../Code/SelectModelList.aspx",
				"SearchModel",
				1000, 400,
				false
				);

			string TicketNo = this.Request["TicketNo"];
			string AssetNo = this.Request["AssetNo"];

			if ( !this.IsPostBack )
			{
				BindICMSAsset( TicketNo, AssetNo );
			}

			if( this.IsSubmittedBy )
			{
				BindICMSAsset( TicketNo, AssetNo );
			}
			
			SetValidator();
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
			this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		private void SetValidator()
		{
			XjosHelper.SetValidator( this.TbxParentAssetNo,
				new XjosValidator( XjosValidatorType.Minlength, "8", "" )
				//new XjosValidator( XjosValidatorType.Numeric )
				);

			this.TbxParentAssetNo.MaxLength = 8;
			XjosHelper.SetValidator(
				this.TbxSerial,
				new XjosValidator( XjosValidatorType.Required )
				);

			//����� �϶�
			if ( this.DdnlCPUType.SelectedValue.Trim() == "MNTR" ||
				 this.DdnlCPUType.SelectedValue.Trim() == "MONL"
				)
			{
				this.TbxParentAssetNo.Enabled = true;
				this.DdnlMonitorType.Enabled = true;

				XjosHelper.SetValidator( this.TbxParentAssetNo,
					new XjosValidator( XjosValidatorType.Required )
					);
				this.TbxParentAssetNo.MaxLength = 8;
				
			}

			//������ �϶�
			if ( this.DdnlCPUType.SelectedValue == "BNWP" ||
				this.DdnlCPUType.SelectedValue == "BSAP" ||
				this.DdnlCPUType.SelectedValue == "CNWP" ||
				this.DdnlCPUType.SelectedValue == "CSAP" ||
				this.DdnlCPUType.SelectedValue == "BNP2" ||
				this.DdnlCPUType.SelectedValue == "BNP3" ||
				this.DdnlCPUType.SelectedValue == "BNP4" 
				)
			{
				this.TbxParentAssetNo.Enabled = true;
				this.DdnlCPUType.Enabled = true;

				XjosHelper.SetValidator( this.TbxParentAssetNo,
					new XjosValidator( XjosValidatorType.Required )
					);
				this.TbxParentAssetNo.MaxLength = 8;
			}

			if ( !ICMSController.isExistAsset( this.TbxAssetNo.Text ) )
			{
				IbtnSearchModel.Visible = true;
				this.TbxParentAssetNo.Enabled = true;
				this.DdnlParentAssetType.Enabled = true;
				this.TbxManufacturer.Enabled = true;
				//this.TbxModelNumber.Enabled = true;
				this.TbxSerial.Enabled = true;
				this.DdnlStatus.Enabled = true;
				this.DdnlClassID.Enabled = true;
				this.DdnlCPUType.Enabled = true;
				this.TbxPONumber.Enabled = true;

				XjosHelper.SetValidator( 
					this.TbxParentAssetNo,
					new XjosValidator( XjosValidatorType.Required )
					);
				this.TbxParentAssetNo.MaxLength = 8;
			
				XjosHelper.SetValidator(
					this.TbxManufacturer,
					new XjosValidator( XjosValidatorType.Required )
					);
				XjosHelper.SetValidator(
					this.TbxModelNumber,
					new XjosValidator( XjosValidatorType.Required )
					);
				XjosHelper.SetValidator(
					this.TbxSerial,
					new XjosValidator( XjosValidatorType.Required )
					);
				XjosHelper.SetValidator(
					this.TbxPONumber,
					new XjosValidator( XjosValidatorType.Required )
					);
			}

			XjosHelper.ValidateOnClick (
				this.BtnSave,
				MessageManager.GetMessage("Common", "UPDATE_QUESTION")
				) ;
		}

		private void BindICMSAsset( string TicketNo, string AssetNo )
		{
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlParentAssetType, "ASSET_TYPE", true );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlStatus, "COMP_STATUS" );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlClassID, "CLASS_ID" );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlCPUType, "CPU_TYPE" );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlMonitorType, "MONITOR_TYPE", true );

			ICMSDS ds = ICMSController.SelectICMSAsset( TicketNo, AssetNo );
			ICMSDS.TB_ICMS_ASSETRow dr = ds.TB_ICMS_ASSET[0];

			this.TbxTicketNo.Text = dr.TicketNo;

			this.TbxAssetNo.Text = dr.AssetNo;
			this.TbxParentAssetNo.Text = dr.ParentAssetNo;
			this.TbxManufacturer.Text = dr.Make;
			this.TbxModelNumber.Text = dr.ModelNo;
			this.TbxSerial.Text = dr.SerialNo;

			if ( !dr.IsParentAssetTypeNull() )
				this.DdnlParentAssetType.SelectedValue = dr.ParentAssetType;
			
			this.DdnlStatus.SelectedValue = dr.Status;
			this.LblStatus.Text = dr.Status;
			this.DdnlClassID.SelectedValue = dr.AssetType;
			this.DdnlCPUType.SelectedValue = dr.CPUType;
			this.LblCPUType.Text = dr.CPUType;
			
			if ( !dr.IsMonitorTypeNull() )
				this.DdnlMonitorType.SelectedValue = dr.MonitorType;

			if ( !dr.IsPONumberNull() )
				this.TbxPONumber.Text = dr.PONumber;

		}

		private void BtnSave_Click(object sender, System.EventArgs e)
		{
			if ( isValidation() )
			{
				UpdateAsset();
				NavigationHelper.Close( true );
			}
		}

		private bool isValidation()
		{
			if ( this.DdnlCPUType.SelectedValue == "MNTR" )
			{
				if ( this.DdnlMonitorType.SelectedValue == "" )
				{
					ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "NO_MONITOR" ) );
					return false;
				}
			}

			//������ �϶�
			if ( this.LblCPUType.Text == "BNWP" ||
				this.LblCPUType.Text == "BSAP" ||
				this.LblCPUType.Text == "CNWP" ||
				this.LblCPUType.Text == "CSAP" ||
				this.LblCPUType.Text == "BNP2" ||
				this.LblCPUType.Text == "BNP3" ||
				this.LblCPUType.Text == "BNP4" 
				)
			{
				if ( this.DdnlCPUType.SelectedValue == "BNWP" ||
					this.DdnlCPUType.SelectedValue == "BSAP" ||
					this.DdnlCPUType.SelectedValue == "CNWP" ||
					this.DdnlCPUType.SelectedValue == "CSAP" ||
					this.DdnlCPUType.SelectedValue == "BNP2" ||
					this.DdnlCPUType.SelectedValue == "BNP3" ||
					this.DdnlCPUType.SelectedValue == "BNP4"
					)
				{
					return true;
				}
				else
				{
					ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "CHAGNE_CPU_TYPE" ) );
					return false;
				}
			}

			return true;
		}

		private void UpdateAsset()
		{
			ICMSDS ds = new ICMSDS();
			ds.EnforceConstraints = false;
			ICMSDS.TB_ICMS_ASSETRow dr = ds.TB_ICMS_ASSET.NewTB_ICMS_ASSETRow();

			dr.TicketNo = this.TbxTicketNo.Text;
			dr.AssetNo = this.TbxAssetNo.Text;
			dr.ParentAssetNo = this.TbxParentAssetNo.Text;
			dr.Make = this.TbxManufacturer.Text;
			dr.ModelNo = this.TbxModelNumber.Text;
			dr.SerialNo = this.TbxSerial.Text;
			dr.PONumber = this.TbxPONumber.Text;
			dr.ParentAssetType = this.DdnlParentAssetType.SelectedValue;
			dr.Status = this.DdnlStatus.SelectedValue;
			dr.AssetType = this.DdnlClassID.SelectedValue;
			dr.CPUType = this.DdnlCPUType.SelectedValue;
			dr.MonitorType = this.DdnlMonitorType.SelectedValue;

			ds.TB_ICMS_ASSET.AddTB_ICMS_ASSETRow( dr );

			ICMSController.UpdateICMSAsset( ds );
		}

		private void BtnClose_Click(object sender, System.EventArgs e)
		{
			NavigationHelper.Close( false );
		}
	}
}
