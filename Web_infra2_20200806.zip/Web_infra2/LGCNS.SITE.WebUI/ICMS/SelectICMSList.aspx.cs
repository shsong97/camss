using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Paging;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;



namespace LGCNS.SITE.WebUI.ICMS
{
	/// <summary>
	/// SelectICMSList�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectICMSList : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected System.Web.UI.WebControls.DropDownList DdnlEngineer;
		protected System.Web.UI.WebControls.TextBox TbxPageSize;
		protected System.Web.UI.WebControls.Label LblTotalCount;
		protected System.Web.UI.WebControls.DropDownList DdlPage;
		protected System.Web.UI.WebControls.Label LblTotalPages;
		protected System.Web.UI.WebControls.Button BtnSearch;
		protected System.Web.UI.WebControls.Button BtnClear;
		protected System.Web.UI.WebControls.Button BtnSaveExcel;
		protected System.Web.UI.WebControls.DropDownList DdnlConfirmFlag;
		protected System.Web.UI.WebControls.DropDownList DdnlServiceType;
		protected System.Web.UI.WebControls.TextBox TbxAssetNo;
		protected System.Web.UI.WebControls.TextBox TbxEmpNo;
		protected System.Web.UI.WebControls.TextBox TbxActivityDateFrom;
		protected System.Web.UI.WebControls.TextBox TbxActivityDateTo;
		protected System.Web.UI.WebControls.TextBox TbxConfirmDateFrom;
		protected System.Web.UI.WebControls.TextBox TbxConfirmDateTo;
		protected System.Web.UI.WebControls.TextBox TbxEmpName;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected System.Web.UI.WebControls.DropDownList DdnlBill;
		protected System.Web.UI.WebControls.Button BtnRefresh;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos(true);

			NavigationHelper.RegisterHiddenIFrame ("HiddenFrame") ;
			NavigationHelper.SetNavigation (this.BtnSaveExcel, "HiddenFrame", "SelectICMSListAsXls.aspx", true) ;
			NavigationHelper.SetNavigation (this.BtnRefresh, "HiddenFrame", "SelectRefreshListAsXls.aspx", true) ;

			this.DgrdDataGrid.NavigateOnRowClick (
				"", // �̵��� �����Ӹ�, ��������ü�� �̵��Ҷ� ""�� �����Ѵ�.
				"SelectICMS.aspx", // LinkŬ���� �̵��� Url  (����ȸȭ��)
				new string [1] {"TicketNo"},  // LinkŬ���� ������ Query String �� key�� �迭
				new int [1] {0}, // LinkŬ���� ������ Query String �� value���� ������ Cell Index�� �迭
				false  // // ������������ ���� SelectTicket.aspx ���� submit��Ų��. (POST������� ȣ���Ѵ�.)
				) ;
			
			XjosHelper.SetValidator (this.TbxActivityDateFrom,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);
			XjosHelper.SetValidator (this.TbxActivityDateTo,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);
			XjosHelper.SetValidator (this.TbxConfirmDateFrom,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);
			XjosHelper.SetValidator (this.TbxConfirmDateTo,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);

			XjosHelper.ValidateOnClick(this.BtnSearch); // Xjos Validation�� ������ ��ư ����

			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if ( !Page.IsPostBack )
			{
				InitializeControls();
				//SearchICMSListPaging();
			}

			if ( this.IsSubmittedBy )
			{
				InitializeControls();
				//SearchICMSListPaging();
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
			this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void InitializeControls()
		{
			InitializeControls( false );
		}

		private void InitializeControls(bool isClear)
		{
			this.TbxTicketNo.Text = "";
			this.TbxAssetNo.Text = "";
			this.TbxEmpNo.Text = "";
			this.TbxEmpName.Text = "";


			this.LblTotalCount.Text = "0";
			this.LblTotalPages.Text = "1";

			LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea, true );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlServiceType, "SERVICE_TYPE", true );
			LGCNS.SITE.Common.WebUI.UserInfo.BindDropDownList( this.DdnlEngineer, true );

			this.TbxActivityDateFrom.Text = "";
			this.TbxActivityDateTo.Text = "";
			this.TbxConfirmDateFrom.Text = "";
			this.TbxConfirmDateTo.Text = "";
			this.DdnlConfirmFlag.SelectedValue = "";

			ICMSDS ds = new ICMSDS();
			this.DgrdDataGrid.ShowFooterMessage = true;
			this.DgrdDataGrid.FooterMessage = MessageManager.GetMessage( "Common", "NO_DATA" );
			this.DgrdDataGrid.DataSource = ds.Tables["TB_ICMS_LIST"];
			this.DgrdDataGrid.DataBind();

			if ( !isClear )
			{
				if ( this.CurrentUserAuthority.CompareTo( "T" ) == 0 )
				{
					this.DdnlEngineer.SelectedValue = this.CurrentUserAlterUserID;
					this.DdnlConfirmFlag.SelectedValue = "N";
					SearchICMSListPaging();
				}
			}
		}

		private void BtnClear_Click(object sender, System.EventArgs e)
		{
			InitializeControls( true );
		}

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			SearchICMSListPaging();
		}

		private void SearchICMSListPaging()
		{
			NameValueCollection searchCondition = new NameValueCollection();
			searchCondition["TicketNo"] = this.TbxTicketNo.Text;
			searchCondition["AssetNo"] = this.TbxAssetNo.Text;
			searchCondition["EmpNo"] = this.TbxEmpNo.Text;
			searchCondition["EmpName"] = this.TbxEmpName.Text;
			searchCondition["Engineer"] = this.DdnlEngineer.SelectedValue;
			searchCondition["Servicetype"] = this.DdnlServiceType.SelectedValue;
			searchCondition["ConfirmFlag"] = this.DdnlConfirmFlag.SelectedValue;
			searchCondition["ActivityDateFrom"] = this.TbxActivityDateFrom.Text;
			searchCondition["ActivityDateTo"] = this.TbxActivityDateTo.Text;
			searchCondition["ConfirmDateFrom"] = this.TbxConfirmDateFrom.Text;
			searchCondition["ConfirmDateTo"] = this.TbxConfirmDateTo.Text;
			searchCondition["Area"] = this.DdnlArea.SelectedValue;
			searchCondition["Bill"] = this.DdnlBill.SelectedValue;

			int currentPage = Convert.ToInt32(this.DdlPage.SelectedValue);
			int pageSize	= Convert.ToInt32(this.TbxPageSize.Text);

			ICMSDS ds = ICMSController.SelectICMSList( currentPage, pageSize, "", searchCondition );
			this.DgrdDataGrid.VirtualItemCount = 100 ;
			this.DgrdDataGrid.DataSource = ds.Tables["TB_ICMS_LIST"];
			this.DgrdDataGrid.DataBind() ;

			//��Ͽ� ���� ����
			int totalPage			= PagingHelper.GetTotalPage (ds) ;
			this.LblTotalCount.Text = PagingHelper.GetTotalCount (ds).ToString () ;
			this.LblTotalPages.Text = totalPage.ToString() ;

			//Page DropDownList Setting
			this.DdlPage.Items.Clear();
			for(int i = 1; i <= totalPage ; i++)
			{
				this.DdlPage.Items.Add(i.ToString());
			}

			//�������� ������ ���õǵ���
			if(this.DdlPage.Items.Count > 0)
			{
				if( currentPage <= totalPage )
				{
					this.DdlPage.Items[currentPage - 1].Selected = true;
				}
				else
				{
					this.DdlPage.Items[0].Selected = true;
				}
			}
		}


	}
}
