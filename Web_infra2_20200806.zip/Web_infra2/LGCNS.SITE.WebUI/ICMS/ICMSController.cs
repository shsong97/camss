using System;
using System.Collections.Specialized;

using LGCNS.LAF.Web;
using LGCNS.SITE.DTO;
using LGCNS.SITE.ICMS.Biz;

namespace LGCNS.SITE.WebUI.ICMS
{
	/// <summary>
	/// ICMSController�� ���� ��� �����Դϴ�.
	/// </summary>
	public class ICMSController : ControllerBase
	{
		public ICMSController() {}
		

		#region ManageICMS

		public static void InsertICMS (ICMSDS ds)
		{
			ICMSBizTx biz = null ;

			try
			{
				biz = new ICMSBizTx();
				biz.InsertICMS (ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static void UpdateICMS (ICMSDS ds)
		{
			ICMSBizTx biz = null ;

			try
			{
				biz = new ICMSBizTx();
				biz.UpdateICMS(ds);
//				biz.DeleteICMSDetail(ds);
//				biz.InsertICMSDetail(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static void DeleteICMS (ICMSDS ds)
		{
			ICMSBizTx biz = null ;

			try
			{
				biz = new ICMSBizTx();
				biz.DeleteICMS(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		#endregion

		#region ManageICMSAsset

		public static void InsertICMSAsset (ICMSDS ds)
		{
			ICMSBizTx biz = null ;

			try
			{
				biz = new ICMSBizTx();
				biz.InsertICMSAsset (ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}
//20060525 lglsy - �ڻ��߰��ϸ鼭 detail ������ �߰��ϵ��� ������.
		public static void InsertICMSAssetDetail (ICMSDS ds)
		{
			ICMSBizTx biz = null ;
			
				try
				{
					biz = new ICMSBizTx();
					biz.InsertICMSAssetDetail (ds);
				}
				catch(Exception ex)
				{
					throw ex ;
				}
				finally
				{
					if(biz != null)
					{
						biz.Dispose () ;
						biz = null ;
					}
				}
		}

		public static void UpdateICMSAsset (ICMSDS ds)
		{
			ICMSBizTx biz = null ;

			try
			{
				biz = new ICMSBizTx();
				biz.UpdateICMSAsset(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}


		public static void DeleteICMSAsset (ICMSDS ds)
		{
			ICMSBizTx biz = null ;

			try
			{
				biz = new ICMSBizTx();
				biz.DeleteICMSAsset(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}


		#endregion

		#region SelectICMS

		public static ICMSDS SelectICMS(string TicketNo)
		{
			ICMSBizNTx biz = null ;
			ICMSDS ds = null ;

			try
			{
				biz = new ICMSBizNTx();
				ds = biz.SelectICMS(TicketNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}


		public static ICMSDS SelectICMSList( int currentPage, int pageSize, string order, NameValueCollection searchCondition )
		{
			ICMSBizNTx biz = null ;
			ICMSDS ds = null ;

			try
			{
				biz = new ICMSBizNTx();
				ds = biz.SelectICMSList(currentPage,pageSize,order,searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static ICMSDS SelectICMSListForXls( int currentPage, int pageSize, string order, NameValueCollection searchCondition )
		{
			ICMSBizNTx biz = null ;
			ICMSDS ds = null ;

			try
			{
				biz = new ICMSBizNTx();
				ds = biz.SelectICMSListForXls(currentPage,pageSize,order,searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static ICMSDS SelectICMSListForXls2( int currentPage, int pageSize, string order, NameValueCollection searchCondition )
		{
			ICMSBizNTx biz = null ;
			ICMSDS ds = null ;

			try
			{
				biz = new ICMSBizNTx();
				ds = biz.SelectICMSListForXls2(currentPage,pageSize,order,searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}
		public static ICMSDS SelectIMACICMSListForXls( int currentPage, int pageSize, string order, NameValueCollection searchCondition )
		{
			ICMSBizNTx biz = null ;
			ICMSDS ds = null ;

			try
			{
				biz = new ICMSBizNTx();
				ds = biz.SelectIMACICMSListForXls(currentPage,pageSize,order,searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static ICMSDS SelectRefreshListForXls( int currentPage, int pageSize, string order, NameValueCollection searchCondition )
		{
			ICMSBizNTx biz = null ;
			ICMSDS ds = null ;

			try
			{
				biz = new ICMSBizNTx();
				ds = biz.SelectRefreshListForXls(currentPage,pageSize,order,searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}
		
		#endregion

		public static bool isExistICMS( string TicketNo )
		{
			ICMSDS ds = SelectICMS( TicketNo );

			if ( ds.TB_ICMS.Count == 1 )
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		public static bool isExistICMSAsset ( string TicketNo )
		{
			ICMSDS ds = SelectICMSAsset( TicketNo );

			if ( ds.TB_ICMS_ASSET.Count > 0 )
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		public static ICMSDS SelectTicket(string TicketNo)
		{
			ICMSBizNTx biz = null ;
			ICMSDS ds = null ;

			try
			{
				biz = new ICMSBizNTx();
				ds = biz.SelectTicket(TicketNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}


		public static ICMSDS SelectICMSAsset(string TicketNo)
		{
			return SelectICMSAsset( TicketNo, "" );
		}

		public static ICMSDS SelectICMSAsset(string TicketNo,string AssetNo)
		{
			ICMSBizNTx biz = null ;
			ICMSDS ds = null ;

			try
			{
				biz = new ICMSBizNTx();
				ds = biz.SelectICMSAsset(TicketNo,AssetNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static ICMSDS SelectIMACList( string FromDate, string ToDate )
		{
			ICMSBizNTx biz = null ;
			ICMSDS ds = null ;

			try
			{
				biz = new ICMSBizNTx();
				ds = biz.SelectIMACList( FromDate, ToDate );
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}
		public static ICMSDS SelectAssetDetail(string AssetNo)
		{
			ICMSBizNTx biz = null ;
			ICMSDS ds = null ;

			try
			{
				biz = new ICMSBizNTx();
				ds = biz.SelectAssetDetail(AssetNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static ICMSDS SelectAssetList(string EmpNo, string TicketNo)
		{
			ICMSBizNTx biz = null ;
			ICMSDS ds = null ;

			try
			{
				biz = new ICMSBizNTx();
				ds = biz.SelectAssetList(EmpNo, TicketNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}


		public static void ConfirmICMS( string TicketNo, string UserID )
		{
			ICMSBizTx biz = null ;

			try
			{
				biz = new ICMSBizTx();
				biz.ConfirmICMS(TicketNo, UserID);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}
		
		public static void CancelICMS( string TicketNo, string UserID )
		{
			ICMSBizTx biz = null ;

			try
			{
				biz = new ICMSBizTx();
				biz.CancelICMS(TicketNo, UserID);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}



		#region Emp

		public static EmpDS SelectEmp(string Area, string EmpNo)
		{
			EmpDS ds = null;
			ICMSBizNTx biz = null;
			
			try
			{
				biz = new ICMSBizNTx();
				ds = biz.SelectEmp(Area,EmpNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}

		public static void UpdateEmp(EmpDS ds)
		{
			ICMSBizTx biz = null;
			
			try
			{
				biz = new ICMSBizTx () ;
				biz.UpdateEmp(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}
		}

		#endregion

		#region User
		public static UserDS SelectUser(string UserID)
		{
			UserDS ds = null;
			ICMSBizNTx biz = null;
			
			try
			{
				biz = new ICMSBizNTx();
				ds = biz.SelectUser(UserID);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}

		#endregion


		#region Site

		public static CodeDS SelectSite( string Area, string SiteCode )
		{
			CodeDS ds = null;
			ICMSBizNTx biz = null;
			
			try
			{
				biz = new ICMSBizNTx();
				ds = biz.SelectSite( Area, SiteCode );
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}

		public static string getBuildingInfo( string Area, string SiteCode )
		{
			CodeDS ds = SelectSite( Area, SiteCode );
			CodeDS.TB_SITERow dr = ds.TB_SITE[0];

			return dr.SvcLevel + "-" + dr.BuildingCode;
		}

		public static string getSiteInfo( string Area, string SiteCode )
		{
			CodeDS ds = SelectSite( Area, SiteCode );
			CodeDS.TB_SITERow dr = ds.TB_SITE[0];

			return dr.SiteCode + " " + dr.LocationName;
		}

		#endregion

		#region Asset

		public static AssetDS SelectAsset( string AssetNo )
		{
			AssetDS ds = null;
			ICMSBizNTx biz = null;
			
			try
			{
				biz = new ICMSBizNTx();
				ds = biz.SelectAsset( AssetNo );
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds ;
		}

		public static bool isExistAsset( string AssetNo )
		{
			bool isExist = false;
			
			AssetDS ds = null;

			try
			{
				ds = SelectAsset( AssetNo );

				if ( ds.Tables["TB_ASSET"].Rows.Count > 0 )
				{
					isExist = true;
				}
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(ds!=null)
				{
					ds.Dispose();
					ds = null;
				}
			}

			return isExist;
		}

		#endregion
	}
}
