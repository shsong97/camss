using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;



namespace LGCNS.SITE.WebUI.ICMS
{
	/// <summary>
	/// SelectICMS�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectICMS : LGCNS.SITE.Common.SITEPageBase
	{
		#region Controls

		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected System.Web.UI.WebControls.TextBox TbxActivityDate;
		protected System.Web.UI.WebControls.DropDownList DdnlBillingType;
		protected System.Web.UI.WebControls.DropDownList DdnlServiceType;
		protected System.Web.UI.WebControls.DropDownList DdnlCountry;
		protected System.Web.UI.WebControls.DropDownList DdnlSiteCode;
		protected System.Web.UI.WebControls.TextBox TbxFloor;
		protected System.Web.UI.WebControls.TextBox TbxComments;
		protected System.Web.UI.WebControls.TextBox TbxTechName;
		protected System.Web.UI.WebControls.TextBox TbxTechContactNo;
		protected System.Web.UI.WebControls.TextBox TbxTechID;
		protected System.Web.UI.WebControls.TextBox TbxEmpNo;
		protected System.Web.UI.WebControls.TextBox TbxFirstName;
		protected System.Web.UI.WebControls.TextBox TbxLastName;
		protected System.Web.UI.WebControls.TextBox TbxContactNo;
		protected System.Web.UI.WebControls.TextBox TbxLoginID;
		protected System.Web.UI.WebControls.TextBox TbxDept;
		protected System.Web.UI.WebControls.TextBox TbxDeptCode;
		protected System.Web.UI.WebControls.TextBox TbxAssetNo;
		protected System.Web.UI.WebControls.TextBox TbxCPUSpeed;
		protected System.Web.UI.WebControls.DropDownList DdnlOPSystem;
		protected System.Web.UI.WebControls.TextBox TbxMemory;
		protected System.Web.UI.WebControls.TextBox TbxHDDSize;
		protected System.Web.UI.WebControls.TextBox TbxNoCPU;
		protected System.Web.UI.WebControls.TextBox TbxHostName;
		protected System.Web.UI.WebControls.TextBox TbxMACAddress;
		protected System.Web.UI.WebControls.TextBox TbxIPAddress;
		protected System.Web.UI.WebControls.Panel PnlICMSDetail;
		protected System.Web.UI.WebControls.DropDownList DdnlRRS;
		protected System.Web.UI.WebControls.DropDownList DdnlHDDFormat;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdICMSAsset;
		protected System.Web.UI.WebControls.Button BtnUpdate;
		protected System.Web.UI.WebControls.Button BtnPrint;
		protected System.Web.UI.WebControls.TextBox TbxCreateID;
		protected System.Web.UI.WebControls.TextBox TbxCreateDate;
		protected System.Web.UI.WebControls.TextBox TbxUpdateID;
		protected System.Web.UI.WebControls.TextBox TbxUpdateDate;
		protected System.Web.UI.WebControls.TextBox TbxConfirmFlag;
		protected System.Web.UI.WebControls.Button BtnConfirm;
		protected System.Web.UI.WebControls.Button BtnDelete;
		protected System.Web.UI.WebControls.TextBox TbxConfirmID;
		protected System.Web.UI.WebControls.TextBox TbxConfirmDate;
		protected System.Web.UI.WebControls.Label LblArea;
		protected System.Web.UI.WebControls.Label LblBuildingInfo;
		protected System.Web.UI.WebControls.Button BtnConfirmCancel;
		protected System.Web.UI.WebControls.DropDownList DdnlNCon;
		protected System.Web.UI.WebControls.Button BtnCancel;

		#endregion
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			XjosHelper.RegisterXjos(true);

			NavigationHelper.SetNavigation( this.BtnUpdate,
				"",
				"UpdateICMS.aspx",
				true
			);
			ScriptHelper.SetConfirmMessageOn( this.BtnConfirm,
				MessageManager.GetMessage( "Common", "CONFIRM_QUESTION" )
			);
			ScriptHelper.SetConfirmMessageOn( this.BtnDelete,
				MessageManager.GetMessage( "Common", "DELETE_QUESTION" )
			);
			NavigationHelper.SetHistoryBack( this.BtnCancel );
			NavigationHelper.SetPopupWindow( this.BtnPrint,
				"PrintICMS.aspx",
				"PrintICMS",
				1000, 600,
				true
			);

			if( !this.IsPostBack )
			{
				BindICMSAll( this.Request["TicketNo"] );
			}
			if ( this.IsSubmittedBy )
			{
				BindICMSAll( this.Request["TicketNo"] );
			}

            ClientScript.RegisterHiddenField( "TicketNo", this.TbxTicketNo.Text );

			if ( this.TbxConfirmFlag.Text == "Y" )
			{
				this.BtnUpdate.Visible = false;
				this.BtnConfirm.Visible = false;
				this.BtnDelete.Visible = false;
				if ( this.CurrentUserAuthority.CompareTo( "A" ) == 0 )
				{
					this.BtnConfirmCancel.Visible=true;
				}
				else
				{
					this.BtnConfirmCancel.Visible=false;
				}
			}

			if ( this.CurrentUserAuthority.CompareTo( "A" ) > 0 )
			{
				this.BtnConfirm.Visible = false;
				this.BtnDelete.Visible = false;
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnConfirm.Click += new System.EventHandler(this.BtnConfirm_Click);
			this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
			this.BtnConfirmCancel.Click += new System.EventHandler(this.BtnConfirmCancel_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		#region Search

		private void BindICMSAll( string TicketNo )
		{
			InitialContorls();

			ICMSDS ds = ICMSController.SelectICMS( TicketNo );
			ds.EnforceConstraints = false;

			BindICMS( ds );
			BindICMSAsset( ds );
			BindICMSDetail( ds );
		}

		private void InitialContorls()
		{
			this.BtnConfirmCancel.Visible=false;
		}

		private void BindICMS ( ICMSDS ds )
		{

			ICMSDS.TB_ICMSRow dr = ds.TB_ICMS[0];

			this.LblArea.Text = dr.Area;
			
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlServiceType, "SERVICE_TYPE" );
			LGCNS.SITE.Common.WebUI.SiteInfo.BindDropDownList( this.DdnlSiteCode, dr.Area, false, true );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlOPSystem, "OP_SYSTEM", true );

			this.TbxTicketNo.Text = dr.TicketNo;
			this.TbxActivityDate.Text = dr.ActivityDate.ToShortDateString() + " " + dr.ActivityDate.ToShortTimeString();
			this.DdnlBillingType.SelectedValue = dr.BILL;
			this.DdnlServiceType.SelectedValue = dr.ServiceType;
			this.DdnlCountry.SelectedValue = dr.Country.Trim();
			this.DdnlSiteCode.SelectedValue = dr.SiteCode;
			this.TbxFloor.Text = dr.Floor;
			this.LblBuildingInfo.Text = "( " + ICMSController.getBuildingInfo( dr.Area, dr.SiteCode ) + " )";
			this.TbxComments.Text = dr.Comments;

			this.TbxTechID.Text = dr.TechnicianID;
			this.TbxTechName.Text = dr.TechnicianName;
			this.TbxTechContactNo.Text = dr.TechnicianContactNo;

			this.TbxEmpNo.Text = dr.EmpNo;
			this.TbxFirstName.Text = dr.FirstName;
			this.TbxLastName.Text = dr.LastName;
			this.TbxContactNo.Text = dr.EmpContactNo;
			this.TbxLoginID.Text = dr.LoginID;
			//this.TbxDept.Text = LGCNS.SITE.Common.WebUI.DeptInfo.getDeptNameEng( dr.Area, dr.DeptCode );
			this.TbxDept.Text = LGCNS.SITE.Common.WebUI.DeptInfo.getDeptName( dr.Area, dr.DeptCode );
			
			this.TbxDeptCode.Text = dr.DeptCode;

			this.DdnlRRS.SelectedValue = dr.RRSAgent;
			this.DdnlHDDFormat.SelectedValue = dr.HDDFormat;

			this.TbxCreateID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.CreateID );
			
			this.TbxCreateDate.Text = dr.CreateDate.ToShortDateString() + " " + dr.CreateDate.ToShortTimeString();
			this.TbxUpdateID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.UpdateID );
			this.TbxUpdateDate.Text = dr.UpdateDate.ToShortDateString() + " " + dr.UpdateDate.ToShortTimeString();

			this.TbxConfirmFlag.Text = dr.ConfirmFlag;
			if ( !dr.IsConfirmIDNull() )
				this.TbxConfirmID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.ConfirmID );
			if ( !dr.IsConfirmDateNull() )
				this.TbxConfirmDate.Text = dr.ConfirmDate.ToShortDateString() + " " + dr.ConfirmDate.ToShortTimeString();
		}

		private void BindICMSAsset( ICMSDS ds )
		{
			this.DgrdICMSAsset.DataSource = ds.TB_ICMS_ASSET;
			this.DgrdICMSAsset.DataBind();
		}

		private void BindICMSDetail( ICMSDS ds )
		{
			ICMSDS.TB_ICMS_DETAILRow dr = ds.TB_ICMS_DETAIL[0];
			
			this.DdnlNCon.Items.Add("Y");
			this.DdnlNCon.Items.Add("N");
			
			this.TbxAssetNo.Text = dr.AssetNo;
			this.TbxCPUSpeed.Text = dr.CPUSpeed;
			this.DdnlOPSystem.SelectedValue = dr.OPSystem;
			this.TbxMemory.Text = dr.TotalMemory;
			this.TbxHDDSize.Text = dr.HDDSize;
			this.TbxNoCPU.Text = dr.NoCPU;
			this.TbxHostName.Text = dr.HostName;
			this.TbxMACAddress.Text = dr.MACAddress;
			this.TbxIPAddress.Text = dr.IPAddress;
			if (dr.NCon == "Y") 
			{
				this.DdnlNCon.SelectedValue = dr.NCon;
			}
			else
			{
				this.DdnlNCon.SelectedValue = "N";
			}

//			this.DdnlNCon.SelectedValue = dr.NCon;
//			this.PnlICMSDetail.Visible = true;
//��ȸ�� Detail������ ��� ������ ����. 20060706 lglsy
			if ( this.TbxAssetNo.Text.Trim().Length > 0 )
			{
				this.PnlICMSDetail.Visible = true;
			}
			else // ������ �Ⱥ��̵��� ��. 20060706 lglsy
			{
				this.PnlICMSDetail.Visible = false;
			}
		}


		#endregion


		private void BtnConfirm_Click(object sender, System.EventArgs e)
		{
			ICMSController.ConfirmICMS( this.TbxTicketNo.Text, this.CurrentUserID );

			NavigationHelper.Redirect(
				MessageManager.GetMessage( "Common", "CONFIRM_DONE" ),
				"",
				"SelectICMS.aspx?TicketNo=" + this.TbxTicketNo.Text
			);
		}

		private void BtnDelete_Click(object sender, System.EventArgs e)
		{
			ICMSDS ds = new ICMSDS();
			ds.EnforceConstraints = false;
			ICMSDS.TB_ICMSRow drICMS = ds.TB_ICMS.NewTB_ICMSRow();
			drICMS.TicketNo = this.TbxTicketNo.Text;
			ds.TB_ICMS.AddTB_ICMSRow( drICMS );

			ICMSController.DeleteICMS( ds );

			NavigationHelper.Redirect(
				MessageManager.GetMessage( "Common", "DELETE_DONE" ),
				"",
				"SelectICMSList.aspx"
				);
		}

		private void BtnConfirmCancel_Click(object sender, System.EventArgs e)
		{
			ICMSController.CancelICMS( this.TbxTicketNo.Text, this.CurrentUserID );

			NavigationHelper.Redirect(
				MessageManager.GetMessage( "Common", "CONFIRM_CANCEL_DONE" ),
				"",
				"SelectICMS.aspx?TicketNo=" + this.TbxTicketNo.Text
			);
		}
	}
}
