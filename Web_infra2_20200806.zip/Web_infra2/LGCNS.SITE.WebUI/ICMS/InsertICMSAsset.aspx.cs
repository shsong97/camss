using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;



using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.ICMS
{
	/// <summary>
	/// InsertICMSAsset�� ���� ��� �����Դϴ�.
	/// </summary>
	public class InsertICMSAsset : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected System.Web.UI.WebControls.TextBox TbxAssetNo;
		protected System.Web.UI.WebControls.TextBox TbxParentAssetNo;
		protected System.Web.UI.WebControls.TextBox TbxManufacturer;
		protected System.Web.UI.WebControls.TextBox TbxSerial;
		protected System.Web.UI.WebControls.TextBox TbxPONumber;

		protected System.Web.UI.WebControls.DropDownList DdnlParentAssetType;
		protected System.Web.UI.WebControls.DropDownList DdnlStatus;
		protected System.Web.UI.WebControls.DropDownList DdnlCPUType;
		protected System.Web.UI.WebControls.DropDownList DdnlMonitorType;
		protected System.Web.UI.WebControls.DropDownList DdnlClassID;
		
		protected System.Web.UI.WebControls.ImageButton IbtnSearchAsset;
		protected System.Web.UI.WebControls.ImageButton IbtnSearchModel;
		
		
		protected System.Web.UI.WebControls.Button BtnSave;
		protected System.Web.UI.WebControls.Panel pnlParentAssetType;
		protected System.Web.UI.WebControls.Panel Panel1;
		protected System.Web.UI.WebControls.TextBox TbxModelNumber1;
		protected System.Web.UI.WebControls.TextBox TbxModelNumber;
		protected System.Web.UI.WebControls.Button BtnClose;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }
            
			XjosHelper.RegisterXjos(true);

			NavigationHelper.SetPopupWindow(
				this.IbtnSearchModel,
				"../Code/SelectModelList.aspx",
				"SearchModel",
				1000, 600,
				false
				);
			SetValidator();

			if ( !this.IsPostBack )
			{
				this.TbxTicketNo.Text = this.Request["TicketNo"];
				this.TbxAssetNo.Text = "";
				InitializeControls();
			}
			if ( this.IsSubmittedBy )
			{
				this.TbxTicketNo.Text = this.Request["TicketNo"];
				this.TbxAssetNo.Text = "";
				InitializeControls();
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.IbtnSearchAsset.Click += new System.Web.UI.ImageClickEventHandler(this.IbtnSearchAsset_Click);
			this.TbxModelNumber.TextChanged += new System.EventHandler(this.TbxModelNumber_TextChanged);
			this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
			this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void SetValidator()
		{
			XjosHelper.SetValidator( 
				this.TbxAssetNo,
				new XjosValidator( XjosValidatorType.Required )
				);
            this.TbxAssetNo.MaxLength = 8;

			XjosHelper.SetValidator( 
				this.TbxParentAssetNo,
				new XjosValidator( XjosValidatorType.Required )
				);
			this.TbxParentAssetNo.MaxLength = 8;
			
			XjosHelper.SetValidator(
				this.TbxManufacturer,
				new XjosValidator( XjosValidatorType.Required )
				);
			XjosHelper.SetValidator(
				this.TbxModelNumber,
				new XjosValidator( XjosValidatorType.Required )
			);
			XjosHelper.SetValidator(
				this.TbxModelNumber1,
				new XjosValidator( XjosValidatorType.Required )
				);

			XjosHelper.SetValidator(
				this.TbxSerial,
				new XjosValidator( XjosValidatorType.Required )
				);

			//�ű��ڻ��϶���,
			if( this.Request["DdnlServiceType"] == "ST01" )
			{
				XjosHelper.SetValidator(
					this.TbxPONumber,
					new XjosValidator( XjosValidatorType.Required )
					);
			}
			XjosHelper.ValidateOnClick ( 
				this.BtnSave,
				MessageManager.GetMessage("Common", "REGISTER_QUESTION")
				) ;
		}

		private void InitializeControls()
		{
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlParentAssetType, "ASSET_TYPE", true );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlStatus, "COMP_STATUS" );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlClassID, "CLASS_ID" );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlCPUType, "CPU_TYPE" );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlMonitorType, "MONITOR_TYPE", true );
		}

		private void IbtnSearchAsset_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			//Validation �߰�
			if ( this.TbxAssetNo.Text.Length == 0 )
			{
				ScriptHelper.ShowAlert(
					MessageManager.GetMessage( "ICMS", "INPUT_ASSETNO" )
				);
				return;
			}
			if( this.TbxAssetNo.Text.Length != 8 )
			{
				ScriptHelper.ShowAlert(
					MessageManager.GetMessage( "ICMS", "INVALID_ASSETNO" )
				);
				return;
			}
			InitializeControls();
			BindIAsset( this.TbxAssetNo.Text );
		}

		private void BtnClose_Click(object sender, System.EventArgs e)
		{
			NavigationHelper.Close( false );
		}

		private void BtnSave_Click(object sender, System.EventArgs e)
		{
			if (this.TbxModelNumber.Text.Length < 1)
			{
				ScriptHelper.ShowAlert(	MessageManager.GetMessage( "ICMS", "NO_MODEL" ) );
			
				return;
			}

			SaveICMSAsset();
			NavigationHelper.Close( true );
		}

		private void BindIAsset( string AssetNo )
		{
			AssetDS ds = ICMSController.SelectAsset( AssetNo );

			if ( ds.TB_ASSET.Count == 1 )
			{
				AssetDS.TB_ASSETRow dr = ds.TB_ASSET[0];

				this.TbxAssetNo.Text = dr.AssetNo;
				this.TbxParentAssetNo.Text = dr.ParentAssetNo;
				this.TbxManufacturer.Text = dr.Manufacturer;
				this.TbxModelNumber.Text = dr.ModelNumber;
				this.TbxModelNumber1.Text = dr.ModelNumber;
				this.TbxSerial.Text = dr.SerialNumber;
				this.DdnlStatus.SelectedValue = dr.CompStatus;
				this.DdnlClassID.SelectedValue = dr.ClassID;
				this.DdnlCPUType.SelectedValue = dr.CPUType;
			}
			else
			{
				ScriptHelper.ShowAlert(	MessageManager.GetMessage( "Common", "NOT_EXIST" ) );
			}
		}

		private void SaveICMSAsset()
		{
			ICMSDS ds = new ICMSDS();
			ds.EnforceConstraints = false;
			ICMSDS.TB_ICMS_ASSETRow dr = ds.TB_ICMS_ASSET.NewTB_ICMS_ASSETRow();

			dr.TicketNo = this.TbxTicketNo.Text;
			dr.AssetNo = this.TbxAssetNo.Text;
			dr.ParentAssetNo = this.TbxParentAssetNo.Text;
			dr.Make = this.TbxManufacturer.Text;
			dr.ModelNo = this.TbxModelNumber.Text;
			dr.SerialNo = this.TbxSerial.Text;
			dr.PONumber = this.TbxPONumber.Text;
			dr.ParentAssetType = this.DdnlParentAssetType.SelectedValue;
			dr.Status = this.DdnlStatus.SelectedValue;
			dr.AssetType = this.DdnlClassID.SelectedValue;
			dr.CPUType = this.DdnlCPUType.SelectedValue;
			dr.MonitorType = this.DdnlMonitorType.SelectedValue;

			ds.TB_ICMS_ASSET.AddTB_ICMS_ASSETRow( dr );

			ICMSController.InsertICMSAsset( ds );
		}

		private void TbxModelNumber_TextChanged(object sender, System.EventArgs e)
		{
			this.TbxModelNumber1.Text = this.TbxModelNumber.Text;
		}
	}
}
