using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.ICMS
{
	/// <summary>
	/// InsertICMS�� ���� ��� �����Դϴ�.
	/// </summary>
	public class InsertICMS : LGCNS.SITE.Common.SITEPageBase
	{
		#region Controls

		protected System.Web.UI.WebControls.Button BtnSave;
		protected System.Web.UI.WebControls.TextBox TbxTechName;
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected System.Web.UI.WebControls.DropDownList DdnlRRS;
		protected System.Web.UI.WebControls.DropDownList DdnlHDDFormat;
		protected System.Web.UI.WebControls.TextBox TbxActivityDate;
		protected System.Web.UI.WebControls.DropDownList DdnlBillingType;
		protected System.Web.UI.WebControls.DropDownList DdnlCountry;
		protected System.Web.UI.WebControls.DropDownList DdnlSiteCode;
		protected System.Web.UI.WebControls.TextBox TbxTechContactNo;
		protected System.Web.UI.WebControls.DropDownList DdnlServiceType;
		protected System.Web.UI.WebControls.TextBox TbxFloor;
		protected System.Web.UI.WebControls.TextBox TbxComments;
		protected System.Web.UI.WebControls.TextBox TbxEmpNo;
		protected System.Web.UI.WebControls.TextBox TbxFirstName;
		protected System.Web.UI.WebControls.TextBox TbxLastName;
		protected System.Web.UI.WebControls.TextBox TbxContactNo;
		protected System.Web.UI.WebControls.TextBox TbxLoginID;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdICMSAsset;
		protected System.Web.UI.WebControls.TextBox TbxAssetNo;
		protected System.Web.UI.WebControls.ImageButton IbtnSearchDetail;
		protected System.Web.UI.WebControls.TextBox TbxCPUSpeed;
		protected System.Web.UI.WebControls.DropDownList DdnlOPSystem;
		protected System.Web.UI.WebControls.TextBox TbxMemory;
		protected System.Web.UI.WebControls.TextBox TbxNoCPU;
		protected System.Web.UI.WebControls.TextBox TbxHostName;
		protected System.Web.UI.WebControls.TextBox TbxMACAddress;
		protected System.Web.UI.WebControls.TextBox TbxIPAddress;
		protected System.Web.UI.WebControls.TextBox TbxTechID;
		protected System.Web.UI.WebControls.Button BtnAddAsset;
		protected System.Web.UI.WebControls.Button BtnNewAsset;
		protected System.Web.UI.WebControls.TextBox TbxHDDSize;
		protected System.Web.UI.WebControls.Panel PnlICMSDetail;
		protected System.Web.UI.WebControls.DropDownList DdnlDeptCode;
		protected System.Web.UI.WebControls.Label LblArea;
		protected System.Web.UI.WebControls.Label LblBuildingInfo;
		protected System.Web.UI.WebControls.DropDownList DdnlNCon;
		protected System.Web.UI.WebControls.Button BtnCancel;

		#endregion

		private void SetNavigation()
		{
			NavigationHelper.SetPopupWindow( this.BtnAddAsset,
				"SelectICMSAsset.aspx",
				"SelectAsset",
				1000, 500,
				true
				);

			NavigationHelper.SetPopupWindow( this.BtnNewAsset,
				"InsertICMSAsset.aspx",
				"InsertAsset",
				600, 400,
				true
				);

			this.DgrdICMSAsset.OpenWindowOnRowClick(
				"UpdateICMSAsset.aspx",
				"UpadteICMSAsset",
				600, 400,
				new string[2] { "TicketNo", "AssetNo" },
				new int[2] { 0, 1 },
				true
				);
		}
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }
			XjosHelper.RegisterXjos(true);

			string TicketNo = this.Request["TicketNo"];

			//�ش� Ticket�� ICMS�� ������ ���, ��ȸȭ������ �̵�
			if ( ICMSController.isExistICMS( TicketNo ) )
			{
				NavigationHelper.Redirect( "SelectICMS.aspx?TicketNo=" + TicketNo );
				return;
			}

			SetNavigation();
			
			if( !this.IsPostBack )
			{
				BindTicket(TicketNo);
				BindUser( this.CurrentUserID );
			}

			if ( this.IsSubmittedBy )
			{
				BindTicket(TicketNo);
				BindUser( this.CurrentUserID );
			}

			//�ش� ICMS�� Temp Asset Data ��ȸ
			BindICMSAsset( TicketNo );

			if( this.IsReloadedByPopup )
			{
				ReloadRequestData();
			}

			SetValidator();

			NavigationHelper.SetHistoryBack( this.BtnCancel );
			ScriptHelper.SetConfirmMessageOn( this.BtnSave, MessageManager.GetMessage( "Common", "REGISTER_QUESTION" ) );

            ClientScript.RegisterHiddenField("TicketNo", this.TbxTicketNo.Text );
            ClientScript.RegisterHiddenField("EmpNo", this.TbxEmpNo.Text );
//20060530 lglsy �ʱⰪ��
			if( this.DdnlOPSystem.SelectedValue == "" ) 
				this.DdnlOPSystem.SelectedValue ="OP15";
	

			if ( this.TbxAssetNo.Text.Length > 0 )
			{
				this.PnlICMSDetail.Visible = true;
			}
			else // ������ �Ⱥ��̵��� ��. 20060706 lglsy
			{
				this.PnlICMSDetail.Visible = false;
			}
		}

		private void ReloadRequestData()
		{
			this.TbxActivityDate.Text = this.Request["TbxActivityDate"];
			this.DdnlBillingType.SelectedValue = this.Request["DdnlBillingType"];
			this.DdnlServiceType.SelectedValue = this.Request["DdnlServiceType"];
			this.DdnlSiteCode.SelectedValue = this.Request["DdnlSiteCode"];
				
			this.TbxLastName.Text = this.Request["TbxLastName"];
			this.TbxFirstName.Text = this.Request["TbxFirstName"];
			this.TbxContactNo.Text = this.Request["TbxContactNo"];
			this.TbxLoginID.Text = this.Request["TbxLoginID"];
			this.DdnlDeptCode.SelectedValue = this.Request["DdnlDeptCode"];

			this.TbxFloor.Text = this.Request["TbxFloor"];
			this.TbxComments.Text = this.Request["TbxComments"];
			if ( isRequriedDetail() )
			{
				this.TbxAssetNo.Text = this.Request["TbxAssetNo"];
				this.TbxCPUSpeed.Text = this.Request["TbxCPUSpeed"];
				this.DdnlOPSystem.SelectedValue =  this.Request["DdnlOPSystem"];
				this.TbxMemory.Text = this.Request["TbxMemory"];
				this.TbxHDDSize.Text = this.Request["TbxHDDSize"];
				this.TbxNoCPU.Text = this.Request["TbxNoCPU"];
				this.TbxHostName.Text = this.Request["TbxHostName"];
				this.TbxMACAddress.Text = this.Request["TbxMACAddress"];
				this.TbxIPAddress.Text = this.Request["TbxIPAddress"];
				this.DdnlNCon.SelectedValue =  this.Request["DdnlNCon"];
			}
			else
			{
				this.TbxAssetNo.Text = "";
				this.TbxCPUSpeed.Text = "";
				this.DdnlOPSystem.SelectedValue = "OP15";
				this.TbxMemory.Text = "";
				this.TbxHDDSize.Text = "";
				this.TbxNoCPU.Text = "";
				this.TbxHostName.Text = "";
				this.TbxMACAddress.Text = "";
				this.TbxIPAddress.Text = "";					
				this.DdnlNCon.SelectedValue = "";
			}
				
			this.DdnlRRS.SelectedValue =  this.Request["DdnlRRS"];
			this.DdnlHDDFormat.SelectedValue =  this.Request["DdnlHDDFormat"];

			string AssetNo = strAssetNoOfRequriedDetail();
			this.TbxAssetNo.Text = AssetNo;

			if ( this.TbxAssetNo.Text.Length == 8 )
			{
				BindICMSDetail( AssetNo );
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
			this.IbtnSearchDetail.Click += new System.Web.UI.ImageClickEventHandler(this.IbtnSearchDetail_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		private bool isRequriedDetail()
		{
			if( this.DgrdICMSAsset.Items.Count == 1 )
			{
				//2005-05-18:�ڻ��� surplus�̸� ������ �ʴ´�.
				if("SRPL" == this.DgrdICMSAsset.Items[0].Cells[2].Text)
				{
					return false;
				}
				return true;
			}

			for( int inx=0; inx < this.DgrdICMSAsset.Items.Count; inx++ )
			{
				// Active�� �ڻ�
				if ( "A" == this.DgrdICMSAsset.Items[inx].Cells[2].Text )
				{
					//CPU_TYPE �� OP�� �����ϸ� Detail ������ �ݵ�� �Է��Ͽ��� ��
					//20060525 NETWORK PRINTER �߰���.
					if ( "OP" == this.DgrdICMSAsset.Items[inx].Cells[3].Text.Substring(0,2)  || "BN" == this.DgrdICMSAsset.Items[inx].Cells[3].Text.Substring(0,2) ) 
					{
						return true;
					}
				}
			}

			return false;
		}

		private string strAssetNoOfRequriedDetail()
		{
			string AssetNo = "";

			if( this.DgrdICMSAsset.Items.Count == 1 )
			{
//active �ڻ��϶��� AssetNo�� return �ϵ��� ��. 20060706 lglsy
				if ( "A" == this.DgrdICMSAsset.Items[0].Cells[2].Text )
				{
					AssetNo = this.DgrdICMSAsset.Items[0].Cells[1].Text;
					return AssetNo;
				}
				return AssetNo;
			}

			for( int inx=0; inx < this.DgrdICMSAsset.Items.Count; inx++ )
			{
				// Active�� �ڻ�
				if ( "A" == this.DgrdICMSAsset.Items[inx].Cells[2].Text )
				{
					//CPU_TYPE �� OP�� �����ϸ� Detail ������ �ݵ�� �Է��Ͽ��� ��
					//20060525 NETWORK PRINTER �߰���.
					if ( "OP" == this.DgrdICMSAsset.Items[inx].Cells[3].Text.Substring(0,2)  || "BN" == this.DgrdICMSAsset.Items[inx].Cells[3].Text.Substring(0,2) ) 
					{
						AssetNo = this.DgrdICMSAsset.Items[inx].Cells[1].Text;
						return AssetNo;
					}
				}
			}

			return AssetNo;
		}

		private void SetValidator()
		{
			XjosHelper.SetValidator (this.TbxActivityDate, new XjosValidator (XjosValidatorType.Date) );
			XjosHelper.SetValidator (this.TbxFloor, new XjosValidator( XjosValidatorType.Required ) );
			XjosHelper.SetValidator (this.TbxComments, new XjosValidator( XjosValidatorType.Required ) );
			XjosHelper.SetValidator (this.DdnlNCon, new XjosValidator( XjosValidatorType.Required ) );

			if ( isRequriedDetail() )
			{
				XjosHelper.SetValidator( this.TbxAssetNo,
					new XjosValidator( XjosValidatorType.Required ),
					new XjosValidator( XjosValidatorType.Minlength, "8", "" )
					);
				// 20060530 lglsy : �ڻ��� CLASS ID�� laptop, desktop, server, workstation�ΰ͸� Validation
				if(IsCheckAsset(-1))
				{
					XjosHelper.SetValidator (this.TbxCPUSpeed, new XjosValidator( XjosValidatorType.Required ) );
					XjosHelper.SetValidator (this.TbxMemory, new XjosValidator( XjosValidatorType.Required ) );
					XjosHelper.SetValidator (this.TbxHDDSize, new XjosValidator( XjosValidatorType.Required ) );
					XjosHelper.SetValidator (this.TbxHostName, new XjosValidator( XjosValidatorType.Required ) );
					XjosHelper.SetValidator (this.TbxMACAddress, new XjosValidator( XjosValidatorType.Required ) );
				}
			}
			this.TbxAssetNo.MaxLength = 8;

			XjosHelper.ValidateOnClick ( this.BtnSave ) ;
		}

		#region Search

		private void BindTicket ( string TicketNo )
		{
			ICMSDS ds = new ICMSDS();
			ds.EnforceConstraints = false;
            ds = ICMSController.SelectTicket( TicketNo );
			ICMSDS.TB_ICMSRow dr = ds.TB_ICMS[0];

			this.LblArea.Text = dr.Area;
			string Area = dr.Area;

			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlServiceType, "SERVICE_TYPE" );
			LGCNS.SITE.Common.WebUI.SiteInfo.BindDropDownList( this.DdnlSiteCode, Area, false, true );
			LGCNS.SITE.Common.WebUI.DeptInfo.BindDropDownList( this.DdnlDeptCode, Area );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlOPSystem, "OP_SYSTEM", true );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlNCon, "NET_CONNECT", true );

			this.TbxTicketNo.Text = dr.TicketNo;
			this.TbxActivityDate.Text = DateTime.Now.ToShortDateString();
			this.DdnlBillingType.SelectedValue = dr.BILL;
			this.DdnlSiteCode.SelectedValue = dr.SiteCode;
			this.TbxComments.Text = dr.Comments;

			this.TbxEmpNo.Text = dr.EmpNo;
			this.TbxFirstName.Text = dr.FirstName;
			this.TbxLastName.Text = dr.LastName;
			this.TbxContactNo.Text = dr.EmpContactNo;
			this.TbxLoginID.Text = dr.LoginID;
			this.DdnlDeptCode.SelectedValue = dr.DeptCode;
		}

		private void BindUser ( string UserID )
		{
			UserDS ds = ICMSController.SelectUser( UserID );
			UserDS.TB_USERRow dr = ds.TB_USER[0];

			this.TbxTechID.Text = dr.UserID;
			this.TbxTechName.Text = dr.UserNameEng;
			this.TbxTechContactNo.Text = dr.ContactNo;
		}

		private void BindICMSAsset( string TicketNo )
		{
			ICMSDS ds = null;

			if ( TicketNo == null )
			{
				ds = new ICMSDS();
			}
			else
			{
				ds = ICMSController.SelectICMSAsset( TicketNo );
			}

			this.DgrdICMSAsset.DataSource = ds.TB_ICMS_ASSET;
			this.DgrdICMSAsset.DataBind();
		}

		#endregion

		#region BindICMSDetail

		private void IbtnSearchDetail_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			if ( isValidAssetNo( this.TbxAssetNo.Text ) )
			{
				BindICMSDetail( this.TbxAssetNo.Text );
			}
		}

		private bool isValidAssetNo( string AssetNo )
		{
			for( int inx=0; inx < this.DgrdICMSAsset.Items.Count; inx++ )
			{
				if ( AssetNo == this.DgrdICMSAsset.Items[inx].Cells[1].Text )
				{
					return true;
				}
			}

			ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "NOT_EXIST_ASSET" ) );
			return false;
		}

		private void BindICMSDetail( string AssetNo )
		{
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlOPSystem, "OP_SYSTEM" );
			ICMSDS ds = ICMSController.SelectAssetDetail( AssetNo );
			if ( ds.TB_ICMS_DETAIL.Count == 1 )
			{
				ICMSDS.TB_ICMS_DETAILRow dr = ds.TB_ICMS_DETAIL[0];

				this.TbxCPUSpeed.Text = dr.CPUSpeed;
//				this.DdnlOPSystem.SelectedValue = dr.OPSystem;
//20060530 lglsy OPsystem �ʱⰪ
				if( dr.OPSystem == "" ) 
					this.DdnlOPSystem.SelectedValue ="OP15";
				else
					this.DdnlOPSystem.SelectedValue = dr.OPSystem;		
				this.TbxMemory.Text = dr.TotalMemory;
				this.TbxHDDSize.Text = dr.HDDSize;
				this.TbxNoCPU.Text = dr.NoCPU;
				this.TbxHostName.Text = dr.HostName;
				this.TbxMACAddress.Text = dr.MACAddress;
				this.TbxIPAddress.Text = dr.IPAddress;
			}

			this.PnlICMSDetail.Visible = true;
		}

		#endregion

		#region Save
		
		private void BtnSave_Click(object sender, System.EventArgs e)
		{
			if ( isValidation() )
			{
				SaveICMS();
		
				NavigationHelper.Redirect(
					MessageManager.GetMessage( "Common", "REGISTER_DONE" ),
					"",
					"SelectICMS.aspx?TicketNo=" + this.TbxTicketNo.Text
					);
			}
		}

		private bool isValidMonitor()
		{
			bool isValid = true;

			for( int inx=0; inx < this.DgrdICMSAsset.Items.Count; inx++ )
			{
				//CPU_TYPE �� OP�� �����ϸ� Detail ������ �ݵ�� �Է��Ͽ��� ��
				if ( "MNTR" == this.DgrdICMSAsset.Items[inx].Cells[3].Text )
				{
					//MonitorType
					if( this.DgrdICMSAsset.Items[inx].Cells[16].Text.Trim().Length != 4 )
					{
						isValid = false;
					}
				}
			}

			return isValid;
		}

		private bool isValidation()
		{
			if ( ! ICMSController.isExistICMSAsset( this.TbxTicketNo.Text ) )
			{
				ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "NO_ASSET" ) );
				return false;
			}

			int cntAsset = this.DgrdICMSAsset.Items.Count;

			if ( this.TbxFloor.Text.Length < 1 )
			{
				ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "NO_FLOOR" ) );
				return false;
			}

			if ( this.TbxFloor.Text.IndexOf( "F" ) != -1 )
			{
				ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "NOT_FLOOR" ) );
				return false;
			}

			if ( cntAsset < 1 )
			{
				ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "NO_ASSET" ) );
				return false;
			}
			for( int inx=0; inx < cntAsset; inx++ )
			{
				// Active�� �ڻ�
				if ( "A" == this.DgrdICMSAsset.Items[inx].Cells[2].Text )
				{
					//Active �ڻ��� ������ �� �ڻ� ��ȣ�� �־���Ѵ�. lglsy 20051216
					if ( this.TbxAssetNo.Text.Length != 8 )
					{
						ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "NO_DETAIL" ) );
						return false;
					}
					//CPU_TYPE �� OP�� �����ϸ� Detail ������ �ݵ�� �Է��Ͽ��� ��
					//20060525 NETWORK PRINTER �߰���.
					if ( "OP" == this.DgrdICMSAsset.Items[inx].Cells[3].Text.Substring(0,2)) 
					{
//						if ( this.TbxAssetNo.Text.Length != 8 ) // ���� ����. 
//						{
//							ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "NO_DETAIL" ) );
//							return false;
//						}

						if(IsCheckAsset(inx))
						{
							if ( this.TbxCPUSpeed.Text.Length < 1 )
							{
								ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "NO_CPUSpeed" ) );
								return false;
							}

							if ( this.DdnlOPSystem.SelectedValue == "" )
							{
								ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "NO_OPSystem" ) );
								return false;
							}

							if ( this.TbxMemory.Text.Length < 1 )
							{
								ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "NO_Memory" ) );
								return false;
							}

							if ( this.TbxHDDSize.Text.Length < 1 )
							{
								ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "NO_HDDSize" ) );
								return false;
							}

							if ( this.TbxMACAddress.Text.Length < 1 )
							{
								ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "NO_MACAddress" ) );
								return false;
							}

							if ( this.TbxHostName.Text.Length < 1 )
							{
								ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "NO_HostName" ) );
								return false;
							}
							//lglsy �߰�
							if ( this.DdnlNCon.SelectedValue.Length < 1 )
							{
								ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "NOT_NCON" ) );
								return false;
							}
						}
					}
//20060526 lglsy �����ϱ� ���ؼ��� OPSystem�� ������ ���� �־�� �Ѵ�.
					else
					{
						if ( this.DdnlOPSystem.SelectedValue == "" )
						{
							ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "NO_OPSystem" ) );
							return false;
						}
					}
				}
			}

			if( !isValidMonitor() )
			{
				ScriptHelper.ShowAlert( MessageManager.GetMessage( "ICMS", "NO_MONITOR_TYPE" ) );
				return false;
			}

			return true;
		}


		private void SaveICMS()
		{
			ICMSDS ds = new ICMSDS();
			ds.EnforceConstraints = false;

			setICMS( ds );
			setICMSDetail( ds );

			ICMSController.InsertICMS( ds );
			SaveEmp();
		}

		private void SaveEmp()
		{
			EmpDS ds = new EmpDS();
			EmpDS.TB_EMPRow dr = ds.TB_EMP.NewTB_EMPRow();

			dr.Area = this.LblArea.Text;
			dr.EmpNo = this.TbxEmpNo.Text;
			dr.EmpName = LGCNS.SITE.Common.WebUI.EmpInfo.getEmpName( dr.Area, this.TbxEmpNo.Text );
			
			dr.FirstName = this.TbxFirstName.Text;
			dr.LastName = this.TbxLastName.Text;
			dr.ContactNo = this.TbxContactNo.Text;
			dr.LoginID = this.TbxLoginID.Text;
			dr.DeptCode = this.DdnlDeptCode.SelectedValue;
			dr.SiteCode = this.DdnlSiteCode.SelectedValue;

			ds.TB_EMP.AddTB_EMPRow( dr );

			ICMSController.UpdateEmp( ds );
		}

		private void setICMS( ICMSDS ds )
		{
			ICMSDS.TB_ICMSRow dr = ds.TB_ICMS.NewTB_ICMSRow();

			dr.TicketNo = this.TbxTicketNo.Text;
			dr.ActivityDate = DateTime.Now;

			dr.BILL = this.DdnlBillingType.SelectedValue;
			dr.ServiceType = this.DdnlServiceType.SelectedValue;
			dr.Country = this.DdnlCountry.SelectedValue.Trim();
			
			dr.SiteCode = this.DdnlSiteCode.SelectedValue;

			dr.Floor = this.TbxFloor.Text.Replace( " ", "" );

			dr.TechnicianID = this.TbxTechID.Text;
			dr.TechnicianName = this.TbxTechName.Text;
			dr.TechnicianContactNo = this.TbxTechContactNo.Text;

			dr.EmpNo = this.TbxEmpNo.Text;
			dr.FirstName = this.TbxFirstName.Text;
			dr.LastName = this.TbxLastName.Text;
			dr.EmpContactNo = this.TbxContactNo.Text;
			
			dr.LoginID = this.TbxLoginID.Text;
			dr.DeptCode = this.DdnlDeptCode.SelectedValue;
			dr.Comments = this.TbxComments.Text;
			dr.RRSAgent = this.DdnlRRS.SelectedValue;
			dr.HDDFormat = this.DdnlHDDFormat.SelectedValue;

			dr.ConfirmFlag = "N";
			dr.CreateID = this.CurrentUserID;
			dr.CreateDate = DateTime.Now;
			dr.UpdateID = this.CurrentUserID;
			dr.UpdateDate = DateTime.Now;

			ds.TB_ICMS.AddTB_ICMSRow( dr );
		}

		private void setICMSDetail( ICMSDS ds )
		{
			ICMSDS.TB_ICMS_DETAILRow drDetail = ds.TB_ICMS_DETAIL.NewTB_ICMS_DETAILRow();

			drDetail.TicketNo = this.TbxTicketNo.Text;
			drDetail.AssetNo = this.TbxAssetNo.Text;
			drDetail.CPUSpeed = this.TbxCPUSpeed.Text;
			drDetail.OPSystem = this.DdnlOPSystem.SelectedValue;
			drDetail.TotalMemory = this.TbxMemory.Text;
			drDetail.HDDSize = this.TbxHDDSize.Text;
			drDetail.NoCPU = this.TbxNoCPU.Text;
			drDetail.HostName = this.TbxHostName.Text;
			drDetail.MACAddress = this.TbxMACAddress.Text;
			drDetail.IPAddress = this.TbxIPAddress.Text;
			drDetail.NCon = this.DdnlNCon.SelectedValue;

			ds.TB_ICMS_DETAIL.AddTB_ICMS_DETAILRow( drDetail );
		}

		#endregion
		private bool IsCheckAsset(int i)
		{
			string asset_type="";
			if(i<0)
			{
				for( int inx=0; inx < this.DgrdICMSAsset.Items.Count; inx++ )
				{
					// Active�� �ڻ�
					if ( "A" == this.DgrdICMSAsset.Items[inx].Cells[2].Text )
					{
						//CPU_TYPE �� OP�� �����ϸ� Detail ������ �ݵ�� �Է��Ͽ��� ��
						//20060525 NETWORK PRINTER �߰���.
						if ( "OP" == this.DgrdICMSAsset.Items[inx].Cells[3].Text.Substring(0,2)  || "BN" == this.DgrdICMSAsset.Items[inx].Cells[3].Text.Substring(0,2) ) 
						{
							asset_type=this.DgrdICMSAsset.Items[inx].Cells[12].Text;
							if(asset_type.CompareTo("CL01")==0 || asset_type.CompareTo("CL02")==0 
								|| asset_type.CompareTo("CL12")==0 || asset_type.CompareTo("CL15")==0)
							{// 2005-05-18 : �ڻ��� CLASS ID�� laptop, desktop, server, workstation�ΰ͸� Validation
								return true;
							}
						}
					}
				}
			}
			else
			{
				// Active�� �ڻ�
				if ( "A" == this.DgrdICMSAsset.Items[i].Cells[2].Text )
				{
					//CPU_TYPE �� OP�� �����ϸ� Detail ������ �ݵ�� �Է��Ͽ��� ��
					//20060525 NETWORK PRINTER �߰���.
					if ( "OP" == this.DgrdICMSAsset.Items[i].Cells[3].Text.Substring(0,2)  || "BN" == this.DgrdICMSAsset.Items[i].Cells[3].Text.Substring(0,2) ) 
					{
						asset_type=this.DgrdICMSAsset.Items[i].Cells[12].Text;
						if(asset_type.CompareTo("CL01")==0 || asset_type.CompareTo("CL02")==0 
							|| asset_type.CompareTo("CL12")==0 || asset_type.CompareTo("CL15")==0)
						{// 2005-05-18 : �ڻ��� CLASS ID�� laptop, desktop, server, workstation�ΰ͸� Validation
							return true;
						}
					}
				}
			}
			return false;
		}
	}
}
