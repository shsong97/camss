using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Paging;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.ICMS
{
	/// <summary>
	/// SelectICMSListForViewerAsXls�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectICMSListForViewerAsXls : LGCNS.SITE.Common.SITEPageBase
	{
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }
			//XjosHelper.RegisterXjos(true);
			
			this.DgrdDataGrid.EnableViewState = false ;

			try
			{
				SearchICMSListPaging() ;
			}
			catch(Exception ex)
			{
				ScriptHelper.ShowAlert ("�����ٿ�ε��� ������ �߻��߽��ϴ�. (" + ex.Message + ")" ) ;
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void SearchICMSListPaging()
		{
			NameValueCollection searchCondition = new NameValueCollection();
			searchCondition["TicketNo"] = Request["TbxTicketNo"];
			searchCondition["AssetNo"] = Request["TbxAssetNo"];
			searchCondition["EmpNo"] = Request["TbxEmpNo"];
			searchCondition["EmpName"] = Request["TbxEmpName"];
			searchCondition["Engineer"] = Request["DdnlEngineer"];
			searchCondition["Servicetype"] = Request["DdnlServiceType"];
			searchCondition["ConfirmFlag"] = Request["DdnlConfirmFlag"];
			searchCondition["ActivityDateFrom"] = Request["TbxActivityDateFrom"];
			searchCondition["ActivityDateTo"] = Request["TbxActivityDateTo"];
			searchCondition["ConfirmDateFrom"] = Request["TbxConfirmDateFrom"];
			searchCondition["ConfirmDateTo"] = Request["TbxConfirmDateTo"];
			searchCondition["Area"] = Request["DdnlArea"];
			searchCondition["Bill"] = Request["DdnlBill"];

			//int currentPage = 1;
			//int pageSize	= Convert.ToInt32(Request["LblTotalCount"]);
			ICMSDS ds = ICMSController.SelectICMSListForXls2( 0, 0, "", searchCondition );

			this.DgrdDataGrid.DataSource = ds.Tables["TB_ICMS_LIST"];
			this.DgrdDataGrid.DataBind();

			//this.DgrdDataGrid.ExportAsXls ("IES_Templete.xls") ;
			LGCNS.SITE.Common.WebUI.DataToXls.datagridToXls(Response,this.DgrdDataGrid,"IES_Templete.xls");
		}
	}
}
