using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;



namespace LGCNS.SITE.WebUI.ICMS
{
	/// <summary>
	/// PrintICMS�� ���� ��� �����Դϴ�.
	/// </summary>
	public class PrintICMS : LGCNS.SITE.Common.SITEPageBase
	{
		public int cntPage;
		public int cntAsset;

		public string TicketNo;
		public string TechnicianName;
		public string TechnicialContact;

		public string EmpNo;
		public string FirstName;
		public string LastName;
		public string ContactNo;
		public string LoginID;
		public string Dept;
		public string ActDate;

		public string Billing ;
		public string ServiceType ;
		public string Country; 
		public string SiteCode;
		public string Floor ;
		public string Comment ;

		public string CpuSpeed ;
		public string OpSystem; 
		public string Memory ;
		public string HddSize; 
		public string NoCpu ;
		public string HostName ;
		public string MacAddress ;
		public string IpAddress ;

		public string RRS ;
		public string Format ;
		public string HDDFormat;
		public ICMSDS.TB_ICMS_ASSETDataTable dt;
		protected System.Web.UI.WebControls.Image ImgLogo;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			if( !this.IsPostBack )
				BindICMSAll( this.Request["TicketNo"] );

			if( this.IsSubmittedBy )
				BindICMSAll( this.Request["TicketNo"] );
		}
		
		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		#region Search

		private void BindICMSAll( string TicketNo )
		{
			ICMSDS ds = ICMSController.SelectICMS( TicketNo );
			ds.EnforceConstraints = false;

			BindICMS( ds );
			BindICMSAsset( ds );
			BindICMSDetail( ds );
		}

		private void BindICMS ( ICMSDS ds )
		{

			ICMSDS.TB_ICMSRow dr = ds.TB_ICMS[0];

			this.TicketNo = dr.TicketNo;
			this.ActDate = dr.ActivityDate.ToShortDateString();
			this.Billing = dr.BILL;
			this.ServiceType = LGCNS.SITE.Common.WebUI.CodeInfo.getCodeDesc( "SERVICE_TYPE", dr.ServiceType );
			
			this.Country = dr.Country.Trim() + " ( " + dr.Area + " )";
			this.SiteCode = ICMSController.getSiteInfo( dr.Area, dr.SiteCode );
			this.Floor = dr.Floor + " ( " + ICMSController.getBuildingInfo( dr.Area, dr.SiteCode ) + " )";
			this.Comment = dr.Comments;

			this.TechnicianName = dr.TechnicianName;
			this.TechnicialContact = dr.TechnicianContactNo;

			this.EmpNo = dr.EmpNo;
			this.FirstName = dr.FirstName;
			this.LastName = dr.LastName;
			this.ContactNo = dr.EmpContactNo;
			this.LoginID = dr.LoginID;
			if (dr.Area.CompareTo("OEK") == 0)
			{
				this.Dept = LGCNS.SITE.Common.WebUI.DeptInfo.getDeptName( dr.Area, dr.DeptCode ) + " (" 
					+ LGCNS.SITE.Common.WebUI.DeptInfo.getBizUnit( dr.Area, dr.DeptCode ) + ")" ;
				if (this.Dept.Length > 31) 
				this.Dept = this.Dept.Substring(0,29);
			}
			else
			{
				this.Dept = LGCNS.SITE.Common.WebUI.DeptInfo.getDeptName( dr.Area, dr.DeptCode );
			}

			this.RRS = dr.RRSAgent;
			this.Format = dr.HDDFormat;
			if(this.Format.CompareTo("Y")==0)
			{
				this.HDDFormat="Yes";
			}
			else 
			{
				this.HDDFormat="No";
			}
		}

		private void BindICMSAsset( ICMSDS ds )
		{
			dt = ds.TB_ICMS_ASSET;

			cntAsset = dt.Count;
			if ( (cntAsset % 5) == 0 )
			{
				if( cntAsset == 0 )
					cntPage=1;
				else
					cntPage = (int)(( cntAsset ) / 5);
			}
			else
				cntPage = (int)(( cntAsset ) / 5) + 1;
		}

		private void BindICMSDetail( ICMSDS ds )
		{
			ICMSDS.TB_ICMS_DETAILRow dr = ds.TB_ICMS_DETAIL[0];

			this.CpuSpeed = dr.CPUSpeed;
			this.OpSystem = LGCNS.SITE.Common.WebUI.CodeInfo.getCodeDesc( "OP_SYSTEM", dr.OPSystem );
			this.Memory = dr.TotalMemory;
			this.HddSize = dr.HDDSize;
			this.NoCpu = dr.NoCPU;
			this.HostName = dr.HostName;
			this.MacAddress = dr.MACAddress;
			this.IpAddress = dr.IPAddress;
		}

		#endregion
	}
}
