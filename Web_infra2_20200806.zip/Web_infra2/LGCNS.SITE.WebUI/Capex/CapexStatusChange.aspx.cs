using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.Paging ;

using LGCNS.SITE.DTO;



namespace LGCNS.SITE.WebUI.Capex
{
	/// <summary>
	/// CapexStatusChange�� ���� ��� �����Դϴ�.
	/// </summary>
	public class CapexStatusChange : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
		protected System.Web.UI.WebControls.Button BtnSearch;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
			this.DgrdDataGrid.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdDataGrid_EditCommand);
			this.DgrdDataGrid.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.DgrdDataGrid_DeleteCommand);
			this.DgrdDataGrid.SelectedIndexChanged += new System.EventHandler(this.DgrdDataGrid_SelectedIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			SearchCapexStatus();
		}
		private void SearchCapexStatus()
		{
			NameValueCollection searchCondition = new NameValueCollection();
			searchCondition["TicketNo"] = this.TbxTicketNo.Text;
			
			CapexDS ds = null;
			ds=CapexController.SelectCapexStatusList(searchCondition);

			this.DgrdDataGrid.ShowFooterMessage = false;
			this.DgrdDataGrid.DataSource = ds.TB_CAPEX_STATUS;
			this.DgrdDataGrid.DataBind();
		}

		private void DgrdDataGrid_DeleteCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			int inx=e.Item.ItemIndex;
			NameValueCollection searchCondition = new NameValueCollection();
			searchCondition["TicketNo"] =  DgrdDataGrid.Items[inx].Cells[2].Text;
			searchCondition["Flag"] = "D";
			searchCondition["Status"] = ((DropDownList)DgrdDataGrid.Items[inx].Cells[3].Controls[1]).SelectedValue;;
			
			CapexController.CapexStatusChange(searchCondition);
			SearchCapexStatus();
		}

		private void DgrdDataGrid_EditCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			int inx=e.Item.ItemIndex;
			NameValueCollection searchCondition = new NameValueCollection();
			searchCondition["TicketNo"] = DgrdDataGrid.Items[inx].Cells[2].Text;
			searchCondition["Flag"] = "S";
			searchCondition["Status"] = ((DropDownList)DgrdDataGrid.Items[inx].Cells[3].Controls[1]).SelectedValue;;
			
			CapexController.CapexStatusChange(searchCondition);
			SearchCapexStatus();
		}

		public DataTable BindCapexStatusList( )
		{
			CapexDS ds = CapexController.SelectCapexStatus();
			return ds.TB_BASE;		
		}

		private void DgrdDataGrid_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}
	}
}
