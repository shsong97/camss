using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
//using System.Web.Mail;
using System.Net.Mail;
using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;



namespace LGCNS.SITE.WebUI.Capex
{
	/// <summary>
	/// SelectCapex�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectCapex : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxArea;
		protected System.Web.UI.WebControls.TextBox TbxDesc;
		protected System.Web.UI.WebControls.TextBox TbxRemark;
		protected System.Web.UI.WebControls.TextBox TbxReasonNoHandle;
		protected System.Web.UI.WebControls.TextBox TbxCloseContents;
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdTicketEmp;
		protected System.Web.UI.WebControls.Button BtnApprove;
		protected System.Web.UI.WebControls.Button BtnReject;
		protected System.Web.UI.WebControls.Label LblCapexNo;
		protected System.Web.UI.WebControls.Button BtnClose;
		protected System.Web.UI.WebControls.TextBox TbxCreateDate;
		protected System.Web.UI.WebControls.DropDownList DdnlVendorDesc;
		protected System.Web.UI.WebControls.TextBox TbxDescription1;


		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; } 
			NavigationHelper.SetNavigation( this.BtnClose,	"",	"./SelectCapexList.aspx",	true);


			XjosHelper.RegisterXjos(true);

			string TicketNo = this.Request["TicketNo"];
			string CapexNo = this.Request["CapexNo"];
//			string TicketNo = "634289";
//			string CapexNo = "CAPEX-OTIS-20070001";


			// GET������� ȣ��ɶ�
			if ( !this.IsPostBack )
			{
				SelectTicketData( TicketNo, CapexNo );
			}

			// POST������� ȣ��ɶ�
			// NavigationHelper�� LDataGrid�� ���� POST������� ȣ��ɶ��� ���� ������ �ε�ÿ��� 
			// IsPostBack ������Ƽ�� true�� �ǹǷ� 
			// IsSubmittedBy ������Ƽ�� ���� POST������� ȣ��Ǿ������� üũ�� �� �ִ�.
			if(this.IsSubmittedBy)
			{
				SelectTicketData( TicketNo, CapexNo );
			}

            ClientScript.RegisterHiddenField("TicketNo", TbxTicketNo.Text) ;
            ClientScript.RegisterHiddenField("CapexNo", LblCapexNo.Text) ;

			ScriptHelper.SetConfirmMessageOn (this.BtnReject, MessageManager.GetMessage("Common", "REJECT_QUESTION") );
			ScriptHelper.SetConfirmMessageOn (this.BtnApprove, MessageManager.GetMessage("Common", "APPROVE_QUESTION") );
		}


		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnApprove.Click += new System.EventHandler(this.BtnApprove_Click);
			this.BtnReject.Click += new System.EventHandler(this.BtnReject_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		#region Ticket
		private void SelectTicketData( string TicketNo , string CapexNo)
		{
			this.TbxTicketNo.Text = TicketNo;
			this.LblCapexNo.Text = CapexNo;

			TicketDS ds = null;

			ds = CapexController.SelectTicket( TicketNo );

			BindTicketInfo( ds.TB_TICKET_ENTIRE[0] );
			BindTicketEmpList( ds.TB_TICKET_EMP_ENTIRE );
			
			CapexDS ds2 = null;
			ds2 = CapexController.SelectCapexMast( TicketNo, CapexNo );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlVendorDesc, "VENDOR_TYPE",true );
			this.DdnlVendorDesc.SelectedValue=ds2.TB_CAPEX_MAST[0].VendorDesc;
		}

		private void BindTicketInfo( TicketDS.TB_TICKET_ENTIRERow dr )
		{
			this.TbxArea.Text = dr.Area;
			this.TbxDesc.Text = dr.Description;
			this.TbxRemark.Text = dr.Remark;
			this.TbxReasonNoHandle.Text = dr.ReasonNoHandle;
			this.TbxCloseContents.Text = dr.CloseContents;
			this.TbxCreateDate.Text = dr.CreateDate;
		}

		private void BindTicketEmpList( TicketDS.TB_TICKET_EMP_ENTIREDataTable dt )
		{
			this.DgrdTicketEmp.DataSource = dt;
			this.DgrdTicketEmp.DataBind();
		}
		#endregion


		private void BtnApprove_Click(object sender, System.EventArgs e)
		{
			string Flag = "C";
			string CapexNo = this.LblCapexNo.Text;
			SaveCapexData(Flag, CapexNo );	//1�� ����
			SendMail(Flag, CapexNo);
			NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "APPROVE_DONE" ), "./SelectCapexList.aspx" );		
		}

		private void BtnReject_Click(object sender, System.EventArgs e)
		{
			string Flag = "B";
			string CapexNo = this.LblCapexNo.Text;
			SaveCapexData(Flag, CapexNo );	//1�� ����
			SendMail(Flag, CapexNo);

			NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "REJECT_DONE" ), "./SelectCapexList.aspx" );		
		}


		private void SaveCapexData( string Flag, string CapexNo )
		{
			string UserID = this.CurrentUserAlterUserID;
			string Description = this.TbxDescription1.Text;
			CapexController.SaveCapexData(CapexNo, Flag, UserID, Description,this.DdnlVendorDesc.SelectedValue);

		}


		//Capex ������ ���� ������ ����
		//������ �������� �ٽ� ������ �ʴ� ������ ��� ������.
		private void SendMail(string Flag, string CapexNo)
		{
			string TicketNo = this.TbxTicketNo.Text;
//			string Area = this.TbxArea.Text;
//			string UserID = this.CurrentUserAlterUserID;
			string TicketDes = this.TbxDesc.Text;
			string CreateDate = this.TbxCreateDate.Text;
			string EmpName = this.DgrdTicketEmp.Items[0].Cells[4].Text;	


			string mailBody;
			
			TicketDS ds = null;

			ds = CapexController.SelectMailCapex();

			MailMessage mailMsg = new MailMessage();
			//mailMsg.UrlContentBase = "http://www.w3.org/TR/REC-html40";

			for (int i = 0; i < ds.TB_BASE_MAIL.Count; i++)
			{
                //					mailMsg.From = "helpdesk@otis.co.kr";
                if (ds.TB_BASE_MAIL[i].Col1 == "D") mailMsg.To.Add(new MailAddress(ds.TB_BASE_MAIL[i].Email));
				if (ds.TB_BASE_MAIL[i].Col1 == "A" ) 
				{
					if(ds.TB_BASE_MAIL[i].Col2==this.CurrentUserID)
					{
                        mailMsg.From = new MailAddress(ds.TB_BASE_MAIL[i].Email);
					}
				}
			}//for	

			mailBody = "";	
			if (Flag == "B")
			{
				mailMsg.Subject = "[ " + TicketNo + " - " + EmpName + " ] Capex �����Ǿ����ϴ�." ;
				mailBody = mailBody		+ " ��û��ȣ : " + TicketNo.Trim() +"\n";
				mailBody = mailBody		+ " �� û �� : " + EmpName.Trim() +"\n";
				mailBody = mailBody		+ " �������� : " + CreateDate.Trim() +"\n";
				mailBody = mailBody		+ " ��û���� : " + TicketDes.Trim() +"\n";

				mailBody = mailBody		+ " �����մϴ�.";

				mailMsg.Body = mailBody;
			}
			else
			{
				mailMsg.Subject = "[ " + TicketNo + " - " + EmpName + " ] CAPEX 1�� ���εǾ����ϴ�.";
				mailBody = mailBody		+ " ��û��ȣ : " + TicketNo.Trim() +"\n";
				mailBody = mailBody		+ " �� û �� : " + EmpName.Trim() +"\n";
				mailBody = mailBody		+ " �������� : " + CreateDate.Trim() +"\n";
				mailBody = mailBody		+ " ��û���� : " + TicketDes.Trim() +"\n";

				mailBody = mailBody		+ " �����մϴ�.";

				mailMsg.Body = mailBody;
			}

            string server = LGCNS.LAF.Common.ConfigurationManagement.LConfigurationManager.GetConfigValue("SMTP_SERVER");
            SmtpClient client = new SmtpClient(server);
            client.Send(mailMsg);

        }
	}
}
