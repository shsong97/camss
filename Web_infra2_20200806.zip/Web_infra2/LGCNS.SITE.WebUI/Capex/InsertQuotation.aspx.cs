using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.Paging ;

using LGCNS.SITE.DTO;
using LGCNS.SITE.Code;


namespace LGCNS.SITE.WebUI.Capex
{
	/// <summary>
	/// InsertQuotation�� ���� ��� �����Դϴ�.
	/// </summary>
	public class InsertQuotation : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Button BtnSave;
		protected System.Web.UI.WebControls.Button BtnCancel;
		protected System.Web.UI.WebControls.TextBox TbxQuotaNo;
		protected System.Web.UI.WebControls.TextBox TbxQty;
		protected System.Web.UI.WebControls.TextBox TbxUnitPrice;
		protected System.Web.UI.WebControls.TextBox TbxCreateID;
		protected System.Web.UI.WebControls.TextBox TbxCategoryH;
		protected System.Web.UI.WebControls.TextBox TbxCategory;
		protected System.Web.UI.WebControls.DropDownList DdnlCategory;
		protected System.Web.UI.WebControls.TextBox TbxMake;
		protected System.Web.UI.WebControls.TextBox TbxCPUSpeed;
		protected System.Web.UI.WebControls.DropDownList DdnlSystemID;
		protected System.Web.UI.WebControls.DropDownList DdnlCPUType;
		protected System.Web.UI.WebControls.TextBox TbxModelNo;
		protected System.Web.UI.WebControls.DropDownList DdnlClassID;
		protected System.Web.UI.WebControls.TextBox TbxTypeDesc;
		protected System.Web.UI.WebControls.TextBox TbxComments;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			XjosHelper.RegisterXjos(true);
			XjosHelper.SetValidator (this.TbxQty,
				new XjosValidator (XjosValidatorType.Required,		"������ �ʼ��Է��Դϴ�.") ,
				new XjosValidator (XjosValidatorType.Numeric, "������ ���ڸ� �Է����ּ���.")
				);
			XjosHelper.SetValidator (this.TbxUnitPrice,
				new XjosValidator (XjosValidatorType.Required,		"������ �ʼ��Է��Դϴ�.") ,
				new XjosValidator (XjosValidatorType.Numeric, "������ ���ڸ� �Է����ּ���.")
				);
//			XjosHelper.SetValidator (this.TbxMDepreciation,
//				new XjosValidator (XjosValidatorType.Numeric, "Monthly_Depreciation�� ���ڸ� �Է����ּ���.")
//				);
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
//			XjosHelper.SetValidator (this.TbxCreateDate,
//				new XjosValidator (XjosValidatorType.Required),
//				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
//				);
//			XjosHelper.SetValidator (this.TbxUpdateDate,
//				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
//				);


			XjosHelper.SetValidator (this.TbxModelNo, 
				new XjosValidator (XjosValidatorType.Required,		"Model No�� �ʼ��Է��Դϴ�.") ,
				new XjosValidator (XjosValidatorType.Minlength ,"4", "Model No�� �ּ�4�ڸ� �Դϴ�.") 
				) ;
			XjosHelper.ValidateOnClick (this.BtnSave);


			if ( !this.IsPostBack )
			{
				InitializeControls();
			}

			// POST������� ȣ��ɶ�
			// NavigationHelper�� LDataGrid�� ���� POST������� ȣ��ɶ��� ���� ������ �ε�ÿ��� 
			// IsPostBack ������Ƽ�� true�� �ǹǷ� 
			// IsSubmittedBy ������Ƽ�� ���� POST������� ȣ��Ǿ������� üũ�� �� �ִ�.
			if(this.IsSubmittedBy)
			{
				InitializeControls();
			}

		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DdnlCategory.SelectedIndexChanged += new System.EventHandler(this.DdnlCategory_SelectedIndexChanged);
			this.DdnlCPUType.SelectedIndexChanged += new System.EventHandler(this.DdnlWBSE_SelectedIndexChanged);
			this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
			this.BtnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void InitializeControls( )
		{
			CapexDS ds = null;

			LGCNS.SITE.Common.WebUI.CapexInfo.BindDropDownListCategory( this.DdnlCategory, false );
//			LGCNS.SITE.Common.WebUI.CapexInfo.BindDropDownListGubun( this.DdnlGubun, true );
			LGCNS.SITE.Common.WebUI.CapexInfo.BindDropDownListCode( this.DdnlClassID, false ,"CLASS_ID");
			LGCNS.SITE.Common.WebUI.CapexInfo.BindDropDownListCode( this.DdnlCPUType, false ,"CPU_TYPE");
			LGCNS.SITE.Common.WebUI.CapexInfo.BindDropDownListCode( this.DdnlSystemID, false ,"SYSTEM_ID");

			ds = null;
            
			ds = CapexController.SelectQuotationMaxNo();

			this.TbxQuotaNo.Text = ds.TB_QUOTATION_NO[0].QuotaNo;
			this.DdnlCategory.SelectedValue = "";
			this.TbxCategory.Text = "";
			this.TbxCategory.Enabled = true;
			this.TbxCategoryH.Text = "";
			this.TbxQty.Text =  "";
			this.TbxUnitPrice.Text =  "";
			this.TbxCreateID.Text = this.CurrentUserAlterUserID;
//			this.DdnlGubun.SelectedValue = "";
			this.TbxComments.Text = "";


		}

		private void BtnSave_Click(object sender, System.EventArgs e)
		{
			SaveOneQuotationData();

//			ScriptHelper.ShowAlert(	MessageManager.GetMessage( "Common", "SAVE_DONE" )		);
			InitializeControls();
			NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "SAVE_DONE" ), "./SelectQuotation.aspx" );	
			//���� ���� ���� �־����.
		}

		private void BtnCancel_Click(object sender, System.EventArgs e)
		{
			NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "CANCEL_DONE" ), "./SelectQuotation.aspx" );	
		}

		private void DdnlCategory_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (this.DdnlCategory.SelectedValue == "") 
			{
				this.TbxCategory.Enabled = true;
			}
			else
			{
				this.TbxCategory.Enabled = false;
				this.TbxCategory.Text = "";
			}

		}

		private void SaveOneQuotationData()
		{
			NameValueCollection searchCondition = new NameValueCollection();
			searchCondition["QuotaNo"] = this.TbxQuotaNo.Text;
			if (this.DdnlCategory.SelectedValue == "") 
			{
				searchCondition["Category"] = "$$$"+this.TbxCategory.Text;
			}
			else
			{
				searchCondition["Category"] = this.DdnlCategory.SelectedValue;
			}
			
			searchCondition["Category_H"] = this.TbxCategoryH.Text;
			searchCondition["ModelNo"] = this.TbxModelNo.Text;
			searchCondition["Make"] = this.TbxMake.Text;
			searchCondition["ClassID"] = this.DdnlClassID.SelectedValue;
			searchCondition["CPUSpeed"] = this.TbxCPUSpeed.Text;
			searchCondition["SystemID"] = this.DdnlSystemID.SelectedValue;
			searchCondition["CPUType"] = this.DdnlCPUType.SelectedValue;
			searchCondition["TypeDesc"] = this.TbxTypeDesc.Text;
			searchCondition["Qty"] = this.TbxQty.Text;
			searchCondition["unit_price"] = this.TbxUnitPrice.Text;
			searchCondition["CreateID"] = this.TbxCreateID.Text;
			searchCondition["Description"] = this.TbxComments.Text;
//			searchCondition["Gubun"] = this.DdnlGubun.SelectedValue;

			CapexController.InsertQuotationData(searchCondition );

		}

		private void TbxInvoiceID_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void DdnlWBSE_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}


	}
}
