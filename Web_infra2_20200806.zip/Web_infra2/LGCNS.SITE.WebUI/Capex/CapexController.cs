using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.FileManagement;

using LGCNS.SITE.CAPEX.Biz;
using LGCNS.SITE.DTO;
using LGCNS.SITE.Code.Biz;


namespace LGCNS.SITE.WebUI.Capex
{
	/// <summary>
	/// CapexController�� ���� ��� �����Դϴ�.
	/// </summary>
	public class CapexController : ControllerBase
	{
		public CapexController() {}


		#region Select 
		public static CapexDS SelectQuotationHistData( int currentPage, int pageSize, NameValueCollection searchCondition )
		{

			CapexBizNTx biz = null ;
			CapexDS ds = null ;

			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectQuotationHistData (currentPage, pageSize, searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static CapexDS SelectQuotationMaxNo()
		{

			CapexBizNTx biz = null ;
			CapexDS ds = null ;

			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectQuotationMaxNo ();
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static CapexDS SelectQuotationData( string QuotationNo  )
		{

			CapexBizNTx biz = null ;
			CapexDS ds = null ;

			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectQuotationData (QuotationNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static CapexDS SelectOneQuotationData( string QuotaNo, string SPEC )
		{

			CapexBizNTx biz = null ;
			CapexDS ds = null ;

			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectOneQuotationData (QuotaNo, SPEC);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static CapexDS SelectOneUpQuotationData( string QuotaNo, string SPEC )
		{

			CapexBizNTx biz = null ;
			CapexDS ds = null ;

			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectOneUpQuotationData (QuotaNo, SPEC);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static CapexDS SelectCapexMast (string TicketNo , string CapexNo)
		{
			CapexDS ds = null;
			CapexBizNTx biz = null;
		
			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectCapexMast( TicketNo, CapexNo );		
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}


		public static CapexDS SelectCapexDes ( string CapexNo)
		{
			CapexDS ds = null;
			CapexBizNTx biz = null;
		
			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectCapexDes( CapexNo );		
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}


		public static CapexDS SelectCapexAutorityList(string Flag)
		{

			CapexBizNTx biz = null ;
			CapexDS ds = null ;

			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectCapexAutorityList (Flag);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static void CapexStatusChange(NameValueCollection searchCondition)
		{
			CapexBizNTx biz = null ;

			try
			{
				biz = new CapexBizNTx();
				biz.CapexStatusChange (searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return;
		}
		
		public static CapexDS SelectCapexStatusList(NameValueCollection searchCondition)
		{
			CapexBizNTx biz = null ;
			CapexDS ds = null ;

			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectCapexStatusList (searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static CapexDS SelectCapexDataList(string Flag1, string Flag, int currentPage, int pageSize, NameValueCollection searchCondition )
		{

			CapexBizNTx biz = null ;
			CapexDS ds = null ;

			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectCapexDataList (Flag1, Flag, currentPage, pageSize, searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}


		public static CapexDS SelectCapexDataListXls(NameValueCollection searchCondition )
		{

			CapexBizNTx biz = null ;
			CapexDS ds = null ;

			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectCapexDataListXls (searchCondition);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}



		#endregion


		#region Backup 
		public static void BackupQuotationData ()
		{
			CapexBizTx biz = null ;

			try
			{
				biz = new CapexBizTx();
				biz.BackupQuotationData ();
				
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}
		#endregion

		#region Manage

		public static void UpdateQuotationData (NameValueCollection searchCondition )
		{
			CapexBizTx biz = null ;

			try
			{
				biz = new CapexBizTx();
				biz.UpdateQuotationData (searchCondition);
				
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}


		public static void DeleteQuotationData (NameValueCollection searchCondition )
		{
			CapexBizTx biz = null ;

			try
			{
				biz = new CapexBizTx();
				biz.DeleteQuotationData (searchCondition);
				
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static void InsertQuotationData (NameValueCollection searchCondition )
		{
			CapexBizTx biz = null ;

			try
			{
				biz = new CapexBizTx();
				biz.InsertQuotationData (searchCondition);
		
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static void SaveCapexData( string CapexNo, string Flag, string UserID , string Description)
		{
			SaveCapexData(CapexNo,Flag,UserID,Description,"");
		}

		public static void SaveCapexData( string CapexNo, string Flag, string UserID , string Description, string Vendor)
		{
			CapexBizTx biz = null ;

			try
			{
				biz = new CapexBizTx();
				biz.SaveCapexData(CapexNo, Flag, UserID, Description, Vendor);

				
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}


		public static void SaveMCapexNo( string CapexNo, string TicketNo, string Seq)
		{
			CapexBizTx biz = null ;

			try
			{
				biz = new CapexBizTx();
				biz.SaveMCapexNo(CapexNo, TicketNo, Seq);

				
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}


		public static void SaveCapexConfirmData( string CapexNo, string  MordNo, string  CheckNo,string   DemandDate,string   UserID)
		{
			CapexBizTx biz = null ;

			try
			{
				biz = new CapexBizTx();
				biz.SaveCapexConfirmData(CapexNo, MordNo, CheckNo, DemandDate, UserID);

				
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}
		
		public static void InsertCapexDetail( string CapexNo, string Seq, string Model, string Qty , string Price, string LedgerEntry, string UserID)
		{
			CapexBizTx biz = null ;

			try
			{
				biz = new CapexBizTx();
				biz.InsertCapexDetail(CapexNo, Seq, Model, Qty , Price, LedgerEntry, UserID);

				
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		
		public static void UpdateCapexDetail( string CapexNo, string Seq, string Model, string Qty , string Price, string LedgerEntry, string UserID)
		{
			CapexBizTx biz = null ;

			try
			{
				biz = new CapexBizTx();
				biz.UpdateCapexDetail(CapexNo, Seq, Model, Qty , Price, LedgerEntry, UserID);

				
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static void DeleteCapexDetail( string CapexNo, string Seq)
		{
			CapexBizTx biz = null ;

			try
			{
				biz = new CapexBizTx();
				biz.DeleteCapexDetail(CapexNo, Seq);

				
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static void ConfirmCSCCapexData( string CapexNo )
		{
			ConfirmCSCCapexData(CapexNo,"Y");
		}

		public static void ConfirmCSCCapexData( string CapexNo, string flag )
		{
			CapexBizTx biz = null ;

			try
			{
				biz = new CapexBizTx();
				biz.ConfirmCSCCapexData(CapexNo,flag);

				
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		#endregion

		#region Ticket // Ticket �� ���� ���� ��������.

		public static bool isNumeric( string s )
		{
			try
			{
				int i = int.Parse( s );
			}
			catch( Exception ex )
			{
				string errmsg=ex.Message;
				return false;
			}

			return true;
		}
		
		public static bool isValidTicket( string s )  //Ticket���� ���� ������ ���� �����ؾ���.
		{
//			if ( s == "SRICMS"  )
//			{
//				return true;
//			}

			if ( s.Trim().Length == 6  || s.Trim().Length == 7  )
			{
				if ( isNumeric(s) )
					return true;
				else 
					return false;
			}

			if ( s.Trim().Length == 8 )
			{
				if ( s.Substring(0,2).Equals("MY") || s.Substring(0,2).Equals("RF") )
				{
					if ( isNumeric(s.Substring(2)) )
						return true;
					else 
						return false;
				}
			}
			return false;
		}

		public static TicketDS SelectTicket(string TicketNo)
		{

			CapexBizNTx biz = null ;
			TicketDS ds = null ;

			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectTicket (TicketNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static TicketDS SelectMailCapex( )
		{

			LGCNS.SITE.Ticket.Biz.TicketBizNTx biz = null ;
			TicketDS ds = null ;

			try
			{
				biz = new LGCNS.SITE.Ticket.Biz.TicketBizNTx();
				
				ds = biz.SelectMailCapex ();
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}
		#endregion

		#region Controll DataSource, Model, LegerEntry

		public static CapexDS GetNewDataSource( int cntCols )
		{
			CapexDS ds = new CapexDS();
			ds.EnforceConstraints = false;
			CapexDS.TB_CAPEX_DESRow dr = null;

			for (int i = 1; i <= cntCols; i++) 
			{
				dr = ds.TB_CAPEX_DES.NewTB_CAPEX_DESRow();
 
				//dr.TicketNo = TicketNo;
				dr.Seq  = i;
				dr.Qty = 0;
				dr.Amount = 0;
				dr.Price = 0;
 
				ds.TB_CAPEX_DES.AddTB_CAPEX_DESRow( dr );
			}

			return ds;
		}

		public static void AddRowsOnDataGrid( DataGrid dgrd, int cntCols )
		{
			CapexDS ds = GetDataSource( dgrd );
			ds.EnforceConstraints = false;
			CapexDS.TB_CAPEX_DESRow dr = null;

			for (int i = 1; i <= cntCols; i++) 
			{
				dr = ds.TB_CAPEX_DES.NewTB_CAPEX_DESRow();

				dr.Seq = ds.TB_CAPEX_DES.Count + 1;
				dr.Amount = 0;
				dr.Price = 0;
				dr.Qty = 0;
//				dr.Discriptions ="";
//				dr.Discriptions1 ="";

				ds.TB_CAPEX_DES.AddTB_CAPEX_DESRow( dr );
			}

			dgrd.DataSource = ds.TB_CAPEX_DES;
			dgrd.DataBind();
		}


		public static string CalculateSum( DataGrid dgrd )
		{
			ulong SubTotal = 0;
			ulong Total = 0;

			for( int inx = 0; inx < dgrd.Items.Count; inx++ )
			{
				string Model = ((DropDownList)dgrd.Items[inx].Cells[1].Controls[1]).SelectedValue;
				string Price = SelectPrice(Model);

				string Qty = ((TextBox)dgrd.Items[inx].Cells[2].Controls[1]).Text;

				if( Qty.Length < 1 || Price.Length < 1 )
				{
					SubTotal = 0;
					Price = "0";
				}
				else
				{ 
					try
					{
						SubTotal = ulong.Parse( Qty ) * ulong.Parse( Price );
					}
					catch( Exception ex )
					{
						string errmsg=ex.Message;
						ScriptHelper.ShowAlert(	MessageManager.GetMessage( "Acq", "NO_NUMERIC" ) );
						return "Error";
					}
				}

				((TextBox)dgrd.Items[inx].Cells[4].Controls[1]).Text = SubTotal.ToString();
				((TextBox)dgrd.Items[inx].Cells[3].Controls[1]).Text = Price.ToString();
				Total = Total + SubTotal;
			}

			return Total.ToString();
		}


		public static string SelectPrice( string Model )
		{
			CapexBizNTx biz = null;
			string ResultStatement = "";

			try
			{
				biz = new CapexBizNTx();
				ResultStatement = biz.SelectPrice(Model);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}

			return ResultStatement;
		}



		public static CapexDS GetDataSource( DataGrid dgrd )
		{
			CapexDS ds = new CapexDS();
			ds.EnforceConstraints = false;
			CapexDS.TB_CAPEX_DESRow dr = null;

			for( int inx = 0 ; inx < dgrd.Items.Count ; inx++ )
			{
				dr = ds.TB_CAPEX_DES.NewTB_CAPEX_DESRow();

				//dr.TicketNo = TicketNo;

				dr.Seq = int.Parse( ((TextBox)dgrd.Items[inx].Cells[0].Controls[1]).Text );
				dr.Discriptions = ((DropDownList)dgrd.Items[inx].Cells[1].Controls[1]).SelectedValue;
				
				try
				{
					dr.Qty = int.Parse( ((TextBox)dgrd.Items[inx].Cells[2].Controls[1]).Text );
				}
				catch( Exception ex )
				{
					string errmsg=ex.Message;
					dr.Qty = 0;
				}

				try
				{
					dr.Price = int.Parse( ((TextBox)dgrd.Items[inx].Cells[3].Controls[1]).Text );
				}
				catch( Exception ex )
				{
					string errmsg=ex.Message;
					dr.Price = 0;
				}

				try
				{
					dr.Amount = int.Parse( ((TextBox)dgrd.Items[inx].Cells[4].Controls[1]).Text );
				}
				catch( Exception ex )
				{
					string errmsg=ex.Message;
					dr.Amount = 0;
				}
								
				dr.LedgerEntry = ((DropDownList)dgrd.Items[inx].Cells[5].Controls[1]).SelectedValue;

				ds.TB_CAPEX_DES.AddTB_CAPEX_DESRow( dr );
			}

			return ds;
		}

		public static CapexDS SelectModelList()
		{
			CapexDS ds = null;
			CapexBizNTx biz = null;
		
			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectModel( );			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}
		public static CapexDS SelectCapexStatus()
		{
			CapexDS ds = null;
			CapexBizNTx biz = null;
		
			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectCapexStatus( );			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}

		public static CapexDS SelectLedgerEntrylList()
		{
			CapexDS ds = null;
			CapexBizNTx biz = null;
		
			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectLedgerEntrylList( );			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}


		public static CapexDS SelectAuthority ( string CapexNo, string UserID)
		{
			CapexDS ds = null;
			CapexBizNTx biz = null;
		
			try
			{
				biz = new CapexBizNTx();
				ds = biz.SelectAuthority(CapexNo, UserID);
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}

//Code List ������.
		public static CodeDS SelectCodeList( string ClassID )
		{
			CodeDS ds = null;
			CodeBizNTx biz = null;
		
			try
			{
				biz = new CodeBizNTx();
				ds = biz.SelectCodeList( ClassID );			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}


		
		#endregion
	}
}
