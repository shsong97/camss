using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
//using System.Web.Mail;
using System.Net.Mail;
using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;




namespace LGCNS.SITE.WebUI.Capex
{
	/// <summary>
	/// CompleteCapex�� ���� ��� �����Դϴ�.
	/// </summary>
	public class CompleteCapex : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected System.Web.UI.WebControls.TextBox TbxArea;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdTicketEmp;
		protected System.Web.UI.WebControls.TextBox TbxDesc;
		protected System.Web.UI.WebControls.TextBox TbxRemark;
		protected System.Web.UI.WebControls.TextBox TbxReasonNoHandle;
		protected System.Web.UI.WebControls.TextBox TbxCloseContents;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
		protected System.Web.UI.WebControls.TextBox TbxCapexNo;
		protected System.Web.UI.WebControls.Button BtnConfirm;
		protected System.Web.UI.WebControls.TextBox TbxMordNo;
		protected System.Web.UI.WebControls.TextBox TbxCheckNo;
		protected System.Web.UI.WebControls.TextBox TbxDemandDate;
		protected System.Web.UI.WebControls.TextBox TbxApproveID1;
		protected System.Web.UI.WebControls.TextBox TbxApproveID2;
		protected System.Web.UI.WebControls.Button BtnSave;
		protected System.Web.UI.WebControls.TextBox TbxRequestDate;
		protected System.Web.UI.WebControls.TextBox TbxStatusFlag;
		protected System.Web.UI.WebControls.TextBox TbxDescription2;
		protected System.Web.UI.WebControls.TextBox TbxDescription1;
		protected System.Web.UI.WebControls.TextBox TbxApproveDate1;
		protected System.Web.UI.WebControls.TextBox TbxDescription3;
		protected System.Web.UI.WebControls.TextBox TbxApproveDate2;
		protected System.Web.UI.WebControls.TextBox TbxTickeDate;
		protected System.Web.UI.WebControls.Button BtnDemandReq;
		protected System.Web.UI.WebControls.Button BtnDemandComp;
		protected System.Web.UI.WebControls.TextBox TbxDemandComplete;
		protected System.Web.UI.WebControls.DropDownList DdnlDemandflag;
		protected System.Web.UI.WebControls.DropDownList DdnlVendorDesc;
		protected System.Web.UI.WebControls.Button BtnClose;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; } 
			NavigationHelper.SetNavigation( this.BtnClose,	"",	"./SelectCapexListHelp.aspx",	true);

			XjosHelper.RegisterXjos(true);

			string TicketNo = this.Request["TicketNo"];
			string CapexNo = this.Request["CapexNo"];

			// GET������� ȣ��ɶ�
			if ( !this.IsPostBack )
			{
				InitializeControls ( TicketNo, CapexNo );
			}

			// POST������� ȣ��ɶ�
			// NavigationHelper�� LDataGrid�� ���� POST������� ȣ��ɶ��� ���� ������ �ε�ÿ��� 
			// IsPostBack ������Ƽ�� true�� �ǹǷ� 
			// IsSubmittedBy ������Ƽ�� ���� POST������� ȣ��Ǿ������� üũ�� �� �ִ�.
			if(this.IsSubmittedBy)
			{
				InitializeControls ( TicketNo, CapexNo );
			}

            ClientScript.RegisterHiddenField("TicketNo", TbxTicketNo.Text) ;
            ClientScript.RegisterHiddenField("CapexNo", TbxCapexNo.Text) ;
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnConfirm.Click += new System.EventHandler(this.BtnConfirm_Click);
			this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
			this.BtnDemandReq.Click += new System.EventHandler(this.BtnDemandReq_Click);
			this.BtnDemandComp.Click += new System.EventHandler(this.BtnDemandComp_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		#region Ticket
		private void SelectTicketData( string TicketNo , string CapexNo)
		{
			this.TbxTicketNo.Text = TicketNo;
			this.TbxCapexNo.Text = CapexNo;

			TicketDS ds = null;

			ds = CapexController.SelectTicket( TicketNo );

			BindTicketInfo( ds.TB_TICKET_ENTIRE[0] );
			BindTicketEmpList( ds.TB_TICKET_EMP_ENTIRE );
		}

		private void BindTicketInfo( TicketDS.TB_TICKET_ENTIRERow dr )
		{
			this.TbxArea.Text = dr.Area;
			this.TbxDesc.Text = dr.Description;
			this.TbxRemark.Text = dr.Remark;
			this.TbxReasonNoHandle.Text = dr.ReasonNoHandle;
			this.TbxCloseContents.Text = dr.CloseContents;
			this.TbxTickeDate.Text = dr.CreateDate;
		}

		private void BindTicketEmpList( TicketDS.TB_TICKET_EMP_ENTIREDataTable dt )
		{
			this.DgrdTicketEmp.DataSource = dt;
			this.DgrdTicketEmp.DataBind();
		}
		#endregion

		private void SelectCapexMastData( string TicketNo , string CapexNo)
		{
			CapexDS ds = null;

			ds = CapexController.SelectCapexMast( TicketNo, CapexNo );
			this.TbxDescription1.Text = ds.TB_CAPEX_MAST[0].Comment_1;
			this.TbxDescription2.Text = ds.TB_CAPEX_MAST[0].Comment_0;
			this.TbxDescription3.Text = ds.TB_CAPEX_MAST[0].Comment_2;
			this.TbxStatusFlag.Text = ds.TB_CAPEX_MAST[0].StatusFlag;
			
			this.TbxApproveID1.Text = ds.TB_CAPEX_MAST[0].Approve_Id1;
			this.TbxApproveDate1.Text = ds.TB_CAPEX_MAST[0].Approve_Date1;
			this.TbxApproveID2.Text = ds.TB_CAPEX_MAST[0].Approve_Id2;
			this.TbxApproveDate2.Text = ds.TB_CAPEX_MAST[0].Approve_Date2;
			this.TbxMordNo.Text = ds.TB_CAPEX_MAST[0].Mord_No;
			this.TbxCheckNo.Text = ds.TB_CAPEX_MAST[0].Check_No;
			this.TbxDemandDate.Text = ds.TB_CAPEX_MAST[0].Demand_Date;
			this.TbxRequestDate.Text = ds.TB_CAPEX_MAST[0].CreateDate.ToString();

			//lgssha:08.06.19 ��ü�� û����û ȭ�� �߰�
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlVendorDesc, "VENDOR_TYPE",true );
			this.DdnlVendorDesc.SelectedValue =ds.TB_CAPEX_MAST[0].VendorDesc;

			this.DdnlDemandflag.SelectedValue = ds.TB_CAPEX_MAST[0].DemandFlag;
			this.TbxDemandComplete.Text = ds.TB_CAPEX_MAST[0].DemandCompleteDate.ToString();
		}

		private void SelectCapexDesData(string CapexNo)
		{
			CapexDS ds = null;

			ds = CapexController.SelectCapexDes( CapexNo );
			DgrdDataGrid.DataSource= ds.TB_CAPEX_DES;
			DgrdDataGrid.DataBind();
		}


		private void InitializeControls( string TicketNo, string CapexNo)
		{
			SelectTicketData( TicketNo, CapexNo );
			SelectCapexMastData( TicketNo, CapexNo );
			SelectCapexDesData( CapexNo );

			BtnDemandReq.Visible=false;
			BtnDemandComp.Visible=false;

			if (this.TbxStatusFlag.Text == "���ֿϷ�")
			{
				BtnConfirm.Visible = false;
				BtnDemandReq.Visible=true;
			}
			else if (this.TbxStatusFlag.Text == "û����û")
			{
				BtnConfirm.Visible = false;
				BtnDemandComp.Visible=true;
			}
			else
			{
				;
			}

		}
//���� ����Ŭ��
		private void BtnConfirm_Click(object sender, System.EventArgs e)
		{
			string Flag = "G";
			string CapexNo = this.TbxCapexNo.Text;
			string UserID = this.CurrentUserID;
			string TicketNo = this.TbxTicketNo.Text;

			/* ���� �Ϸῡ�� capex no �����Ǿ�����, 2���������� �ٽ� ������ lgssha.08.07.02
			for (int i = 1; i < this.DgrdDataGrid.Items.Count + 1; i++)
			{
				CapexController.SaveMCapexNo(CapexNo, TicketNo, i.ToString());
			}
			*/

			SaveCapexData(Flag, CapexNo );	// ����
			NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "ORDER_DONE" ), "./SelectCapexListHelp.aspx" );	
		}

		private void SaveCapexData( string Flag, string CapexNo )
		{
			string UserID = this.CurrentUserID;
			string Description = "";
			CapexController.SaveCapexData(CapexNo, Flag, UserID, Description,this.DdnlVendorDesc.SelectedValue);

		}

		//Capex ������ ���� ������ ����
		//������ �������� �ٽ� ������ �ʴ� ������ ��� ������.
		private void SendMail(string Flag, string CapexNo)
		{
			string TicketNo = this.TbxTicketNo.Text;
			string TicketDes = this.TbxDesc.Text;
			string CreateDate = this.TbxTickeDate.Text;
			string EmpName = this.DgrdTicketEmp.Items[0].Cells[4].Text;	
			string ApproveID1 = this.TbxApproveID1.Text;
			string ApproveID2 = this.TbxApproveID2.Text;
			string ApproveDate1 = this.TbxApproveDate1.Text;	


			string mailBody;
			
			TicketDS ds = null;

			ds = CapexController.SelectMailCapex();

			MailMessage mailMsg = new MailMessage();
			//mailMsg.UrlContentBase = "http://www.w3.org/TR/REC-html40";

			for (int i = 0; i < ds.TB_BASE_MAIL.Count; i++)
			{
                if (ds.TB_BASE_MAIL[i].Col1 == "D") mailMsg.To.Add(new MailAddress(ds.TB_BASE_MAIL[i].Email));
                if (ds.TB_BASE_MAIL[i].Col1 == "C") mailMsg.From = new MailAddress(ds.TB_BASE_MAIL[i].Email);
			}//for	

			mailBody = "";	
			mailMsg.Subject = "[ " + TicketNo + " - " + EmpName + " ] CAPEX ����" ;
			
			mailBody = mailBody		+ " ��û��ȣ : " + TicketNo.Trim() +"\n";
			mailBody = mailBody		+ " �� û �� : " + EmpName.Trim() +"\n";
			mailBody = mailBody		+ " �������� : " + CreateDate.Trim() +"\n";
			mailBody = mailBody		+ " ��û���� : " + TicketDes.Trim() +"\n";
			mailBody = mailBody		+ " ���������� : " + ApproveDate1.Trim() +"\n";
			mailBody = mailBody		+ " ���������� : " + ApproveID1.Trim() +"\n";

			mailBody = mailBody		+ " �����մϴ�.";

			mailMsg.Body = mailBody;


            string server = LGCNS.LAF.Common.ConfigurationManagement.LConfigurationManager.GetConfigValue("SMTP_SERVER");
            SmtpClient client = new SmtpClient(server);
            client.Send(mailMsg);

        }

		private void BtnSave_Click(object sender, System.EventArgs e)
		{
			string CapexNo = this.TbxCapexNo.Text;
			string MordNo = this.TbxMordNo.Text;
			string CheckNo = this.TbxCheckNo.Text;
			string DemandDate = this.TbxDemandDate.Text;
			string UserID = this.CurrentUserID;

			SaveCapexData("", CapexNo );
			CapexController.SaveCapexConfirmData(CapexNo, MordNo, CheckNo, DemandDate, UserID);			
			NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "SAVE_DONE" ), "./SelectCapexListHelp.aspx" );	
		}

//û����û
		private void BtnDemandReq_Click(object sender, System.EventArgs e)
		{
			string Flag = "R";
			string CapexNo = this.TbxCapexNo.Text;
			string UserID = this.CurrentUserID;
			string TicketNo = this.TbxTicketNo.Text;

			SaveCapexData(Flag, CapexNo );	
			NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "DEMAND_R_DONE" ), "./SelectCapexListHelp.aspx" );			
		}

//û���Ϸ�
		private void BtnDemandComp_Click(object sender, System.EventArgs e)
		{
			string Flag = "Y";
			string CapexNo = this.TbxCapexNo.Text;
			string UserID = this.CurrentUserID;
			string TicketNo = this.TbxTicketNo.Text;

			SaveCapexData(Flag, CapexNo );	
			NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "DEMAND_Y_DONE" ), "./SelectCapexListHelp.aspx" );		
		}

	}
}

