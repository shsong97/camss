using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.Paging ;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Capex
{
	/// <summary>
	/// SelectCapexList�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectCapexList : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxEmpNo;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected System.Web.UI.WebControls.TextBox TbxPageSize;
		protected System.Web.UI.WebControls.Label LblTotalCount;
		protected System.Web.UI.WebControls.DropDownList DdlPage;
		protected System.Web.UI.WebControls.Label LblTotalPages;
		protected System.Web.UI.WebControls.Button BtnSearch;
		protected System.Web.UI.WebControls.Button BtnClear;
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected System.Web.UI.WebControls.TextBox TbxCreateDateFrom;
		protected System.Web.UI.WebControls.TextBox TbxCreateDateTo;
		protected System.Web.UI.WebControls.DropDownList DdnlCStatus;
		protected System.Web.UI.WebControls.Button BtnSaveExcel;
		protected System.Web.UI.WebControls.DropDownList DdnlFlag;
		protected System.Web.UI.WebControls.TextBox TbxEmpName;
		protected System.Web.UI.WebControls.TextBox TbxModelDesc;
		protected System.Web.UI.WebControls.Button BtnSelectAll;
		protected System.Web.UI.WebControls.Button BtnUnselectAll;
		protected System.Web.UI.WebControls.Button BtnBillReq;
		protected System.Web.UI.WebControls.Button BtnBillComplete;
		protected System.Web.UI.WebControls.DropDownList DdnlVendorDesc;
		protected System.Web.UI.WebControls.Button BtnCSCConfirm;
		protected System.Web.UI.WebControls.Button BtnCSCCancel;
		protected System.Web.UI.WebControls.DropDownList DdnlDate;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; } 
			NavigationHelper.RegisterHiddenIFrame ("HiddenFrame") ;
			NavigationHelper.SetNavigation (this.BtnSaveExcel, "HiddenFrame", "SelectCapexListAsXls.aspx", true) ;
			/*this.DgrdDataGrid.NavigateOnRowClick (
				"", // �̵��� �����Ӹ�, ��������ü�� �̵��Ҷ� ""�� �����Ѵ�.
				"CapexTemp.aspx", // LinkŬ���� �̵��� Url  (����ȸȭ��)
				new string [3] {"CapexNo", "TicketNo","Flag"},  // LinkŬ���� ������ Query String �� key�� �迭
				new int [3] {0,1,13}, // LinkŬ���� ������ Query String �� value���� ������ Cell Index�� �迭
				true  // // ������������ ���� SelectTicket.aspx ���� submit��Ų��. (POST������� ȣ���Ѵ�.)
				) ;
			*/
			XjosHelper.RegisterXjos(true);

			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			XjosHelper.SetValidator (this.TbxCreateDateFrom,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);
			XjosHelper.SetValidator (this.TbxCreateDateTo,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);

			this.DgrdDataGrid.SetMultipleSelect(0,false,this.BtnSelectAll,this.BtnUnselectAll,"�ϳ��̻����ؾ��մϴ�.");
			this.DgrdDataGrid.NavigateOnCellClick(2,"","CapexTemp.aspx",new string [3] {"CapexNo", "TicketNo","Flag"},new int [3] {1,2,14},true);
			
			// GET������� ȣ��ɶ�
			if ( !this.IsPostBack )
			{
				InitializeControls();
				SelectCapexDataList( );
			}


			// POST������� ȣ��ɶ�
			// NavigationHelper�� LDataGrid�� ���� POST������� ȣ��ɶ��� ���� ������ �ε�ÿ��� 
			// IsPostBack ������Ƽ�� true�� �ǹǷ� 
			// IsSubmittedBy ������Ƽ�� ���� POST������� ȣ��Ǿ������� üũ�� �� �ִ�.
			if(this.IsSubmittedBy)
			{
				InitializeControls();
				SelectCapexDataList( );
			}

		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
			this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
			this.BtnBillReq.Click += new System.EventHandler(this.BtnBillReq_Click);
			this.BtnBillComplete.Click += new System.EventHandler(this.BtnBillComplete_Click);
			this.BtnCSCConfirm.Click += new System.EventHandler(this.BtnCSCConfirm_Click);
			this.BtnCSCCancel.Click += new System.EventHandler(this.BtnCSCCancel_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		private void InitializeControls( )
		{
			LGCNS.SITE.Common.WebUI.CapexInfo.BindDropDownListCStatus( this.DdnlCStatus, true );
			LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea, true );
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlVendorDesc, "VENDOR_TYPE",true );
			if(this.CurrentUserAuthority=="Y")
			{
				GetVendorIndex(this.CurrentUserName);
				//this.DdnlVendorDesc
				
			}

			this.TbxCreateDateFrom.Text = "";
			this.TbxCreateDateTo.Text = "";
			this.TbxEmpNo.Text = "";
			this.TbxTicketNo.Text = "";

			if(this.CurrentCapexUserAuthority != "A")
			{
				BtnCSCConfirm.Visible=false;
				BtnCSCCancel.Visible=false;
			}

		}

		private void GetVendorIndex( string VendorId )
		{
 
			for ( int i = 0; i < DdnlVendorDesc.Items.Count; i++)
			{
				if ( DdnlVendorDesc.Items[i].Text.Equals(VendorId) )
				{
					DdnlVendorDesc.SelectedIndex=i;
					return;
				}
			}
		}

		private void SelectCapexDataList( )
		{
			NameValueCollection searchCondition = new NameValueCollection();
			searchCondition["TicketNo"] = this.TbxTicketNo.Text;
			searchCondition["CapexStatus"] = this.DdnlCStatus.SelectedValue;
			searchCondition["Area"] = this.DdnlArea.SelectedValue;
			searchCondition["EmpNo"] = this.TbxEmpNo.Text;
			searchCondition["EmpName"] = this.TbxEmpName.Text;

            if(this.CurrentUserAuthority=="Y") 
            {//vendor�̸� �ڽŸ� ��ȸ ����
                searchCondition["VendorDesc"] = this.CurrentUserID;
            }   
            else
                searchCondition["VendorDesc"] = this.DdnlVendorDesc.SelectedValue;
			

			searchCondition["CreateDateFrom"] = this.TbxCreateDateFrom.Text;
			searchCondition["CreateDateTo"] = this.TbxCreateDateTo.Text;
			searchCondition["CFlag"] = this.DdnlFlag.SelectedValue; //CSC �Ϸ� �̿Ϸ� ����
			searchCondition["OptDate"] = this.DdnlDate.SelectedValue;
			searchCondition["ModelDesc"] = this.TbxModelDesc.Text;

			int currentPage = Convert.ToInt32(this.DdlPage.SelectedValue);
			int pageSize	= Convert.ToInt32(this.TbxPageSize.Text);

			CapexDS ds = null;

			ds = CapexController.SelectCapexDataList("A", "", currentPage, pageSize, searchCondition  );

			this.DgrdDataGrid.ShowFooterMessage = false;
			this.DgrdDataGrid.DataSource = ds.TB_CAPEX_LIST;
			this.DgrdDataGrid.DataBind();

			//��Ͽ� ���� ����
			int totalPage			= PagingHelper.GetTotalPage (ds) ;
			this.LblTotalCount.Text = PagingHelper.GetTotalCount (ds).ToString () ;
			this.LblTotalPages.Text = totalPage.ToString() ;

			//Page DropDownList Setting
			this.DdlPage.Items.Clear();
			for(int i = 1; i <= totalPage ; i++)
			{
				this.DdlPage.Items.Add(i.ToString());
			}

			//�������� ������ ���õǵ���
			if(this.DdlPage.Items.Count > 0)
			{
				if( currentPage <= totalPage )
				{
					this.DdlPage.Items[currentPage - 1].Selected = true;
				}
				else
				{
					this.DdlPage.Items[0].Selected = true;
				}
			}
			
		}

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			SelectCapexDataList();
		}

		private void BtnClear_Click(object sender, System.EventArgs e)
		{
			InitializeControls( );
		}

		private void BtnBillReq_Click(object sender, System.EventArgs e)
		{
			SelectCapexReqConfirm("R");
			SelectCapexDataList();
		}

		private void BtnBillComplete_Click(object sender, System.EventArgs e)
		{
			SelectCapexReqConfirm("Y");
			SelectCapexDataList();
		}

		private void SelectCapexReqConfirm(string ConfrimFlag)
		{
			//û����û(R), û���Ϸ�(Y) ó�� �߰�(lgssha : 08.06.13)
			if(this.DgrdDataGrid.SelectedIndexes.Length>0)
			{
				SelectCapexDataList( );
				DataGridItem[] selectedItems = this.DgrdDataGrid.SelectedItems;

				for(int i=0; i<selectedItems.Length; i++)
				{							
					string CapexNo = selectedItems[i].Cells[1].Text;
					string UserID = this.CurrentUserID;
					CapexController.SaveCapexData(CapexNo, ConfrimFlag, UserID, "");
				}		
			}
		}

		private void BtnCSCConfirm_Click(object sender, System.EventArgs e)
		{	
			CSCConfirmRequest("Y");
			SelectCapexDataList();
		}
		private void BtnCSCCancel_Click(object sender, System.EventArgs e)
		{
			CSCConfirmRequest("N");
			SelectCapexDataList();
		}
		private void CSCConfirmRequest(string flag)
		{
			//CSC û����û(Y), û������(N) (lgssha : 08.08.04)
			if(this.DgrdDataGrid.SelectedIndexes.Length>0)
			{
				SelectCapexDataList( );
				DataGridItem[] selectedItems = this.DgrdDataGrid.SelectedItems;

				for(int i=0; i<selectedItems.Length; i++)
				{							
					string CapexNo = selectedItems[i].Cells[1].Text;
					CapexController.ConfirmCSCCapexData(CapexNo,flag);
				}		
			}	
		}




	}
}
