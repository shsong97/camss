using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
//using System.Web.Mail;
using System.Net.Mail;
using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;


namespace LGCNS.SITE.WebUI.Capex
{
	/// <summary>
	/// CreateCapex01�� ���� ��� �����Դϴ�.
	/// </summary>
	public class InsertCapex : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected System.Web.UI.WebControls.TextBox TbxArea;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdTicketEmp;
		protected System.Web.UI.WebControls.TextBox TbxDesc;
		protected System.Web.UI.WebControls.TextBox TbxRemark;
		protected System.Web.UI.WebControls.TextBox TbxReasonNoHandle;
		protected System.Web.UI.WebControls.TextBox TbxCloseContents;
		protected System.Web.UI.WebControls.TextBox TbxDescription1;
		protected System.Web.UI.WebControls.Button BtnRequest;
		protected System.Web.UI.WebControls.Button BtnSave;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
		protected System.Web.UI.WebControls.TextBox TbxDescription2;
		protected System.Web.UI.WebControls.TextBox TbxCapexNo;
		protected System.Web.UI.WebControls.TextBox TbxTotal;
		protected System.Web.UI.WebControls.Button BtnCalculate;
		protected System.Web.UI.WebControls.Button BtnClose;
		protected System.Web.UI.WebControls.TextBox TbxApproveDate1;
		protected System.Web.UI.WebControls.TextBox TbxTickeDate;
		protected System.Web.UI.WebControls.TextBox TbxStatusFlag;
		protected System.Web.UI.WebControls.TextBox TbxCreateDate;
		protected System.Web.UI.WebControls.TextBox TbxApproveID;
		protected System.Web.UI.WebControls.DropDownList DdnlVendorDesc;
		protected System.Web.UI.WebControls.Button BtnAdd;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; } 
			NavigationHelper.SetNavigation( this.BtnClose,	"",	"./SelectCapexListHelp.aspx",	true);

			XjosHelper.RegisterXjos(true);

			string TicketNo = this.Request["TicketNo"];
			string CapexNo = this.Request["CapexNo"];


			// GET������� ȣ��ɶ�
			if ( !this.IsPostBack )
			{
				InitializeControls ( TicketNo, CapexNo );
			}

			// POST������� ȣ��ɶ�
			// NavigationHelper�� LDataGrid�� ���� POST������� ȣ��ɶ��� ���� ������ �ε�ÿ��� 
			// IsPostBack ������Ƽ�� true�� �ǹǷ� 
			// IsSubmittedBy ������Ƽ�� ���� POST������� ȣ��Ǿ������� üũ�� �� �ִ�.
			if(this.IsSubmittedBy)
			{
				InitializeControls ( TicketNo, CapexNo );
			}

            ClientScript.RegisterHiddenField("TicketNo", TbxTicketNo.Text) ;
            ClientScript.RegisterHiddenField("CapexNo", TbxCapexNo.Text) ;

		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
			this.BtnCalculate.Click += new System.EventHandler(this.BtnCalculate_Click);
			this.BtnRequest.Click += new System.EventHandler(this.BtnRequest_Click);
			this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		#region Ticket
		private void SelectTicketData( string TicketNo , string CapexNo)
		{
			this.TbxTicketNo.Text = TicketNo;
			this.TbxCapexNo.Text = CapexNo;

			TicketDS ds = null;

			ds = CapexController.SelectTicket( TicketNo );

			BindTicketInfo( ds.TB_TICKET_ENTIRE[0] );
			BindTicketEmpList( ds.TB_TICKET_EMP_ENTIRE );
		}

		private void BindTicketInfo( TicketDS.TB_TICKET_ENTIRERow dr )
		{
			this.TbxArea.Text = dr.Area;
			this.TbxDesc.Text = dr.Description;
			this.TbxRemark.Text = dr.Remark;
			this.TbxReasonNoHandle.Text = dr.ReasonNoHandle;
			this.TbxCloseContents.Text = dr.CloseContents;
			this.TbxTickeDate.Text = dr.CreateDate;	//ticket ������
			this.TbxCreateDate.Text = dr.CreateDate;
		}

		private void BindTicketEmpList( TicketDS.TB_TICKET_EMP_ENTIREDataTable dt )
		{
			this.DgrdTicketEmp.DataSource = dt;
			this.DgrdTicketEmp.DataBind();
		}
		#endregion

		private void SelectCapexMastData( string TicketNo , string CapexNo)
		{
			CapexDS ds = null;

			ds = CapexController.SelectCapexMast( TicketNo, CapexNo );

			this.TbxDescription1.Text = ds.TB_CAPEX_MAST[0].Comment_1;
			this.TbxApproveID.Text = ds.TB_CAPEX_MAST[0].Approve_Id1;
			this.TbxApproveDate1.Text = ds.TB_CAPEX_MAST[0].Approve_Date1.ToString();
			this.TbxStatusFlag.Text = ds.TB_CAPEX_MAST[0].StatusFlag;
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlVendorDesc, "VENDOR_TYPE",true );
			this.DdnlVendorDesc.SelectedValue =ds.TB_CAPEX_MAST[0].VendorDesc;
		}

		private void InitializeControls( string TicketNo, string CapexNo)
		{
			SelectTicketData( TicketNo, CapexNo );
			SelectCapexMastData( TicketNo, CapexNo );

			CapexDS ds = CapexController.GetNewDataSource( 5 );
			DgrdDataGrid.DataSource= ds.TB_CAPEX_DES;
			DgrdDataGrid.DataBind();
			DataGrid dgrd = this.DgrdDataGrid;

		}

		public DataTable BindModelList( )
		{
			CapexDS ds = CapexController.SelectModelList();
			return ds.TB_BASE;		 // TB_QUOTATION_NO �ִ� ���̺� ���
		}

		public DataTable BindLedgerEntrylList( )
		{
			CapexDS ds = CapexController.SelectLedgerEntrylList();
			return ds.TB_BASE;		 // TB_QUOTATION_NO �ִ� ���̺� ���
		}

		public int GetStateIndex( string Model )
		{
			CapexDS ds = CapexController.SelectModelList();
 
			for ( int i = 0; i < ds.TB_BASE.Count; i++)
			{
				CapexDS.TB_BASERow dr = ds.TB_BASE[i]; // TB_QUOTATION_NO �ִ� ���̺� ���

				if ( dr.Col1.ToString() == Model )
				{
					return i;
				}
			}

			return 0;
		}

		public int GetStateIndexLedgerEntry( string Model )
		{
			CapexDS ds = CapexController.SelectLedgerEntrylList();
 
			for ( int i = 0; i < ds.TB_BASE.Count; i++)
			{
				CapexDS.TB_BASERow dr = ds.TB_BASE[i]; // TB_QUOTATION_NO �ִ� ���̺� ���

				if ( dr.Col1.ToString() == Model )
				{
					return i;
				}
			}

			return 0;
		}



		private void BtnAdd_Click(object sender, System.EventArgs e)
		{
			CapexController.AddRowsOnDataGrid( this.DgrdDataGrid, 1 );
		}

		private void BtnRequest_Click(object sender, System.EventArgs e)
		{
			string Flag = "D";
			string CapexNo = this.TbxCapexNo.Text;

			for( int inx=0; inx<this.DgrdDataGrid.Items.Count; inx++ )
			{
				if(((DropDownList)DgrdDataGrid.Items[inx].Cells[1].Controls[1]).SelectedValue == "") continue;
				if(((TextBox)DgrdDataGrid.Items[inx].Cells[2].Controls[1]).Text == "0")
				{
					ScriptHelper.ShowAlert(	MessageManager.GetMessage( "Common", "QTY_ZERO" ) );
					return ;	
				}
			}
			BtnCalculate_Click( sender,  e);
			SaveCapexData(Flag, CapexNo );	//���� ��û

			if (SaveCapexDetail(CapexNo) > 0)
			{
				SendMail(Flag, CapexNo);
				if(this.CurrentUserAuthority.Equals("A"))
					NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "REQUEST_DONE" ), "./SelectCapexListHelp.aspx" );		
				else
					NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "REQUEST_DONE" ), "./SelectCapexList.aspx" );		
			}
		}

		private void BtnSave_Click(object sender, System.EventArgs e)
		{
			string Flag = "H";
			string CapexNo = this.TbxCapexNo.Text;
			BtnCalculate_Click( sender,  e);
			SaveCapexData(Flag, CapexNo );	// �ӽ�����
			if (SaveCapexDetail(CapexNo) > 0)
			{
				//NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "SAVE_DONE" ), "./SelectCapexList.aspx" ); 
				//Helpdesk�� �Ʒ� ȭ������ ���ߵ��� ������?(lgssha:08/07/31)
				if(this.CurrentUserAuthority.Equals("A"))
					NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "SAVE_DONE" ), "./SelectCapexListHelp.aspx" );
				else
					NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "SAVE_DONE" ), "./SelectCapexList.aspx" ); 
			}
		}

		private int SaveCapexDetail(string CapexNo)
		{
			int cnt = 0;
			string UserID = this.CurrentUserID;
			for( int inx=0; inx<this.DgrdDataGrid.Items.Count; inx++ )
			{
				if(((DropDownList)DgrdDataGrid.Items[inx].Cells[1].Controls[1]).SelectedValue != "")
				{
					CapexController.InsertCapexDetail (CapexNo,
						((TextBox)DgrdDataGrid.Items[inx].Cells[0].Controls[1]).Text,
						((DropDownList)DgrdDataGrid.Items[inx].Cells[1].Controls[1]).SelectedValue, 
						((TextBox)DgrdDataGrid.Items[inx].Cells[2].Controls[1]).Text,
						((TextBox)DgrdDataGrid.Items[inx].Cells[3].Controls[1]).Text,
						((DropDownList)DgrdDataGrid.Items[inx].Cells[5].Controls[1]).SelectedValue,
						UserID);
					cnt++;
				}
			}
			return cnt;
		}

		private void SaveCapexData( string Flag, string CapexNo )
		{
			string UserID = this.CurrentUserAlterUserID;
			string Description = this.TbxDescription2.Text;
			CapexController.SaveCapexData(CapexNo, Flag, UserID, Description,this.DdnlVendorDesc.SelectedValue);

		}

		
		private void BtnCalculate_Click(object sender, System.EventArgs e)
		{
			this.TbxTotal.Text = CapexController.CalculateSum( this.DgrdDataGrid );		
		}

		//Capex ������ ���� ������ ����
		//������ �������� �ٽ� ������ �ʴ� ������ ��� ������.
		private void SendMail(string Flag, string CapexNo)
		{
			string TicketNo = this.TbxTicketNo.Text;
			string TicketDes = this.TbxDesc.Text;
			string CreateDate = this.TbxCreateDate.Text;
			string EmpName = this.DgrdTicketEmp.Items[0].Cells[4].Text;	
			string ApproveID1 = this.TbxApproveID.Text;
			string ApproveDate1 = this.TbxApproveDate1.Text;


			string mailBody;
			
			TicketDS ds = null;

			ds = CapexController.SelectMailCapex();

			MailMessage mailMsg = new MailMessage();
			//mailMsg.UrlContentBase = "http://www.w3.org/TR/REC-html40";

			for (int i = 0; i < ds.TB_BASE_MAIL.Count; i++)
			{
                if (ds.TB_BASE_MAIL[i].Col1 == "A") mailMsg.To.Add(new MailAddress(ds.TB_BASE_MAIL[i].Email));
                if (ds.TB_BASE_MAIL[i].Col1 == "D") mailMsg.From = new MailAddress(ds.TB_BASE_MAIL[i].Email);
			}//for	

			mailBody = "";	
		
			mailMsg.Subject = "[ " + TicketNo + " - " + EmpName + " ] ���� �����Ǿ����ϴ�." ;
			mailBody = mailBody		+ " ��û��ȣ : " + TicketNo.Trim() +"\n";
			mailBody = mailBody		+ " �� û �� : " + EmpName.Trim() +"\n";
			mailBody = mailBody		+ " �������� : " + CreateDate.Trim() +"\n";
			mailBody = mailBody		+ " ��û���� : " + TicketDes.Trim() +"\n";
			mailBody = mailBody		+ " ���������� : " + ApproveDate1.Trim() +"\n";
			mailBody = mailBody		+ " ���������� : " + ApproveID1.Trim() +"\n";

			mailBody = mailBody		+ " �����մϴ�.";

			mailMsg.Body = mailBody;


            string server = LGCNS.LAF.Common.ConfigurationManagement.LConfigurationManager.GetConfigValue("SMTP_SERVER");
            SmtpClient client = new SmtpClient(server);
            client.Send(mailMsg);

        }

	}
}

