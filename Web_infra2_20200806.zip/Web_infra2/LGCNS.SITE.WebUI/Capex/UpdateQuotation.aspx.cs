using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.Paging ;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Capex
{
	/// <summary>
	/// UpdateCapex�� ���� ��� �����Դϴ�.
	/// </summary>
	public class UpdateQuotation : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxQuotaNo;
		protected System.Web.UI.WebControls.DropDownList DdnlCategory;
		protected System.Web.UI.WebControls.TextBox TbxCategory;
		protected System.Web.UI.WebControls.TextBox TbxCategoryH;
		protected System.Web.UI.WebControls.TextBox TbxModelNo;
		protected System.Web.UI.WebControls.TextBox TbxMake;
		protected System.Web.UI.WebControls.DropDownList DdnlClassID;
		protected System.Web.UI.WebControls.TextBox TbxCPUSpeed;
		protected System.Web.UI.WebControls.DropDownList DdnlWBSE;
		protected System.Web.UI.WebControls.TextBox TbxComments;
		protected System.Web.UI.WebControls.TextBox TbxQty;
		protected System.Web.UI.WebControls.TextBox TbxUnitPrice;
		protected System.Web.UI.WebControls.TextBox TbxAmount;
		protected System.Web.UI.WebControls.TextBox TbxInvoiceID;
		protected System.Web.UI.WebControls.TextBox TbxCreateID;
		protected System.Web.UI.WebControls.TextBox TbxCreateDate;
		protected System.Web.UI.WebControls.TextBox TbxUpdateID;
		protected System.Web.UI.WebControls.TextBox TbxUpdateDate;
		protected System.Web.UI.WebControls.Button BtnSave;
		protected System.Web.UI.WebControls.Button BtnDelete;
		protected System.Web.UI.WebControls.DropDownList DdnlSystemID;
		protected System.Web.UI.WebControls.DropDownList DdnlCPUType;
		protected System.Web.UI.WebControls.TextBox TbxTypeDesc;
		protected System.Web.UI.WebControls.TextBox TbxModelNo1;
		protected System.Web.UI.WebControls.Button BtnCancel;


	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			XjosHelper.RegisterXjos(true);
			XjosHelper.SetValidator (this.TbxQty,
				new XjosValidator (XjosValidatorType.Required,		"������ �ʼ��Է��Դϴ�.") ,
				new XjosValidator (XjosValidatorType.Numeric, "������ ���ڸ� �Է����ּ���.")
				);
			XjosHelper.SetValidator (this.TbxInvoiceID,
				new XjosValidator (XjosValidatorType.Numeric, "InvoiceID �� ���ڸ� �Է����ּ���.")
				);			
			XjosHelper.SetValidator (this.TbxUnitPrice,
				new XjosValidator (XjosValidatorType.Required,		"������ �ʼ��Է��Դϴ�.") ,
				new XjosValidator (XjosValidatorType.Numeric, "������ ���ڸ� �Է����ּ���.")
				);
//			XjosHelper.SetValidator (this.TbxMDepreciation,
//				new XjosValidator (XjosValidatorType.Numeric, "Monthly_Depreciation�� ���ڸ� �Է����ּ���.")
//				);
			XjosHelper.SetValidator (this.TbxModelNo, 
				new XjosValidator (XjosValidatorType.Required,		"Model No�� �ʼ��Է��Դϴ�.") ,
				new XjosValidator (XjosValidatorType.Minlength ,"4", "Model No�� �ּ�4�ڸ� �Դϴ�.") 
				) ;		
			XjosHelper.ValidateOnClick (this.BtnSave);


			string QuotaNo = this.Request["QuotaNo"];
			string SPEC = this.Request["SPEC"];

//			string QuotaNo = "CNSSK-20070017";
//			string SPEC = "HP Laserjet 1320";

			if ( !this.IsPostBack )
			{
				InitializeControls(QuotaNo, SPEC);
			}

			// POST������� ȣ��ɶ�
			// NavigationHelper�� LDataGrid�� ���� POST������� ȣ��ɶ��� ���� ������ �ε�ÿ��� 
			// IsPostBack ������Ƽ�� true�� �ǹǷ� 
			// IsSubmittedBy ������Ƽ�� ���� POST������� ȣ��Ǿ������� üũ�� �� �ִ�.
			if(this.IsSubmittedBy)
			{
				InitializeControls(QuotaNo, SPEC);
			}

		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.DdnlCategory.SelectedIndexChanged += new System.EventHandler(this.DdnlCategory_SelectedIndexChanged);
			this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
			this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
			this.BtnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void InitializeControls(string QuotaNo, string SPEC )
		{
			CapexDS ds = null;

			LGCNS.SITE.Common.WebUI.CapexInfo.BindDropDownListCategory( this.DdnlCategory, false );
			LGCNS.SITE.Common.WebUI.CapexInfo.BindDropDownListWBSE( this.DdnlWBSE, true );
			LGCNS.SITE.Common.WebUI.CapexInfo.BindDropDownListCode( this.DdnlClassID, false ,"CLASS_ID");
			LGCNS.SITE.Common.WebUI.CapexInfo.BindDropDownListCode( this.DdnlCPUType, false ,"CPU_TYPE");
			LGCNS.SITE.Common.WebUI.CapexInfo.BindDropDownListCode( this.DdnlSystemID, false ,"SYSTEM_ID");

			ds = null;
			ds = CapexController.SelectOneUpQuotationData(QuotaNo, SPEC);

			this.TbxQuotaNo.Text = ds.TB_QUOTATION_UP[0].QuotaNo;
			this.DdnlCategory.SelectedValue = ds.TB_QUOTATION_UP[0].Category;
			this.TbxCategory.Text = "";
			this.TbxCategory.Enabled = false;
			this.TbxCategoryH.Text = ds.TB_QUOTATION_UP[0].Category_H;
            this.TbxModelNo.Text = ds.TB_QUOTATION_UP[0].ModelNo;
			this.TbxModelNo1.Text = ds.TB_QUOTATION_UP[0].ModelNo;
			this.TbxMake.Text = ds.TB_QUOTATION_UP[0].Make;
			this.DdnlClassID.SelectedValue = ds.TB_QUOTATION_UP[0].ClassID;
			this.TbxCPUSpeed.Text = ds.TB_QUOTATION_UP[0].CPUSpeed;
			this.DdnlSystemID.SelectedValue = ds.TB_QUOTATION_UP[0].SystemID;
			this.DdnlCPUType.SelectedValue = ds.TB_QUOTATION_UP[0].CPUType;
			this.TbxTypeDesc.Text = ds.TB_QUOTATION_UP[0].TypeDesc;
			this.DdnlWBSE.SelectedValue = ds.TB_QUOTATION_UP[0].WBSE;
			this.TbxComments.Text = ds.TB_QUOTATION_UP[0].Description;

			this.TbxQty.Text =  ds.TB_QUOTATION_UP[0].Qty;
			this.TbxUnitPrice.Text =  ds.TB_QUOTATION_UP[0].unit_price.ToString();
			this.TbxAmount.Text = ds.TB_QUOTATION_UP[0].Amount.ToString();
			this.TbxInvoiceID.Text = ds.TB_QUOTATION_UP[0].InvoiceId.ToString();
			this.TbxCreateID.Text = ds.TB_QUOTATION_UP[0].CreateID;
			this.TbxCreateDate.Text = ds.TB_QUOTATION_UP[0].CreateDate;
			this.TbxUpdateID.Text = this.CurrentUserAlterUserID;//ds.TB_QUOTATION_HIST[0].UpdateID;
			this.TbxUpdateDate.Text = ds.TB_QUOTATION_UP[0].UpdateDate;

		}

		private void BtnSave_Click(object sender, System.EventArgs e)
		{
			SaveOneQuotationData();

			NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "UPDATE_DONE" ), "./SelectQuotation.aspx" );	
		}

		private void BtnCancel_Click(object sender, System.EventArgs e)
		{
			NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "CANCEL_DONE" ), "./SelectQuotation.aspx" );
		}

		private void DdnlCategory_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (this.DdnlCategory.SelectedValue == "") 
			{
				this.TbxCategory.Enabled = true;
			}
			else
			{
				this.TbxCategory.Enabled = false;
				this.TbxCategory.Text = "";
			}

		}

		private void SaveOneQuotationData()
		{
			NameValueCollection searchCondition = new NameValueCollection();
			searchCondition["QuotaNo"] = this.TbxQuotaNo.Text;
			if (this.DdnlCategory.SelectedValue == "") 
			{
				searchCondition["Category"] = "$$$"+this.TbxCategory.Text;
			}
			else
			{
				searchCondition["Category"] = this.DdnlCategory.SelectedValue;
			}
			
			searchCondition["Category_H"] = this.TbxCategoryH.Text;
			searchCondition["ModelNo"] = this.TbxModelNo.Text;
			searchCondition["ModelNo1"] = this.TbxModelNo1.Text;
			searchCondition["Make"] = this.TbxMake.Text;
			searchCondition["ClassID"] = this.DdnlClassID.SelectedValue;
			searchCondition["CPUSpeed"] = this.TbxCPUSpeed.Text;
			searchCondition["SystemID"] = this.DdnlSystemID.SelectedValue;
			searchCondition["CPUType"] = this.DdnlCPUType.SelectedValue;
			searchCondition["TypeDesc"] = this.TbxTypeDesc.Text;
			searchCondition["WBSE"] = this.DdnlWBSE.SelectedValue;
			searchCondition["Description"] = this.TbxComments.Text;
			searchCondition["Qty"] = this.TbxQty.Text;
			searchCondition["unit_price"] = this.TbxUnitPrice.Text;
			searchCondition["UpdateID"] = this.CurrentUserAlterUserID;
			searchCondition["InvoiceId"] = this.TbxInvoiceID.Text;

			CapexController.UpdateQuotationData(searchCondition );

		}

		private void BtnDelete_Click(object sender, System.EventArgs e)
		{
			NameValueCollection searchCondition = new NameValueCollection();
			searchCondition["QuotaNo"] = this.TbxQuotaNo.Text;
			searchCondition["SPEC"] = this.TbxModelNo.Text;
			searchCondition["UpdateID"] = this.CurrentUserAlterUserID;

			CapexController.DeleteQuotationData(searchCondition);

			NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "DELETE_DONE" ), "./SelectQuotation.aspx" );	
		}


	}
}
