using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
//using System.Web.Mail;
using System.Net.Mail;
using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Capex
{
	/// <summary>
	/// ApproveCapex�� ���� ��� �����Դϴ�.
	/// </summary>
	public class ApproveCapex : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected System.Web.UI.WebControls.TextBox TbxArea;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdTicketEmp;
		protected System.Web.UI.WebControls.TextBox TbxDesc;
		protected System.Web.UI.WebControls.TextBox TbxRemark;
		protected System.Web.UI.WebControls.TextBox TbxReasonNoHandle;
		protected System.Web.UI.WebControls.TextBox TbxCloseContents;
		protected System.Web.UI.WebControls.TextBox TbxCapexNo;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
		protected System.Web.UI.WebControls.Button BtnApprove;
		protected System.Web.UI.WebControls.TextBox TbxDescription3;
		protected System.Web.UI.WebControls.Button BtnClose;
		protected System.Web.UI.WebControls.TextBox TbxStatusFlag;
		protected System.Web.UI.WebControls.TextBox TbxApproveID;
		protected System.Web.UI.WebControls.TextBox TbxRequestDate;
		protected System.Web.UI.WebControls.TextBox TbxDescription2;
		protected System.Web.UI.WebControls.TextBox TbxDescription1;
		protected System.Web.UI.WebControls.TextBox TbxApproveDate1;
		protected System.Web.UI.WebControls.TextBox TbxTickeDate;
		protected System.Web.UI.WebControls.DropDownList DdnlVendorDesc;
		protected System.Web.UI.WebControls.Button BtnReject;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; } 
			NavigationHelper.SetNavigation( this.BtnClose,	"",	"./SelectCapexList.aspx",	true);

			XjosHelper.RegisterXjos(true);

			string TicketNo = this.Request["TicketNo"];
			string CapexNo = this.Request["CapexNo"];

			// GET������� ȣ��ɶ�
			if ( !this.IsPostBack )
			{
				InitializeControls ( TicketNo, CapexNo );
			}

			// POST������� ȣ��ɶ�
			// NavigationHelper�� LDataGrid�� ���� POST������� ȣ��ɶ��� ���� ������ �ε�ÿ��� 
			// IsPostBack ������Ƽ�� true�� �ǹǷ� 
			// IsSubmittedBy ������Ƽ�� ���� POST������� ȣ��Ǿ������� üũ�� �� �ִ�.
			if(this.IsSubmittedBy)
			{
				InitializeControls ( TicketNo, CapexNo );
			}

            ClientScript.RegisterHiddenField("TicketNo", TbxTicketNo.Text) ;
            ClientScript.RegisterHiddenField("CapexNo", TbxCapexNo.Text) ;

		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnApprove.Click += new System.EventHandler(this.BtnApprove_Click);
			this.BtnReject.Click += new System.EventHandler(this.BtnReject_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		#region Ticket
		private void SelectTicketData( string TicketNo , string CapexNo)
		{
			this.TbxTicketNo.Text = TicketNo;
			this.TbxCapexNo.Text = CapexNo;

			TicketDS ds = null;

			ds = CapexController.SelectTicket( TicketNo );

			BindTicketInfo( ds.TB_TICKET_ENTIRE[0] );
			BindTicketEmpList( ds.TB_TICKET_EMP_ENTIRE );
		}

		private void BindTicketInfo( TicketDS.TB_TICKET_ENTIRERow dr )
		{
			this.TbxArea.Text = dr.Area;
			this.TbxDesc.Text = dr.Description;
			this.TbxRemark.Text = dr.Remark;
			this.TbxReasonNoHandle.Text = dr.ReasonNoHandle;
			this.TbxCloseContents.Text = dr.CloseContents;
			this.TbxTickeDate.Text = dr.CreateDate;	//ticket ������
		}

		private void BindTicketEmpList( TicketDS.TB_TICKET_EMP_ENTIREDataTable dt )
		{
			this.DgrdTicketEmp.DataSource = dt;
			this.DgrdTicketEmp.DataBind();
		}
		#endregion

		private void SelectCapexMastData( string TicketNo , string CapexNo)
		{
			CapexDS ds = null;

			ds = CapexController.SelectCapexMast( TicketNo, CapexNo );
			this.TbxDescription1.Text = ds.TB_CAPEX_MAST[0].Comment_1;
			this.TbxApproveDate1.Text = ds.TB_CAPEX_MAST[0].Approve_Date1.ToString();
			this.TbxApproveID.Text = ds.TB_CAPEX_MAST[0].Approve_Id1;
			this.TbxDescription2.Text = ds.TB_CAPEX_MAST[0].Comment_0;
			this.TbxRequestDate.Text = ds.TB_CAPEX_MAST[0].CreateDate.ToString();
			this.TbxStatusFlag.Text = ds.TB_CAPEX_MAST[0].StatusFlag;
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlVendorDesc, "VENDOR_TYPE",true );
			this.DdnlVendorDesc.SelectedValue =ds.TB_CAPEX_MAST[0].VendorDesc;
			
		}

		private void SelectCapexDesData(string CapexNo)
		{
			CapexDS ds = null;

			ds = CapexController.SelectCapexDes( CapexNo );
			DgrdDataGrid.DataSource= ds.TB_CAPEX_DES;
			DgrdDataGrid.DataBind();
		}


		private void InitializeControls( string TicketNo, string CapexNo)
		{
			SelectTicketData( TicketNo, CapexNo );
			SelectCapexMastData( TicketNo, CapexNo );
			SelectCapexDesData( CapexNo );
		}

		private void BtnApprove_Click(object sender, System.EventArgs e)
		{
			string Flag = "F";
			string CapexNo = this.TbxCapexNo.Text;
			string TicketNo = this.TbxTicketNo.Text;
			//2�����ν� capex no ����
			for (int i = 1; i < this.DgrdDataGrid.Items.Count + 1; i++)
			{
				CapexController.SaveMCapexNo(CapexNo, TicketNo, i.ToString());
			}

			SaveCapexData(Flag, CapexNo );	//2������
			SendMail(Flag, CapexNo);
			NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "APPROVE_DONE" ), "./SelectCapexList.aspx" );		
		}

		private void BtnReject_Click(object sender, System.EventArgs e)
		{
			string Flag = "E";
			string CapexNo = this.TbxCapexNo.Text;
			SaveCapexData(Flag, CapexNo );	// 2������
			NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "REJECT_DONE" ), "./SelectCapexList.aspx" );		
		}

		private void SaveCapexData( string Flag, string CapexNo )
		{
			string UserID = this.CurrentUserAlterUserID;
			string Description = this.TbxDescription3.Text;
			CapexController.SaveCapexData(CapexNo, Flag, UserID, Description,this.DdnlVendorDesc.SelectedValue);

		}

		//Capex ������ ���� ������ ����
		//������ �������� �ٽ� ������ �ʴ� ������ ��� ������.
		private void SendMail(string Flag, string CapexNo)
		{
			string TicketNo = this.TbxTicketNo.Text;
			string TicketDes = this.TbxDesc.Text;
			string CreateDate = this.TbxTickeDate.Text;
			string EmpName = this.DgrdTicketEmp.Items[0].Cells[4].Text;	
			string ApproveID1 = this.TbxApproveID.Text;
			string ApproveDate1 = this.TbxApproveDate1.Text;	


			string mailBody;
			
			TicketDS ds = null;

			ds = CapexController.SelectMailCapex();

			MailMessage mailMsg = new MailMessage();
			//mailMsg.UrlContentBase = "http://www.w3.org/TR/REC-html40";

			for (int i = 0; i < ds.TB_BASE_MAIL.Count; i++)
			{
                if (ds.TB_BASE_MAIL[i].Col1 == "D") mailMsg.To.Add(new MailAddress(ds.TB_BASE_MAIL[i].Email));
				if (Flag == "F")
				{
                    if (ds.TB_BASE_MAIL[i].Col1 == "C") mailMsg.Bcc.Add(new MailAddress(ds.TB_BASE_MAIL[i].Email));
				}
				//if (ds.TB_BASE_MAIL[i].Col1 == "A" ) mailMsg.From = mailMsg.From + ds.TB_BASE_MAIL[i].Email  + " ; ";
				if (ds.TB_BASE_MAIL[i].Col1 == "A" ) 
				{
					if(ds.TB_BASE_MAIL[i].Col2==this.CurrentUserID)
					{
                        mailMsg.From = new MailAddress(ds.TB_BASE_MAIL[i].Email);
					}
				}
			}//for	

			mailBody = "";	
			if (Flag == "E")
			{
				mailMsg.Subject = "[ " + TicketNo + " - " + EmpName + " ] CAPEX ���� �Ǿ����ϴ�." ;
				mailBody = mailBody		+ " ��û��ȣ : " + TicketNo.Trim() +"\n";
				mailBody = mailBody		+ " �� û �� : " + EmpName.Trim() +"\n";
				mailBody = mailBody		+ " �������� : " + CreateDate.Trim() +"\n";
				mailBody = mailBody		+ " ��û���� : " + TicketDes.Trim() +"\n";
				mailBody = mailBody		+ " ���������� : " + ApproveDate1.Trim() +"\n";
				mailBody = mailBody		+ " ���������� : " + ApproveID1.Trim() +"\n";

				mailBody = mailBody		+ " �����մϴ�.";

				mailMsg.Body = mailBody;
			}
			else
			{
				mailMsg.Subject = "[ " + TicketNo + " - " + EmpName + " ] CAPEX 2�� ���� �Ǿ����ϴ�.";
				mailBody = mailBody		+ " ��û��ȣ : " + TicketNo.Trim() +"\n";
				mailBody = mailBody		+ " �� û �� : " + EmpName.Trim() +"\n";
				mailBody = mailBody		+ " �������� : " + CreateDate.Trim() +"\n";
				mailBody = mailBody		+ " ��û���� : " + TicketDes.Trim() +"\n";
				mailBody = mailBody		+ " ���������� : " + ApproveDate1.Trim() +"\n";
				mailBody = mailBody		+ " ���������� : " + ApproveID1.Trim() +"\n";

				mailBody = mailBody		+ " �����մϴ�.";

				mailMsg.Body = mailBody;
			}


            string server = LGCNS.LAF.Common.ConfigurationManagement.LConfigurationManager.GetConfigValue("SMTP_SERVER");
            SmtpClient client = new SmtpClient(server);
            client.Send(mailMsg);

        }

	}
}

