using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Mail;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Capex
{
	/// <summary>
	/// ApproveCapexNext�� ���� ��� �����Դϴ�.
	/// </summary>
	public class ApproveCapexNext : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected System.Web.UI.WebControls.TextBox TbxArea;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdTicketEmp;
		protected System.Web.UI.WebControls.TextBox TbxDesc;
		protected System.Web.UI.WebControls.TextBox TbxRemark;
		protected System.Web.UI.WebControls.TextBox TbxReasonNoHandle;
		protected System.Web.UI.WebControls.TextBox TbxCloseContents;
		protected System.Web.UI.WebControls.TextBox TbxDescription1;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
		protected System.Web.UI.WebControls.TextBox TbxCapexNo;
		protected System.Web.UI.WebControls.TextBox TbxDescription2;
		protected System.Web.UI.WebControls.TextBox TbxApproveDate1;
		protected System.Web.UI.WebControls.TextBox TbxDescription3;
		protected System.Web.UI.WebControls.TextBox TbxTickeDate;
		protected System.Web.UI.WebControls.TextBox TbxRequestDate;
		protected System.Web.UI.WebControls.TextBox TbxApproveDate2;
		protected System.Web.UI.WebControls.Button BtnConfirm;
		protected System.Web.UI.WebControls.Button BtnClose;
		protected System.Web.UI.WebControls.TextBox TbxStatusFlag;
		protected System.Web.UI.WebControls.DropDownList DdnlVendorDesc;
		protected System.Web.UI.WebControls.TextBox TbxConfirmDate;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; } 

			XjosHelper.RegisterXjos(true);

			string TicketNo = this.Request["TicketNo"];
			string CapexNo = this.Request["CapexNo"];
			//			string TicketNo = "634289";
			//			string CapexNo = "CAPEX-OTIS-20070001";
			NavigationHelper.SetNavigation( this.BtnClose,	"",	"./SelectCapexList.aspx",	true);

			// GET������� ȣ��ɶ�
			if ( !this.IsPostBack )
			{
				InitializeControls ( TicketNo, CapexNo );
			}

			// POST������� ȣ��ɶ�
			// NavigationHelper�� LDataGrid�� ���� POST������� ȣ��ɶ��� ���� ������ �ε�ÿ��� 
			// IsPostBack ������Ƽ�� true�� �ǹǷ� 
			// IsSubmittedBy ������Ƽ�� ���� POST������� ȣ��Ǿ������� üũ�� �� �ִ�.
			if(this.IsSubmittedBy)
			{
				InitializeControls ( TicketNo, CapexNo );
			}

            ClientScript.RegisterHiddenField("TicketNo", TbxTicketNo.Text) ;
            ClientScript.RegisterHiddenField("CapexNo", TbxCapexNo.Text) ;
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnConfirm.Click += new System.EventHandler(this.BtnConfirm_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		#region Ticket
		private void SelectTicketData( string TicketNo , string CapexNo)
		{
			this.TbxTicketNo.Text = TicketNo;
			this.TbxCapexNo.Text = CapexNo;

			TicketDS ds = null;

			ds = CapexController.SelectTicket( TicketNo );

			BindTicketInfo( ds.TB_TICKET_ENTIRE[0] );
			BindTicketEmpList( ds.TB_TICKET_EMP_ENTIRE );
		}

		private void BindTicketInfo( TicketDS.TB_TICKET_ENTIRERow dr )
		{
			this.TbxArea.Text = dr.Area;
			this.TbxDesc.Text = dr.Description;
			this.TbxRemark.Text = dr.Remark;
			this.TbxReasonNoHandle.Text = dr.ReasonNoHandle;
			this.TbxCloseContents.Text = dr.CloseContents;
			this.TbxTickeDate.Text = dr.CreateDate;	//ticket ������
		}

		private void BindTicketEmpList( TicketDS.TB_TICKET_EMP_ENTIREDataTable dt )
		{
			this.DgrdTicketEmp.DataSource = dt;
			this.DgrdTicketEmp.DataBind();
		}
		#endregion

		private void SelectCapexMastData( string TicketNo , string CapexNo)
		{
			CapexDS ds = null;

			ds = CapexController.SelectCapexMast( TicketNo, CapexNo );
			this.TbxDescription1.Text = ds.TB_CAPEX_MAST[0].Comment_1;
			this.TbxApproveDate1.Text = ds.TB_CAPEX_MAST[0].Approve_Date1.ToString();
			this.TbxDescription2.Text = ds.TB_CAPEX_MAST[0].Comment_0;
			this.TbxRequestDate.Text = ds.TB_CAPEX_MAST[0].CreateDate.ToString();
			this.TbxDescription3.Text = ds.TB_CAPEX_MAST[0].Comment_2;
			this.TbxApproveDate2.Text = ds.TB_CAPEX_MAST[0].Approve_Date2.ToString();
			this.TbxConfirmDate.Text = ds.TB_CAPEX_MAST[0].Confirm_Date.ToString();
			this.TbxStatusFlag.Text = ds.TB_CAPEX_MAST[0].StatusFlag;
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlVendorDesc, "VENDOR_TYPE",true );
			this.DdnlVendorDesc.SelectedValue =ds.TB_CAPEX_MAST[0].VendorDesc;

		}

		private void SelectCapexDesData(string CapexNo)
		{
			CapexDS ds = null;

			ds = CapexController.SelectCapexDes( CapexNo );
			DgrdDataGrid.DataSource= ds.TB_CAPEX_DES;
			DgrdDataGrid.DataBind();
		}


		private void InitializeControls( string TicketNo, string CapexNo)
		{
			SelectTicketData( TicketNo, CapexNo );
			SelectCapexMastData( TicketNo, CapexNo );
			SelectCapexDesData( CapexNo );
		}

		private void BtnConfirm_Click(object sender, System.EventArgs e)
		{
			CapexController.ConfirmCSCCapexData(TbxCapexNo.Text);	
			NavigationHelper.Redirect( MessageManager.GetMessage( "Common", "CONFIRM_DONE" ), "./SelectCapexList.aspx" );	
		}

	}
}

