using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Capex
{
	/// <summary>
	/// SelectCapexListAsXls�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectCapexListAsXls : LGCNS.SITE.Common.SITEPageBase
	{
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }

			this.DgrdDataGrid.EnableViewState = false ;

			try
			{
				SearctCapexListPaging() ;
			}
			catch(Exception ex)
			{
				ScriptHelper.ShowAlert ("�����ٿ�ε��� ������ �߻��߽��ϴ�. (" + ex.Message) ;
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
            this.Load += new System.EventHandler(this.Page_Load);

        }
		#endregion

		private void SearctCapexListPaging()
		{
			NameValueCollection searchCondition = new NameValueCollection();
			searchCondition["CapexNo"] = ""; //Request["TbxCapexNo"];
			searchCondition["TicketNo"] = Request["TbxTicketNo"];
			searchCondition["CapexStatus"] = Request["DdnlCStatus"];
			searchCondition["Area"] = Request["DdnlArea"];
			searchCondition["EmpNo"] = Request["TbxEmpNo"];
			searchCondition["EmpName"] = Request["TbxEmpName"];
			searchCondition["VendorDesc"] = Request["DdnlVendorDesc"];
			searchCondition["CreateDateFrom"] = Request["TbxCreateDateFrom"];
			searchCondition["CreateDateTo"] = Request["TbxCreateDateTo"];
			searchCondition["CFlag"] = Request["DdnlFlag"];
			searchCondition["OptDate"] = Request["DdnlDate"];

			string CapexNo = ""; //this.Request["TbxCapexNo"];
			string UserID = this.CurrentUserID;
			string Flag1 = "";
			CapexDS ds = CapexController.SelectAuthority(CapexNo, UserID) ;

			if (ds.TB_BASE.Count > 0)
			{
				Flag1 = ds.TB_BASE[0].Col1; //�����
			}
			else
			{
				Flag1 = ""; //�����
			}
			ds = CapexController.SelectCapexDataList("B", "H",  0, 0, searchCondition  );
			this.DgrdDataGrid.ShowFooterMessage = false;
			this.DgrdDataGrid.DataSource = ds.TB_CAPEX_LIST1;
			this.DgrdDataGrid.DataBind();
			
			LGCNS.SITE.Common.WebUI.DataToXls.datagridToXls(Response,this.DgrdDataGrid,"CapexList.xls");
			//this.DgrdDataGrid.ExportAsXls ("CapexList.xls") ;
		}


	}
}
