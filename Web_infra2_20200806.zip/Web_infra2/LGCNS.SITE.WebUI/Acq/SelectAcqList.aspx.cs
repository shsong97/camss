using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.Paging ;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Acq
{
	/// <summary>
	/// SelectAcqList�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectAcqList : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected System.Web.UI.WebControls.TextBox TbxEmpNo;
		protected System.Web.UI.WebControls.TextBox TbxEmpName;
		protected System.Web.UI.WebControls.TextBox TbxPageSize;
		protected System.Web.UI.WebControls.Label LblTotalCount;
		protected System.Web.UI.WebControls.DropDownList DdlPage;
		protected System.Web.UI.WebControls.Label LblTotalPages;
		protected System.Web.UI.WebControls.Button BtnSearch;
		protected System.Web.UI.WebControls.Button BtnClear;
		protected System.Web.UI.WebControls.Button BtnSaveExcel;
		protected System.Web.UI.WebControls.TextBox TbxConfirmDateFrom;
		protected System.Web.UI.WebControls.TextBox TbxConfirmDateTo;
		protected System.Web.UI.WebControls.DropDownList DdnlConfirm;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected System.Web.UI.WebControls.TextBox TbxCreateDateFrom;
		protected System.Web.UI.WebControls.TextBox TbxCreateDateTo;
		protected System.Web.UI.WebControls.DropDownList DdnlVendorDesc;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }
			XjosHelper.RegisterXjos(true);

			NavigationHelper.RegisterHiddenIFrame ("HiddenFrame") ;
			NavigationHelper.SetNavigation (this.BtnSaveExcel, "HiddenFrame", "SelectAcqListAsXls.aspx", true) ;

			this.DgrdDataGrid.NavigateOnRowClick(
				"",
				"SelectAcq.aspx",
				new string [1] {"TicketNo"},  // LinkŬ���� ������ Query String �� key�� �迭
				new int [1] {0}, // LinkŬ���� ������ Query String �� value���� ������ Cell Index�� �迭
				false  // // ������������ ���� SelectTicket.aspx ���� submit��Ų��. (POST������� ȣ���Ѵ�.)
				) ;

			SetValidator();

			if( !this.IsPostBack )
			{
				InitControls();
				//BindAcqList();
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
			this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		private void BindAcqList()
		{
			NameValueCollection SearchCondition = new NameValueCollection();
			SearchCondition["Area"] = this.DdnlArea.SelectedValue;
			SearchCondition["TicketNo"] = this.TbxTicketNo.Text;
			SearchCondition["EmpNo"] = this.TbxEmpNo.Text;
			SearchCondition["EmpName"] = this.TbxEmpName.Text;
			SearchCondition["CreateDateFrom"] = this.TbxCreateDateFrom.Text;
			SearchCondition["CreateDateTo"] = this.TbxCreateDateTo.Text;
			SearchCondition["ConfirmDateFrom"] = this.TbxConfirmDateFrom.Text;
			SearchCondition["ConfirmDateTo"] = this.TbxConfirmDateTo.Text;
			SearchCondition["ConfirmFlag"] = this.DdnlConfirm.SelectedValue;
			
			if(this.CurrentUserAuthority=="Y") //vendor�̸� �ڽŸ� ��ȸ ����
				SearchCondition["VendorDesc"] = this.CurrentUserID;
			else
				SearchCondition["VendorDesc"] = this.DdnlVendorDesc.SelectedValue;

			int currentPage = Convert.ToInt32(this.DdlPage.SelectedValue);
			int pageSize	= Convert.ToInt32(this.TbxPageSize.Text);

			AcqDS ds = AcqController.SelectAcqList( currentPage, pageSize, SearchCondition );

			this.DgrdDataGrid.DataSource = ds.Tables["TB_ACQ_LIST"];
			this.DgrdDataGrid.DataBind();

			//��Ͽ� ���� ����
			int totalPage			= PagingHelper.GetTotalPage (ds) ;
			this.LblTotalCount.Text = PagingHelper.GetTotalCount (ds).ToString () ;
			this.LblTotalPages.Text = totalPage.ToString() ;

			//Page DropDownList Setting
			this.DdlPage.Items.Clear();
			for(int i = 1; i <= totalPage ; i++)
			{
				this.DdlPage.Items.Add(i.ToString());
			}

			//�������� ������ ���õǵ���
			if(this.DdlPage.Items.Count > 0)
			{
				if( currentPage <= totalPage )
				{
					this.DdlPage.Items[currentPage - 1].Selected = true;
				}
				else
				{
					this.DdlPage.Items[0].Selected = true;
				}
			}
		}

		private void InitControls()
		{
			LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea, true );
			this.TbxTicketNo.Text = "";
			this.TbxEmpNo.Text = "";
			this.TbxEmpName.Text = "";
			this.TbxCreateDateFrom.Text = "";
			this.TbxCreateDateTo.Text = "";
			this.TbxConfirmDateFrom.Text = "";
			this.TbxConfirmDateTo.Text = "";
			LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlVendorDesc, "VENDOR_TYPE",true );

			if(this.CurrentUserAuthority=="Y")
			{
				GetVendorIndex(this.CurrentUserName);
				this.DdnlVendorDesc.Enabled=false;
			}

			this.TbxPageSize.Text = "10";
			this.LblTotalCount.Text = "0";

			this.DdlPage.Items.Clear();
			this.DdlPage.Items.Add( "1" );
			
			this.LblTotalPages.Text = "1";
			

		}

		private void GetVendorIndex( string VendorId )
		{
 
			for ( int i = 0; i < DdnlVendorDesc.Items.Count; i++)
			{
				if ( DdnlVendorDesc.Items[i].Text.Equals(VendorId) )
				{
					DdnlVendorDesc.SelectedIndex=i;
					return;
				}
			}
		}

		private void SetValidator()
		{
			XjosHelper.SetValidator (this.TbxCreateDateFrom,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);
			XjosHelper.SetValidator (this.TbxCreateDateTo,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);
			XjosHelper.SetValidator (this.TbxConfirmDateFrom,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);
			XjosHelper.SetValidator (this.TbxConfirmDateTo,
				new XjosValidator (XjosValidatorType.Date, "���� ������ �ƴմϴ�.")
				);
			XjosHelper.ValidateOnClick(this.BtnSearch);
		}

		private void BtnClear_Click(object sender, System.EventArgs e)
		{
			InitControls();
		}

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			BindAcqList();
		}
	}
}
