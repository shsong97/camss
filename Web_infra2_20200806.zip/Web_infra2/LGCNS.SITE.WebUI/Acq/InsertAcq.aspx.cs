using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Acq
{
	/// <summary>
	/// InsertAcq�� ���� ��� �����Դϴ�.
	/// </summary>
	public class InsertAcq : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
		protected System.Web.UI.WebControls.Button BtnSave;
		protected System.Web.UI.WebControls.Button BtnCancel;
		protected System.Web.UI.WebControls.TextBox TbxTotal;
		protected System.Web.UI.WebControls.TextBox TbxEngComment;
		protected System.Web.UI.WebControls.Button BtnAdd;
		protected System.Web.UI.WebControls.TextBox TbxRequestDate;
        protected System.Web.UI.WebControls.DropDownList DdnlVendorDesc;
		protected System.Web.UI.WebControls.Button BtnCalculate;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }
			XjosHelper.RegisterXjos(true);

			string TicketNo = this.Request["TicketNo"];

			if ( AcqController.isExistAcq( TicketNo ) )
			{
				NavigationHelper.Redirect( "SelectAcq.aspx?TicketNo=" + TicketNo );
				return;
			}

			ScriptHelper.SetConfirmMessageOn(
				this.BtnSave,
				MessageManager.GetMessage( "Common", "REGISTER_QUESTION" ) 
			);

			NavigationHelper.SetHistoryBack( this.BtnCancel );

			if (this.IsSubmittedBy) 
			{
				this.TbxTicketNo.Text = this.Request["TicketNo"];
				this.TbxRequestDate.Text = this.Request["TbxCreateDate"];

                GetAcqData( this.Request["TicketNo"] );

				AcqDS ds = AcqController.GetNewDataSource( 5 );
				DgrdDataGrid.DataSource= ds.TB_ACQ_DETAIL;
				DgrdDataGrid.DataBind();
			}

            ClientScript.RegisterHiddenField( "TicketNo", this.TbxTicketNo.Text );
	
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            this.BtnCalculate.Click += new System.EventHandler(this.BtnCalculate_Click);
            this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
            this.Load += new System.EventHandler(this.Page_Load);

        }
		#endregion

        private void GetAcqData( string TicketNo )
        {
            LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlVendorDesc, "VENDOR_TYPE",true );
            AcqDS ds = AcqController.SelectAcq( TicketNo );

            if( ds.TB_ACQ.Count == 1 )
            {
                AcqDS.TB_ACQRow dr = ds.TB_ACQ[0];

                this.TbxTicketNo.Text = dr.TicketNo;
				
                this.TbxRequestDate.Text = ds.TB_TICKET[0].CreateDate.ToShortDateString();

                this.TbxEngComment.Text = dr.EngComment;                
                this.DdnlVendorDesc.SelectedValue=dr.VendorDesc;               

                this.DgrdDataGrid.DataSource = ds.TB_ACQ_DETAIL;
                this.DgrdDataGrid.DataBind();
            }
        }
		private void BtnCalculate_Click(object sender, System.EventArgs e)
		{
			this.TbxTotal.Text = AcqController.CalculateSum( this.DgrdDataGrid );
		}

        public DataTable BindLedgerEntrylList( )
        {
            CapexDS ds = AcqController.SelectLedgerEntrylList();
            return ds.TB_BASE;		 // TB_QUOTATION_NO �ִ� ���̺� ���
        }

		private void BtnSave_Click(object sender, System.EventArgs e)
		{
			AcqDS ds = null;

			ds = AcqController.GetDataSource( this.DgrdDataGrid, this.TbxTicketNo.Text );
			ds.TB_ACQ_DETAIL[0].Division = "E";
			ds.EnforceConstraints = false;

			SetAcqInfo( ds );
			AcqController.InsertAcq( ds );

			NavigationHelper.Redirect(
				MessageManager.GetMessage( "Common", "REGISTER_DONE" ),
				"",
				"SelectAcq.aspx?TicketNo=" + this.TbxTicketNo.Text
			);
		}

		private void SetAcqInfo( AcqDS ds )
		{
			AcqDS.TB_ACQRow dr = ds.TB_ACQ.NewTB_ACQRow();

			dr.TicketNo = this.TbxTicketNo.Text;

			dr.EngComment = this.TbxEngComment.Text;
			dr.CreateID = this.CurrentUserID;
			dr.CreateDate = DateTime.Now;
			dr.UpdateID = this.CurrentUserID;
			dr.UpdateDate = DateTime.Now;
			dr.VendorDesc = this.DdnlVendorDesc.SelectedValue;

			ds.TB_ACQ.AddTB_ACQRow( dr );
		}


		private void BtnAdd_Click(object sender, System.EventArgs e)
		{
			AcqController.AddRowsOnDataGrid( this.DgrdDataGrid, 1 );
			BtnCalculate_Click( sender, e );
		}
	}
}

