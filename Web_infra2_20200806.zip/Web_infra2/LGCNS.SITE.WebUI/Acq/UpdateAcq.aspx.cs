using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
//using System.Web.Mail;
using System.Net.Mail;
using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;
using LGCNS.SITE.CAPEX;

namespace LGCNS.SITE.WebUI.Acq
{
	/// <summary>
	/// UpdateAcq�� ���� ��� �����Դϴ�.
	/// </summary>
	public class UpdateAcq : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
		protected System.Web.UI.WebControls.TextBox TbxTotal;
		protected System.Web.UI.WebControls.Button BtnCalculate;
		protected System.Web.UI.WebControls.Button BtnSave;
		protected System.Web.UI.WebControls.DropDownList DropDownList1;
		protected System.Web.UI.WebControls.TextBox TbxEngComment;
		protected System.Web.UI.WebControls.TextBox TbxAdminComment;
		protected System.Web.UI.WebControls.Button BtnConfirm;
		protected System.Web.UI.WebControls.TextBox TbxRequestDate;
		protected System.Web.UI.WebControls.Button BtnAdd;
		protected System.Web.UI.WebControls.TextBox TbxAcqNo;
		protected System.Web.UI.WebControls.DropDownList DdnlVendorDesc;
		protected System.Web.UI.WebControls.Button BtnCancel;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }
			XjosHelper.RegisterXjos(true);

			ScriptHelper.SetConfirmMessageOn(
				this.BtnSave,
				MessageManager.GetMessage( "Common", "UPDATE_QUESTION" ) 
				);

			ScriptHelper.SetConfirmMessageOn(
				this.BtnConfirm,
				MessageManager.GetMessage( "Common", "UPDATE_QUESTION" ) + 
				MessageManager.GetMessage( "Common", "CONFIRM_QUESTION" ) 
				);

			NavigationHelper.SetHistoryBack( this.BtnCancel );

			if ( !this.IsPostBack )
			{
				GetAcqData( this.Request["TicketNo"] );
				BtnCalculate_Click( sender, e );
				AcqController.SetIndex( this.DgrdDataGrid );
			}

			if ( this.IsSubmittedBy )
			{
				GetAcqData( this.Request["TicketNo"] );
				BtnCalculate_Click( sender, e );
				AcqController.SetIndex( this.DgrdDataGrid );
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            this.BtnCalculate.Click += new System.EventHandler(this.BtnCalculate_Click);
            this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
            this.BtnConfirm.Click += new System.EventHandler(this.BtnConfirm_Click);
            this.Load += new System.EventHandler(this.Page_Load);

        }
		#endregion

		private void GetAcqData( string TicketNo )
		{
			AcqDS ds = AcqController.SelectAcq( TicketNo );

			if( ds.TB_ACQ.Count == 1 )
			{
				AcqDS.TB_ACQRow dr = ds.TB_ACQ[0];

				this.TbxTicketNo.Text = dr.TicketNo;
				
				this.TbxRequestDate.Text = ds.TB_TICKET[0].CreateDate.ToShortDateString();

				if( !dr.IsAcqNoNull() )
					this.TbxAcqNo.Text = dr.AcqNo;

				this.TbxEngComment.Text = dr.EngComment;
				if ( ! dr.IsAdmCommentNull() )
				{
					this.TbxAdminComment.Text = dr.AdmComment;
				}
				LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlVendorDesc, "VENDOR_TYPE",true );
				this.DdnlVendorDesc.SelectedValue=dr.VendorDesc;

				this.DgrdDataGrid.DataSource = ds.TB_ACQ_DETAIL;
				this.DgrdDataGrid.DataBind();
			}
			else
			{
				NavigationHelper.Redirect(
					MessageManager.GetMessage( "Common", "NO_TICKET" ),
					"SelectAcqList.aspx"
					);
			}
		}

		public DataTable dtAcqDivision()
		{
			DataTable dt = new DataTable();

			dt.Columns.Add( new DataColumn( "Code", typeof(string)) );
			dt.Columns.Add( new DataColumn( "CodeDesc", typeof(string)) );

			DataRow dr;
 
			dr = dt.NewRow(); dr[0] = ""; dr[1] = ""; dt.Rows.Add(dr);
			dr = dt.NewRow(); dr[0] = "E"; dr[1] = "Expensed"; dt.Rows.Add(dr);
			dr = dt.NewRow(); dr[0] = "C"; dr[1] = "Capex"; dt.Rows.Add(dr);
			dr = dt.NewRow(); dr[0] = "P"; dr[1] = "PassThrough"; dt.Rows.Add(dr);

			return dt;
		}

		public int GetSelectedIndex( string s )
		{
			int index = 0;

			switch( s )       
			{         
				case "E":   
					index = 1;
					break;
				case "C":            
					index = 2;
					break;
				case "P":            
					index = 3;
					break;
				default:            
					index = 0;
					break;      
			}

			return index;
		}

		private void BtnCalculate_Click(object sender, System.EventArgs e)
		{
			this.TbxTotal.Text = AcqController.CalculateSum( this.DgrdDataGrid );
		}

		private void BtnAdd_Click(object sender, System.EventArgs e)
		{
			AcqController.AddRowsOnDataGrid( this.DgrdDataGrid, 1 );
			BtnCalculate_Click( sender, e );
			AcqController.SetIndex( this.DgrdDataGrid );
		}

		private void BtnSave_Click(object sender, System.EventArgs e)
		{
			AcqDS ds = null;

			ds = AcqController.GetDataSource( this.DgrdDataGrid, this.TbxTicketNo.Text );
			ds.EnforceConstraints = false;

			SetAcqInfo( ds, false );
			AcqController.UpdateAcq( ds );

			NavigationHelper.Redirect(
				MessageManager.GetMessage( "Common", "UPDATE_DONE" ),
				"",
				"UpdateAcq.aspx?TicketNo=" + this.TbxTicketNo.Text
			);
		}

		private void BtnConfirm_Click(object sender, System.EventArgs e)
		{
			AcqDS ds = null;

			ds = AcqController.GetDataSource( this.DgrdDataGrid, this.TbxTicketNo.Text );
			ds.EnforceConstraints = false;

			SetAcqInfo( ds, true );
			AcqController.UpdateAcq( ds );
			SendMail(); 
			NavigationHelper.Redirect(
				MessageManager.GetMessage( "Common", "CONFIRM_DONE" ),
				"",
				"SelectAcq.aspx?TicketNo=" + this.TbxTicketNo.Text
				);
		}

		private void SetAcqInfo( AcqDS ds, bool isConfirm )
		{
			AcqDS.TB_ACQRow dr = ds.TB_ACQ.NewTB_ACQRow();

			dr.TicketNo = this.TbxTicketNo.Text;

			dr.EngComment = this.TbxEngComment.Text;
			dr.AdmComment = this.TbxAdminComment.Text;
			
			dr.CreateID = this.CurrentUserID;
			dr.CreateDate = DateTime.Now;
			
			dr.UpdateID = this.CurrentUserID;
			dr.UpdateDate = DateTime.Now;
            dr.VendorDesc = this.DdnlVendorDesc.SelectedValue;
			if ( isConfirm )
			{
				dr.ConfirmID = this.CurrentUserID;
				dr.ConfirmDate = DateTime.Now;
			}

			dr.AcqNo = this.TbxAcqNo.Text;
			ds.TB_ACQ.AddTB_ACQRow( dr );
		}

		public int GetStateIndexA3( string A3 )
		{
			if ( A3 == "Y" )
			{
				return 1;
			}
			return 0;
		}


		public DataTable BindLedgerEntrylList( )
		{
			CapexDS ds = AcqController.SelectLedgerEntrylList();
			return ds.TB_BASE;		 // TB_QUOTATION_NO �ִ� ���̺� ���
		}


		public int GetStateIndexLedgerEntry( string LedgerEntry )
		{
			CapexDS ds = AcqController.SelectLedgerEntrylList();
 
			for ( int i = 0; i < ds.TB_BASE.Count; i++)
			{
				CapexDS.TB_BASERow dr = ds.TB_BASE[i]; // TB_QUOTATION_NO �ִ� ���̺� ���

				if ( dr.Col1.ToString() == LedgerEntry )
				{
					return i;
				}
			}

			return 0;
		}



		//Capex ������ ���� ������ ����
		//������ �������� �ٽ� ������ �ʴ� ������ ��� ������.
		private void SendMail()
		{
			string TicketNo = this.TbxTicketNo.Text;
			string UserID = this.CurrentUserAlterUserID;
			string TicketDes = "";
			string CreateDate = "";
			string EmpName = "";
			string mailBody;
			
			TicketDS ds = null;
			ds = AcqController.SelectTicketAcq(TicketNo);
			TicketDes = ds.TB_TICKET_MAIL[0].Description;
			CreateDate = ds.TB_TICKET_MAIL[0].InsertDate;
			EmpName = ds.TB_TICKET_MAIL[0].EmpName;
			ds = null;
			ds = AcqController.SelectMailCapex();

			MailMessage mailMsg = new MailMessage();
			//mailMsg.UrlContentBase = "http://www.w3.org/TR/REC-html40";

			for (int i = 0; i < ds.TB_BASE_MAIL.Count; i++)
			{
                if (ds.TB_BASE_MAIL[i].Col1 == "A") mailMsg.To.Add(new MailAddress(ds.TB_BASE_MAIL[i].Email));
                if (ds.TB_BASE_MAIL[i].Col1 == "D") mailMsg.From = new MailAddress(ds.TB_BASE_MAIL[i].Email);
			}//for					
			mailMsg.Subject = "[ " + TicketNo + " - " + EmpName + " ] Capex ���� �Ǿ����ϴ�.";

			//mail Body
			mailBody = "";
			mailBody = mailBody		+ " ��û��ȣ : " + TicketNo.Trim() +"\n";
			mailBody = mailBody		+ " �� û �� : " +  EmpName.Trim() +"\n";
			mailBody = mailBody		+ " �������� : " + CreateDate.Trim() +"\n";
			mailBody = mailBody		+ " ��û���� : " + TicketDes.Trim() +"\n";

			mailBody = mailBody		+ " �����մϴ�.";

			mailMsg.Body = mailBody;



            string server = LGCNS.LAF.Common.ConfigurationManagement.LConfigurationManager.GetConfigValue("SMTP_SERVER");
            SmtpClient client = new SmtpClient(server);
            client.Send(mailMsg);
        }

	}
}
