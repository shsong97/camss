using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Acq
{
	/// <summary>
	/// PrintAcq�� ���� ��� �����Դϴ�.
	/// </summary>
	public class PrintAcq : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.Label LblTicketNo;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
		protected System.Web.UI.WebControls.Label LblEngComment;
		protected System.Web.UI.WebControls.Label LblAdmComment;
		protected System.Web.UI.WebControls.Label LblTotal;
		protected System.Web.UI.WebControls.Label LblCSC;
		protected System.Web.UI.WebControls.Label LblRequestDate;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// ���⿡ ����� �ڵ带 ��ġ�Ͽ� �������� �ʱ�ȭ�մϴ�.
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }
			XjosHelper.RegisterXjos(true);

			GetAcqData( this.Request["TicketNo"] );
			this.LblTotal.Text = CalculateSum( this.DgrdDataGrid );
			//AcqController.SetIndex( this.DgrdDataGrid );

			ConvertNumber( this.DgrdDataGrid );

		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void ConvertNumber( DataGrid dgrd )
		{
			for( int inx = 0; inx < dgrd.Items.Count; inx++ )
			{
				dgrd.Items[inx].Cells[3].Text = AddComma( dgrd.Items[inx].Cells[3].Text );
				dgrd.Items[inx].Cells[4].Text = AddComma( dgrd.Items[inx].Cells[4].Text );
			}
		}

		private string CalculateSum( DataGrid dgrd )
		{
			ulong SubTotal = 0;
			ulong Total = 0;

			for( int inx = 0; inx < dgrd.Items.Count; inx++ )
			{
				string Amount = dgrd.Items[inx].Cells[3].Text;
				string UnitCost = dgrd.Items[inx].Cells[4].Text;

				if( Amount.Length < 1 || UnitCost.Length < 1 )
				{
					SubTotal = 0;
				}
				else
				{ 
					try
					{
						SubTotal = ulong.Parse( Amount ) * ulong.Parse( UnitCost );
					}
					catch( Exception ex )
					{
						string errmsg=ex.Message;
						ScriptHelper.ShowAlert(	MessageManager.GetMessage( "Acq", "NO_NUMERIC" ) );
						return "Error";
					}
				}

				//dgrd.Items[inx].Cells[6].Text = SubTotal.ToString();
				dgrd.Items[inx].Cells[6].Text = AddComma( SubTotal );
				Total = Total + SubTotal;
			}
				
			SubTotal =  (ulong)(Total *  0.072); //CSC Markup ���� ��� 
			this.LblCSC.Text = SubTotal.ToString();

			this.LblCSC.Text = AddComma( this.LblCSC.Text );
			//return Total.ToString();
			Total = (ulong)( Total + SubTotal );
			return AddComma( Total );
		}

		public string AddComma( string number )
		{
			if ( LGCNS.SITE.Common.CommonUtil.isNumeric( number ) )
			{
				return AddComma( ulong.Parse( number ) );
			}
			else
			{
				return number;
			}
		}	

		public string AddComma( ulong number )
		{
			string tempStr = number.ToString();
			int Length = tempStr.Length;

			int remain = (int)( Length % 3 );
			int mod = (int)( Length / 3 );

			string final = "";

			if( remain > 0 )
			{
				final = tempStr.Substring( 0, remain ) + ",";
			}

			for( int inx = 1; inx <= mod ; inx++ )
			{
				final = final + tempStr.Substring( remain + ( 3*(inx-1) ) , 3 ) + ",";
			}
			
			final = final.Substring( 0, final.Length - 1 );

			return final;
		}

		private void GetAcqData( string TicketNo )
		{
			AcqDS ds = AcqController.SelectAcqPrint( TicketNo );

			if( ds.TB_ACQ.Count == 1 )
			{
				AcqDS.TB_ACQRow dr = ds.TB_ACQ[0];

				this.LblTicketNo.Text = dr.TicketNo;

				if( !dr.IsEngCommentNull() )
					this.LblEngComment.Text = dr.EngComment;

				if( !dr.IsAdmCommentNull() )
				this.LblAdmComment.Text = dr.AdmComment;
//
//				this.TbxRequestDate.Text = ds.TB_TICKET[0].CreateDate.ToShortDateString();
//
//				this.TbxEngComment.Text = dr.EngComment;
//				if ( ! dr.IsAdmCommentNull() )
//				{
//					this.TbxAdminComment.Text = dr.AdmComment;
//				}
//
//				this.TbxCreateID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.CreateID );
//				this.TbxCreateDate.Text = dr.CreateDate.ToShortDateString() + " " + dr.CreateDate.ToShortTimeString();
//
//				this.TbxUpdateID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.UpdateID );
//				this.TbxUpdateDate.Text = dr.UpdateDate.ToShortDateString() + " " + dr.UpdateDate.ToShortTimeString();
//
//				if ( !dr.IsConfirmIDNull() )
//					this.TbxConfirmID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.ConfirmID );
//				if ( !dr.IsConfirmDateNull() )
//					this.TbxConfirmDate.Text = dr.ConfirmDate.ToShortDateString() + " " + dr.ConfirmDate.ToShortTimeString();
//

				AcqDS.TB_TICKETRow drTicket = ds.TB_TICKET[0];
				this.LblRequestDate.Text = drTicket.CreateDate.ToShortDateString();

				this.DgrdDataGrid.DataSource = ds.TB_ACQ_DETAIL;
				this.DgrdDataGrid.DataBind();
			}
			else
			{
				ScriptHelper.ShowAlert(
					MessageManager.GetMessage( "Common", "NO_TICKET" )
				);

				NavigationHelper.Close( false );
			}
		}
	}
}
