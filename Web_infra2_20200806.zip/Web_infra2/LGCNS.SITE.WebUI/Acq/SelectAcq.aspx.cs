using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.WebUI.Acq
{
	/// <summary>
	/// SelectAcq�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectAcq : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxTicketNo;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
		protected System.Web.UI.WebControls.TextBox TbxTotal;
		protected System.Web.UI.WebControls.TextBox TbxEngComment;
		protected System.Web.UI.WebControls.TextBox TbxAdminComment;
		protected System.Web.UI.WebControls.Button BtnConfirm;
		protected System.Web.UI.WebControls.Button BtnUpdate;
		protected System.Web.UI.WebControls.Button BtnPrint;
		protected System.Web.UI.WebControls.TextBox TbxRequestDate;
		protected System.Web.UI.WebControls.TextBox TbxCreateID;
		protected System.Web.UI.WebControls.TextBox TbxCreateDate;
		protected System.Web.UI.WebControls.TextBox TbxUpdateID;
		protected System.Web.UI.WebControls.TextBox TbxUpdateDate;
		protected System.Web.UI.WebControls.TextBox TbxConfirmID;
		protected System.Web.UI.WebControls.TextBox TbxConfirmDate;
		protected System.Web.UI.WebControls.TextBox TbxAcqNo;
		protected System.Web.UI.WebControls.TextBox TbxAssetNo;
		protected System.Web.UI.WebControls.Button BtnAssetNo;
		protected System.Web.UI.WebControls.DropDownList DdnlVendorDesc;
		protected System.Web.UI.WebControls.Button BtnCancel;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }
			XjosHelper.RegisterXjos(true);

			NavigationHelper.SetNavigation(
				this.BtnUpdate,
				"",
				"UpdateAcqForEngineer.aspx",
				true
			);

			NavigationHelper.SetNavigation(
				this.BtnConfirm,
				"",
				"UpdateAcq.aspx",
				true
				);
			
			NavigationHelper.SetHistoryBack( this.BtnCancel );


			NavigationHelper.SetPopupWindow(
				this.BtnPrint,
				"PrintAcq.aspx", //?TicketNo=" + this.TbxTicketNo.Text,
				"PrintAcq",
				700, 700,
				true
			);

			NavigationHelper.SetPopupWindow(
				this.BtnAssetNo,
				"../Asset/SelectAssetAcq.aspx", //?TicketNo=" + this.TbxTicketNo.Text,
				"SelectAssetAcq",
				1000, 600,
				true
				);
	
			if( !this.IsPostBack )
			{
				GetAcqData( this.Request["TicketNo"] );
				this.TbxTotal.Text = AcqController.CalculateSum( this.DgrdDataGrid );
				AcqController.SetIndex( this.DgrdDataGrid );

			}
			if( this.IsSubmittedBy )
			{
				GetAcqData( this.Request["TicketNo"] );
				this.TbxTotal.Text = AcqController.CalculateSum( this.DgrdDataGrid );
				AcqController.SetIndex( this.DgrdDataGrid );
	
			}

            ClientScript.RegisterHiddenField( "TicketNo", this.TbxTicketNo.Text );

			if ( this.CurrentUserAuthority.CompareTo( "A" ) > 0 )
			{
				this.BtnConfirm.Visible = false;
			}

			if ( this.TbxConfirmDate.Text.Length > 0 )
			{
				this.BtnUpdate.Visible = false;
				this.BtnConfirm.Visible = false;
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
            this.Load += new System.EventHandler(this.Page_Load);

        }
		#endregion

		private void GetAcqData( string TicketNo )
		{
			AcqDS ds = AcqController.SelectAcq( TicketNo );

			if( ds.TB_ACQ.Count == 1 )
			{
				AcqDS.TB_ACQRow dr = ds.TB_ACQ[0];

				this.TbxTicketNo.Text = dr.TicketNo;

				this.TbxRequestDate.Text = ds.TB_TICKET[0].CreateDate.ToShortDateString();

				if( !dr.IsAcqNoNull() )
					this.TbxAcqNo.Text = dr.AcqNo;

				this.TbxEngComment.Text = dr.EngComment;
				if ( ! dr.IsAdmCommentNull() )
				{
					this.TbxAdminComment.Text = dr.AdmComment;
				}

				this.TbxCreateID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.CreateID );
				this.TbxCreateDate.Text = dr.CreateDate.ToShortDateString() + " " + dr.CreateDate.ToShortTimeString();

				this.TbxUpdateID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.UpdateID );
				this.TbxUpdateDate.Text = dr.UpdateDate.ToShortDateString() + " " + dr.UpdateDate.ToShortTimeString();

				if ( !dr.IsConfirmIDNull() )
					this.TbxConfirmID.Text = LGCNS.SITE.Common.WebUI.UserInfo.getUserName( dr.ConfirmID );
				if ( !dr.IsConfirmDateNull() )
					this.TbxConfirmDate.Text = dr.ConfirmDate.ToShortDateString() + " " + dr.ConfirmDate.ToShortTimeString();

				LGCNS.SITE.Common.WebUI.CodeInfo.BindDropDownList( this.DdnlVendorDesc, "VENDOR_TYPE",true );
				this.DdnlVendorDesc.SelectedValue=dr.VendorDesc;
				
				this.DgrdDataGrid.DataSource = ds.TB_ACQ_DETAIL;
				this.DgrdDataGrid.DataBind();
			}
			else
			{
				NavigationHelper.Redirect(
					MessageManager.GetMessage( "Common", "NO_TICKET" ),
					"SelectAcqList.aspx"
				);
			}
		}

		public int GetStateIndexA3( string A3 )
		{
			if ( A3 == "Y" )
			{
				return 1;
			}
			return 0;
		}


		public DataTable BindLedgerEntrylList( )
		{
			CapexDS ds = AcqController.SelectLedgerEntrylList();
			return ds.TB_BASE;		 // TB_QUOTATION_NO �ִ� ���̺� ���
		}


		public int GetStateIndexLedgerEntry( string LedgerEntry )
		{
			CapexDS ds = AcqController.SelectLedgerEntrylList();
 
			for ( int i = 0; i < ds.TB_BASE.Count; i++)
			{
				CapexDS.TB_BASERow dr = ds.TB_BASE[i]; // TB_QUOTATION_NO �ִ� ���̺� ���

				if ( dr.Col1.ToString() == LedgerEntry )
				{
					return i;
				}
			}

			return 0;
		}


	}
}
