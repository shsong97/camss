using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Specialized;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.SITE.DTO;

using LGCNS.SITE.Acq.Biz;

namespace LGCNS.SITE.WebUI.Acq
{
	/// <summary>
	/// AcqController�� ���� ��� �����Դϴ�.
	/// </summary>
	public class AcqController : ControllerBase
	{
		public AcqController() {}

		#region Controll DataSource

		public static AcqDS GetNewDataSource( int cntCols )
		{
			AcqDS ds = new AcqDS();
			ds.EnforceConstraints = false;
			AcqDS.TB_ACQ_DETAILRow dr = null;

			for (int i = 1; i <= cntCols; i++) 
			{
				dr = ds.TB_ACQ_DETAIL.NewTB_ACQ_DETAILRow();
 
				//dr.TicketNo = TicketNo;
				dr.Seq  = i;
				dr.Amount = 0;
				dr.UnitCost = 0;
 
				ds.TB_ACQ_DETAIL.AddTB_ACQ_DETAILRow( dr );
			}

			return ds;
		}


		public static AcqDS GetDataSource( DataGrid dgrd )
		{
			AcqDS ds = new AcqDS();
			ds.EnforceConstraints = false;
			AcqDS.TB_ACQ_DETAILRow dr = null;

			for( int inx = 0 ; inx < dgrd.Items.Count ; inx++ )
			{
				dr = ds.TB_ACQ_DETAIL.NewTB_ACQ_DETAILRow();

				//dr.TicketNo = TicketNo;

				dr.Seq = int.Parse( ((TextBox)dgrd.Items[inx].Cells[0].Controls[1]).Text );
				dr._Item = ((TextBox)dgrd.Items[inx].Cells[1].Controls[1]).Text;
				dr.SA = ((TextBox)dgrd.Items[inx].Cells[2].Controls[1]).Text;
				try
				{
					dr.MakeDate = ((TextBox)dgrd.Items[inx].Cells[3].Controls[1]).Text;
				}
				catch( Exception ex )
				{
					string errmsg=ex.Message;
					dr.MakeDate = "";
				}
				dr.A3 = ((DropDownList)dgrd.Items[inx].Cells[4].Controls[1]).SelectedValue;
				dr.Spec = ((TextBox)dgrd.Items[inx].Cells[5].Controls[1]).Text;

				try
				{
					dr.Amount = int.Parse( ((TextBox)dgrd.Items[inx].Cells[6].Controls[1]).Text );
				}
				catch( Exception ex )
				{
					string errmsg=ex.Message;
					dr.Amount = 0;
				}

				try
				{
					dr.UnitCost = int.Parse( ((TextBox)dgrd.Items[inx].Cells[7].Controls[1]).Text );
				}
				catch( Exception ex )
				{
					string errmsg=ex.Message;
					dr.UnitCost = 0;
				}

				try
				{
					dr.Division = ((DropDownList)dgrd.Items[inx].Cells[8].Controls[1]).SelectedValue;
				}
				catch( Exception ex )
				{
					string errmsg=ex.Message;
					dr.Division = "E";
				}


				ds.TB_ACQ_DETAIL.AddTB_ACQ_DETAILRow( dr );
			}

			return ds;
		}


		public static AcqDS GetDataSource( DataGrid dgrd, string TicketNo )
		{
			AcqDS ds = new AcqDS();
			ds.EnforceConstraints = false;
			AcqDS.TB_ACQ_DETAILRow dr = null;

			for( int inx = 0 ; inx < dgrd.Items.Count ; inx++ )
			{
				dr = ds.TB_ACQ_DETAIL.NewTB_ACQ_DETAILRow();

				dr.TicketNo = TicketNo;

				dr.Seq = inx + 1;
				dr._Item = ((TextBox)dgrd.Items[inx].Cells[1].Controls[1]).Text;
				dr.SA = ((TextBox)dgrd.Items[inx].Cells[2].Controls[1]).Text;
				try
				{
					dr.MakeDate = ((TextBox)dgrd.Items[inx].Cells[3].Controls[1]).Text;
				}
				catch( Exception ex )
				{
					string errmsg=ex.Message;
					dr.MakeDate = "";
				}
				dr.A3 = ((DropDownList)dgrd.Items[inx].Cells[4].Controls[1]).SelectedValue;
				dr.Spec = ((TextBox)dgrd.Items[inx].Cells[5].Controls[1]).Text;

				try
				{
					dr.Amount = int.Parse( ((TextBox)dgrd.Items[inx].Cells[6].Controls[1]).Text );
				}
				catch( Exception ex )
				{
					string errmsg=ex.Message;
					dr.Amount = 0;
				}

				try
				{
					dr.UnitCost = int.Parse( ((TextBox)dgrd.Items[inx].Cells[7].Controls[1]).Text );
				}
				catch( Exception ex )
				{
					string errmsg=ex.Message;
					dr.UnitCost = 0;
				}

				try
				{
					dr.Division = ((DropDownList)dgrd.Items[inx].Cells[8].Controls[1]).SelectedValue;
				}
				catch( Exception ex )
				{
					string errmsg=ex.Message;
					dr.Division = "E";
				}

				if( dr._Item.Length > 0 | dr.Spec.Length > 0 )
				{
					ds.TB_ACQ_DETAIL.AddTB_ACQ_DETAILRow( dr );
				}
			}

			return ds;
		}


		public static string CalculateSum( DataGrid dgrd )
		{
			ulong SubTotal = 0;
			ulong Total = 0;

			for( int inx = 0; inx < dgrd.Items.Count; inx++ )
			{
				string Amount = ((TextBox)dgrd.Items[inx].Cells[6].Controls[1]).Text;
				string UnitCost = ((TextBox)dgrd.Items[inx].Cells[7].Controls[1]).Text;

				if( Amount.Length < 1 || UnitCost.Length < 1 )
				{
					SubTotal = 0;
				}
				else
				{ 
					try
					{
						SubTotal = ulong.Parse( Amount ) * ulong.Parse( UnitCost );
					}
					catch( Exception ex )
					{
						string errmsg=ex.Message;
						ScriptHelper.ShowAlert(	MessageManager.GetMessage( "Acq", "NO_NUMERIC" ) );
						return "Error";
					}
				}

				((TextBox)dgrd.Items[inx].Cells[9].Controls[1]).Text = SubTotal.ToString();
				Total = Total + SubTotal;
			}

			return Total.ToString();
		}

	
		public static void AddRowsOnDataGrid( DataGrid dgrd, int cntCols )
		{
			AcqDS ds = GetDataSource( dgrd );
			ds.EnforceConstraints = false;
			AcqDS.TB_ACQ_DETAILRow dr = null;

			for (int i = 1; i <= cntCols; i++) 
			{
				dr = ds.TB_ACQ_DETAIL.NewTB_ACQ_DETAILRow();

				dr.Seq = ds.TB_ACQ_DETAIL.Count + 1;
				dr.Amount = 0;
				dr.UnitCost = 0;

				ds.TB_ACQ_DETAIL.AddTB_ACQ_DETAILRow( dr );
			}

			dgrd.DataSource = ds.TB_ACQ_DETAIL;
			dgrd.DataBind();
		}

	
		public static void SetIndex( DataGrid dgrd )
		{
			for( int inx = 0; inx < dgrd.Items.Count; inx++ )
			{
				try
				{
					((DropDownList)dgrd.Items[inx].Cells[8].Controls[1]).SelectedValue =
						((TextBox)dgrd.Items[inx].Cells[10].Controls[1]).Text;
				}
				catch
				{
					((DropDownList)dgrd.Items[inx].Cells[8].Controls[1]).SelectedIndex = 0;
				}
			}
		}

		#endregion

		#region ManageAcq

		public static void InsertAcq (AcqDS ds)
		{
			AcqBizTx biz = null ;

			try
			{
				biz = new AcqBizTx();
				biz.InsertAcq (ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz != null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		public static void UpdateAcq (AcqDS ds)
		{
			AcqBizTx biz = null ;

			try
			{
				biz = new AcqBizTx();
				biz.UpdateAcq(ds);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}


		public static CapexDS SelectLedgerEntrylList()
		{
			CapexDS ds = null;
			AcqBizNTx biz = null;
		
			try
			{
				biz = new AcqBizNTx();
				ds = biz.SelectLedgerEntrylList( );			
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}


		public static void DeleteAcq (string TicketNo)
		{
			AcqBizTx biz = null ;

			try
			{
				biz = new AcqBizTx();
				biz.DeleteAcq(TicketNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
		}

		#endregion

		#region SelectAcq

		public static AcqDS SelectAcq( string TicketNo )
		{
			AcqBizNTx biz = null ;
			AcqDS ds = null ;

			try
			{
				biz = new AcqBizNTx();
				ds = biz.SelectAcq(TicketNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static AcqDS SelectAcqPrint( string TicketNo )
		{
			AcqBizNTx biz = null ;
			AcqDS ds = null ;

			try
			{
				biz = new AcqBizNTx();
				ds = biz.SelectAcqPrint(TicketNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		public static AcqDS SelectAcqList( int currentPage, int pageSize, NameValueCollection SearchCondition )
		{
			AcqBizNTx biz = null ;
			AcqDS ds = null ;

			try
			{
				biz = new AcqBizNTx();
				ds = biz.SelectAcqList( currentPage, pageSize, SearchCondition );
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}

		#endregion

		public static bool isExistAcq( string TicketNo )
		{
			bool isExist = false;
			AcqDS ds = null ;

			try
			{
				ds = SelectAcq(TicketNo);
				
				if( ds.TB_ACQ.Count == 1 )
				{
					isExist = true;
				}
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(ds!=null)
				{
					ds.Dispose () ;
					ds = null ;
				}
			}
			
			return isExist;
		}

		#region Capex
		public static TicketDS SelectMailCapex( )
		{

			AcqBizNTx biz = null ;
			TicketDS ds = null ;

			try
			{
				biz = new AcqBizNTx();
				
				ds = biz.SelectMailCapex ();
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}


		#endregion

		#region Ticket

		public static TicketDS SelectTicketAcq( string TicketNo )
		{
			AcqBizNTx biz = null ;
			TicketDS ds = null ;

			try
			{
				biz = new AcqBizNTx();
				ds = biz.SelectTicketAcq(TicketNo);
			}
			catch(Exception ex)
			{
				throw ex ;
			}
			finally
			{
				if(biz!=null)
				{
					biz.Dispose () ;
					biz = null ;
				}
			}
			return ds ;
		}


		#endregion
	}
}
