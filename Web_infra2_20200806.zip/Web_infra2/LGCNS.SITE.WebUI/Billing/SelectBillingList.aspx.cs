using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

namespace LGCNS.SITE.WebUI.Billing
{
	/// <summary>
	/// SelectBillingList�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectBillingList : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxFromMonth;
		protected System.Web.UI.WebControls.TextBox TbxToMonth;
		protected System.Web.UI.WebControls.Button BtnSearch;
		protected System.Web.UI.WebControls.Button BtnExcel;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }
			XjosHelper.RegisterXjos(true);

			XjosHelper.SetValidator (this.TbxFromMonth,
				new XjosValidator (XjosValidatorType.Required),
				new XjosValidator (XjosValidatorType.Minlength, "6", null),
				new XjosValidator (XjosValidatorType.Numeric)
				);
			this.TbxFromMonth.MaxLength = 6;
			XjosHelper.SetValidator (this.TbxToMonth,
				new XjosValidator (XjosValidatorType.Required),
				new XjosValidator (XjosValidatorType.Minlength, "6", null),
				new XjosValidator (XjosValidatorType.Numeric)
				);
			this.TbxToMonth.MaxLength = 6;
			XjosHelper.ValidateOnClick ( this.BtnSearch );

			NavigationHelper.RegisterHiddenIFrame ("HiddenFrame") ;
			NavigationHelper.SetNavigation (this.BtnExcel, "HiddenFrame", "SelectBillingListForXls.aspx", true) ;

			if ( !this.IsPostBack )
			{
				LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea, true );

				this.TbxFromMonth.Text = DateTime.Now.AddMonths( -1 ).Date.Year.ToString() + DateTime.Now.AddMonths( -1 ).ToShortDateString().Substring( 5, 2 );
				this.TbxToMonth.Text = DateTime.Now.Date.Year.ToString() + DateTime.Now.ToShortDateString().Substring( 5, 2 );
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{   
			this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			if ( !BillingController.isValidYearMonth( this.TbxFromMonth.Text ) ) { return; }
			if ( !BillingController.isValidYearMonth( this.TbxToMonth.Text ) ) { return; }

			BindBillingList( this.DdnlArea.SelectedValue, this.TbxFromMonth.Text, this.TbxToMonth.Text );
		}

		private void BindBillingList( string Area, string FromMonth, string ToMonth )
		{
			DataSet ds = BillingController.SelectBillingList( Area, FromMonth, ToMonth );

			this.DgrdDataGrid.DataSource = ds.Tables["TB_BILLING_LIST"];
			this.DgrdDataGrid.DataBind();
		}
	}
}
