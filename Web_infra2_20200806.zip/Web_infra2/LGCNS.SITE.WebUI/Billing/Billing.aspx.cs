using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

namespace LGCNS.SITE.WebUI.Billing
{
	/// <summary>
	/// Billing�� ���� ��� �����Դϴ�.
	/// </summary>
	public class Billing : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxYearMonth;
		protected System.Web.UI.WebControls.Button BtnExcute;
		protected System.Web.UI.WebControls.Button BtnCancel;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }
			XjosHelper.RegisterXjos(true);

			XjosHelper.SetValidator (this.TbxYearMonth,
				new XjosValidator (XjosValidatorType.Required),
				new XjosValidator (XjosValidatorType.Minlength, "6", null),
				new XjosValidator (XjosValidatorType.Numeric)
				);
			this.TbxYearMonth.MaxLength = 6;
			XjosHelper.ValidateOnClick (
				this.BtnExcute,
				MessageManager.GetMessage("Common", "BILLING")
				) ;

			NavigationHelper.SetHistoryBack( this.BtnCancel );

			if ( !this.IsPostBack )
			{
				this.TbxYearMonth.Text = DateTime.Now.Date.Year.ToString() + DateTime.Now.ToShortDateString().Substring( 5, 2 );
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnExcute.Click += new System.EventHandler(this.BtnExcute_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BtnExcute_Click(object sender, System.EventArgs e)
		{
			if ( !BillingController.isValidYearMonth( this.TbxYearMonth.Text ) ) { return; }

			BillingController.Billing( this.TbxYearMonth.Text );

			NavigationHelper.Redirect(
				MessageManager.GetMessage( "Common", "COMPLETE_BILLING" ),
				"",
				"SelectBillingMonth.aspx?YearMonth=" + this.TbxYearMonth.Text
			);
		}


	}
}
