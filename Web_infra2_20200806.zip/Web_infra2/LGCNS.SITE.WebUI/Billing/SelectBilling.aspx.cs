using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

namespace LGCNS.SITE.WebUI.Billing
{
	/// <summary>
	/// SelectBilling�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectBilling : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxDate;
		protected System.Web.UI.WebControls.Button BtnSearch;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }
			XjosHelper.RegisterXjos(true);

			XjosHelper.SetValidator (this.TbxDate,
				new XjosValidator (XjosValidatorType.Required),
				new XjosValidator (XjosValidatorType.Date)
				);
			XjosHelper.ValidateOnClick ( this.BtnSearch );

			if ( !this.IsPostBack )
			{
				LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea, true );
				this.TbxDate.Text = DateTime.Now.ToShortDateString();
				BtnSearch_Click( sender, e );
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			BindBilling( this.DdnlArea.SelectedValue, this.TbxDate.Text );
		}

		private void BindBilling( string Area, string SearchDate )
		{
			DataSet ds = BillingController.SelectBilling( Area, SearchDate );

			this.DgrdDataGrid.DataSource = ds.Tables["TB_BILLING_LIST"];
			this.DgrdDataGrid.DataBind();
		}
	}
}
