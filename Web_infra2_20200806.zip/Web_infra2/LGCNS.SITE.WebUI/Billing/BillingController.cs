using System;
using System.Data;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;
using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.Billing.Biz;

namespace LGCNS.SITE.WebUI.Billing
{
	/// <summary>
	/// BillingController�� ���� ��� �����Դϴ�.
	/// </summary>
	public class BillingController : ControllerBase
	{
		public BillingController() {}

		public static void Billing( string YearMonth )
		{
			BillingBizTx biz = null;
		
			try
			{
				biz = new BillingBizTx();
				biz.Billing( YearMonth );
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}
		}

		
		public static DataSet SelectBilling( string Area, string SearchDate )
		{
			BillingBizNTx biz = null;
			DataSet ds = null;
	
			try
			{
				biz = new BillingBizNTx();
				ds = biz.SelectBilling( Area, SearchDate );
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}

		public static DataSet SelectBillingMonth( string Area, string YearMonth )
		{
			BillingBizNTx biz = null;
			DataSet ds = null;
		
			try
			{
				biz = new BillingBizNTx();
				ds = biz.SelectBillingMonth( Area, YearMonth );
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}

		public static DataSet SelectBillingList( string Area, string FromMonth, string ToMonth )
		{
			BillingBizNTx biz = null;
			DataSet ds = null;
		
			try
			{
				biz = new BillingBizNTx();
				ds = biz.SelectBillingList( Area, FromMonth, ToMonth );
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}

		public static DataSet SelectBillingListForXls( string Area, string FromMonth, string ToMonth )
		{
			BillingBizNTx biz = null;
			DataSet ds = null;
		
			try
			{
				biz = new BillingBizNTx();
				ds = biz.SelectBillingListForXls( Area, FromMonth, ToMonth );
			}
			catch( Exception ex )
			{
				throw ex;
			}
			finally
			{
				if ( biz != null )
				{
					biz.Dispose();
					biz = null;
				}
			}

			return ds;
		}

		public static bool isValidYearMonth( string YearMonth )
		{
			try
			{
				DateTime dt = DateTime.Parse( YearMonth.Substring( 0, 4 ) + "-" + YearMonth.Substring( 4, 2 ) + "-01" );
			}
			catch( Exception ex )
			{
				string errmsg=ex.Message;
				ScriptHelper.ShowAlert( MessageManager.GetMessage( "Common", "YEAR_MONTH" ) );
				return false;
			}

			return true;
		}
	}
}
