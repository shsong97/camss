using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using LGCNS.LAF.Web;
using LGCNS.LAF.Common.Message;

namespace LGCNS.SITE.WebUI.Billing
{
	/// <summary>
	/// SelectBillingMonth�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SelectBillingMonth : LGCNS.SITE.Common.SITEPageBase
	{
		protected System.Web.UI.WebControls.TextBox TbxYearMonth;
		protected LGCNS.LAF.Web.Controls.LDataGrid DgrdDataGrid;
		protected System.Web.UI.WebControls.Button BtnExcel;
		protected System.Web.UI.WebControls.DropDownList DdnlArea;
		protected System.Web.UI.WebControls.Button BtnSearch;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if ( !this.isAuthority( this.Request.RawUrl.ToString() ) ) { return; }
			XjosHelper.RegisterXjos(true);

			XjosHelper.SetValidator (this.TbxYearMonth,
				new XjosValidator (XjosValidatorType.Required),
				new XjosValidator (XjosValidatorType.Minlength, "6", null),
				new XjosValidator (XjosValidatorType.Numeric)
				);
            
			this.TbxYearMonth.MaxLength = 6;
			XjosHelper.ValidateOnClick ( this.BtnSearch );

			NavigationHelper.RegisterHiddenIFrame ("HiddenFrame") ;
			NavigationHelper.SetNavigation (this.BtnExcel, "HiddenFrame", "SelectBillingMonthForXls.aspx", true) ;

			if ( !this.IsPostBack )
			{
				LGCNS.SITE.Common.WebUI.AreaInfo.BindDropDownList( this.DdnlArea, true );

				if ( this.Request["YearMonth"] != null )
				{
					this.TbxYearMonth.Text = this.Request["YearMonth"];
					BindBillingMonth( this.DdnlArea.SelectedValue, this.Request["YearMonth"] );
				}
				else
				{
					this.TbxYearMonth.Text = DateTime.Now.Date.Year.ToString() + DateTime.Now.ToShortDateString().Substring( 5, 2 );
				}
			}
		}

		#region Web Form �����̳ʿ��� ������ �ڵ�
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: �� ȣ���� ASP.NET Web Form �����̳ʿ� �ʿ��մϴ�.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// �����̳� ������ �ʿ��� �޼����Դϴ�.
		/// �� �޼����� ������ �ڵ� ������� �������� ���ʽÿ�.
		/// </summary>
		private void InitializeComponent()
		{    
			this.BtnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BtnSearch_Click(object sender, System.EventArgs e)
		{
			if ( !BillingController.isValidYearMonth( this.TbxYearMonth.Text ) ) { return; }

			BindBillingMonth( this.DdnlArea.SelectedValue, this.TbxYearMonth.Text );
		}

		private void BindBillingMonth( string Area, string YearMonth )
		{
			DataSet ds = BillingController.SelectBillingMonth( Area, YearMonth );

			this.DgrdDataGrid.DataSource = ds.Tables["TB_BILLING_LIST"];
			this.DgrdDataGrid.DataBind();
		}
	}
}
