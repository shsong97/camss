using System;
using System.EnterpriseServices;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Collections.Specialized;

using LGCNS.LAF.DA;
using LGCNS.LAF.Common.Exceptions;
using LGCNS.LAF.Common.DataAccess;
using LGCNS.LAF.Common.Paging ;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.SURVEY.DA
{
	/// <summary>
	/// SurveyDA�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SurveyDA : LGCNS.LAF.DA.DABase
	{
		private const string PROJECT_NAME	= "LGCNS.SITE.SURVEY" ;
		private const string CLASS_NAME		= "LGCNS.SITE.SURVEY.DA.SurveyDA" ;

		public SurveyDA()
		{
			//
			// ���⿡ ������ ������ �߰��մϴ�.
			//
		}

		//lglsy 20051129 TicketNo ���� ������.
		[AutoComplete(true)]
		public SurveyDS isSelectTicketDesc(string TicketNo, string EmpNo)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = TicketNo;
			dc["EmpNo"] = EmpNo;

			SurveyDS ds = new SurveyDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "isSelectTicketDesc") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_TICKET_DESC"}, dc) ;

			return ds ;
		}	

		[AutoComplete(true)]
		public SurveyDS SelectQuestion(string Qtype, string Use)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Qtype"] = Qtype;
			dc["Use"] = Use;

			SurveyDS ds = new SurveyDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectQuestion") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_SURVEY_QUEST"}, dc) ;

			return ds ;
		}
		

		[AutoComplete(true)]
		public SurveyDS SelectSurveyRate(string Area, string DateFrom, string DateTo)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Area"] = Area;
			dc["DateFrom"] = DateFrom;
			dc["DateTo"] = DateTo;

			SurveyDS ds = new SurveyDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectSurveyRate") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_SURVEY_CHK"}, dc) ;

			return ds ;
		}


		[AutoComplete(true)]
		public SurveyDS SelectSurveyAnswer(string TicketNo, string Area, string DateFrom, string DateTo)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = TicketNo;
			dc["Area"] = Area;
			dc["DateFrom"] = DateFrom;
			dc["DateTo"] = DateTo;

			SurveyDS ds = new SurveyDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectSurveyAnswer") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_SURVEY_ANSWER"}, dc) ;

			return ds ;
		}

		[AutoComplete(true)]
		public SurveyDS SelectMailTicket(string TicketNo)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = TicketNo;

			SurveyDS ds = new SurveyDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectMailTicket") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_TICKET_MAIL"}, dc) ;

			return ds ;
		}


		#region ManageQuestion
		[AutoComplete(true)]
		public SurveyDS SelectOneQuestion(string Qtype, string Seq)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Qtype"] = Qtype;
			dc["Seq"] = Convert.ToInt32(Seq);

			SurveyDS ds = new SurveyDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectOneQuestion") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_SURVEY_QUEST"}, dc) ;

			return ds ;
		}


		[AutoComplete(true)]
		public void InsertQuestion(string Qtype, string Question, string CreateID)
		{
			SurveyDS ds = new SurveyDS();
			LDataCollection dc = new LDataCollection () ;
			dc["Qtype"] = Qtype;
			dc["Question"] = Question;
			dc["CreateID"] = CreateID;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertQuestion", ds.TB_SURVEY_QUEST) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}


		[AutoComplete(true)]
		public void UpdateQuestion(string Qtype, string Seq, string Question, string UseCHK, string UpdateID)
		{
			SurveyDS ds = new SurveyDS();
			LDataCollection dc = new LDataCollection () ;
			dc["Qtype"] = Qtype;
			dc["Seq"] = Seq;
			dc["Question"] = Question;
			dc["UseCHK"] = UseCHK;
			dc["UpdateID"] = UpdateID;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateQuestion", ds.TB_SURVEY_QUEST) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}


		[AutoComplete(true)]
		public void DeleteQuestion(string Qtype, string Seq)
		{
			SurveyDS ds = new SurveyDS();
			LDataCollection dc = new LDataCollection () ;
			dc["Qtype"] = Qtype;
			dc["Seq"] = Seq;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteQuestion", ds.TB_SURVEY_QUEST) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		[AutoComplete(true)]
		public string InsertAnswerChk(string TicketNo)
		{
			string Result = "";

			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = TicketNo;
			dc["Result"] = Result;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertAnswerChk" ) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;

			Result = ps.DataParameters["@Result"].Value.ToString();

			return Result;
		}

		[AutoComplete(true)]
		public void InsertAnswer(SurveyDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertAnswer", ds.TB_SURVEY_ANSWER ) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_SURVEY_ANSWER[0]) ;
		}
		#endregion

	}
}
