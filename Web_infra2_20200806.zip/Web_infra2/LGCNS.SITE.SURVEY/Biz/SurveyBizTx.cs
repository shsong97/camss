using System;
using System.EnterpriseServices;
//using System.Data;
using System.Collections.Specialized;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.SURVEY.DA;
using LGCNS.SITE.DTO;


//using System.Collections;
//
//using LGCNS.LAF.Common.Log;
//
//using LGCNS.LAF.Common.FileManagement;
//
//using System.IO;
//using System.Configuration;
//using System.Text;

namespace LGCNS.SITE.SURVEY.Biz
{
	/// <summary>
	/// SurveyBizTx�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SurveyBizTx : LGCNS.LAF.Biz.BizTxBase
	{
		public SurveyBizTx()
		{
			//
			// ���⿡ ������ ������ �߰��մϴ�.
			//
		}
		#region ManageQuestion
		[AutoComplete(true)]
		public void InsertQuestion(string Qtype, string Question, string CreateID)
		{
			SurveyDA da = null;
			
			try
			{
				da = new SurveyDA();
				da.InsertQuestion(Qtype, Question, CreateID);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void UpdateQuestion(string Qtype, string Seq, string Question, string UserCHK, string UpdateID)
		{
			SurveyDA da = null;
			
			try
			{
				da = new SurveyDA();
				da.UpdateQuestion(Qtype, Seq, Question, UserCHK, UpdateID);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void DeleteQuestion(string Qtype,string Seq)
		{
			SurveyDA da = null;

			try
			{
				da = new SurveyDA();
				da.DeleteQuestion(Qtype, Seq) ;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void InsertAnswer(SurveyDS ds)
		{
			SurveyDA da = null;
			
			try
			{
				da = new SurveyDA ();
				da.InsertAnswer(ds);				
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		public string InsertAnswerChk(string TicketNo)
		{
			SurveyDA da = null;
			string Result = "";
			
			try
			{
				da = new SurveyDA ();
				Result = da.InsertAnswerChk(TicketNo);				
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return Result;
		}
		#endregion

	}

}
