vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Jan 2006 09:37:46 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|12 Jan 2006 09:37:46 -0000
vti_filesize:IR|2724
