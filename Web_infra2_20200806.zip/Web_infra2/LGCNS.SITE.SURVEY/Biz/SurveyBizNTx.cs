using System;
using System.EnterpriseServices;
//using System.Data;
using System.Collections.Specialized;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.SURVEY.DA;
using LGCNS.SITE.DTO;


namespace LGCNS.SITE.SURVEY.Biz
{
	/// <summary>
	/// SurveyBizNTx�� ���� ��� �����Դϴ�.
	/// </summary>
	public class SurveyBizNTx : LGCNS.LAF.Biz.BizNTxBase
	{
		public SurveyBizNTx() {}

		//lglsy 20051107 �߰� �ڻ� ������
		public SurveyDS isSelectTicketDesc(string TicketNo, string EmpNo)
		{
			SurveyDS ds = null;
			SurveyDA da = null;

			try
			{
				da = new SurveyDA();
				ds = da.isSelectTicketDesc( TicketNo, EmpNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public SurveyDS SelectQuestion(string Qtype, string Use)
		{
			SurveyDS ds = null;
			SurveyDA da = null;

			try
			{
				da = new SurveyDA();
				ds = da.SelectQuestion( Qtype, Use);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public SurveyDS SelectSurveyRate(string Area, string DateFrom, string DateTo)
		{
			SurveyDS ds = null;
			SurveyDA da = null;

			try
			{
				da = new SurveyDA();
				ds = da.SelectSurveyRate(Area, DateFrom, DateTo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public SurveyDS SelectSurveyAnswer(string TicketNo,string Area,  string DateFrom, string DateTo)
		{
			SurveyDS ds = null;
			SurveyDA da = null;

			try
			{
				da = new SurveyDA();
				ds = da.SelectSurveyAnswer(TicketNo, Area, DateFrom, DateTo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public SurveyDS SelectMailTicket(string TicketNo)
		{
			SurveyDS ds = null;
			SurveyDA da = null;

			try
			{
				da = new SurveyDA();
				ds = da.SelectMailTicket( TicketNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}


		#region ManageQuestion
		public SurveyDS SelectOneQuestion(string Qtype, string Seq)
		{
			SurveyDS ds = null;
			SurveyDA da = null;

			try
			{
				da = new SurveyDA();
				ds = da.SelectOneQuestion( Qtype, Seq);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}
		#endregion
	}
}
