using System;
using System.EnterpriseServices;

using LGCNS.LAF.Common.Exceptions;
using LGCNS.LAF.Common.Paging ;

using LGCNS.SITE.BBS.DA;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.BBS.Biz
{
	public class BBSBizNTx : LGCNS.LAF.Biz.BizNTxBase
	{
		public BBSBizNTx() {}

		[AutoComplete(true)]
		public BBSDS SelectBBSList(int currentPage, int pageSize, string order, string title)
		{
			BBSDS ds = null;
			BBSDA da = null;

			try
			{
				da = new BBSDA ();
				ds = da.SelectBBSList(currentPage, pageSize, order, title) ;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		[AutoComplete(true)]
		public BBSDS SelectBBSList(string registerID)
		{
			BBSDS ds = null;
			BBSDA da = null;

			try
			{
				da = new BBSDA ();
				ds = da.SelectBBSList(registerID);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		[AutoComplete(true)]
		public BBSDS SelectBBS(int seq)
		{
			BBSDS ds = null;
			BBSDA da = null;

			try
			{
				//�Խù� ��ȸ�� ������Ʈ
				da = new BBSDA ();
				da.UpdateBBSReaded(seq);

				ds = da.SelectBBS(seq);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

	}
}
