vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|14 Jun 2004 07:47:22 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|14 Jun 2004 07:47:22 -0000
vti_filesize:IR|4302
