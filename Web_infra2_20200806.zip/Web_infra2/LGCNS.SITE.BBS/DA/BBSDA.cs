using System;
using System.EnterpriseServices;
using System.Data;
using System.Data.SqlClient;

using LGCNS.LAF.DA;
using LGCNS.LAF.Common.Paging ;
using LGCNS.LAF.Common.Exceptions;
using LGCNS.LAF.Common.DataAccess;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.BBS.DA
{
	public class BBSDA : LGCNS.LAF.DA.DABase
	{
		private const string PROJECT_NAME	= "LGCNS.SITE.BBS" ;
		private const string CLASS_NAME		= "LGCNS.SITE.BBS.DA.BBSDA" ;

		public BBSDA() {}

		[AutoComplete(true)]
		public void InsertBBS(BBSDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertBBS") ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_BBS[0]) ;
			int seq = Convert.ToInt32 (ps.DataParameters ["@Seq"].Value) ;

			InsertBBSFile (ds, seq) ;
		}

		[AutoComplete(true)]
		private void InsertBBSFile(BBSDS ds, int seq)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertBBSFile") ;
			foreach(BBSDS.TB_BBS_FILERow dr in ds.TB_BBS_FILE.Rows)
			{
				dr.Seq = seq ;
				ADOHelper.ExecuteNonQuery (ps, dr) ;
			}
		}

		[AutoComplete(true)]
		public void UpdateBBSReaded(int seq)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Seq"] = seq ; 

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateBBSReaded") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		[AutoComplete(true)]
		public void UpdateBBS(BBSDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateBBS") ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_BBS[0]) ;
				
			// #2 �������� ����
			DeleteBBSFile(ds.TB_BBS[0].Seq);
				
			// #3 �������� ���
			InsertBBSFile(ds, ds.TB_BBS[0].Seq);
		}

		[AutoComplete(true)]
		public void DeleteBBS(int seq)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Seq"] = seq ;

			// #1 ���� ���� ���� ����
			DeleteBBSFile (seq) ;

			// #2 �Խù� ���� ����
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteBBS") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		[AutoComplete(true)]
		private void DeleteBBSFile(int seq)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Seq"] = seq ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteBBSFile") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		[AutoComplete(true)]
		public BBSDS SelectBBSList(int currentPage, int pageSize, string order, string title)
		{
			if(order==null) order = "Seq DESC" ;

			LDataCollection dc = new LDataCollection () ;
			dc["[ORDER]"]	= order ;
			dc["Title"]		= title ;
		
			BBSDS ds = new BBSDS () ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectBBSList") ;
			ADOHelper.FillDataSet (ps, ds, "TB_BBS", currentPage, pageSize, dc) ;

			int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;

			PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;

			return ds ;
		}

		[AutoComplete(true)]
		public BBSDS SelectBBSList(string registerID)
		{
			LDataCollection dc	= new LDataCollection () ;
			dc["RegisterID"]	= registerID ;

			BBSDS ds = new BBSDS();

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectBBSListByRegisterID") ;
			ADOHelper.FillDataSet (ps, ds, new string[] {"TB_BBS"}, dc) ;

			return ds ;
		}

		[AutoComplete(true)]
		public BBSDS SelectBBS(int seq)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Seq"] = seq ;

			BBSDS ds = new BBSDS();

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectBBS") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_BBS","TB_BBS_FILE"}, dc) ;

			return ds ;
		}

		[AutoComplete(true)]
		public BBSDS SelectBBSFileList(int seq)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Seq"] = seq ;

			BBSDS ds = new BBSDS();

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectBBSFileList") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_BBS_FILE"}, dc) ;

			return ds ;
		}
	}
}