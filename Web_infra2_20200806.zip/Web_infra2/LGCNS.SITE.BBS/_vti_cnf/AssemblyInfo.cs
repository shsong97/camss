vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|05 Dec 2004 03:41:00 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|05 Dec 2004 03:41:00 -0000
vti_filesize:IR|2532
