vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Jan 2006 05:22:24 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|18 Jan 2006 05:22:24 -0000
vti_filesize:IR|86985
