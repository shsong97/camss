vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 Jan 2006 01:52:26 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|20 Jan 2006 01:52:26 -0000
vti_filesize:IR|206868
