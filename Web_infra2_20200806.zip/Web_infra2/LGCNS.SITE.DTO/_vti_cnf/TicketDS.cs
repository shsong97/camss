vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|29 May 2006 08:19:47 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|29 May 2006 08:19:47 -0000
vti_filesize:IR|327532
