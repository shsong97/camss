vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|30 Nov 2005 07:34:08 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|30 Nov 2005 07:34:08 -0000
vti_filesize:IR|111158
