using System;
using System.EnterpriseServices;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;

using LGCNS.LAF.DA;
using LGCNS.LAF.Common.Exceptions;
using LGCNS.LAF.Common.DataAccess;
using LGCNS.LAF.Common.Paging ;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.Emp.DA
{
	public class EmpDA : LGCNS.LAF.DA.DABase
	{
		private const string PROJECT_NAME	= "LGCNS.SITE.Emp" ;
		private const string CLASS_NAME		= "LGCNS.SITE.Emp.DA.EmpDA" ;

		public EmpDA()	{}

		[AutoComplete(true)]
		public void InsertEmp (EmpDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertEmp", ds.TB_EMP ) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_EMP[0]) ;
		}


		[AutoComplete(true)]
		public void UpdateEmp (EmpDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateEmp", ds.TB_EMP ) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_EMP[0]) ;
		}


		[AutoComplete(true)]
		public void DeleteEmp (string Area, string EmpNo)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Area"]	= Area ;
			dc["EmpNo"]	= EmpNo ;

			EmpDS ds = new EmpDS();

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteEmp", ds.TB_EMP ) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		[AutoComplete(true)]
		public string isExistEmpNo(string Area, string EmpNo)
		{
			string result="";

			LDataCollection dc = new LDataCollection () ;
			dc["Area"]	= Area ;
			dc["EmpNo"]	= EmpNo ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "isExistEmpNo" ) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;

			result = ps.DataParameters["@Result"].Value.ToString();
			return result;
		}

		[AutoComplete(true)]
		public EmpDS SelectEmp(string Area, string EmpNo)
		{
			EmpDS ds = new EmpDS () ;

			LDataCollection dc = new LDataCollection () ;
			dc["Area"]	= Area ;
			dc["EmpNo"]	= EmpNo ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectEmp") ;
			ADOHelper.FillDataSet (ps, ds, new string []{"TB_EMP", "TB_EMP_ENTIRE"}, dc) ;

			return ds ;
		}

		[AutoComplete(true)]
		public EmpDS SelectEmp(string EmpNo)
		{
			EmpDS ds = new EmpDS () ;

			LDataCollection dc = new LDataCollection () ;
			dc["EmpNo"]	= EmpNo ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectEmpOnly") ;
			ADOHelper.FillDataSet (ps, ds, new string []{"TB_EMP", "TB_EMP_ENTIRE"}, dc) ;

			return ds ;
		}

		[AutoComplete(true)]
		public EmpDS SelectEmpList (int currentPage, int pageSize, string order, string Area, string EmpNo, string EmpName)
		{
			if(order==null || order=="") 
				order = "EmpName ASC" ; // ���ļ����� �������� ������� ������̸� ������ ����

			EmpDS ds = new EmpDS () ;

			// LPresparedStatement�� ������ ������
			LDataCollection dc = new LDataCollection () ;
			dc["[ORDER]"]	= order;
			dc["Area"]		= Area ;
			dc["EmpNo"]		= EmpNo;
			dc["EmpName"]	= EmpName ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectEmpList") ;
			ADOHelper.FillDataSet (ps, ds, "TB_EMP_ENTIRE", currentPage, pageSize, dc) ;

			if( pageSize > 0 )
			{
				int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;

				PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;
			}

			return ds ;
		}

		[AutoComplete(true)]
		public EmpDS SelectDept( string Area, string DeptCode )
		{
			EmpDS ds = new EmpDS () ;

			LDataCollection dc = new LDataCollection () ;
			dc["Area"]	= Area ;
			dc["DeptCode"]	= DeptCode ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectDept", ds.TB_DEPT) ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_DEPT"}, dc) ;

			return ds ;
		}

		public EmpDS SelectSite( string Area, string SiteCode )
		{
			EmpDS ds = new EmpDS () ;
			LDataCollection dc = new LDataCollection () ;
			dc["Area"]	= Area ;
			dc["SiteCode"]	= SiteCode ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectSite", ds.TB_SITE);
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_SITE"}, dc) ;

			return ds ;
		}
	}
}