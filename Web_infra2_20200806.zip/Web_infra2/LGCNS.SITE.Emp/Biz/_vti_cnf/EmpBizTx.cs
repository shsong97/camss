vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|16 Feb 2005 11:26:48 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|16 Feb 2005 11:26:48 -0000
vti_filesize:IR|1330
