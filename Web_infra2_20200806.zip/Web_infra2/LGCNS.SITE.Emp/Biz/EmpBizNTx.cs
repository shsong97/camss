using System;
using System.EnterpriseServices;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.Emp.DA;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.Emp.Biz
{
	public class EmpBizNTx : LGCNS.LAF.Biz.BizNTxBase
	{
		public EmpBizNTx() {}

		
		[AutoComplete(true)]
		public string isExistEmpNo(string Area, string EmpNo)
		{
			string result="";
			EmpDA da = null;
			
			try
			{
				da = new EmpDA();
				result = da.isExistEmpNo(Area, EmpNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return result ;		
		}		
		[AutoComplete(true)]
		public EmpDS SelectEmp(string Area, string EmpNo)
		{
			EmpDS ds = null;
			EmpDA da = null;
			
			try
			{
				da = new EmpDA();
				ds = da.SelectEmp(Area, EmpNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;		
		}			

		[AutoComplete(true)]
		public EmpDS SelectEmp(string EmpNo)
		{
			EmpDS ds = null;
			EmpDA da = null;
			
			try
			{
				da = new EmpDA();
				ds = da.SelectEmp(EmpNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;		
		}			

		[AutoComplete(true)]
		public EmpDS SelectEmpList( string Area, string EmpNo )
		{
			return SelectEmpList( 0,0,Area, EmpNo,"" );
		}

		[AutoComplete(true)]
		public EmpDS SelectEmpList (int currentPage, int pageSize, string Area, string EmpNo, string EmpName)
		{
			return SelectEmpList (currentPage, pageSize, null, Area, EmpNo, EmpName) ;
		}

		[AutoComplete(true)]
		public EmpDS SelectEmpList (int currentPage, int pageSize, string order, string Area, string EmpNo, string EmpName)
		{
			EmpDS ds = null;
			EmpDA da = null;
			
			try
			{
				da = new EmpDA();
				ds = da.SelectEmpList(currentPage, pageSize, order, Area, EmpNo, EmpName);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;		
		}

		#region Dept

		[AutoComplete(true)]
		public EmpDS SelectDept ( string Area, string DeptCode )
		{
			EmpDS ds = null;
			EmpDA da = null;
			
			try
			{
				da = new EmpDA();
				ds = da.SelectDept( Area, DeptCode );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}

		#endregion

		#region Site
		[AutoComplete(true)]
		public EmpDS SelectSite( string Area, string SiteCode )
		{
			EmpDS ds = null;
			EmpDA da = null;
			
			try
			{
				da = new EmpDA();
				ds = da.SelectSite( Area, SiteCode );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}
		#endregion
	}
}
