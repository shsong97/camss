using System;
using System.Collections;
using System.EnterpriseServices;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.Emp.DA;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.Emp.Biz
{
	public class EmpBizTx : LGCNS.LAF.Biz.BizTxBase
	{
		public EmpBizTx() {}

		[AutoComplete(true)]
		public void InsertEmp (EmpDS ds)
		{
			EmpDA da = null;
			
			try
			{
				da = new EmpDA();
				da.InsertEmp(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void UpdateEmp (EmpDS ds)
		{
			EmpDA da = null;
			
			try
			{
				da = new EmpDA();
				da.UpdateEmp(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void DeleteEmp (string Area, string EmpNo)
		{
			EmpDA da = null;
			
			try
			{
				da = new EmpDA();
				da.DeleteEmp (Area,EmpNo) ;
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}
	}
}