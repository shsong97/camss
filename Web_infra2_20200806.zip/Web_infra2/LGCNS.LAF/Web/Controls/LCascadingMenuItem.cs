﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;

namespace LGCNS.LAF.Web.Controls
{
    public class LCascadingMenuItem
    {
        public List<LCascadingMenuItem> MenuItems;
        public LCascadingMenuItem()
        {

        }
        public LCascadingMenuItem(string name, string description, string url)
        {
            // 메뉴 미사용 - LCascadingMenuItem 추가 기능 구현
            //new LCascadingMenuItem ("SelectBBSList","게시물목록1", "BBS/SelectBBSList.aspx")

        }
        public LCascadingMenuItem(string name, string description)
        {
            // 생성자 오버로딩
            //LCascadingMenuItem(name, description, null);
        }

        public LCascadingMenuItem Add(HyperLink lik, string name)
        {
            // LCascadingMenuItem Add 구현
            LCascadingMenuItem item = new LCascadingMenuItem();
            return item;
        }
    }
}
