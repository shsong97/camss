﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LGCNS.LAF.Web.Controls
{
    public class LTreeMenuServiceBase : IDisposable
    {
        public void Dispose()
        {
            this.Dispose();
        }

        protected virtual void Dispose(bool b)
        {
            this.Dispose();
        }

        protected virtual LTreeNodeCollection GetChildNodeCollection(string parentNodeId)
        {
            LTreeNodeCollection node = new LTreeNodeCollection();
            return node;
        }
    }
}
