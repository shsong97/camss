﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace LGCNS.LAF.Web.Controls
{
    public class LTreeNodeDS : DataSet
    {
        public LTreeNode Node;
        public class NodeRow 
        {
            public string Id;
            public string ImgExpand;
            public string ImgClosed;
            public string Title;
            public string Text;
            public string Href;
            public string Target;
            public string ParentId;
            public int Order;

            public NodeRow()
            {
            }

            public void SetParentIdNull()
            {
            }
        }

        public NodeRow NewNodeRow()
        {
            NodeRow node = new NodeRow();
            return node;
        }
    }
}
