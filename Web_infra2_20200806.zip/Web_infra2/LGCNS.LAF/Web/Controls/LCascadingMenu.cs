﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LGCNS.LAF.Web.Controls
{
    public class LCascadingMenu
    {
        public LCascadingMenuItem MenuItems;
        public LCascadingMenuLayout MainMenuLayout;
        public ItemStyleClass ItemStyle;
        public class ItemStyleClass
        {
            // 미사용-LCascadingMenu 의 ItemStyleClass 속성을 어떻게 설정하는지 확인 필요
            public string Target = "main";
            public string Color = "darkslategray";
            public string HeaderImageUrl = "default";
            public string BorderColorDark = "#d4d0c8";
            public string BorderColorLight = "white";
            public string FontFamily = "굴림체";
            public int FontSize = 12;
            public int Width = 60;
            public int HeaderWidth = 0;
            public int OffsetWidth = 30;
            public string CascadingMouseEvent = "onclick"; // 기본값은 onclick
        }
    }
    public enum LCascadingMenuLayout { Vertical, Horizontal };
}
