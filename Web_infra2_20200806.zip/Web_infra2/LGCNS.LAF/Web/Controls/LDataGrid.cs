﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LGCNS.LAF.Web.Controls
{
    public class LDataGrid : DataGrid
    {
        public bool ShowFooterMessage;
        public string FooterMessage;
        public DataGridItem[] UnSelectedItems;
        public DataGridItem[] SelectedItems;
        public int[] SelectedIndexes;
        public bool AllowScroll;
        public int ScrollHeight;
        public int ScrollWidth;
        public bool EnableHovering;

        public string frame;
        public string url;
        public string[] paramString;
        public int[] paramInt;
        public string script;

        public void SetMultipleSelect(int column, bool isMulti, Button btnSelectAll, Button btnUnSelectAll, string shouldSelectOne)
        {
            // NOT_: LDataGrid SetMultipleSelect 사용하는 화면을 찾아서 테스트 해야됨. icms
            /*this.LDataGrid1.SetMultipleSelect (
				0,  // 체크박스를 설정할 컬럼Index
				false,  // 하나이상 선택해야할지 여부
				this.BtnSelectAll,  // 체크박스를 전체선택할 버튼
				this.BtnUnSelectAll , // 체크박스를 전체선택해제할 버튼
				"" // shouldSelectOne=true 로 설정할 경우 하나도 선택안했을때 Xjos Validation Message
				) ;
            */
            //DataGrid dg = new DataGrid();
            //dg.Items[0].Cells[0].
            //this.DgrdDataGrid.SetMultipleSelect(0,false,this.BtnSelectAll,this.BtnUnselectAll,"하나이상선택해야합니다.");
        }

        public void ExportAsXls(string filename)
        {
            // LDataGrid ExportAsXls 확인 필요
            // LGCNS.SITE.Common.WebUI.DataToXls.datagridToXls 를 사용함
            Page p = HttpContext.Current.CurrentHandler as Page;
            p.Response.Clear();
            p.Response.ContentEncoding = System.Text.Encoding.GetEncoding("ks_c_5601-1987");
            p.Response.Charset = "euc-kr";
            p.Response.AddHeader("content-disposition", "attachment;filename=" + filename);
            p.Response.ContentType = "application/vnd.xls";
            System.IO.StringWriter stringWriter = new System.IO.StringWriter();
            HtmlTextWriter htmlTextWriter = new HtmlTextWriter(stringWriter);
            p.Response.Write("<meta http-equiv=Content-Type content='text/html; charset=ks_c_5601-1987'>");
            this.RenderControl(htmlTextWriter);
            p.Response.Write(stringWriter.ToString());
            p.Response.End();
        }

        public void NavigateOnCellClick(int column, string frame, string url, string[] paramString, int[] paramInt, bool isReturn)
        {
            // LDataGrid NavigateOnCellClick : column = -1 이면 Row, 그외는 컬럼위치
            // 컬럼은 의미없음 tr에 이벤트 발생됨
            // item 바인딩 이벤트를 먼저 등록후 데이터를 조회해야 함수가 생성된다.
            this.frame = frame;
            this.url = url;
            this.paramString = paramString;
            this.paramInt = paramInt;
            this.script = "SubmitForm('" + frame + "','" + url + "{0}" + "');";
            this.ItemDataBound += LDataGrid_ItemDataBound; // 데이터 바인딩시 호출 함수
        }

        private void LDataGrid_ItemDataBound(object sender, DataGridItemEventArgs e)
        {
            // 백슬래시를 2개로 표현방법. BBS\\2007\\05\\ 로 표현되어야 하는데 \로 표현되어 문자가 깨어지는것 같음
            string param = "";
            if (paramString.Length > 0)
            {
                for (int i = 0; i < paramString.Length; i++)
                {
                    string pa = paramString[i];
                    string va = e.Item.Cells[paramInt[i]].Text; // cell 값 읽어오기
                    va=va.Replace(@"\",@"\\");
                    string pair = "&" + pa + "=" + va;
                    param += pair;
                }
                param = "?" + param.Substring(1);
            }
            string item = string.Format(script, param);
            if(e.Item.ItemIndex>=0)
                e.Item.Attributes["onclick"] = item;
        }

        public void NavigateOnCellClick(int column, string frame, string url, string[] paramString, int[] paramInt)
        {
            NavigateOnCellClick(column, frame, url, paramString, paramInt, false);
        }
        public void NavigateOnRowClick(string frame, string url, string[] paramString, int[] paramInt, bool isReturn)
        {
            NavigateOnCellClick(-1, frame, url, paramString, paramInt, isReturn);
        }
        public void NavigateOnRowClick(string frame, string url, string[] paramString, int[] paramInt)
        {
            NavigateOnRowClick(frame, url, paramString, paramInt, false);
        }

        public void OpenWindowOnCellClick(int column, string url, string name, int width, int height, string[] paramString, int[] paramInt, bool isReturn)
        {
            this.frame = "_blank";
            this.url = url;
            this.paramString = paramString;
            this.paramInt = paramInt;
            this.script = "OpenWindow('" + name + "','" + "{0}" + "'," + width.ToString() + "," + height.ToString() + ");";
            this.ItemDataBound += LDataGrid_ItemDataBound;
        }

        public void OpenWindowOnRowClick(string url, string name, int width, int height, string[] paramString, int[] paramInt)
        {
            OpenWindowOnCellClick(-1, url, name, width, height, paramString, paramInt, false);
        }
        public void OpenWindowOnRowClick(string url, string name, int width, int height, string[] paramString, int[] paramInt, bool isReturn)
        {
            OpenWindowOnCellClick(-1, url, name, width, height, paramString, paramInt, isReturn);
        }        
    }
}
