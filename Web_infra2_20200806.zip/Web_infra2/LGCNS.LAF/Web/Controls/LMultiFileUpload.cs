﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using LGCNS.LAF.Common.FileManagement;
using System.Web.UI.HtmlControls;
namespace LGCNS.LAF.Web.Controls
{
    public class LMultiFileUpload : WebControl
    {
        public int MaxFileCount;
        public int DefaultFileCount;
        public DropDownList FileCountSelector;

        public ArrayList GetFileTransferObjectArrayList(string procedure, string module)
        {
            string realRoot = Configuration.RealRootPath;
            if (!procedure.Equals(""))
                procedure += @"\";

            if (!module.Equals(""))
                module += @"\";
            else
            {
                //모듈이 없으면 연월로 저장
                string year = string.Format("{0}",DateTime.Now.Year);
                string month = string.Format("{0:00}",DateTime.Now.Month);
                module = year + @"\" + month + @"\";
            }
            string realPath = procedure + module;

            // 파일업로드 객체를 받아와서 파일 객체를 Add 하여 ArrayList로 반환
            // GetFileTransferObjectArrayList 에서 input file 객체를 읽어오는 방법 확인 필요
            ArrayList list = new ArrayList();
            Page p = HttpContext.Current.CurrentHandler as Page;

            for (int i = 1; i <= MaxFileCount; i++)
            {
                string requestFileObject = this.ID + @"_FILE_" + i.ToString();
                HttpPostedFile postedFile = p.Request.Files[requestFileObject];
                string orginalfilename = Path.GetFileName(postedFile.FileName);
                if (orginalfilename != null)
                {
                    if (!orginalfilename.Equals(""))
                    {
                        // 파일명,경로 저장
                        string guid = "[" + Guid.NewGuid().ToString() + "]";
                        string extension = orginalfilename.Substring(orginalfilename.LastIndexOf('.'));
                        string fileheader = orginalfilename.Substring(0, orginalfilename.LastIndexOf('.'));
                        string filename = fileheader + guid + extension;

                        FileTransferObject fto = new FileTransferObject();
                        fto.FilePath = realPath + filename;
                        fto.OriginalFileName = orginalfilename;
                        fto.PostedFile = postedFile;

                        list.Add(fto);
                    }
                }
            }
            return list;
        }

        public ArrayList GetFileTransferObjectArrayList(string procedure)
        {
            return GetFileTransferObjectArrayList(procedure, "");
        }

        protected override void Render(System.Web.UI.HtmlTextWriter writer)
        {
            Page p = HttpContext.Current.CurrentHandler as Page;

            // TODO: FileCountSelector의 객체에 설정하지 않고 동일한 객체가 추가됨

            // NOT_: form 객체에 enctype 속성을 추가해야함
            HtmlForm form = this.Parent as HtmlForm;
            form.Enctype = "multipart/form-data";
            string obName = this.ID;
            for (int i = 1; i <= MaxFileCount; i++)
            {
                FileCountSelector.Items.Add(new ListItem(i.ToString()));
                if (i == DefaultFileCount)
                    FileCountSelector.SelectedIndex = i - 1;
            }
            FileCountSelector.Attributes.Add("onChange", obName+"_OnFileCountChange(this)");
            FileCountSelector.RenderControl(writer); // render를 하지 않으면 스크립트가 생성되지 않음.
            


            for (int i = 1; i <= MaxFileCount; i++)
            {
                string visible = "none";
                if (DefaultFileCount >= i)
                {
                    visible = "block";
                }
                string html = @"<div id=""" + obName + @"_DIV_" + i.ToString() + @""" style=""DISPLAY: " + visible + @"; POSITION: relative"">";
                html += @"<input id=""" + obName + @"_FILE_" + i.ToString() + @""" type=""file"" name =""" + obName + @"_FILE_" + i.ToString();
                html += @""" style =""WIDTH: 225px; HEIGHT: 22px""></div>";
                writer.Write(html);
            }

            string scriptid = obName + "_OnFileCountChange";
            string script = @"<script language=""javascript"">";
            script += "function " + scriptid+ "(pFileCountSelector)" + "\n";
            script += @"{" + "\n";
            script += @"	var iMaxFileCount = " + MaxFileCount.ToString() + " ;" + "\n";
            script += @"	var iFileCount = pFileCountSelector.value ;" + "\n";
            script += @"	for(i= 1; i<= iMaxFileCount ; i++)" + "\n";
            script += @"	{" + "\n";
            script += @"		var oDiv = document.getElementById('" + obName + "_DIV_' + i) ;" + "\n";
            script += @"		var sDisplay = 'none' ;" + "\n";
            script += @"		if(i<=iFileCount) sDisplay='block' ;" + "\n";
            script += @"		oDiv.style.display = sDisplay ; " + "\n";
            script += @"		if(i>iFileCount)" + "\n";
            script += @"		{" + "\n";
            script += @"			var oFile = document.getElementById('" + obName + "_FILE_' + i) ;" + "\n";
            script += @"			oFile.value = '' ;" + "\n";
            script += @"		}" + "\n";
            script += @"	}" + "\n";
            script += @"}" + "\n";
            script += @"</script>";
            // NOT_: 임시로 컨트롤에 자바스크립트 추가는 됨.
            writer.Write(script);
            // NOT_: page에 스크립트 추가 방법 확인
            //p.ClientScript.RegisterClientScriptBlock(p.GetType(), scriptid, script);
        }
       
    }
}
