﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace LGCNS.LAF.Web.Controls
{
    public class LTreeNodeCollection
    {
        
        public LTreeNodeCollection()
        {
        }
        public LTreeNodeCollection(LTreeNodeDS ds, bool isRoot)
        {
        }
        public LTreeNodeCollection(LTreeNodeDS ds, string parentNodeId, bool isRoot)
        {
        }

        public void AddRange(LTreeNode[] nodes)
        {
            // 미사용-LTreeNodeCollection AddRange
        }
    }
}
