﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;

namespace LGCNS.LAF.Web.Controls
{
    public class LTreeNode : TreeNode
    {
        public List<LTreeNode> Nodes;
        public int Count { get; set; }

        public LTreeNode()
        {

        }
        public LTreeNode(string menu, string menuName, string optioName, string optionValue, string option2, string frame, string url, bool isNode)
        {
            // 미사용-LTreeNode 구현
            //new LTreeNode("UserList", "사용자목록", "사용자목록", "default", "default", "main", "User/SelectUserList.aspx", false)
        }

        public void AddNodeRow(LTreeNodeDS.NodeRow drNode)
        {
        }

        public LTreeNodeDS.NodeRow NewNodeRow()
        {
            LTreeNodeDS.NodeRow row = new LTreeNodeDS.NodeRow();
            return row;
        }
    }
}
