﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LGCNS.LAF.Web.Controls
{
    public class LTreeMenu
    {
        // 미사용-LTreeMenu 구현
        public LTreeNodeCollection Nodes;
        public bool UseWebserviceBehavior;
        public string MenuServiceUrl;
    }
}
