﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LGCNS.LAF.Web
{
    public class XjosHelper
    {
        public static void RegisterXjos(bool isRegister)
        {
            // xjos 자바스크립트를 확인 필요. /aspnet_client/laf_net/XJOS/xjos.js 를 로딩
            // web.config 에 <pages enableEventValidation="false"/> 속성을 추가하였는데 없이도 동작하는 방법 확인해야함

            Page p = HttpContext.Current.CurrentHandler as Page;
            string script = @"<script language=""jscript"" src=""/aspnet_client/laf_net/Scripts/laf_net_common.js""></script>";
            script += @"<script language=""jscript"" src=""/aspnet_client/laf_net/xjos/xjos.js""></script>";
            p.ClientScript.RegisterStartupScript(p.GetType(), "RegisterXjos", script);

            string register = "";
            if(isRegister)
            {
                register = "registered";
            }
            string regXjos = @"<input type = ""hidden"" name = ""_XJOS"" id = ""_XJOS"" value = """ + register + @""">";
            regXjos += @"<input type=""hidden"" name=""__EVENTTARGET"" id=""__EVENTTARGET"" value="""">";
            regXjos += @"<input type=""hidden"" name=""__EVENTARGUMENT"" id=""__EVENTARGUMENT"" value="""">";

            regXjos += @"<input type=""hidden"" name=""_RELOADEDBY"" id=""_RELOADEDBY"" value="""">";
            regXjos += @"<input type=""hidden"" name=""_COMMONSTATE"" id=""_COMMONSTATE"" value="""">";
            regXjos += @"<input type=""hidden"" name=""_NAVIGATIONSTATE"" id=""_NAVIGATIONSTATE"" value="""">";


            p.ClientScript.RegisterClientScriptBlock(p.GetType(), "_XJOS", regXjos);
        }

        
        public static void SetValidator(DropDownList ddList, XjosValidator x1)
        {
            // textBox 구현하면 동일함.
            if (x1 != null)
            {
                ddList.Attributes.Add(x1.attr, x1.value);
                ddList.Attributes.Add(x1.attr_msg, x1.value_msg);
            }
        }
        public static void SetValidator(TextBox textBox, XjosValidator x1)
        {
            SetValidator(textBox, x1, null, null);
        }

        public static void SetValidator(TextBox textBox, XjosValidator x1, XjosValidator x2)
        {
            SetValidator(textBox, x1, x2, null);
        }

        public static void SetValidator(TextBox textBox, XjosValidator x1, XjosValidator x2, XjosValidator x3)
        {
            // SetValidator.textBox
            if (x1 != null)
            {
                textBox.Attributes.Add(x1.attr, x1.value);
                textBox.Attributes.Add(x1.attr_msg, x1.value_msg);
            }
            if (x2 != null)
            {
                textBox.Attributes.Add(x2.attr, x2.value);
                textBox.Attributes.Add(x2.attr_msg, x2.value_msg);
            }

            if (x3 != null)
            {
                textBox.Attributes.Add(x3.attr, x3.value);
                textBox.Attributes.Add(x3.attr_msg, x3.value_msg);
            }
        }

        public static void ValidateOnClick(Button btn)
        {
            ValidateOnClick(btn, null);
        }
        public static void ValidateOnClick(Button btn, string message)
        {
            string include = "";
            include += @"<script type = ""text/javascript"" >" + "\n";
            include += @" //<![CDATA[" + "\n";
            include += @" var theForm = document.forms['Form1'];" + "\n";
            include += @"            if (!theForm)" + "\n";
            include += @"            {" + "\n";
            include += @"                theForm = document.Form1;" + "\n";
            include += @"            }" + "\n";
            include += @"            function __doPostBack(eventTarget, eventArgument)" + "\n";
            include += @"            {" + "\n";
            include += @"                if (!theForm.onsubmit || (theForm.onsubmit() != false))" + "\n";
            include += @"                {" + "\n";
            include += @"                    theForm.__EVENTTARGET.value = eventTarget;" + "\n";
            include += @"                    theForm.__EVENTARGUMENT.value = eventArgument;" + "\n";
            include += @"                    theForm.submit();" + "\n";
            include += @"                }" + "\n";
            include += @"            }" + "\n";
            include += @"//]]>" + "\n";
            include += @"</script >" + "\n";

            Page p = HttpContext.Current.CurrentHandler as Page;
            p.ClientScript.RegisterClientScriptBlock(p.GetType(), "ValidateOnClick", include);

            string script = "";
            if (message == null)
            {
                script = "if(serveSubmit()==false)" + "\n";
                script += "{" + "\n";
                script += "\t" + "return false ;" + "\n";
                script += "}" + "\n";
                script += "else" + "\n";
                script += "{" + "\n";
                script += "\t" + @"__doPostBack('" + btn.ID + @"','') ;" + "\n";
                script += "}" + "\n";
            }
            else
            {
                script = "if(serveSubmit()==false)" + "\n";
                script += "{" + "\n";
                script += "\t" + "return false ;" + "\n";
                script += "}" + "\n";
                script += "else" + "\n";
                script += "{" + "\n";

                script += "\t" + @"if(confirm('" + message + "'))" + "\n";
                script += "\t" + "{" + "\n";
                script += "\t" + "\t" + @"__doPostBack('" + btn.ID + "','') ;" + "\n";
                script += "\t" + "}" + "\n";
                script += "\t" + "else" + "\n";
                script += "\t" + "{" + "\n";
                script += "\t" + "\t" + "return false ;" + "\n";
                script += "\t" + "}" + "\n";

                script += "}" + "\n";
            }
            // ValidateOnClick submit시 dopostback이 제대로 동작하지 않음
            btn.OnClientClick = script;
        }
    }
}
