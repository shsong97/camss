﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI;

namespace LGCNS.LAF.Web
{
    public partial class PageBase : Page
    {
        // MUST: PageBase : Page 의 속성 정의 구현해야함
        // TODO: IsSubmittedBy 를 페이지 전송시(submit) 에 true 로 설정해야함
        public bool IsSubmittedBy = false; // 스크립트로 전송시 셋팅해야 될것 같음
        public bool IsReloadedByPopup = false;
        public bool IsReloaded = false;
        public bool IsReloadedByDifferentFrame = false;
        
    }
}
