﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LGCNS.LAF.Web
{
    public class XjosValidator
    {
        public string attr = "";
        public string value = "";
        public string attr_msg = "";
        public string value_msg = "";

        public XjosValidator()
        {

        }
        public XjosValidator(XjosValidatorType xType)
        {
            Validator(xType, "", "");
        }
        public XjosValidator(XjosValidatorType xType, string message)
        {
            Validator(xType, "", message);
        }

        public XjosValidator(XjosValidatorType xType, string constraints, string message)
        {
            Validator(xType, constraints, message);
        }

        public void Validator(XjosValidatorType xType, string constraints, string message)
        {
            // XjosValidator 생성자
            // 속성과 속성_msg 를 생성한다.
            if (xType == XjosValidatorType.Date)
            {
                attr = "date";
            }
            else if (xType == XjosValidatorType.Required)
            {
                attr = "required";
            }
            else if (xType == XjosValidatorType.Minlength)
            {
                attr = "minlength";
            }
            else if (xType == XjosValidatorType.Alpha_Numeric)
            {
                attr = "alpha_numeric";
            }
            else if (xType == XjosValidatorType.Alphabetic)
            {
                attr = "alphabetic";
            }
            else if (xType == XjosValidatorType.Email)
            {
                attr = "email";
            }
            else if (xType == XjosValidatorType.Maxbyte)
            {
                attr = "maxbyte";
            }
            else if (xType == XjosValidatorType.Numeric)
            {
                attr = "numeric";
            }

            value = constraints;
            attr_msg = attr + "_msg";
            value_msg = message;
        }
    }
    
    public enum XjosValidatorType { Date, Required, Minlength, Alpha_Numeric, Alphabetic, Email, Maxbyte, Numeric }
}
