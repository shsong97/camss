﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LGCNS.LAF.Web
{
    public class NavigationHelper
    {
        public static void Redirect(string message, string target, string url)
        {
            //Page 객체를 얻어 자바스크립트 보여줌
            Page p = HttpContext.Current.CurrentHandler as Page;
            string script = "<script>" + "\n";
            if (message!=null)
            {
                if(!message.Equals(""))
                    script += "alert('" + message + "');" + "\n";
            }
            if(target == null)
            {
                target = "_top";
            }
            if (target.Equals(""))
            {
                target = "_top";
            }
            if (target.Equals("top"))
            {
                target = "_top";
            }
            script += "window.open('" + url + "', '" + target + "');" + "\n";
            script += "</script>";
            p.ClientScript.RegisterClientScriptBlock(p.GetType(), "Redirect", script);
        }
        public static void Redirect(string message, string url)
        {
            Redirect(message, null, url);
        }

        public static void SetHistoryBack(Button button)
        {
            string script = "window.history.back();return false;";
            button.OnClientClick = script;
        }

        public static void SetHistoryBack(LinkButton button)
        {
            string script = "window.history.back();return false;";
            button.OnClientClick = script;
        }

        public static void Redirect(string url)
        {
            Redirect("", "", url);
        }

        public static void Close(bool cloesed, NameValueCollection valuesToSend)
        {
            // MUST: Close 기능이 무엇인지 확인필요. windows.close 하고 부모를 reload. 공통 자바스크립트를 호출하면 된다.
            Page p = HttpContext.Current.CurrentHandler as Page;
            //p.ClientScript.RegisterStartupScript
        }

        public static void Close(bool cloesed)
        {
            Close(cloesed, null);
        }

        public static void RegisterHiddenIFrame(string frameName)
        {
            // Hidden IFrame 생성
            //<iframe name='HiddenFrame' border=0 width=0 height=0></iframe>
            Page p = HttpContext.Current.CurrentHandler as Page;
            string script = "<iframe name='" + frameName + "' border=0 width=0 height=0></iframe>";
            p.ClientScript.RegisterClientScriptBlock(p.GetType(), frameName, script);
        }

        public static void SetNavigation(Button button, string windowName, string url, bool isReturn)
        {
            // SetNavigation 구현
            //NavigateTo('', '/LGCNS.SITE.WebUI/Code/ManageNotice.aspx'); return false;
            string script = "SubmitForm('" + windowName + "','" + url + "'); return false";// + isReturn.ToString();
            //SubmitForm('HiddenFrame','SelectAssetListAsXls.aspx');return false;
            button.OnClientClick = script;
        }

        public static void SetPopupWindow(ImageButton button, string url, string windowName, int width, int height, bool isReturn)
        {
            // SetPopupWindow 동작하는지 확인필요
            if (windowName.Equals(""))
                windowName = "_top";
            string script = "OpenWindowNSubmit('" + url + "','" + windowName + "'," + width.ToString() + "," + height.ToString() + ");return false; ";
            button.OnClientClick = script;

        }
        public static void SetPopupWindow(Button button, string url, string windowName, int width, int height, bool isReturn)
        {
            // SetPopupWindow 동작하는지 확인필요
            if (windowName.Equals(""))
                windowName = "_top";
            string script = "OpenWindowNSubmit('" + url + "','" + windowName + "'," + width.ToString() + "," + height.ToString() + ");return false; ";
            button.OnClientClick = script;
        }
        public static void SetPopupWindow(HyperLink button, string url, string windowName, int width, int height, bool isReturn)
        {
            // SetPopupWindow 동작하는지 확인필요
            //OpenWindowNSubmit('SendMail.aspx','SendMail',400,500);return false
            if (windowName.Equals(""))
                windowName = "_top";
            string script = "OpenWindowNSubmit('" + url + "','" + windowName + "'," + width.ToString() + "," + height.ToString() + ");return false;";
            button.Attributes["onclick"] = script;
        }

    }
}
