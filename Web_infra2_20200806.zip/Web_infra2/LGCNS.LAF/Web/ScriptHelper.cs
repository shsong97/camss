﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LGCNS.LAF.Web
{
    public class ScriptHelper
    {
        public static void SetConfirmMessageOn(Button button, string message)
        {
            string script = "retrun confirm('" + message + "');";
            button.OnClientClick += script;
        }

        public static void ShowAlert(string message)
        {
            //Page 객체를 얻어 자바스크립트 보여줌
            Page p = HttpContext.Current.CurrentHandler as Page;
            string script= "<script>alert('" + message + "');</script>";
            p.ClientScript.RegisterClientScriptBlock(p.GetType(), "ShowAlert", script);
        }

        public static string ToJavaScript(string source)
        {
            string script = "<script>" + source + "</script>";
            return script;
        }
    }
}
