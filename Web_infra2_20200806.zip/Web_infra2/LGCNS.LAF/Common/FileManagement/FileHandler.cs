﻿using System;
using System.Web;

namespace LGCNS.LAF.Common.FileManagement
{
    public class FileHandler : IHttpHandler
    {
        /// <summary>
        /// You will need to configure this handler in the Web.config file of your 
        /// web and register it with IIS before being able to use it. For more information
        /// see the following link: https://go.microsoft.com/?linkid=8101007
        /// </summary>
        #region IHttpHandler Members

        public bool IsReusable
        {
            // Return false in case your Managed Handler cannot be reused for another request.
            // Usually this would be false in case you have some state information preserved per request.
            get { return true; }
        }

        public void ProcessRequest(HttpContext context)
        {
            //write your handler implementation here.
            string file = context.Request.QueryString["FILENAME"];
            string filePath = context.Request.QueryString["FILEPATH"];
            string realPath = Configuration.RealRootPath + filePath;
            string contentDisposition = @"attachment; filename=""" + file + @"""";
            context.Response.ContentType = "application/octet-stream";
            context.Response.AppendHeader("Content-Disposition", contentDisposition);
            context.Response.WriteFile(realPath);
        }

        #endregion
    }
}
