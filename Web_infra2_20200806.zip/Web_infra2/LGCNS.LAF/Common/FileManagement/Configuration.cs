﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LGCNS.LAF.Common.ConfigurationManagement;

namespace LGCNS.LAF.Common.FileManagement
{
    public class Configuration
    {
        public static string RealRootPath
        {
            get { return LConfigurationManager.GetConfigValue("LGCNS.LAF.FileTransfer", "RealRootPath"); }
        }
    }
}
