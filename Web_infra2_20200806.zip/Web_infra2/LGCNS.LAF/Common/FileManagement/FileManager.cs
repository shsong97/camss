﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace LGCNS.LAF.Common.FileManagement
{
    public class FileManager
    {
        public static void Save(FileTransferObject fto)
        {
            // Save 구현 - 파일 객체에서 정보를 가져와서 파일을 저장한다.
            string filePath = Configuration.RealRootPath + fto.FilePath;
            // 디렉토리가 없으면 하위 폴더 생성한다.
            string fileDirectory = filePath.Substring(0, filePath.LastIndexOf('\\'));
            if(!Directory.Exists(fileDirectory))
            {
                Directory.CreateDirectory(fileDirectory);
            }
            // 파일 저장
            fto.PostedFile.SaveAs(filePath);

        }

        public static void Delete(string filePath)
        {
            // Delete 구현
            string realRootPath = Configuration.RealRootPath + filePath;
            File.Delete(realRootPath);
        }
    }
}
