﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace LGCNS.LAF.Common.FileManagement
{
    public class FileTransferObject 
    {
        // FileTransferObject 구현
        public string FilePath;
        public string OriginalFileName;
        public HttpPostedFile PostedFile; // 파일 객체를 저장
    }
}
