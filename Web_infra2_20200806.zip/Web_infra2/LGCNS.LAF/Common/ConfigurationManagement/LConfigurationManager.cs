﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace LGCNS.LAF.Common.ConfigurationManagement
{
    public class LConfigurationManager
    {

        static string projectRoot = @"D:\Web_infra2\";

        public static string GetConfigValue(string configKey)
        {
            return GetConfigValue("LGCNS.SITE", configKey);
        }

        public static string GetConfigValue(string module, string configKey)
        {
            //LGCNS.SITE.config 파일에서 Key,Value 값을 가져온다.
            string configValue = string.Empty;
            string filepath = GetRoot() + @"Configuration\" + module + @".config";
            XmlDocument xml = new XmlDocument();
            xml.Load(filepath);

            foreach (XmlNode xmlNode in xml.DocumentElement.ChildNodes[0].ChildNodes[0].ChildNodes[0])
            {
                foreach (XmlNode item in xmlNode.ChildNodes)
                {
                    if (item.Name.Equals("key"))
                    {
                        string key = item.InnerText.Trim();
                        if (key.Equals(configKey))
                        {
                            configValue = item.NextSibling.InnerText.Trim();
                            return configValue;
                        }
                    }
                }
            }
            

            return configValue;
        }

        public static string GetRoot()
        {
            //TODO: 프로젝트 Root 구하는 방법 또는 사이트 최대 root
            string root = HttpContext.Current.Server.MapPath("/");
            // 하기는 모두 가상디렉토리를 root로 본다.
            //AppDomain.CurrentDomain.BaseDirectory;// HttpRuntime.AppDomainAppPath; // HttpContext.Current.Server.MapPath("/");
            
            return projectRoot;
        }
    }
}
