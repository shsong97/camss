﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace LGCNS.LAF.Common.Message
{
    // 미사용 - MessageDS 클래스 구현
    public class MessageDS
    {
        public MessageClass Message;
        public class MessageClass
        {
            public MessageDS.MessageRow FindByMessageID(string messageId)
            {
                MessageDS.MessageRow result = new MessageDS.MessageRow();
                return result;
            }
        }

        public class MessageRow
        {
            public string MessageValue;
        }
        public void ReadXml(string filePath)
        {
            
        }

        public void ReadXml(FileStream fs)
        {

        }
    }
}
