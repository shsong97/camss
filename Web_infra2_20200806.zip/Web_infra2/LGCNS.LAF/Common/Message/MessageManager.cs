﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using LGCNS.LAF.Common.ConfigurationManagement;

namespace LGCNS.LAF.Common.Message
{
    public class MessageManager
    {
        public static string GetMessage(string classParam, string messageParam)
        {
            string result = "";

            string configValue = string.Empty;
            string filepath = GetRoot(classParam);
            XmlDocument xml = new XmlDocument();
            xml.Load(filepath);

            //Query xml 찾기
            foreach (XmlNode item in xml.DocumentElement)
            {
                if (item.FirstChild.InnerText.Equals(messageParam))
                {
                    result = item.LastChild.InnerText.Trim();
                    return result;
                }
            }
            return result;
        }

        private static string GetRoot(string classParam)
        {
            return LConfigurationManager.GetConfigValue("LGCNS.LAF.Common.Message", classParam);
        }
    }
}
