﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LGCNS.LAF.Common.Message
{
    public class Configuration
    {
        public static string GetMessageFilePath(string module)
        {
            // GetMessageFilePath 구현
            string filePath = "";
            return filePath;
        }
    }
}
