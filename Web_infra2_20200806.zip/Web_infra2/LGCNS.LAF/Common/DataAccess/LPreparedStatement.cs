﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace LGCNS.LAF.Common.DataAccess
{
    public class LPreparedStatement
    {
        public string query=string.Empty;
        public CommandType cmdType = CommandType.Text;
        public Dictionary<string,SqlParameter> DataParameters=new Dictionary<string, SqlParameter>();
        
    }
}
