﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using LGCNS.LAF.Common.ConfigurationManagement;
using LGCNS.LAF.Common.Paging;

namespace LGCNS.LAF.Common.DataAccess
{
    public class ADOHelper
    {
        public static SqlConnection SqlCon;
        public static string ConnectionString = "";

        public static void ExecuteNonQuery(LPreparedStatement ps, LDataCollection dc)
        {
            // ExecuteNonQuery 구현
            try
            {
                ParameterMapping(ps, dc);
                if (Open())
                {
                    using (SqlCommand sqlCommand = new SqlCommand(ps.query, SqlCon))
                    {
                        sqlCommand.Parameters.AddRange(ps.DataParameters.Values.ToArray<SqlParameter>());
                        sqlCommand.ExecuteNonQuery();
                        sqlCommand.Parameters.Clear();
                        Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Close();
                throw ex;
            }
        }
        
        public static void ExecuteNonQuery(LPreparedStatement ps, DataRow dr)
        {
            // ExecuteNonQuery 구현 확인
            try
            {
                ParameterMapping(ps, dr);
                if (Open())
                {
                    //dr 의 값을 읽어서 dc와 매핑한다.
                    using (SqlCommand sqlCommand = new SqlCommand(ps.query, SqlCon))
                    {
                        sqlCommand.Parameters.AddRange(ps.DataParameters.Values.ToArray<SqlParameter>());
                        sqlCommand.ExecuteNonQuery();
                        sqlCommand.Parameters.Clear();
                        Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Close();
                throw ex;
            }
        }
        public static void FillDataSet(LPreparedStatement ps, DataSet ds, string[] tableArray, LDataCollection dc)
        {
            // dc에 값을 파라미터로 전달한다. adapter로 실행후 데이터를 ds에 매핑한다.
            try
            { 
                ParameterMapping(ps, dc);
                if (Open())
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter())
                    {
                        adapter.SelectCommand = new SqlCommand(ps.query, SqlCon)
                        {
                            CommandType = ps.cmdType
                        };
                        adapter.SelectCommand.Parameters.AddRange(ps.DataParameters.Values.ToArray<SqlParameter>());
                        DataTableMapping[] dtMap = new DataTableMapping[tableArray.Length];
                        for (int i = 0; i < tableArray.Length; i++)
                        {
                            dtMap[i] = new DataTableMapping();
                            dtMap[i].SourceTable = "Table" + (i == 0 ? "" : i.ToString());
                            dtMap[i].DataSetTable = tableArray[i];
                        }
                        adapter.TableMappings.AddRange(dtMap);
                        adapter.Fill(ds);
                       
                        Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Close();
                throw ex;
            }
            
        }

        public static void FillDataSet(LPreparedStatement ps, DataSet ds, string tableName, int currentPage, int pageSize, LDataCollection dc)
        {
            try
            {
                ParameterMapping(ps, dc);
                if(Open())
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter())
                    {
                        adapter.SelectCommand = new SqlCommand(ps.query, SqlCon)
                        {
                            CommandType = ps.cmdType
                        };
                        adapter.SelectCommand.Parameters.AddRange(ps.DataParameters.Values.ToArray<SqlParameter>());
                        adapter.Fill(ds, tableName);
                        Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Close();
                throw ex;
            }            
        }

        public static void FillDataSet(LPreparedStatement ps, DataSet ds, string[] tableArray)
        {
            FillDataSet(ps, ds, tableArray, null);
        }

        private static void ParameterMapping(LPreparedStatement ps, LDataCollection dc)
        {
            // dc 에 있는 값을 ps 에 있는 DataParameter에 value로 매핑시킨다
            // [ORDER] 는 SQL 쿼리문을 replace 한다.
            if (dc == null)
                return;
            foreach (string key in dc.Keys)
            {
                if (key.Equals("[ORDER]"))
                {
                    ps.query=ps.query.Replace(key, dc[key].ToString());
                }
                else
                {
                    string sqlKey = "@" + key;
                    if (ps.DataParameters.Keys.Contains(sqlKey))
                    {
                        if (dc[key] == null)
                            ps.DataParameters[sqlKey].Value = "";
                        else
                            ps.DataParameters[sqlKey].Value = dc[key];//.ToString();
                    }
                }
            }
        }
        private static void ParameterMapping(LPreparedStatement ps, DataRow dr)
        {
            // dc 에 있는 값을 ps 에 있는 DataParameter에 value로 매핑시킨다
            // [ORDER] 는 SQL 쿼리문을 replace 한다.
            // 키 비교시 대소문자 상관없이 할당해야 되나?
            if (dr == null)
                return;

            foreach (string key in ps.DataParameters.Keys)
            {
                string sqlKey = key.Replace("@","");
                if (dr[sqlKey] == null)
                    ps.DataParameters[key].Value = "";
                else
                    ps.DataParameters[key].Value = dr[sqlKey];
            }
        }

        private static bool Open()
        {
            bool returnValue = true;
            try
            {
                // Sql Connection 객체 생성
                if (SqlCon == null)
                {
                    SqlCon = new SqlConnection(getConnectionString());
                }

                if (!SqlCon.ConnectionString.Equals(getConnectionString()))
                {
                    Close();
                    SqlCon = new SqlConnection(getConnectionString());
                }
                // DB 연결 상태가 Open이 아닐 경우에는 DB 연결을 종료한다.
                if (SqlCon.State != ConnectionState.Open)
                {
                    // DB에 연결되어 있으면 접속을 종료한다.
                    if (SqlCon.State == ConnectionState.Connecting)
                        SqlCon.Close();

                    // DB에 연결
                    SqlCon.Open();
                }

            }
            catch (SqlException )
            {
                // 오류 메시지 저장
                returnValue = false;
            }
            catch (Exception )
            {
                returnValue = false;
            }
            return returnValue;
        }
        private static bool Close()
        {
            bool returnValue = true;
            try
            {
                if (SqlCon != null)
                {
                    // DB 연결이 Closed가 아니면 DB 연결을 종료한다.
                    if (SqlCon.State != ConnectionState.Closed)
                        SqlCon.Close();
                }
            }
            catch (SqlException )
            {
                returnValue = false;
            }
            catch (Exception )
            {
                returnValue = false;
            }
            return returnValue;
        }

        private static string getConnectionString()
        {
            // config 파일에서 connection 정보를 가져온다.
            if (!ConnectionString.Equals(""))
                return ConnectionString;
            ConnectionString = LConfigurationManager.GetConfigValue("LGCNS.LAF.Common.DataAccess", "ConnectionString");
            return ConnectionString;
        }
    }
}
