﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Xml;
using System.Data.SqlClient;
using LGCNS.LAF.Common.ConfigurationManagement;

namespace LGCNS.LAF.Common.DataAccess
{
    public class LPreparedStatementFactory
    {
        public static LPreparedStatement Create(string project_name, string class_name, string procedure, object ds)
        {
            //LGCNS.LAF.Common.DataAccess.config 파일에서 projectname의 파일을 가져온다.
            LPreparedStatement lp = new LPreparedStatement();

            string configValue = string.Empty;
            string filepath = LConfigurationManager.GetConfigValue("LGCNS.LAF.Common.DataAccess", project_name);
            XmlDocument xml = new XmlDocument();
            xml.Load(filepath);

            // TODO: LPreparedStatementFactory project_name, class_name 노드 찾기
            foreach (XmlNode xmlNode in xml.DocumentElement.ChildNodes[0].ChildNodes[0])
            {
                string value = xmlNode.Attributes["QueryName"].Value;
                if (value.Equals(procedure))
                {
                    // 커맨드 타입 확인
                    string commandType = xmlNode.Attributes["CommandType"].Value;

                    if (commandType.Equals("StoredProcedure"))
                        lp.cmdType = CommandType.StoredProcedure;
                    else
                        lp.cmdType = CommandType.Text;

                    // SQL 문 또는 파라미터 확인
                    foreach (XmlNode item in xmlNode.ChildNodes)
                    {
                        if (item.Name.Equals("SqlStatement"))
                        {
                            lp.query = item.InnerText.Trim();
                        }
                        else if (item.Name.Equals("Parameter"))
                        {
                            SqlParameter parameter = new SqlParameter();

                            if (item.Attributes["Direction"].Value.ToString().Equals("Input"))
                                parameter.Direction = ParameterDirection.Input;
                            else if (item.Attributes["Direction"].Value.ToString().Equals("Output"))
                                parameter.Direction = ParameterDirection.Output;
                            else if (item.Attributes["Direction"].Value.ToString().Equals("ReturnValue"))
                                parameter.Direction = ParameterDirection.ReturnValue;
                            else
                                parameter.Direction = ParameterDirection.InputOutput;

                            if(item.Attributes["Size"]!=null)
                            {
                                parameter.Size = int.Parse(item.Attributes["Size"].Value);
                            }

                            parameter.ParameterName = item.Attributes["ParameterName"].Value.ToString();
                            lp.DataParameters.Add(item.Attributes["ParameterName"].Value.ToString(), parameter);
                        }

                    }
                    break;
                }
            }

            return lp;
        }

        public static LPreparedStatement Create(string project_name, string class_name, string procedure)
        {
            return Create(project_name, class_name, procedure, null);
        }
    }
}
