﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LGCNS.LAF.Common.Security.Interfaces
{
    public class IUserInfo
    {
        // 미사용 클래스
    }
}
