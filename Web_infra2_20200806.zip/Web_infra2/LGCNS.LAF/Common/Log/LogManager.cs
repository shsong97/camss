﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Principal;
using System.Threading;
using System.IO;
using LGCNS.LAF.Common.ConfigurationManagement;

namespace LGCNS.LAF.Common.Log
{
    public class LogManager
    {

        public static void Publish(Exception ex, string procedure, string data)
        {
            // Log 폴더에 일자별 파일을 생성한다.
            // General Information
            // Exception Information
            // StackTrace information
            IntPtr accounttoken = WindowsIdentity.GetCurrent().Token;
            WindowsIdentity windowsIdentity = new WindowsIdentity(accounttoken);
            DateTime dt = DateTime.Now;
            
            string startLine = "*********************************************";
            string endLine = "---------------------------------------------";
            string cr = "\n";
            string generalInfo = "General Information" + cr;
            generalInfo += startLine + cr;
            generalInfo += "Additional Info:" + cr;
            generalInfo += "ExceptionManager.MachineName: " + Environment.MachineName + cr;
            generalInfo += "ExceptionManager.TimeStamp: " + dt.ToLocalTime().ToString() + cr;
            generalInfo += "ExceptionManager.ThreadIdentity: " + Thread.CurrentPrincipal.ToString() + cr;
            generalInfo += @"ExceptionManager.WindowsIdentity: " + windowsIdentity.Name + cr + cr;

            
            string exceptionInfo = "1) Exception Information" + cr;
            exceptionInfo += startLine + cr;
            exceptionInfo += "Exception Type: " + ex.GetType().ToString() + cr;
            exceptionInfo += "Message: " + ex.Message + cr;
            exceptionInfo += "Procedure: " + (String.IsNullOrEmpty(procedure) ? "NULL" : procedure) + cr;
            exceptionInfo += "Data: " + (String.IsNullOrEmpty(data) ? "NULL":data) + cr;
            exceptionInfo += "TargetSite: " + ex.TargetSite + cr;
            exceptionInfo += "HelpLink: " + ex.HelpLink + cr;
            exceptionInfo += "Source: " + ex.Source + cr + cr;

            string stackTaceInfo = "";
            stackTaceInfo += startLine + cr;
            stackTaceInfo += ex.StackTrace + cr;
            stackTaceInfo += endLine + cr + cr;

            // 디렉토리에서 파일 검색후 Append 모드로 열기
            string logPath = LConfigurationManager.GetRoot() + @"LOG\";
            string fileName = DateTime.Now.ToShortDateString() + ".txt";
            if(!Directory.Exists(logPath))
            {
                Directory.CreateDirectory(logPath);
            }

            if(!File.Exists(logPath + fileName))
            {
                using (StreamWriter sw = File.CreateText(logPath + fileName))
                {
                    sw.WriteLine(generalInfo);
                    sw.WriteLine(exceptionInfo);
                    sw.WriteLine(stackTaceInfo);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(logPath + fileName))
                {
                    sw.WriteLine(generalInfo);
                    sw.WriteLine(exceptionInfo);
                    sw.WriteLine(stackTaceInfo);
                }
            }
        }

        public static void Publish(Exception ex)
        {
            Publish(ex, null, null);
        }
    }
}
