﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace LGCNS.LAF.Common.Paging
{
    public class PagingHelper
    {
        public static int currentPage =0;
        public static int pageSize =10;
        public static int totalCount = 0;

        public static void SetPagingInfo(DataSet ds, int tc, int cp, int ps)
        {
            // DataSet의 Paing 구현 방법 확인
            pageSize = ps;
            currentPage = cp;
            totalCount = tc;
            // ds 에서 실제 페이지에 해당하는 데이터만 ds에 셋팅해야 됨
            DataTable dt = ds.Tables[0].Copy();
            ds.Tables[0].Rows.Clear();
            int maxCount = currentPage * pageSize;

            if (currentPage * pageSize > totalCount)
                maxCount = totalCount;

            for (int i = (currentPage - 1) * pageSize; i < maxCount; i++)
            {
                DataRow dr = dt.Rows[i];
                //DataRow dr = dt[i];
                ds.Tables[0].ImportRow(dr);
            }
        }

        public static int GetTotalPage(DataSet ds)
        {
            // ds 에서 page size 를 구해서 total count 를 나눠야 함
            
            int totalCount = GetTotalCount(ds);
            int totalPage = totalCount / pageSize + 1;
            return totalPage;
        }

        public static int GetTotalCount(DataSet ds)
        {
            //totalCount = ds.Tables[0].Rows.Count;
            return totalCount;
        }
    }
}
