﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LGCNS.LAF.Common.Exceptions
{
    public class BizException : Exception
    {
        public BizException()
        {
            throw new Exception();
        }

        public BizException(string message, Exception ex) 
        {
            Log.LogManager.Publish(ex, "", message);
            throw new Exception(message);
        }
    }


}
