﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LGCNS.LAF.Common.Exceptions
{
    public class MessagingException : Exception
    {
        public MessagingException()
        {

        }

        public MessagingException(string message, string module)
        {
            Log.LogManager.Publish(this, module, message);
        }
    }
}
