﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LGCNS.LAF.DA
{
    public class DABase : IDisposable
    {
        // DABase 삭제 구현
        public void Dispose()
        {
            
        }
    }
}
