vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|02 Mar 2005 13:18:20 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|02 Mar 2005 13:18:20 -0000
vti_filesize:IR|2454
