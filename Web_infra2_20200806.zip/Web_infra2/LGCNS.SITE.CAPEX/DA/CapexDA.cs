using System;
using System.EnterpriseServices;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Collections.Specialized;

using LGCNS.LAF.DA;
using LGCNS.LAF.Common.Exceptions;
using LGCNS.LAF.Common.DataAccess;
using LGCNS.LAF.Common.Paging ;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.CAPEX.DA
{
	/// <summary>
	/// CapexDA�� ���� ��� �����Դϴ�.
	/// </summary>
	public class CapexDA : LGCNS.LAF.DA.DABase
	{
		private const string PROJECT_NAME	= "LGCNS.SITE.CAPEX" ;
		private const string CLASS_NAME		= "LGCNS.SITE.CAPEX.DA.CapexDA" ;

		public CapexDA() {}

		#region Select 
		[AutoComplete(true)]
		public CapexDS SelectQuotationHistData(int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["QuotationNo"] = searchCondition["QuotationNo"];
			dc["CreateDateFrom"] = searchCondition["CreateDateFrom"];
			dc["CreateDateTo"] = searchCondition["CreateDateTo"];

			CapexDS ds = new CapexDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectQuotationHistData") ;
			ADOHelper.FillDataSet (ps, ds, "TB_QUOTATION_HIST", currentPage, pageSize, dc) ;

			if( pageSize > 0 )
			{
				int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;

				PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;
			}

			return ds ;
		}

		[AutoComplete(true)]
		public CapexDS SelectQuotationMaxNo()
		{
			CapexDS ds = new CapexDS () ;
			
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectQuotationMaxNo", ds.TB_QUOTATION_NO) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_QUOTATION_NO"}) ;

			return ds ;
		}


		[AutoComplete(true)]
		public CapexDS SelectQuotationData( string QuotationNo  )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["QuotationNo"] = QuotationNo;

			CapexDS ds = new CapexDS();
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectQuotationData", ds.TB_QUOTATION) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_QUOTATION"}, dc) ;

			return ds ;
		}

		[AutoComplete(true)]
		public CapexDS SelectOneQuotationData( string QuotaNo, string SPEC )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["QuotaNo"] = QuotaNo;
			dc["SPEC"] = SPEC;

			CapexDS ds = new CapexDS();
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectOneQuotationData", ds.TB_QUOTATION_HIST) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_QUOTATION_HIST"}, dc) ;

			return ds ;
		}


		[AutoComplete(true)]
		public CapexDS SelectOneUpQuotationData( string QuotaNo, string SPEC )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["QuotaNo"] = QuotaNo;
			dc["SPEC"] = SPEC;

			CapexDS ds = new CapexDS();
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectOneUpQuotationData", ds.TB_QUOTATION_UP) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_QUOTATION_UP"}, dc) ;

			return ds ;
		}

		[AutoComplete(true)]
		public CapexDS SelectQuotationNo()
		{
			return SelectQuotationNo("") ;
		}

		[AutoComplete(true)]
		public CapexDS SelectQuotationNo(string args)
		{
			CapexDS ds = new CapexDS () ;
			
			LDataCollection dc = new LDataCollection () ;
			dc["QuotationNo"]	= args ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectQuotationNo", ds.TB_QUOTATION_NO) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_QUOTATION_NO"}, dc ) ;

			return ds ;
		}
		#endregion



		#region Capex Select 
		[AutoComplete(true)]
		public CapexDS SelectCapexAutorityList(string Flag )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["Flag"] = Flag;

			CapexDS ds = new CapexDS();
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectCapexAutorityList", ds.TB_CAPEX_LIST) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_CAPEX_LIST"}, dc) ;

			return ds ;
		}

		
		[AutoComplete(true)]
		public void CapexStatusChange(NameValueCollection searchCondition )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = searchCondition["TicketNo"];
			dc["Flag"] = searchCondition["Flag"];
			dc["Status"] = searchCondition["Status"];			
			
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "CapexStatusChange") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		[AutoComplete(true)]
		public CapexDS SelectCapexStatusList(NameValueCollection searchCondition )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = searchCondition["TicketNo"];

			CapexDS ds = new CapexDS();
			ds.EnforceConstraints = false;
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectCapexStatusList") ;
			ADOHelper.FillDataSet (ps, ds, new string[] {"TB_CAPEX_STATUS"},dc) ;			

			return ds ;
		}


		[AutoComplete(true)]
		public CapexDS SelectCapexDataList(string Flag1, string Flag, int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = searchCondition["TicketNo"];
			dc["CapexStatus"] = searchCondition["CapexStatus"];
			dc["Area"] = searchCondition["Area"];
			dc["EmpNo"] = searchCondition["EmpNo"];
			dc["EmpName"] = searchCondition["EmpName"];
			dc["VendorDesc"] = searchCondition["VendorDesc"];
			dc["CreateDateFrom"] = searchCondition["CreateDateFrom"];
			dc["CreateDateTo"] = searchCondition["CreateDateTo"];
			dc["OptDate"] = searchCondition["OptDate"];
			dc["ModelDesc"] = searchCondition["ModelDesc"];
			dc["Flag"] = Flag;
			dc["Flag1"] = Flag1;
			dc["CFlag"] = searchCondition["CFlag"];
			

			CapexDS ds = new CapexDS();
			ds.EnforceConstraints = false;
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectCapexDataList") ;
			ADOHelper.FillDataSet (ps, ds, "TB_CAPEX_LIST", currentPage, pageSize, dc) ;			

			if( pageSize > 0 )
			{
				int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;

				PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;
			}

			return ds ;
		}


		[AutoComplete(true)]
		public CapexDS SelectCapexDataList1(string Flag1, string Flag, int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			LDataCollection dc = new LDataCollection () ;
			//dc["CapexNo"] = searchCondition["CapexNo"];
			dc["TicketNo"] = searchCondition["TicketNo"];
			dc["CapexStatus"] = searchCondition["CapexStatus"];
			dc["Area"] = searchCondition["Area"];
			dc["EmpNo"] = searchCondition["EmpNo"];
			dc["EmpName"] = searchCondition["EmpName"];
			dc["VendorDesc"] = searchCondition["VendorDesc"];
			dc["CreateDateFrom"] = searchCondition["CreateDateFrom"];
			dc["CreateDateTo"] = searchCondition["CreateDateTo"];
			dc["OptDate"] = searchCondition["OptDate"];
			dc["ModelDesc"] = searchCondition["ModelDesc"];
			dc["Flag"] = Flag;
			dc["Flag1"] = Flag1;
			dc["CFlag"] = searchCondition["CFlag"];

			CapexDS ds = new CapexDS();
			ds.EnforceConstraints = false;
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectCapexDataList") ;
			ADOHelper.FillDataSet (ps, ds, "TB_CAPEX_LIST1", currentPage, pageSize, dc) ;			
			
			if( pageSize > 0 )
			{
				int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;

				PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;
			}

			return ds ;
		}

		[AutoComplete(true)]
		public CapexDS SelectCapexDataListXls( NameValueCollection searchCondition )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["CapexNo"] = searchCondition["CapexNo"];
			dc["TicketNo"] = searchCondition["TicketNo"];
			dc["CapexStatus"] = searchCondition["CapexStatus"];
			dc["Area"] = searchCondition["Area"];
			dc["EmpNo"] = searchCondition["EmpNo"];
			dc["EmpName"] = searchCondition["EmpName"];
			dc["CreateID"] = searchCondition["CreateID"];
			dc["CreateDateFrom"] = searchCondition["CreateDateFrom"];
			dc["CreateDateTo"] = searchCondition["CreateDateTo"];

			CapexDS ds = new CapexDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectCapexDataList") ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_CAPEX_LIST"}, dc) ;
			return ds ;
		}


		public CapexDS SelectCapexMast( string TicketNo , string CapexNo)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = TicketNo;
			dc["CapexNo"] = CapexNo;

			CapexDS ds = new CapexDS();
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectCapexMast", ds.TB_CAPEX_MAST) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_CAPEX_MAST"}, dc) ;

			return ds ;
		}


		public CapexDS SelectCapexDes( string CapexNo)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["CapexNo"] = CapexNo;

			CapexDS ds = new CapexDS();
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectCapexDes", ds.TB_CAPEX_DES) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_CAPEX_DES"}, dc) ;

			return ds ;
		}

		#endregion

		#region Category

		[AutoComplete(true)]
		public CapexDS SelectCategory()
		{
			return SelectCategory("") ;
		}

		[AutoComplete(true)]
		public CapexDS SelectCategory(string args)
		{
			CapexDS ds = new CapexDS () ;
			
			LDataCollection dc = new LDataCollection () ;
			dc["Category"]	= args ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectCategory", ds.TB_BASE) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_BASE"}, dc ) ;

			return ds ;
		}
		#endregion


		#region WBSE

		[AutoComplete(true)]
		public CapexDS SelectWBSE()
		{
			return SelectWBSE("") ;
		}

		[AutoComplete(true)]
		public CapexDS SelectWBSE(string args)
		{
			CapexDS ds = new CapexDS () ;
			
			LDataCollection dc = new LDataCollection () ;
			dc["WBSE"]	= args ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectWBSE", ds.TB_BASE) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_BASE"}, dc ) ;

			return ds ;
		}
		#endregion



		#region Gubun

		[AutoComplete(true)]
		public CapexDS SelectGubun()
		{
			return SelectGubun("") ;
		}

		[AutoComplete(true)]
		public CapexDS SelectGubun(string args)
		{
			CapexDS ds = new CapexDS () ;
			
			LDataCollection dc = new LDataCollection () ;
			dc["args"]	= args ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectGubun", ds.TB_BASE) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_BASE"}, dc ) ;

			return ds ;
		}
		#endregion

		#region Capex Status  

		[AutoComplete(true)]
		public CapexDS SelectCapexStatus()
		{
			return SelectCapexStatus("") ;
		}

		[AutoComplete(true)]
		public CapexDS SelectCapexStatus(string args)
		{
			CapexDS ds = new CapexDS () ;
			
			LDataCollection dc = new LDataCollection () ;
			dc["CapexStatus"]	= args ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectCapexStatus", ds.TB_BASE) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_BASE"}, dc ) ;

			return ds ;
		}
		#endregion

		#region Manage 

		[AutoComplete(true)]
		public void BackupQuotationData()
		{
			CapexDS ds = new CapexDS () ;
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "BackupQuotationData", ds.TB_QUOTATION_NO) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_QUOTATION_NO"} ) ;
		}


		[AutoComplete(true)]
		public void  UpdateQuotationData (NameValueCollection searchCondition )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["QuotaNo"] = searchCondition["QuotaNo"];
			dc["Category"] = searchCondition["Category"];
			dc["Category_H"] = searchCondition["Category_H"];
			dc["ModelNo"] = searchCondition["ModelNo"] ;
			dc["ModelNo1"] = searchCondition["ModelNo1"] ;
			dc["Make"] = searchCondition["Make"]  ;
			dc["ClassID"] = searchCondition["ClassID"] ;
			dc["CPUSpeed"] = searchCondition["CPUSpeed"] ;
			dc["SystemID"] = searchCondition["SystemID"] ;
			dc["CPUType"] = searchCondition["CPUType"] ;
			dc["TypeDesc"] = searchCondition["TypeDesc"];
			dc["WBSE"] = searchCondition["WBSE"];
			dc["Description"] = searchCondition["Description"];
			dc["Qty"] = searchCondition["Qty"];
			dc["unit_price"] = searchCondition["unit_price"];
			dc["UpdateID"] = searchCondition["UpdateID"];
			dc["InvoiceId"] = searchCondition["InvoiceId"];

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateQuotationData") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		[AutoComplete(true)]
		public void  DeleteQuotationData (NameValueCollection searchCondition )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["QuotaNo"] = searchCondition["QuotaNo"];
			dc["SPEC"] = searchCondition["SPEC"];
			dc["UpdateID"] = searchCondition["UpdateID"];

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteQuotationData") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}


		[AutoComplete(true)]
		public void  InsertQuotationData (NameValueCollection searchCondition )
		{
			LDataCollection dc = new LDataCollection () ;

			dc["QuotaNo"] = searchCondition["QuotaNo"];
			dc["Category"] = searchCondition["Category"];
			dc["Category_H"] = searchCondition["Category_H"];
			dc["ModelNo"] = searchCondition["ModelNo"] ;
			dc["Make"] = searchCondition["Make"]  ;
			dc["ClassID"] = searchCondition["ClassID"] ;
			dc["CPUSpeed"] = searchCondition["CPUSpeed"] ;
			dc["SystemID"] = searchCondition["SystemID"] ;
			dc["CPUType"] = searchCondition["CPUType"] ;
			dc["TypeDesc"] = searchCondition["TypeDesc"];

			dc["Qty"] = searchCondition["Qty"];
			dc["unit_price"] = searchCondition["unit_price"];
			dc["CreateID"] = searchCondition["CreateID"];
			dc["Description"] = searchCondition["Description"];
//			dc["Gubun"] = searchCondition["Gubun"];

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertQuotationData") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		[AutoComplete(true)]
		public void  SaveCapexData( string CapexNo, string Flag , string UserID, string Description, string Vendor)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["CapexNo"] = CapexNo;
			dc["Flag"] = Flag;
			dc["UserID"] = UserID;
			dc["Description"] = Description;
			dc["VendorDesc"] = Vendor;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SaveCapexData") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}


		[AutoComplete(true)]
		public void  SaveMCapexNo( string CapexNo, string TicketNo, string Seq)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["CapexNo"] = CapexNo;
			dc["TicketNo"] = TicketNo;
			dc["Seq"] = Seq;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SaveMCapexNo") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		
		[AutoComplete(true)]
		public void  SaveCapexConfirmData( string CapexNo, string  MordNo, string  CheckNo,string   DemandDate,string   UserID)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["CapexNo"] = CapexNo;
			dc["MordNo"] = MordNo;
			dc["CheckNo"] = CheckNo;
			dc["DemandDate"] = DemandDate;
			dc["UserID"] = UserID;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SaveCapexConfirmData") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}


		[AutoComplete(true)]
		public void  InsertCapexDetail( string CapexNo, string Seq, string Model, string Qty , string Price, string LedgerEntry, string UserID)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["CapexNo"] = CapexNo;
			dc["Seq"] = Seq;
			dc["Model"] = Model;
			dc["Qty"] = Qty;
			dc["Price"] = Price;
			dc["LedgerEntry"] = LedgerEntry;
			dc["UserID"] = UserID;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertCapexDetail") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}


		[AutoComplete(true)]
		public void  UpdateCapexDetail( string CapexNo, string Seq, string Model, string Qty , string Price, string LedgerEntry, string UserID)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["CapexNo"] = CapexNo;
			dc["Seq"] = Seq;
			dc["Model"] = Model;
			dc["Qty"] = Qty;
			dc["Price"] = Price;
			dc["LedgerEntry"] = LedgerEntry;
			dc["UserID"] = UserID;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateCapexDetail") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}
		[AutoComplete(true)]
		public void  DeleteCapexDetail( string CapexNo, string Seq)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["CapexNo"] = CapexNo;
			dc["Seq"] = Seq;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteCapexDetail") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}

		[AutoComplete(true)]
		public void  ConfirmCSCCapexData( string CapexNo, string Flag )
		{
			LDataCollection dc = new LDataCollection () ;
			dc["CapexNo"] = CapexNo;
			dc["Flag"] = Flag;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "ConfirmCSCCapexData") ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;
		}



		#endregion


		#region Ticket


		[AutoComplete(true)]
		public TicketDS SelectTicket(string ticketNo)
		{
			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"] = ticketNo;

			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectTicket") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_TICKET_ENTIRE","TB_TICKET_EMP_ENTIRE"}, dc) ;

			return ds ;
		}


		#endregion

		#region Model, LedgerEntry
		[AutoComplete(true)]
		public CapexDS SelectModel()
		{
			return SelectModel("") ;
		}

		[AutoComplete(true)]
		public CapexDS SelectModel(string args)
		{
			CapexDS ds = new CapexDS () ;
			
			LDataCollection dc = new LDataCollection () ;
			dc["args"]	= args ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectModel", ds.TB_BASE) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_BASE"}, dc ) ;

			return ds ;
		}

		[AutoComplete(true)]
		public CapexDS SelectLedgerEntrylList()
		{
			return SelectLedgerEntrylList("") ;
		}

		[AutoComplete(true)]
		public CapexDS SelectLedgerEntrylList(string args)
		{
			CapexDS ds = new CapexDS () ;
			
			LDataCollection dc = new LDataCollection () ;
			dc["args"]	= args ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectLedgerEntrylList", ds.TB_BASE) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_BASE"}, dc ) ;

			return ds ;
		}

		public string SelectPrice(string Model)
		{
			string ResultStatement = "";

			LDataCollection dc = new LDataCollection () ;
			dc["Model"] = Model;
			dc["ResultStatement"] = ResultStatement;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectPrice" ) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;

			ResultStatement = ps.DataParameters["@ResultStatement"].Value.ToString();

			return ResultStatement;
		}


		public CapexDS SelectAuthority ( string CapexNo, string UserID)
		{
			CapexDS ds = new CapexDS () ;
			
			LDataCollection dc = new LDataCollection () ;
			dc["CapexNo"]	= CapexNo ;
			dc["UserID"]	= UserID ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectAuthority", ds.TB_BASE) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_BASE"}, dc ) ;

			return ds ;
		}


		#endregion

	}
}
