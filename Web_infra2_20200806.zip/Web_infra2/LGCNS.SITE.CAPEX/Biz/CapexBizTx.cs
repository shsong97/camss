using System;
using System.Collections;
using System.EnterpriseServices;
using System.Collections.Specialized;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.CAPEX.DA;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.CAPEX.Biz
{
	/// <summary>
	/// CapexBizTx�� ���� ��� �����Դϴ�.
	/// </summary>
	public class CapexBizTx : LGCNS.LAF.Biz.BizTxBase
	{
		public CapexBizTx()	{}

		#region Backup 
		[AutoComplete(true)]
		public void BackupQuotationData()
		{
			CapexDA da = null;
			
			try
			{
				da = new CapexDA ();
				da.BackupQuotationData();				
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		#endregion

		#region Manage 

		[AutoComplete(true)]

		public void UpdateQuotationData (NameValueCollection searchCondition )
		{
			CapexDA da = null;
			
			try
			{
				da = new CapexDA ();
				da.UpdateQuotationData(searchCondition);				
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]

		public void DeleteQuotationData (NameValueCollection searchCondition )
		{
			CapexDA da = null;
			
			try
			{
				da = new CapexDA ();
				da.DeleteQuotationData(searchCondition);				
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]

		public void InsertQuotationData (NameValueCollection searchCondition )
		{
			CapexDA da = null;
			
			try
			{
				da = new CapexDA ();
				da.InsertQuotationData(searchCondition);				
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]

		public void SaveCapexData( string CapexNo, string Flag, string UserID, string Description, string Vendor )
		{
			CapexDA da = null;
			
			try
			{
				da = new CapexDA ();
				da.SaveCapexData (CapexNo, Flag, UserID, Description, Vendor);			
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		[AutoComplete(true)]

		public void SaveMCapexNo( string CapexNo, string TicketNo, string Seq)
		{
			CapexDA da = null;
			
			try
			{
				da = new CapexDA ();
				da.SaveMCapexNo(CapexNo, TicketNo, Seq);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		[AutoComplete(true)]

		public void SaveCapexConfirmData( string CapexNo, string  MordNo, string  CheckNo,string   DemandDate,string   UserID)
		{
			CapexDA da = null;
			
			try
			{
				da = new CapexDA ();
				da.SaveCapexConfirmData(CapexNo, MordNo, CheckNo, DemandDate, UserID);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]

		public void InsertCapexDetail( string CapexNo, string Seq, string Model, string Qty , string Price, string LedgerEntry, string UserID)
		{
			CapexDA da = null;
			
			try
			{
				da = new CapexDA ();
				da.InsertCapexDetail(CapexNo, Seq, Model, Qty , Price, LedgerEntry, UserID);;			
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		[AutoComplete(true)]
		public void UpdateCapexDetail( string CapexNo, string Seq, string Model, string Qty , string Price, string LedgerEntry, string UserID)
		{
			CapexDA da = null;
			
			try
			{
				da = new CapexDA ();
				da.UpdateCapexDetail(CapexNo, Seq, Model, Qty , Price, LedgerEntry, UserID);		
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		[AutoComplete(true)]
		public void DeleteCapexDetail( string CapexNo, string Seq)
		{
			CapexDA da = null;
			
			try
			{
				da = new CapexDA ();
				da.DeleteCapexDetail(CapexNo, Seq);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}
		[AutoComplete(true)]

		public void ConfirmCSCCapexData( string CapexNo, string flag)
		{
			CapexDA da = null;
			
			try
			{
				da = new CapexDA ();
				da.ConfirmCSCCapexData (CapexNo,flag);			
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}






		#endregion
	}
}
