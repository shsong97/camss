using System;

using System.Data;
using System.EnterpriseServices;
using System.Collections.Specialized;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.CAPEX.DA;
using LGCNS.SITE.DTO;

namespace LGCNS.SITE.CAPEX.Biz
{
	/// <summary>
	/// CapexBizNTx�� ���� ��� �����Դϴ�.
	/// </summary>
	public class CapexBizNTx : LGCNS.LAF.Biz.BizNTxBase
	{
		public CapexBizNTx() {}

		#region QuotationHist 
		public CapexDS SelectQuotationHistData( int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			CapexDS ds = null;
			CapexDA da = null;

			try
			{
				da = new CapexDA();
				ds = da.SelectQuotationHistData(currentPage, pageSize, searchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}
		#endregion

		#region NO 
		public CapexDS SelectQuotationMaxNo( )
		{
			CapexDS ds = null;
			CapexDA da = null;

			try
			{
				da = new CapexDA();
				ds = da.SelectQuotationMaxNo();
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		[AutoComplete(true)]
		public CapexDS SelectQuotationNo ()
		{
			return SelectQuotationNo("");
		}

		[AutoComplete(true)]
		public CapexDS SelectQuotationNo (string args)
		{
			CapexDS ds = null;
			CapexDA da = null;
			
			try
			{
				da = new CapexDA();
				ds = da.SelectQuotationNo(args);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}

		#endregion


		#region Category 
		[AutoComplete(true)]
		public CapexDS SelectCategory ()
		{
			return SelectCategory("");
		}

		[AutoComplete(true)]
		public CapexDS SelectCategory (string args)
		{
			CapexDS ds = null;
			CapexDA da = null;
			
			try
			{
				da = new CapexDA();
				ds = da.SelectCategory(args);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}

		#endregion


		#region WBSE 
		[AutoComplete(true)]
		public CapexDS SelectWBSE ()
		{
			return SelectWBSE("");
		}

		[AutoComplete(true)]
		public CapexDS SelectWBSE (string args)
		{
			CapexDS ds = null;
			CapexDA da = null;
			
			try
			{
				da = new CapexDA();
				ds = da.SelectWBSE(args);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}

		#endregion

		#region Gubun 
		[AutoComplete(true)]
		public CapexDS SelectGubun ()
		{
			return SelectGubun("");
		}

		[AutoComplete(true)]
		public CapexDS SelectGubun (string args)
		{
			CapexDS ds = null;
			CapexDA da = null;
			
			try
			{
				da = new CapexDA();
				ds = da.SelectGubun(args);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}

		#endregion


		#region Capex Status  
		[AutoComplete(true)]
		public CapexDS SelectCapexStatus ()
		{
			return SelectCapexStatus("");
		}

		[AutoComplete(true)]
		public CapexDS SelectCapexStatus (string args)
		{
			CapexDS ds = null;
			CapexDA da = null;
			
			try
			{
				da = new CapexDA();
				ds = da.SelectCapexStatus(args);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}

		#endregion

		#region Quotation 
		public CapexDS SelectQuotationData( string QuotationNo  )
		{
			CapexDS ds = null;
			CapexDA da = null;

			try
			{
				da = new CapexDA();
				ds = da.SelectQuotationData(QuotationNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public CapexDS SelectOneQuotationData( string QuotaNo, string SPEC )
		{
			CapexDS ds = null;
			CapexDA da = null;

			try
			{
				da = new CapexDA();
				ds = da.SelectOneQuotationData (QuotaNo, SPEC);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public CapexDS SelectOneUpQuotationData( string QuotaNo, string SPEC )
		{
			CapexDS ds = null;
			CapexDA da = null;

			try
			{
				da = new CapexDA();
				ds = da.SelectOneUpQuotationData (QuotaNo, SPEC);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}
		
		#endregion



		#region Capex select 

		public CapexDS SelectCapexAutorityList( string Flag)
		{
			CapexDS ds = null;
			CapexDA da = null;

			try
			{
				da = new CapexDA();
				ds = da.SelectCapexAutorityList(Flag);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}
		
		public void CapexStatusChange(NameValueCollection searchCondition)
		{
			CapexDA da = null;

			try
			{
				da = new CapexDA();
				da.CapexStatusChange(searchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return;
		}
		public CapexDS SelectCapexStatusList(NameValueCollection searchCondition)
		{
			CapexDS ds = null;
			CapexDA da = null;

			try
			{
				da = new CapexDA();
				ds = da.SelectCapexStatusList(searchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public CapexDS SelectCapexDataList(string Flag1,  string Flag, int currentPage, int pageSize, NameValueCollection searchCondition )
		{
			CapexDS ds = null;
			CapexDA da = null;

			try
			{
				da = new CapexDA();
				if (Flag1 == "A")
				{
					ds = da.SelectCapexDataList(Flag1, Flag, currentPage, pageSize, searchCondition);
				}
				else
				{
					ds = da.SelectCapexDataList1(Flag1, Flag, currentPage, pageSize, searchCondition);
				}
				
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public CapexDS SelectCapexDataListXls( NameValueCollection searchCondition )
		{
			CapexDS ds = null;
			CapexDA da = null;

			try
			{
				da = new CapexDA();
				ds = da.SelectCapexDataListXls(searchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}


		public CapexDS SelectCapexMast( string TicketNo , string CapexNo)
		{
			CapexDS ds = null;
			CapexDA da = null;

			try
			{
				da = new CapexDA();
				ds = da.SelectCapexMast( TicketNo, CapexNo );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}


		public CapexDS SelectCapexDes( string CapexNo)
		{
			CapexDS ds = null;
			CapexDA da = null;

			try
			{
				da = new CapexDA();
				ds = da.SelectCapexDes( CapexNo );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		#endregion

		#region Ticket
		public TicketDS SelectTicket(string ticketNo)
		{
			TicketDS ds = null;
			CapexDA da = null;

			try
			{
				da = new CapexDA();
				ds = da.SelectTicket(ticketNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}


		#endregion

		#region Model , LegerEntry

		[AutoComplete(true)]
		public CapexDS SelectModel ()
		{
			return SelectModel("");
		}

		[AutoComplete(true)]
		public CapexDS SelectModel (string args)
		{
			CapexDS ds = null;
			CapexDA da = null;
			
			try
			{
				da = new CapexDA();
				ds = da.SelectModel(args);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}


		[AutoComplete(true)]
		public CapexDS SelectLedgerEntrylList ()
		{
			return SelectLedgerEntrylList("");
		}

		[AutoComplete(true)]
		public CapexDS SelectLedgerEntrylList (string args)
		{
			CapexDS ds = null;
			CapexDA da = null;
			
			try
			{
				da = new CapexDA();
				ds = da.SelectLedgerEntrylList(args);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}


		public string SelectPrice(string Model)
		{
			CapexDA da = null;
			string ResultStatement = "";
			
			try
			{
				da = new CapexDA ();
				ResultStatement = da.SelectPrice(Model);				
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ResultStatement;
		}



		[AutoComplete(true)]
		public CapexDS SelectAuthority ( string CapexNo, string UserID)
		{
			CapexDS ds = null;
			CapexDA da = null;
			
			try
			{
				da = new CapexDA();
				ds = da.SelectAuthority(CapexNo, UserID);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}






		#endregion
	}
}
