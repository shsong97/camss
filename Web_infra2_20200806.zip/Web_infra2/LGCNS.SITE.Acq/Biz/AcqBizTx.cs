using System;
using System.EnterpriseServices;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.DTO;
using LGCNS.SITE.Acq.DA;

namespace LGCNS.SITE.Acq.Biz
{
	/// <summary>
	/// AcqBizTx�� ���� ��� �����Դϴ�.
	/// </summary>
	public class AcqBizTx : LGCNS.LAF.Biz.BizTxBase
	{
		public AcqBizTx()
		{

		}
		#region ManageAcq

		[AutoComplete(true)]
		public void InsertAcq(AcqDS ds)
		{
			AcqDA da = null;
			
			try
			{
				da = new AcqDA ();
				da.InsertAcq(ds);		
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		[AutoComplete(true)]
		public void UpdateAcq(AcqDS ds)
		{
			AcqDA da = null;
	
			try
			{
				da = new AcqDA();
				da.UpdateAcq(ds);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}

		
		[AutoComplete(true)]
		public void DeleteAcq( string TicketNo )
		{
			AcqDA da = null;
			
			try
			{
				da = new AcqDA();
				da.DeleteAcq( TicketNo );
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}
		}


		#endregion




	}
}
