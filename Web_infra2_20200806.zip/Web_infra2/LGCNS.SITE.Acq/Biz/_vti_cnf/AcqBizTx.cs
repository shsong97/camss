vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|07 Mar 2005 03:15:12 -0000
vti_extenderversion:SR|4.0.2.8912
vti_cacheddtm:TX|07 Mar 2005 03:15:12 -0000
vti_filesize:IR|1482
