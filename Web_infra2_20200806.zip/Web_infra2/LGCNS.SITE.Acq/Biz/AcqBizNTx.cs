using System;
using System.EnterpriseServices;
using System.Collections.Specialized;

using LGCNS.LAF.Common.Exceptions;

using LGCNS.SITE.DTO;
using LGCNS.SITE.Acq.DA;

namespace LGCNS.SITE.Acq.Biz
{
	/// <summary>
	/// AcqBizNTx�� ���� ��� �����Դϴ�.
	/// </summary>
	public class AcqBizNTx : LGCNS.LAF.Biz.BizNTxBase
	{
		public AcqBizNTx() {}

		public AcqDS SelectAcq( string TicketNo )
		{
			AcqDA da = null;
			AcqDS ds = null;

			try
			{
				da = new AcqDA ();
				ds = da.SelectAcq(TicketNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public AcqDS SelectAcqPrint( string TicketNo )
		{
			AcqDA da = null;
			AcqDS ds = null;

			try
			{
				da = new AcqDA ();
				ds = da.SelectAcqPrint(TicketNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		public AcqDS SelectAcqList( NameValueCollection SearchCondition )
		{
			return SelectAcqList( 0, 0, SearchCondition );
		}

		public AcqDS SelectAcqList( int currentPage, int pageSize, NameValueCollection SearchCondition )
		{
			AcqDA da = null;
			AcqDS ds = null;

			try
			{
				da = new AcqDA ();
				ds = da.SelectAcqList( currentPage, pageSize, SearchCondition);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}

		[AutoComplete(true)]
		public CapexDS SelectLedgerEntrylList ()
		{
			return SelectLedgerEntrylList("");
		}

		[AutoComplete(true)]
		public CapexDS SelectLedgerEntrylList (string args)
		{
			CapexDS ds = null;
			AcqDA da = null;
			
			try
			{
				da = new AcqDA();
				ds = da.SelectLedgerEntrylList(args);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex);
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds ;
		}

		#region Capex
		public TicketDS SelectMailCapex( )
		{
			TicketDS ds = null;
			AcqDA da = null;

			try
			{
				da = new AcqDA();
				ds = da.SelectMailCapex();
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}
	


		#endregion

		#region Ticket

		public TicketDS SelectTicketAcq( string TicketNo )
		{
			AcqDA da = null;
			TicketDS ds = null;

			try
			{
				da = new AcqDA ();
				ds = da.SelectTicketAcq(TicketNo);
			}
			catch(Exception ex)
			{
				throw new BizException(ex.Message, ex) ;
			}
			finally
			{
				if(da != null)
				{
					da.Dispose();
					da = null;
				}
			}

			return ds;
		}
	


		#endregion
	}
}
