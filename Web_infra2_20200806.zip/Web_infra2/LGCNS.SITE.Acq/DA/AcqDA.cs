using System;
using System.Collections.Specialized;
using System.EnterpriseServices;

//using LGCNS.LAF.DA;
//using LGCNS.LAF.Common.Exceptions;
using LGCNS.LAF.Common.Paging;
using LGCNS.LAF.Common.DataAccess;
//using LGCNS.LAF.Common.Paging ;

using LGCNS.SITE.DTO;

namespace LGCNS.SITE.Acq.DA
{
	/// <summary>
	/// AcqDA�� ���� ��� �����Դϴ�.
	/// </summary>
	public class AcqDA : LGCNS.LAF.DA.DABase
	{
		private const string PROJECT_NAME	= "LGCNS.SITE.Acq" ;
		private const string CLASS_NAME		= "LGCNS.SITE.Acq.DA.AcqDA" ;

		public AcqDA() {}

		#region ManageAcq

		[AutoComplete(true)]
		public void InsertAcq (AcqDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertAcq", ds.TB_ACQ) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_ACQ[0]) ;

			for( int inx = 0; inx < ds.TB_ACQ_DETAIL.Count; inx++ )
			{
				InsertAcqDetail( ds.TB_ACQ_DETAIL[inx] );
			}
		}


		[AutoComplete(true)]
		public void UpdateAcq (AcqDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateAcq", ds.TB_ACQ) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_ACQ[0]) ;

			for( int inx = 0; inx < ds.TB_ACQ_DETAIL.Count; inx++ )
			{
				UpdateAcqDetail( ds.TB_ACQ_DETAIL[inx] );
			}
		}


		[AutoComplete(true)]
		public void DeleteAcq (string TicketNo)
		{
			AcqDS ds = new AcqDS();

			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"]	= TicketNo;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteAcq", ds.TB_ACQ) ;
			
			DeleteAcqDetail( TicketNo );
			ADOHelper.ExecuteNonQuery (ps, dc) ;
			
			ds.Dispose();
		}

		#endregion

		#region ManageAcqDetail

		[AutoComplete(true)]
		public void InsertAcqDetail (AcqDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertAcqDetail", ds.TB_ACQ_DETAIL) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_ACQ_DETAIL[0]) ;
		}

		[AutoComplete(true)]
		public void InsertAcqDetail(AcqDS.TB_ACQ_DETAILRow dr)
		{
			AcqDS ds = new AcqDS();
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "InsertAcqDetail", ds.TB_ACQ_DETAIL) ;
			ADOHelper.ExecuteNonQuery (ps, dr) ;

			ds.Dispose();
		}


		[AutoComplete(true)]
		public void UpdateAcqDetail (AcqDS ds)
		{
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateAcqDetail", ds.TB_ACQ_DETAIL) ;
			ADOHelper.ExecuteNonQuery (ps, ds.TB_ACQ_DETAIL[0]) ;
		}

		[AutoComplete(true)]
		public void UpdateAcqDetail(AcqDS.TB_ACQ_DETAILRow dr)
		{
			AcqDS ds = new AcqDS();
			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "UpdateAcqDetail", ds.TB_ACQ_DETAIL) ;
			ADOHelper.ExecuteNonQuery (ps, dr) ;
			ds.Dispose();
		}


		[AutoComplete(true)]
		public void DeleteAcqDetail (string TicketNo, string Seq)
		{
			AcqDS ds = new AcqDS();

			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"]	= TicketNo;
			dc["Seq"]	= Seq;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteAcqDetail", ds.TB_ACQ_DETAIL) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;

			ds.Dispose();
		}

		[AutoComplete(true)]
		public void DeleteAcqDetail (string TicketNo)
		{
			AcqDS ds = new AcqDS();

			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"]	= TicketNo;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "DeleteAcqDetail", ds.TB_ACQ_DETAIL) ;
			ADOHelper.ExecuteNonQuery (ps, dc) ;

			ds.Dispose();
		}

		#endregion

		#region SelectAcq

		[AutoComplete(true)]
		public AcqDS SelectAcq( string TicketNo )
		{
			AcqDS ds = new AcqDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"]	= TicketNo ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectAcq", ds.TB_ACQ) ;
			ADOHelper.FillDataSet (ps, ds, new string[] {"TB_ACQ", "TB_ACQ_DETAIL", "TB_TICKET"}, dc) ;

			return ds;
		}

		[AutoComplete(true)]
		public AcqDS SelectAcqPrint( string TicketNo )
		{
			AcqDS ds = new AcqDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"]	= TicketNo ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectAcqPrint", ds.TB_ACQ) ;
			ADOHelper.FillDataSet (ps, ds, new string[] {"TB_ACQ", "TB_ACQ_DETAIL", "TB_TICKET"}, dc) ;

			return ds;
		}

		public AcqDS SelectAcqList( int currentPage, int pageSize, NameValueCollection SearchCondition )
		{
			AcqDS ds = new AcqDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["Area"]	= SearchCondition["Area"];
			dc["TicketNo"]	= SearchCondition["TicketNo"];
			dc["EmpNo"]	= SearchCondition["EmpNo"];
			dc["EmpName"]	= SearchCondition["EmpName"];
			dc["CreateDateFrom"]	= SearchCondition["CreateDateFrom"];
			dc["CreateDateTo"]	= SearchCondition["CreateDateTo"];
			dc["ConfirmDateFrom"]	= SearchCondition["ConfirmDateFrom"];
			dc["ConfirmDateTo"]	= SearchCondition["ConfirmDateTo"];
			dc["ConfirmFlag"]	= SearchCondition["ConfirmFlag"];
			dc["VendorDesc"]	= SearchCondition["VendorDesc"];

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectAcqList") ;
			ADOHelper.FillDataSet (ps, ds, "TB_ACQ_LIST", currentPage, pageSize, dc) ;

			if( pageSize > 0 )
			{
				int totalCount = Convert.ToInt32 (ps.DataParameters ["@TotalCount"].Value) ;
				PagingHelper.SetPagingInfo (ds, totalCount, currentPage, pageSize) ;
			}

			return ds;
		}

		#endregion




		#region Capex
		[AutoComplete(true)]
		public TicketDS SelectMailCapex( )
		{
			LDataCollection dc = new LDataCollection () ;

			TicketDS ds = new TicketDS();
			ds.EnforceConstraints = false;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectMailCapex") ;
			ADOHelper.FillDataSet (ps, ds, new string [] {"TB_BASE_MAIL"}, dc) ;

			return ds ;
		}

		[AutoComplete(true)]
		public CapexDS SelectLedgerEntrylList()
		{
			return SelectLedgerEntrylList("") ;
		}

		[AutoComplete(true)]
		public CapexDS SelectLedgerEntrylList(string args)
		{
			CapexDS ds = new CapexDS () ;
			
			LDataCollection dc = new LDataCollection () ;
			dc["args"]	= args ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectLedgerEntrylList", ds.TB_BASE) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_BASE"}, dc ) ;

			return ds ;
		}
		#endregion



		#region Ticket
		[AutoComplete(true)]
		public TicketDS SelectTicketAcq( string TicketNo )
		{
			TicketDS ds = new TicketDS () ;
			ds.EnforceConstraints = false;

			LDataCollection dc = new LDataCollection () ;
			dc["TicketNo"]	= TicketNo ;

			LPreparedStatement ps = LPreparedStatementFactory.Create (PROJECT_NAME, CLASS_NAME, "SelectTicketAcq", ds.TB_TICKET_MAIL) ;
			ADOHelper.FillDataSet( ps, ds, new string [] {"TB_TICKET_MAIL"}, dc ) ;

			return ds;
		}


		#endregion


	}
}
